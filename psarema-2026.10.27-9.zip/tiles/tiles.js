window.PSAREMA_TILES = {
  "url": "tiles/{z}/{x}/{y}.jpg",
  "minZoom": 7,
  "maxZoom": 12,
  "bounds": [
    [
      34.25,
      31.85
    ],
    [
      35.85,
      34.75
    ]
  ],
  "coastalOnlyFrom": null,
  "attribution": "EOxCloudless <a href=\"https://cloudless.eox.at\">https://cloudless.eox.at</a> by EOX IT Services GmbH (Contains modified Copernicus Sentinel data 2016)",
  "license": "CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/) - EOX Sentinel-2 cloudless 2016 layer s2cloudless_3857; tiles recompressed to JPEG q78",
  "sizeMB": 3.6
};
