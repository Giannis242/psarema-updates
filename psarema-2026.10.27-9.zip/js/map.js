'use strict';
// Psarema: the Leaflet map, its layers and the score image.
/* ---------- Map ---------- */
const map = L.map('map', { preferCanvas: true, zoomControl: false, maxBounds: L.latLngBounds(VIEW).pad(.25), maxBoundsViscosity: 1, zoomSnap: .5, maxZoom: 17 })
  .setView([35.05, 33.3], 9);
let fitted = false;
const COAST = [[34.56, 32.27], [35.71, 34.61]]; // the island itself (data/coast.js): phones fit it, as VIEW's sea margins cost a small screen too much
function fitView() {
  const phone = isPhone(), s = map.getSize(), pad = phone && (window.PsMobile?.fitPad() || s.x < s.y && [[0, 70], [0, 190]]), b = phone ? COAST : VIEW;
  if (phone && !pad) return; // before js/mobile.js a phone on its side waits for it: the portrait guess gave zoom 6.5, wider than maxBounds, and the map slid 200 px before the real fit
  const [tl, br] = !phone ? [[350, 60], [10, 10]] // the coast clear of the panel
    : pad.map(p => L.point(p).add([8, 8])); // phones: between the top bar and the sheet (js/mobile.js), 8 px clear
  const room = s.subtract(L.point(tl).add(br));
  if (room.x < 50 || room.y < 50) return; // no size yet (a page opened in a hidden tab), or the phone layout not in place yet: a later call fits
  const whole = !fitted || map.getZoom() <= map.getMinZoom(); // first fit, or still showing the whole island
  if (map._panAnim?._inProgress) { // a rotation's pan back inside the new maxBounds (js/mobile.js)
    if (!whole) { map.once('moveend', () => requestAnimationFrame(fitView)); return; } // a new floor's zoom would cut it short: after it
    // the fit replaces it (waiting showed a 250 ms slide, then a jump); its last 'moveend' must not start it again
    map.off('moveend', map._panInsideMaxBounds); map._panAnim.stop(); map.on('moveend', map._panInsideMaxBounds);
  }
  fitted = true;
  map.options.minZoom = 0; // getBoundsZoom never answers below the current floor: without this the floor could only rise (turned on its side, a phone kept the portrait zoom)
  const z = map.getBoundsZoom(b, false, L.point(tl).add(br)); // after a rotation or resize the floor follows the new size
  if (whole) map.fitBounds(b, { paddingTopLeft: tl, paddingBottomRight: br, animate: false });
  map.setMinZoom(z); // after the fit: raised first, it starts an animated zoom that swallows the fit
}
fitView();
map.on('resize', () => requestAnimationFrame(fitView)); // a frame later: js/mobile.js re-measures its sheet after a rotation in the same frame
addEventListener('DOMContentLoaded', fitView); // again once js/mobile.js has measured the sheet: the map may not change size when it does
new ResizeObserver(() => map.invalidateSize()).observe(map.getContainer()); // a map that starts hidden or unsized fits once it has a size
const zoomCtl = L.control.zoom({ position: 'bottomright' }).addTo(map);
{ // no "Leaflet" link; the data credits (a licence condition) fold into a small (i) button that opens on tap
  map.attributionControl.setPrefix(false);
  const a = map.attributionControl.getContainer(); a.classList.add('folded'); a.title = tr('credits');
  L.DomEvent.on(a, 'click', e => { if (a.classList.contains('folded')) L.DomEvent.preventDefault(e); a.classList.toggle('folded'); });
}
const LocateCtl = L.Control.extend({ options: { position: 'bottomright' }, onAdd() {
  const box = L.DomUtil.create('div', 'leaflet-bar locate'), a = L.DomUtil.create('a', '', box);
  a.href = '#'; a.innerHTML = ic('my-location') || '◎'; a.setAttribute('role', 'button');
  L.DomEvent.on(a, 'click', e => { L.DomEvent.preventDefault(e); L.DomEvent.stopPropagation(e); locateMe(); });
  this._a = a; return box;
} });
const locateCtl = new LocateCtl().addTo(map);
// Leaflet keeps each pane's canvas once made, empty or not: each is a GPU layer 1.2× the screen (2× pixels on phones), re-sized, cleared
// and composited at every move. One goes once its last shape does (contours and spots below their zoom, zones, a cleared ring);
// map.getRenderer puts it back with the next shape. A frame later: a clear-and-redraw keeps its canvas, and the redraw a removal asks for
// has run (Leaflet 1.9.4 leaves it pending after a moveend's own redraw: removed sooner, the renderer drew with no canvas, a TypeError).
map.on('layerremove', ({ layer: { _renderer: r } }) => {
  if (!r || r._dropCheck) return;
  r._dropCheck = requestAnimationFrame(() => {
    r._dropCheck = 0;
    if (!map.hasLayer(r) || Object.keys(r._layers).length) return;
    map.removeLayer(r); r._redrawRequest = null; // Leaflet cancels that frame but keeps its id: back on the map, the renderer never asked for another
  });
});
for (const [name, z] of [['heat', 410], ['zones', 415], ['contours', 420], ['prot', 425], ['sight', 428], ['spots', 430], ['labels', 640], ['mask', 650]]) map.createPane(name).style.zIndex = z;
for (const p of ['labels', 'mask', 'zones']) map.getPane(p).style.pointerEvents = 'none';
// Tiles load half a screen beyond the view, so dragging uncovers imagery that is already there.
const PaddedTiles = L.TileLayer.extend({
  _getTiledPixelBounds(center) { const b = L.TileLayer.prototype._getTiledPixelBounds.call(this, center), pad = b.getSize().divideBy(2); return L.bounds(b.min.subtract(pad), b.max.add(pad)); },
});
const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/', TILE_BOUNDS = L.latLngBounds(VIEW).pad(.1);
const tileOpts = { maxZoom: 17, maxNativeZoom: 17, bounds: TILE_BOUNDS, keepBuffer: 6, updateWhenIdle: false, updateWhenZooming: false };
const DATA_ATTR = 'EMODnet &middot; Copernicus Marine &middot; <a href="https://open-meteo.com/">Open-Meteo</a> &middot; GBIF/OBIS &middot; &copy; OpenStreetMap';
const LOCAL_TILES = window.PSAREMA_TILES, BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACw=';
if (LOCAL_TILES) { // the island's imagery is stored with the app, so it is there at once; sharper online imagery only beyond it
  // Padded too: zooming out, the old level's margin covers the wider view (and the online layer dropping out) until the new tiles arrive, instead of a dark ring.
  // The minZooms sit half a step early: Leaflet picks tiles at the rounded zoom but drops them all below minZoom, so with an integer floor
  // the half step under it (zoomSnap .5) fetched the layer's tiles and threw them away on every move: flashing squares, ~50 requests a pan.
  const full = LOCAL_TILES.coastalOnlyFrom ? LOCAL_TILES.coastalOnlyFrom - 1 : LOCAL_TILES.maxZoom;
  // Their bounds are the stored area's (tiles.js): TILE_BOUNDS reaches past it, and the ring of tiles in between were 404s.
  new PaddedTiles(LOCAL_TILES.url, { maxZoom: 17, minNativeZoom: LOCAL_TILES.minZoom, maxNativeZoom: full, bounds: LOCAL_TILES.bounds, keepBuffer: 10, updateWhenIdle: false,
    errorTileUrl: BLANK, attribution: `${LOCAL_TILES.attribution} &middot; ${DATA_ATTR}` }).addTo(map);
  if (LOCAL_TILES.coastalOnlyFrom) new PaddedTiles(LOCAL_TILES.url, { minZoom: LOCAL_TILES.coastalOnlyFrom - .5, maxZoom: 17, minNativeZoom: LOCAL_TILES.coastalOnlyFrom,
    maxNativeZoom: LOCAL_TILES.maxZoom, bounds: LOCAL_TILES.bounds, keepBuffer: 10, updateWhenIdle: false, errorTileUrl: BLANK }).addTo(map);
  new PaddedTiles(ESRI + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', { ...tileOpts, minZoom: LOCAL_TILES.maxZoom + .5, attribution: 'Esri, Maxar, Earthstar Geographics' }).addTo(map);
} else new PaddedTiles(ESRI + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', { ...tileOpts, attribution: `Imagery &copy; Esri, Maxar, Earthstar Geographics &middot; ${DATA_ATTR}` }).addTo(map);
// Place names only, grey with a dark halo (Esri's reference for dark maps): Boundaries_and_Places drew every community's border in white
// over the land, a web of lines from zoom 10. It holds Cyprus to zoom 14 (empty tiles past it); one step bigger at 15, then none.
const labels = new PaddedTiles(ESRI + 'Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', { ...tileOpts, maxZoom: 15, maxNativeZoom: 14, pane: 'labels', attribution: 'Esri, HERE, Garmin' });
// Preload: once the map rests, the next zoom level in and out of what is on screen goes into the browser's cache, so a pinch or a
// double tap shows imagery at once instead of blank squares. Each tile is asked for once; idle time only, and not when offline.
{
  const asked = new Set(); let t = 0;
  const preload = () => {
    if (navigator.onLine === false) return;
    const z = map.getZoom(), v = map.getPixelBounds();
    map.eachLayer(l => {
      // online layers only: the stored tiles are there at once (padded, they also cover a zoom out), so asking scoreAhead only cost requests
      if (!(l instanceof L.TileLayer) || !l._url || l._url === LOCAL_TILES?.url || !l.options.bounds) return;
      const o = l.options, lb = L.latLngBounds(o.bounds), tb = L.bounds(map.project(lb.getNorthWest(), z), map.project(lb.getSouthEast(), z));
      // only the view inside the layer's bounds, as Leaflet asks: beyond them were 404s (local) and labels under the mask, 7× the tiles on screen at startup
      const x0 = Math.max(v.min.x, tb.min.x), y0 = Math.max(v.min.y, tb.min.y), x1 = Math.min(v.max.x, tb.max.x), y1 = Math.min(v.max.y, tb.max.y);
      if (x0 > x1 || y0 > y1) return;
      for (const dz of [1, -1]) {
        const z2 = Math.round(z) + dz; if (z2 < (o.minZoom ?? 0) || z2 > o.maxZoom) continue;
        const nz = Math.max(o.minNativeZoom ?? 0, Math.min(o.maxNativeZoom ?? z2, z2)), s = map.getZoomScale(nz, z) / 256; // the zoom its tiles exist at
        for (let x = Math.floor(x0 * s); x <= Math.floor(x1 * s); x++) for (let y = Math.floor(y0 * s); y <= Math.floor(y1 * s); y++) {
          const url = L.Util.template(l._url, { ...o, x, y, z: nz }); if (asked.has(url)) continue;
          asked.add(url); new Image().src = url;
        }
      }
    });
  };
  map.on('moveend', () => { clearTimeout(t); t = setTimeout(() => (window.requestIdleCallback || setTimeout)(preload), 600); });
}
{ // everything outside the island's waters (e.g. the mainland on large low-zoom tiles) goes dark
  const v = L.latLngBounds(VIEW).pad(.04), [s, w, n, e] = [v.getSouth(), v.getWest(), v.getNorth(), v.getEast()];
  // SVG, not canvas: a flat fill around a rectangle draws as solid-colour and empty tiles that need no GPU memory, where a canvas
  // was one more full-screen texture (2× pixels on phones) blended at every frame
  // Its colour is css/map-fx.css's --mask (the graded open sea), over the fill given here and the one js/mobile.js sets on phones
  L.polygon([[[20, 20], [20, 50], [50, 50], [50, 20]], [[s, w], [n, w], [n, e], [s, e]]], { pane: 'mask', renderer: L.svg({ pane: 'mask' }), interactive: false, stroke: false, fillColor: '#05080b', fillOpacity: 1, className: 'ps-mask' }).addTo(map);
  // Its edge, and the heat's at the grid's (just inside), fade into it over ~6% of the box: the chart sinks into the sea instead of ending
  // in a hard rectangle (a phone shows all four sides at the start). Static vector, drawn with the mask; 6% keeps Cape Andreas clear.
  const fade = (id, v) => `<linearGradient id="${id}"${v ? ' x2="0" y2="1"' : ''}>${[[0, 1], [.3, .72], [.6, .3], [1, 0]].map(([o, a]) => `<stop offset="${o}" style="stop-color:var(--mask,#05080b)" stop-opacity="${a}"/>`).join('')}</linearGradient>`;
  const svg = L.SVG.create('svg'); svg.setAttribute('viewBox', '0 0 100 100'); svg.setAttribute('preserveAspectRatio', 'none');
  svg.innerHTML = `<defs>${fade('fe-x')}${fade('fe-y', 1)}</defs><g fill="url(#fe-x)"><rect width="6" height="100"/><rect width="6" height="100" transform="matrix(-1 0 0 1 100 0)"/></g>` +
    `<g fill="url(#fe-y)"><rect width="100" height="8"/><rect width="100" height="8" transform="matrix(1 0 0 -1 0 100)"/></g>`;
  L.svgOverlay(svg, v, { pane: 'mask', interactive: false }).addTo(map);
}
// The heat image: two layers in one box (L.SVGOverlay places any element over the bounds, as an image overlay does), repainted in place
// (paint), so a settled change cross-fades from the old picture to the new (css/map-fx.css) and scrubbing swaps at once. Each layer is a
// coarse canvas (the whole grid: a pixel a cell, zoomed out one per 2r×2r cells) and, zoomed in, a fine one over the view (paintFine).
// willReadFrequently keeps them plain (CPU) canvases, drawn like images: a GPU canvas is a texture layer of its own, and the shoreline
// clip-path on it then became a mask and an offscreen pass every frame anything on screen hourMoved. Here the clip is drawn in once per zoom.
const heatBox = L.DomUtil.create('div', 'heat-box');
const heatLayers = [0, 1].map(n => {
  const el = L.DomUtil.create('div', 'heat-layer', heatBox), c = L.DomUtil.create('canvas', '', el), fine = L.DomUtil.create('canvas', '', el);
  el.style.cssText = 'position:absolute;inset:0' + (n ? ';opacity:0;visibility:hidden' : ''); // layout inline: without css/map-fx.css only the fade is lost
  for (const e of [c, fine]) e.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%';
  c.width = W; c.height = H; fine.style.display = 'none';
  return { el, ctx: c.getContext('2d', { willReadFrequently: true }), fine, fctx: fine.getContext('2d', { willReadFrequently: true }), cut: null };
});
let liveLayer = 0; // the layer on show
const heat = L.svgOverlay(heatBox, GRID_BOUNDS, { pane: 'heat', interactive: false });
// The clip below trims the heat at the water's edge (and the north's line): the spread (zoomed out) may then run onto the land, and over the line
const CLIP = !!window.PSAREMA_COAST, NCLIP = CLIP && !!NORTH_AREA?.outline;
if (CLIP) { // clip the heat at the real shoreline (data/coast.js): 250 m cells would otherwise spill onto beaches and rocks
  const m = d => Math.log(Math.tan(Math.PI / 4 + d * Math.PI / 360)), mN = m(NORTH), mS = m(NORTH - H * RES); // the image is stretched in Mercator
  const fx = lo => ((lo - WEST) / (W * RES)).toFixed(5), fy = la => ((mN - m(la)) / (mN - mS)).toFixed(5);
  let d = 'M0 0H1V1H0Z', n = d; // the sea = the whole image minus every land ring (even-odd); n: minus the north's area, which has no data
  for (const r of PSAREMA_COAST) { d += 'M'; for (let k = 0; k < r.length; k += 2) d += `${k ? 'L' : ''}${fx(r[k + 1])} ${fy(r[k])}`; d += 'Z'; }
  for (const r of NORTH_AREA?.outline || []) n += 'M' + r.map(([la, lo]) => `${fx(lo)} ${fy(la)}`).join('L') + 'Z';
  // The north's line too, so the heat (spread over it zoomed out: NCLIP) ends there crisply: the clip of a clip is their intersection
  document.body.insertAdjacentHTML('beforeend', `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><clipPath id="south-clip" clipPathUnits="objectBoundingBox"><path clip-rule="evenodd" d="${n}"/></clipPath>` +
    `<clipPath id="sea-clip" clipPathUnits="objectBoundingBox"${NCLIP ? ' clip-path="url(#south-clip)"' : ''}><path clip-rule="evenodd" d="${d}"/></clipPath></svg>`);
  heat.on('add', () => { heat.getElement().style.clipPath = 'url(#sea-clip)'; });
}
const pins = L.layerGroup(), zones = L.layerGroup(), zoneRenderer = L.canvas({ pane: 'zones' });
const spotRenderer = L.canvas({ pane: 'spots', tolerance: 4 }), sightLayer = L.layerGroup(), sightRenderer = L.canvas({ pane: 'sight' });
const spotLayers = { fishing: L.layerGroup(), structure: L.layerGroup(), access: L.layerGroup(), beach: L.layerGroup() };
const px = new Uint8ClampedArray(N * 4), px32 = new Uint32Array(px.buffer), heatData = new ImageData(px, W, H); // the heat image: RGBA, rows top-down (heatData shares px)

for (const s of SPOTS) {
  const [name, t, la, lo] = s, g = SPOT_GROUP[t]; if (!g) continue;
  L.circleMarker([la, lo], { renderer: spotRenderer, radius: g === 'fishing' ? 4.5 : g === 'beach' ? 3 : 3.5, weight: 1, color: '#05080b',
    fillColor: GROUP_COLOR[g], fillOpacity: g === 'beach' ? .75 : .95, bubblingMouseEvents: false })
    .bindTooltip(() => esc(name || tr('spot')[t]), { direction: 'top', offset: [0, -4] })
    .on('click', () => openSpot(s))
    .addTo(spotLayers[g]);
}
for (const g in spotCount) $('#n-' + g).textContent = spotCount[g].toLocaleString();

const protLayer = L.layerGroup();
let protCount = 0;
for (const z of PROT?.zones || []) {
  const r0 = z.rings[0], c = r0.reduce((a, p) => [a[0] + p[0] / r0.length, a[1] + p[1] / r0.length], [0, 0]);
  if (inNorth(...c)) continue; // the north has no data
  protCount++;
  const [weight, opacity, fillOpacity] = { 'no-take': [1.6, .95, .42], restricted: [1.3, .8, .22] }[z.kind] || [1, .5, 0]; // white dashes on darkened water, unlike the warm best-area outlines
  L.polygon(z.rings, { pane: 'prot', color: '#fff', weight, opacity, dashArray: '5 4', fillColor: '#000', fillOpacity })
    .bindTooltip(() => `<b>${esc(zoneName(z))}</b><br>${esc(tr('kind')[z.kind])}: ${esc(zoneRules(z))}`, { sticky: true }).addTo(protLayer);
}
$('#n-protected').textContent = PROT ? String(protCount) : '–';

// Each fish's markers are made once (All fish: ~1,500, ~12 ms) and kept; a method change leaves the set on the map as it is.
const sightSets = new Map(); let sightOn = null;
function drawSightings() { // recorded sightings of the selected fish; All fish: every fish's, drawn lighter
  if (sightOn === sp.id) return;
  sightLayer.clearLayers(); sightOn = sp.id;
  let set = sightSets.get(sp.id);
  if (!set) {
    const all = !!sp.all, pts = [];
    for (const id of all ? Object.keys(SIGHT) : [sp.id]) { const s = all ? byId(id) : sp; if (s) for (const r of SIGHT[id] || []) if (!inNorth(r[0], r[1])) pts.push([r, s]); }
    sightSets.set(sp.id, set = pts.map(([[la, lo, yr], s]) => L.circleMarker([la, lo], { renderer: sightRenderer, pane: 'sight', radius: all ? 2 : 3, stroke: !all, weight: 1,
      color: '#05080b', fillColor: '#5ee0b0', fillOpacity: all ? .55 : .9 }).bindTooltip(() => `${esc(fishName(s))}${yr ? ` · ${yr}` : ''}`, { direction: 'top' })));
  }
  $('#n-sightings').textContent = window.PSAREMA_SIGHTINGS ? String(set.length) : '–';
  for (const m of set) sightLayer.addLayer(m);
}

let contours = null;
function buildContours() {
  const levels = [20, 50, 100, 200, 500, 1000], style = { 20: [.35, .7], 50: [.4, .8], 100: [.5, .9], 200: [.85, 1.4], 500: [.45, .9], 1000: [.35, .9] };
  const renderer = L.canvas({ pane: 'contours' }), masked = Uint16Array.from(depth, (d, i) => northMask[i] ? 0 : d);
  contours = L.layerGroup();
  for (const g of d3.contours().size([W, H]).thresholds(levels)(masked)) {
    const [op, wt] = style[g.value];
    const add = seg => seg.length >= 12 && L.polyline(seg, { pane: 'contours', renderer, color: g.value === 200 ? '#7fd6ff' : '#cfe9f5',
      opacity: op, weight: wt, interactive: true, smoothFactor: 1 }).bindTooltip(`${g.value} m`, { sticky: true }).addTo(contours);
    for (const poly of g.coordinates) for (const ring of poly) {
      let seg = []; // d3 closes rings along the grid edge and the north; drop those runs so no frame is drawn
      for (const [x, y] of ring) {
        const j = idxAt(NORTH - y * RES, WEST + x * RES);
        if (x < .6 || y < .6 || x > W - .6 || y > H - .6 || (j >= 0 && northMask[j])) { add(seg); seg = []; }
        else seg.push([NORTH - y * RES, WEST + x * RES]);
      }
      add(seg);
    }
  }
}

/* ---------- Rendering ---------- */
const LUT = new Uint8ClampedArray(101 * 4), LUT32 = new Uint32Array(LUT.buffer); // LUT32: the same bytes, one pixel per entry
// Contour bands (a layer option): each score drawn in its 10-point band's middle colour (40–49 as 45), so the chance reads as iso-bands
const BAND = Uint8Array.from({ length: 101 }, (_, s) => Math.min(100, s - s % 10 + 5)), LUTB = new Uint8ClampedArray(101 * 4), LUTB32 = new Uint32Array(LUTB.buffer);
const ON = new Uint8Array(101); // 1 where a score shows (paintFine interpolates between those only)
function buildLut() {
  for (let s = 0; s <= 100; s++) LUT.set(s < state.min ? [0, 0, 0, 0] : heatRgba(s), s * 4);
  for (let s = 0; s <= 100; s++) { LUTB32[s] = s < state.min ? 0 : LUT32[BAND[s]]; ON[s] = LUT[s * 4 + 3] ? 1 : 0; }
}
console.assert(BAND[40] === 45 && BAND[49] === 45 && BAND[100] === 100, 'bands');
{ // the Contour bands option, under Fishing chance in Layers (an option of that layer, so not counted as a layer of its own)
  const row = L.DomUtil.create('div', 'lp-sub'), lab = L.DomUtil.create('label', '', row);
  lab.innerHTML = '<input type="checkbox" id="lay-bands"> <span data-i18n="l_bands"></span>'; lab.dataset.i18nTitle = 'bandsTip';
  $('#lay-heat')?.closest('label')?.after(row);
  const box = lab.firstChild; box.checked = !!state.layers?.bands;
  box.addEventListener('change', () => { state.layers.bands = box.checked; savePrefs(); if (F) paint(); });
}
const wide = new Uint8Array(N), rowMax = new Uint8Array(N);
const spreadFor = z => z < 10 ? 3 : z < 11 ? 2 : 0; // cells of spread: thin coastal bands are a pixel wide when zoomed out
function spread(r) { // max filter over sea cells, so the best value in a ~0.5–0.75 km radius shows
  if (shownN * (2 * r + 1) ** 2 < 4 * N) { // few cells can score (most single fish): lift each scoring cell's square of sea instead, the same maxima
    wide.fill(0);
    for (let k = 0; k < shownN; k++) { // scores are 0 off shownIdx (workHour): no need to read all N
      const i = shownIdx[k], v = scores[i]; if (!v) continue;
      const x = i % W, y = (i - x) / W, xa = x > r ? x - r : 0, xb = x + r < W ? x + r : W - 1;
      for (let yy = y > r ? y - r : 0, ye = y + r < H ? y + r : H - 1; yy <= ye; yy++)
        for (let k = yy * W + xa, e = yy * W + xb; k <= e; k++) if (v > wide[k] && (CLIP || depth[k]) && (NCLIP || !northMask[k])) wide[k] = v;
    }
    return;
  }
  // Rows, then columns. Away from the grid's edges the window is one Math.max of 5 or 7 reads (r is 2 or 3): ~2× faster than a loop
  // per cell (~14 → ~7 ms on a desktop for a map that scores everywhere, as a pelagic fish by boat).
  const s = scores, rm = rowMax, W2 = 2 * W, W3 = 3 * W;
  for (let o = 0; o < N; o += W) for (let x = 0; x < W; x++) {
    const d = o + x;
    if (x >= r && x < W - r) { rm[d] = r === 3 ? Math.max(s[d - 3], s[d - 2], s[d - 1], s[d], s[d + 1], s[d + 2], s[d + 3]) : Math.max(s[d - 2], s[d - 1], s[d], s[d + 1], s[d + 2]); continue; }
    let m = 0; for (let k = o + (x > r ? x - r : 0), e = o + (x + r < W ? x + r : W - 1); k <= e; k++) if (s[k] > m) m = s[k];
    rm[d] = m;
  }
  for (let y = 0, i = 0; y < H; y++) for (let x = 0; x < W; x++, i++) {
    if (!NCLIP && northMask[i] || !CLIP && !depth[i]) { wide[i] = 0; continue; }
    if (y >= r && y < H - r) { wide[i] = r === 3 ? Math.max(rm[i - W3], rm[i - W2], rm[i - W], rm[i], rm[i + W], rm[i + W2], rm[i + W3]) : Math.max(rm[i - W2], rm[i - W], rm[i], rm[i + W], rm[i + W2]); continue; }
    let m = 0; for (let d = (y > r ? y - r : 0) * W + x, e = (y + r < H ? y + r : H - 1) * W + x; d <= e; d += W) if (rm[d] > m) m = rm[d];
    wide[i] = m;
  }
}
console.assert(spreadFor(9) === 3 && spreadFor(10) === 2 && spreadFor(11) === 0, 'spread() unrolls r = 2 and 3 only');
let paintedSpread = -1, paintedStride = 0, paintStale = false;
// Zoomed out, the image has a pixel per d×d cells: d as large as keeps a pixel within ~6 screen px (the browser's smoothing between them
// then draws a soft field, not a staircase), and at most 2r, so every plateau of the spread (2r+1 wide) holds one; at least 2 (one a cell
// showed the plateaus as squares)
const strideFor = (z, r) => [6, 5, 4, 3].find(d => d <= 2 * r && d * RES * 256 * 2 ** z / 360 <= 6) || 2;
const lowImgs = []; // paint's zoomed-out images, one per stride
const lowImg = d => lowImgs[d] ||= (() => { const w = W / d, h = H / d, img = new ImageData(w, h); return { w, h, img, p32: new Uint32Array(img.data.buffer) }; })();
console.assert(W % 60 === 0 && H % 60 === 0, 'every stride (2–6) tiles the grid exactly');
// Leaflet stretches the image evenly in Web Mercator, but grid rows are evenly spaced in latitude: left as is, the heat sits
// up to ~1.7 rows (~400 m) too far north, i.e. on the south coast's beaches. So each image row reads the grid row at its real latitude.
const imgLat = (() => { const m = d => Math.log(Math.tan(Math.PI / 4 + d * Math.PI / 360)), mN = m(NORTH), mS = m(NORTH - H * RES);
  return y => (2 * Math.atan(Math.exp(mN - y / H * (mN - mS))) - Math.PI / 2) * 180 / Math.PI; })(); // the latitude at image row y (0 at the top, H at the bottom)
const MROW = Int16Array.from({ length: H }, (_, y) => Math.min(H - 1, Math.max(0, Math.floor((NORTH - imgLat(y + .5)) / RES))));
const shore = new Uint8Array(N);
let COASTAL = null; // inner land cells with a sea neighbour: the rest of the land has only land (0) around it
function toShore(src) { // land cells next to the sea take their best sea neighbour; the shoreline clip then trims them at the water's edge
  if (!COASTAL) {
    const a = [];
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; if (!depth[i] && (depth[i - 1] || depth[i + 1] || depth[i - W] || depth[i + W])) a.push(i); }
    COASTAL = Int32Array.from(a);
  }
  shore.set(src);
  for (const i of COASTAL) shore[i] = Math.max(src[i - 1], src[i + 1], src[i - W], src[i + W]);
  return shore;
}
// fade: into the hidden layer, then that layer fades in over the other (a settled change: workHour); else into the layer on show, at once
function paint(fade = false) {
  if (!map.hasLayer(heat)) { paintStale = true; return; } // off: painted when it is turned on
  paintStale = false;
  const r = spreadFor(map.getZoom());
  if (r) spread(r);
  const src = r ? wide : CLIP ? toShore(scores) : scores; // zoomed out the spread itself runs over the shore (CLIP)
  paintedSpread = r;
  const bands = !!state.layers?.bands, lut = bands ? LUTB : LUT, lut32 = bands ? LUTB32 : LUT32;
  let vis = lut[3], img = heatData; // vis starts with 0's alpha: land is always 0, so some pixel is
  if (r) { // zoomed out: a pixel per d×d cells (strideFor), read at each block's middle. Every best value still shows at full colour, and
    // the browser's smoothing between the pixels draws a soft field where the spread's plateaus showed as a mosaic of squares. The image
    // is 1/d² the size: ~0.05 ms to fill, a small upload.
    const d = paintedStride = strideFor(map.getZoom(), r), c = d >> 1, o = lowImg(d), p32 = o.p32;
    img = o.img; p32.fill(lut32[0]);
    for (let y = 0, k = 0; y < o.h; y++) for (let i = MROW[y * d + c] * W + c, e = i - c + W; i < e; i += d, k++) { const v = src[i]; if (v) { p32[k] = lut32[v]; vis |= lut[v * 4 + 3]; } }
  } else { // Most of the image is 0 (land, and sea where nothing scores): fill it all with 0's colour, then one 32-bit read per four cells
    // finds the few that score (~1.4 → ~0.3 ms on a desktop)
    const s32 = new Uint32Array(src.buffer, src.byteOffset, N >> 2);
    px32.fill(lut32[0]);
    for (let y = 0, o = 0; y < H; y++) for (let w = MROW[y] * W >> 2, we = w + (W >> 2); w < we; w++, o += 4)
      if (s32[w]) for (let k = 0, s0 = w << 2; k < 4; k++) { const v = src[s0 + k]; px32[o + k] = lut32[v]; vis |= lut[v * 4 + 3]; }
  }
  // The pixels go straight into the layer's canvas: no image file per hour (a 3 MB BMP blob + object URL cost ~36 ms a frame on a phone)
  const lay = heatLayers[fade ? liveLayer ^ 1 : liveLayer], cut = lay.cut = r ? null : fineCut(), cv = lay.ctx.canvas;
  if (cv.width !== img.width) Object.assign(cv, { width: img.width, height: img.height }); // the zoom crossed a spread step: a cleared canvas
  if (vis) lay.ctx.putImageData(img, 0, 0); else lay.ctx.clearRect(0, 0, cv.width, cv.height);
  if (cut && vis) { paintFine(lay, cut, src, bands); lay.ctx.clearRect(cut.x0, cut.y0, cut.x1 - cut.x0, cut.y1 - cut.y0); } // the fine image in place of that part
  else lay.fine.style.display = 'none';
  heatBox.classList.toggle('heat-fade', fade); // off: a fade still running ends at once
  if (fade) {
    liveLayer ^= 1;
    for (const l of heatLayers) Object.assign(l.el.style, l === lay ? { opacity: '', visibility: '' } : { opacity: 0, visibility: 'hidden' });
  }
}
// Zoomed in, a 250 m cell is a square of 6 px or more, and the browser's smoothing still shows the squares. So the part of the image
// under the view (and a quarter screen around it, for panning) is also drawn finer, a pixel per 4 screen px (16 a cell at most), from
// the score itself interpolated between cell centres and then coloured: edges and bands follow smooth curves. Its cost follows the
// screen, not the zoom: ~0.5 ms on a desktop, under 0.2 ms at a phone's size. In its place the coarse canvas is left clear.
const FINE_PX = 4; // ponytail: at zoom 12 (8 px cells) that is only 2 samples a cell, so patch edges still show steps; a fixed pixel budget (2 px there) would cost ~4× on phones
function fineCut() { // that part, in image pixels (columns and Mercator rows), and the fine image's size; null when cells are small
  const a = map.latLngToContainerPoint([NORTH, WEST]), b = map.latLngToContainerPoint([NORTH - H * RES, WEST + W * RES]), sx = (b.x - a.x) / W, sy = (b.y - a.y) / H;
  if (!(sx >= 6)) return null;
  const s = map.getSize(), mx = s.x / 4, my = s.y / 4, ix = v => Math.min(W, Math.max(0, (v - a.x) / sx)), iy = v => Math.min(H, Math.max(0, (v - a.y) / sy));
  const c = { x0: Math.floor(ix(-mx)), x1: Math.ceil(ix(s.x + mx)), y0: Math.floor(iy(-my)), y1: Math.ceil(iy(s.y + my)), view: [ix(0), iy(0), ix(s.x), iy(s.y)], z: map.getZoom() };
  if (c.x1 <= c.x0 || c.y1 <= c.y0) return null;
  const k = Math.max(FINE_PX, sx / 16); // past 16 pixels a cell the browser's own smoothing is as good (the score is linear within a cell)
  c.fw = Math.ceil((c.x1 - c.x0) * sx / k); c.fh = Math.ceil((c.y1 - c.y0) * sy / k);
  return c;
}
let fineImg = null, fineCol = new Int32Array(0), fineWx = new Float32Array(0);
function paintFine(lay, c, f, bands) {
  const { x0, x1, y0, y1, fw, fh } = c, lut = bands ? LUTB : LUT, rnd = bands ? 0 : .5, cx = (x1 - x0) / fw, cy = (y1 - y0) / fh; // cx, cy: cells a fine pixel
  if (lay.fine.width !== fw || lay.fine.height !== fh) Object.assign(lay.fine, { width: fw, height: fh });
  if (fineImg?.width !== fw || fineImg.height !== fh) fineImg = new ImageData(fw, fh); else new Uint32Array(fineImg.data.buffer).fill(0);
  if (fineCol.length < fw + 1) { fineCol = new Int32Array(fw + 1); fineWx = new Float32Array(fw); }
  for (let fx = 0; fx < fw; fx++) { const g = Math.min(W - 1.001, Math.max(0, x0 + (fx + .5) * (x1 - x0) / fw - .5)); fineCol[fx] = g | 0; fineWx[fx] = g - (g | 0); }
  fineCol[fw] = -1; // ends the last run of pixels between the same two cell columns
  const d = fineImg.data, d32 = new Uint32Array(d.buffer);
  for (let fy = 0; fy < fh; fy++) {
    const g = Math.min(H - 1.001, Math.max(0, (NORTH - imgLat(y0 + (fy + .5) * (y1 - y0) / fh)) / RES - .5)), row = (g | 0) * W, wy = g - (g | 0), uy = 1 - wy, o = fy * fw;
    for (let fx = 0, end; fx < fw; fx = end) { // a run of pixels between the same four cell centres: read them once
      const col = fineCol[fx], i = row + col, p = f[i], q = f[i + 1], u = f[i + W], v = f[i + W + 1];
      for (end = fx + 1; fineCol[end] === col;) end++;
      if (!(p | q | u | v)) continue;
      const m = ON[p] | ON[q] << 1 | ON[u] << 2 | ON[v] << 3;
      if (!m) continue;
      if (m === 15) { // inside a patch: plain bilinear, a line along the run
        const A = p * uy + u * wy, B = (q - p) * uy + (v - u) * wy;
        if (!bands) { for (let x = fx, A5 = A + .5; x < end; x++) d32[o + x] = LUT32[A5 + B * fineWx[x] | 0]; continue; }
        // bands: each edge blended over one fine pixel however steep the score is there (t: the distance to it in pixels), with a thin dark line on it
        const gx = B * cx, gy0 = (u - p) * cy, gy1 = (v - q) * cy;
        for (let x = fx; x < end; x++) {
          const wx = fineWx[x], s = A + B * wx, gy = gy0 + (gy1 - gy0) * wx, g = Math.sqrt(gx * gx + gy * gy), e = Math.round(s / 10) * 10, t = (s - e) / g;
          if (e < 40 || e > 90 || !(t < .8 && t > -.8) || g < .05) { d32[o + x] = LUTB32[s | 0]; continue; } // g ~0: flat, on an edge value or not
          const mix = t < -.5 ? 0 : t > .5 ? 1 : t + .5, dark = 1 - .3 * (1 - Math.abs(t) / .8), lo = (e - 1) * 4, hi = e * 4, ob = (o + x) * 4;
          for (let ch = 0; ch < 4; ch++) d[ob + ch] = (LUTB[lo + ch] + (LUTB[hi + ch] - LUTB[lo + ch]) * mix) * (ch < 3 ? dark : 1);
        }
        continue;
      }
      // at a patch's edge only the corners that show count, so the colour fades out there instead of running down the ramp to 0 (a blue rim on everything)
      for (let x = fx; x < end; x++) {
        const wx = fineWx[x], ux = 1 - wx, a = (m & 1) * ux * uy, b = (m >> 1 & 1) * wx * uy, e = (m >> 2 & 1) * ux * wy, h = (m >> 3) * wx * wy, cov = a + b + e + h;
        if (cov <= .25) continue;
        const k = ((p * a + q * b + u * e + v * h) / cov + rnd | 0) * 4, ob = (o + x) * 4;
        d[ob] = lut[k]; d[ob + 1] = lut[k + 1]; d[ob + 2] = lut[k + 2]; d[ob + 3] = cov >= .75 ? lut[k + 3] : lut[k + 3] * (cov - .25) * 2;
      }
    }
  }
  lay.fctx.putImageData(fineImg, 0, 0);
  Object.assign(lay.fine.style, { display: '', left: x0 / W * 100 + '%', top: y0 / H * 100 + '%', width: (x1 - x0) / W * 100 + '%', height: (y1 - y0) / H * 100 + '%' });
}
heat.on('add', () => { if (paintStale && F) paint(); });
console.assert(MROW[0] === 0 && MROW[H - 1] === H - 1 && MROW.every((v, y) => !y || v >= MROW[y - 1]), 'heat rows follow Mercator');
console.assert(W % 4 === 0, 'paint reads whole 32-bit words per row');
map.on('moveend', () => { // a new zoom's spread, stride or sharpness, or the view past the fine image's margin: paint again (~1 ms zoomed in)
  if (!F || !map.hasLayer(heat)) return;
  const z = map.getZoom(), r = spreadFor(z), p = heatLayers[liveLayer].cut, c = r ? null : fineCut();
  if (r !== paintedSpread || r && strideFor(z, r) !== paintedStride || !c !== !p || c && (c.z !== p.z || c.view[0] < p.x0 || c.view[1] < p.y0 || c.view[2] > p.x1 || c.view[3] > p.y1)) paint();
});
const ZW = W / 2, ZH = H / 2, zgrid = new Float32Array(ZW * ZH);
function drawZones() { // outline the 65+ and 80+ areas so hotspots read at a glance
  zones.clearLayers();
  if (!state.layers.zones || !state.layers.heat || !scored) return; // before the first render there is nothing to outline
  // Only the box around the 65+ cells (and a cell of margin, so the lines interpolate as on the whole grid) goes through d3:
  // the whole grid cost ~3 ms a settle on a desktop, most hours with nothing to outline. Scores are 0 off shownIdx (workHour).
  let x0 = ZW, y0 = ZH, x1 = -1, y1 = -1;
  for (let k = 0; k < shownN; k++) {
    const i = shownIdx[k]; if (scores[i] < 65) continue;
    const x = i % W >> 1, y = (i / W | 0) >> 1; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
  }
  if (x1 < 0) return;
  x0 = Math.max(0, x0 - 1); y0 = Math.max(0, y0 - 1); x1 = Math.min(ZW - 1, x1 + 1); y1 = Math.min(ZH - 1, y1 + 1);
  const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
  for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) {
    const i = 2 * (y + y0) * W + 2 * (x + x0);
    zgrid[y * bw + x] = Math.max(scores[i], scores[i + 1], scores[i + W], scores[i + W + 1]);
  }
  const lines = [], o = { renderer: zoneRenderer, pane: 'zones', interactive: false };
  for (const g of d3.contours().size([bw, bh]).thresholds([65, 80])(zgrid.subarray(0, bw * bh)))
    for (const poly of g.coordinates) for (const ring of poly) {
      if (ring.length < 8) continue;
      const ll = ring.map(([x, y]) => [NORTH - (y + y0) * 2 * RES, WEST + (x + x0) * 2 * RES]), hot = g.value >= 80;
      if (hot) L.polyline(ll, { ...o, color: '#ff3d6e', weight: 9, opacity: .16 }).addTo(zones); // the excellent water glows: a wide faint line under them all
      lines.push([ll, hot]);
    }
  for (const [ll, hot] of lines) L.polyline(ll, { ...o, color: hot ? '#ff3d6e' : '#ffe27a', weight: hot ? 2.2 : 1.2, opacity: hot ? 1 : .8 }).addTo(zones);
}
// Scrubbing the timeline, holding an arrow key or playing can ask for many renders a frame: after a render, the next waits for the
// next frame and draws the latest hour, fish and method. renderNow() draws at once.
let renderQueued = false, renderedAt = -1e9, scored = false, hiddenPlay = false;
const flushRender = () => { if (renderQueued) renderNow(); };
function render() {
  if (document.hidden && state.playing) { hiddenPlay = true; return; } // playing in a hidden page: nothing to see, the hour shows when it is back
  if (renderQueued) return;
  if (performance.now() - renderedAt > 50) { renderNow(); return; }
  renderQueued = true; requestAnimationFrame(flushRender); setTimeout(flushRender, 50); // the timer: pages that get no frames (hidden) still draw
}
// Each hour's map is kept: its scores along cur.idx, a byte a cell, for this cur only (curGen, model.js). An hour is scored in slices of
// SLICE_MS, so a tap, a drag or the timeline never waits behind a big map (a pelagic fish or All fish by boat: ~525k cells, ~40 ms an hour
// on a desktop, several times that on a phone); the old picture stays until the new one is whole. Once the hour has been moved, a slow map's
// neighbouring hours are scored ahead in background slices (HOURS_AROUND each way, HOURS_MB at most, never in a hidden page), so scrubbing
// and playing then show them at once. ponytail: main thread only; a worker would need its own copy of the model's grids (~100 MB on a phone).
const hourMaps = new Map(), SLICE_MS = 8, HOURS_AROUND = 12, HOURS_MB = 24;
let hourGen = -1, hourMs = 0, hourMoved = false, hourLast = -1, hourJob = null, hourJobT = false, aheadTask = false;
let shownIdx = new Int32Array(0), shownN = 0, shownGen = -1; // the cells `scores` holds a score for (0 off them): cur.idx when it was shown
const soonTask = (f, bg) => window.scheduler?.postTask ? scheduler.postTask(f, { priority: bg ? 'background' : 'user-visible' }) : setTimeout(f, bg ? 20 : 0);
function hourMap(h) {
  if (hourGen !== curGen) { hourMaps.clear(); hourGen = curGen; hourMs = 0; hourMoved = false; }
  let e = hourMaps.get(h);
  if (!e) hourMaps.set(h, e = { a: new Uint8Array(cur.n), j: 0, ms: 0 });
  return e;
}
function scoreSlice(e, h, until) { // more of hour h's map, until the deadline; true once it is whole
  while (e.j < cur.n) {
    const t = performance.now(), j1 = Math.min(cur.n, e.j + 8192);
    scoreCells(cur, h, h + 1, cur.idx, e.j, j1, 0, e.a); e.j = j1; e.ms += performance.now() - t;
    if (e.j === cur.n) hourMs = e.ms;
    else if (performance.now() > until) return false;
  }
  return true;
}
let settleTimer = 0;
function renderNow() {
  renderQueued = false;
  // While scrubbing (renders < 300 ms apart) the spot list, outlines and open card wait until it settles: they cost ~20 ms a frame on a phone.
  // The heat fades from the old hour (or fish) to the new only when not scrubbing: playing, Now, ★, a tap.
  const busy = performance.now() - renderedAt < 300;
  drawConditions(); drawTimeline(); drawWhen();
  hourMap(state.h); if (hourLast !== state.h) { hourMoved ||= hourLast >= 0; hourLast = state.h; }
  hourJob = { h: state.h, fade: !busy, busy }; workHour(); // a small map is whole after the first slice: on the map at once, as it always was
  renderedAt = performance.now();
}
const pumpHour = () => { hourJobT = false; workHour(); };
function workHour() { // the hour waiting for its map: a slice of it, then onto the map once whole
  if (!hourJob) return;
  const e = hourMap(hourJob.h);
  if (!scoreSlice(e, hourJob.h, performance.now() + SLICE_MS)) { if (!hourJobT) { hourJobT = true; soonTask(pumpHour); } return; }
  const { fade, busy } = hourJob; hourJob = null;
  if (shownGen !== hourGen) { shownIdx = cur.idx.slice(0, cur.n); shownN = cur.n; shownGen = hourGen; } // prepare() reuses cur.idx: a copy
  scores.fill(0); for (let j = 0, a = e.a; j < shownN; j++) scores[shownIdx[j]] = a[j];
  scored = true;
  paint(fade);
  clearTimeout(settleTimer);
  if (busy) settleTimer = setTimeout(settle, 180); else settle();
  scoreAhead();
}
function scoreAhead() { // the next hour around the one shown (nearest first) of a slow map, in a background slice
  if (aheadTask || hourJob || !hourMoved || hourMs < 12 || document.hidden) return;
  let h = -1;
  for (let d = 1; d <= HOURS_AROUND && h < 0; d++) for (const k of [state.h + d, state.h - d]) if (k >= 0 && k < F.T && !(hourMaps.get(k)?.j === cur.n)) { h = k; break; }
  if (h < 0) return;
  while ((hourMaps.size + 1) * cur.n > HOURS_MB * 1e6) { // the farthest hour goes
    let far = state.h; for (const k of hourMaps.keys()) if (Math.abs(k - state.h) > Math.abs(far - state.h)) far = k;
    if (Math.abs(far - state.h) <= Math.abs(h - state.h)) return; hourMaps.delete(far);
  }
  aheadTask = true;
  soonTask(() => { aheadTask = false; if (hourGen === curGen && !hourJob && !document.hidden) { scoreSlice(hourMap(h), h, performance.now() + SLICE_MS); scoreAhead(); } }, true);
}
document.addEventListener('visibilitychange', () => { if (document.hidden) return; if (hiddenPlay) { hiddenPlay = false; if (F) render(); } else if (F) scoreAhead(); });
function settle() { const f = state.focus; drawZones(); drawTop(); if (state.focus !== f) drawConditions(); refreshOpen(); } // drawTop may move the focus spot the readings follow (renderNow drew them for the old one)

function describe(la, lo) {
  let b = null;
  for (const [name, , sla, slo] of NAMED) { const r = km([sla, slo], [la, lo]); if (r.d < 2.5 && (!b || r.d < b.d)) b = { ...r, name: placeName(name) }; }
  if (!b) for (const [en, el, pla, plo] of PLACES) { const r = km([pla, plo], [la, lo]); if (!b || r.d < b.d) b = { ...r, name: state.lang === 'el' ? el : en }; }
  return b.d < .25 ? tr('at', b.name) : tr('of', fmtKm(b.d), compass(b.bearing), b.name);
}
let tops = [];
const B6 = 6, BW = Math.ceil(W / B6), blockBest = new Int32Array(BW * Math.ceil(H / B6));
// The 8 numbered pins are made once and hourMoved: rebuilt each settle, their DOM was redone and their pop restarted at every hour.
// Each: a dark tag (rank · the score in its colour) on a stem over a ring at the spot itself (css/map-fx.css); its element is kept,
// so drawTop sets only the score and colour, and only when they change.
const pinEls = [], pinSet = [];
const pinMarks = Array.from({ length: 8 }, (_, n) => {
  const el = pinEls[n] = L.DomUtil.create('div', n ? 'tp' : 'tp tp1');
  el.innerHTML = `<i class="tp-ring"></i><span class="tp-cap"><b>${n + 1}</b><span></span></span>`;
  return L.marker([0, 0], { icon: L.divIcon({ className: 'top-pin', html: el, iconSize: [0, 0] }), keyboard: false, pane: 'spots' }).on('click', () => tops[n] && openCell(tops[n].i));
});
function drawTop() {
  // The best cell of each 6×6 block (the first in reading order on a tie), from the cells that can score only (scores are 0 off shownIdx): ~2 ms → ~0.1
  const cands = []; blockBest.fill(-1);
  for (let k = 0; k < shownN; k++) {
    const i = shownIdx[k], s = scores[i]; if (s < 40) continue;
    const b = ((i / W | 0) / B6 | 0) * BW + (i % W / B6 | 0), j = blockBest[b];
    if (j < 0 || s > scores[j] || s === scores[j] && i < j) blockBest[b] = i;
  }
  for (const i of blockBest) if (i >= 0) cands.push([scores[i], i]);
  cands.sort((a, b) => b[0] - a[0]); // stable: ties keep block order
  const gap = state.mode === 'boat' ? 3 : 1.5;
  tops = [];
  for (const [s, i] of cands) {
    const p = [latOf(i), lonOf(i)];
    if (tops.every(t => km(t.p, p).d > gap)) tops.push({ s, i, p });
    if (tops.length === 8) break;
  }
  drawSpotList(tops); // the Spots tab (ui.js)
  tops.forEach((t, n) => {
    pinMarks[n].setLatLng(t.p);
    const el = pinEls[n], key = t.s + state.lang; if (pinSet[n] === key) return;
    pinSet[n] = key; el.style.setProperty('--c', solid(t.s)); el.lastChild.lastChild.textContent = t.s; el.title = `${t.s} · ${rating(t.s)}`;
  });
  spacePins();
  if (!state.picked && tops[0]) state.focus = tops[0].i; // conditions follow the best spot until a cell is clicked
}
function spacePins() { // zoomed out, a pin whose capsule would touch a better-ranked one's stays off the map (the list keeps every spot)
  const shown = [];
  pinMarks.forEach((m, n) => {
    const p = n < tops.length && map.latLngToLayerPoint(m.getLatLng());
    if (p && shown.every(q => Math.abs(q.x - p.x) >= 62 || Math.abs(q.y - p.y) >= 36)) { shown.push(p); pins.addLayer(m); } else pins.removeLayer(m);
  });
}
map.on('zoomend', spacePins);

const arrow = deg => `<svg width="11" height="11" viewBox="0 0 10 10" style="transform:rotate(${deg}deg)" aria-hidden="true"><path d="M5 .5l3 4H6v5H4v-5H2z" fill="currentColor"/></svg>`;
const seaNear = ll => { let b = SAMPLE[0], bd = Infinity; for (const j of SAMPLE) { const d = (latOf(j) - ll.lat) ** 2 + ((lonOf(j) - ll.lng) * .82) ** 2; if (d < bd) { bd = d; b = j; } } return b; }; // nearest scoreable sea cell
function nextWindow(list, t) { const w = list.find(([, b]) => b > t); return w ? `${hm(w[0])}–${hm(w[1])}` : '–'; }
function drawConditions() { // the readings that matter most, as mini instruments (js/instruments.js: built once, patched each hour); the drawer has the rest (moreConditions in ui.js)
  if (F) PsInst.strip($('#strip'), state.focus >= 0 ? state.focus : seaNear(map.getCenter()), state.h); // nothing scores yet (a fish that is not biting): the sea mid-map
}
let tlFor = null, tlPh = null; // tlPh: the playhead, all an hour step moves
const tlDays = (from = 0) => { const d = []; for (let h = from; h < F.T; h++) h === from || hours[h].local === 0 ? d.push([h, h + 1]) : d[d.length - 1][1] = h + 1; return d; }; // [from, to) per local day
function dayName(days, k) { // Yesterday, Today, Tomorrow, else e.g. "Thu 29"
  const r = k - days.findIndex(([a, b]) => state.first >= a && state.first < b);
  return r === -1 ? tr('yesterday') : r === 0 ? tr('cToday') : r === 1 ? tr('cTomorrow') : fmtT(hours[days[k][0]].t, { weekday: 'short', day: 'numeric' });
}
// The best chance anywhere, hour by hour, as one smooth curve coloured along its length by each hour's chance, its area fading down;
// night hours darker bands, the past hatched and greyed, now a dashed line, the hour on the map a white line with a knob on the curve.
// Wide screens: the whole range, a hairline and a label (name, best chance, roughest sea and wind) per day. Phones, and wide screens with
// under 2.5 px an hour: one day at a time, so each hour is wide enough to tap, picked from a strip of day chips that scrolls sideways.
// Drawn in px (again when the width changes), so lines and knob keep their size. Hour k sits at k·dx, where the native slider over it puts it.
let tlW = 0; // the track's width (it does not depend on what is drawn in it)
new ResizeObserver(([e]) => { const w = Math.round(e.contentRect.width); if (w !== tlW) { tlW = w; tlFor = null; if (F) drawTimeline(); } }).observe($('#tl'));
const tlH = () => isPhone() ? 44 : 36; // the chart's height: css/timeline.css lays #hour over it at the same height
const greyed = s => { const c = heatRgba(Math.max(s, 50)), l = (3 * c[0] + 6 * c[1] + c[2]) / 10; return `rgb(${c.slice(0, 3).map(v => (v + 3 * l) / 4 | 0)})`; }; // the past: its chance's colour, mostly grey
function monotone(ys, dx) { // an SVG path through (k·dx, ys[k]): cubic and monotone between hours (as d3's curveMonotoneX), so it never shows a chance no hour has
  const n = ys.length, s = ys.slice(1).map((y, k) => (y - ys[k]) / dx), f = v => v.toFixed(1);
  const m = ys.map((_, k) => k === 0 ? s[0] : k === n - 1 ? s[n - 2] : (Math.sign(s[k - 1]) + Math.sign(s[k])) * Math.min(Math.abs(s[k - 1]), Math.abs(s[k]), Math.abs(s[k - 1] + s[k]) / 4));
  let p = `M0,${f(ys[0])}`;
  for (let k = 1; k < n; k++) p += `C${f((k - 2 / 3) * dx)},${f(ys[k - 1] + m[k - 1] * dx / 3)} ${f((k - 1 / 3) * dx)},${f(ys[k] - m[k] * dx / 3)} ${f(k * dx)},${f(ys[k])}`;
  return n > 1 ? p : p + `H${f(dx)}`; // a one-hour stub: flat across
}
const movePh = () => { const k = state.h - tlFor.from; tlPh.style.transform = `translateX(${(k * tlFor.dx).toFixed(1)}px)`; tlPh.firstChild.style.transform = `translateY(${tlFor.ys[k].toFixed(1)}px)`; };
function drawTimeline() {
  tlW ||= $('#tl').clientWidth; // before the observer's first call (it waits for a frame: none in a hidden page)
  const one = isPhone() || tlW < F.T * 2.5, days = tlDays(), di = Math.max(0, days.findIndex(([a, b]) => state.h >= a && state.h < b)), day = days[di];
  const [from, to] = one ? day : [0, F.T];
  const same = tlFor && tlFor.best === best && tlFor.lang === state.lang && tlFor.one === one; // the same days, scale and labels
  if (same && tlFor.from === from && tlFor.to === to) { movePh(); return; } // the same chart: only the playhead moves
  const hi = Math.max(...best), span = Math.max(hi - Math.min(...best), 20); // one scale for all days so they compare; the best hour at the top
  const dayBest = ([a, b]) => pill(Math.round(Math.max(...best.slice(a, b))));
  const cut = F.cutAt ? `<span class="tl-cut">${esc(tr('noWavesAfter', whenT(F.cutAt)))}</span>` : ''; // the wave forecast ended early: so does the timeline
  const n = to - from, ch = tlH(), dx = tlW / Math.max(1, n - 1), X = h => ((h - from) * dx).toFixed(1);
  const every = one ? 3 : [6, 12].find(s => s * dx >= 24) || 24; // hour labels where they fit (phones: every 3 h)
  const ys = best.slice(from, to).map(sc => 6 + (ch - 8) * (hi ? .86 * clamp((hi - sc) / span) : .94)); // 6 px over the top for the knob; nothing scores (banned or closed fish): flat
  let stops = '', night = '', hrs = '', n0 = 0;
  for (let h = from; h < to; h++) {
    const x = hours[h];
    stops += `<stop offset="${n > 1 ? ((h - from) / (n - 1)).toFixed(4) : 0}" stop-color="${h < state.first || !hi ? greyed(best[h]) : solid(best[h])}"/>`;
    if (x.period === 'night') {
      if (h === from || hours[h - 1].period !== 'night') n0 = h;
      if (h === to - 1 || hours[h + 1].period !== 'night') night += `M${Math.max(0, (n0 - from - .5) * dx).toFixed(1)} 0H${Math.min(tlW, (h - from + .5) * dx).toFixed(1)}V${ch}H${Math.max(0, (n0 - from - .5) * dx).toFixed(1)}Z`;
    }
    if (x.local && x.local % every === 0 && hours[h - 1]?.local !== x.local) hrs += `<em style="left:${X(h)}px">${String(x.local).padStart(2, '0')}</em>`; // once on the night the clocks go back
  }
  const line = monotone(ys, dx), now = state.first >= from && state.first < to;
  const sep = one ? '' : days.slice(1).map(([a]) => `M${(+X(a) - dx / 2).toFixed(1)} 0V${ch}`).join('');
  const chart = `<div class="tl-chart"><svg width="${tlW}" height="${ch}" viewBox="0 0 ${tlW} ${ch}" aria-hidden="true"><defs>` +
    `<linearGradient id="tl-c" gradientUnits="userSpaceOnUse" x2="${tlW}">${stops}</linearGradient>` +
    `<linearGradient id="tl-v" x2="0" y2="1"><stop stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity=".02"/></linearGradient>` +
    `<mask id="tl-m"><rect width="100%" height="100%" fill="url(#tl-v)"/></mask>` +
    `<pattern id="tl-x" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V5" stroke="#fff" stroke-opacity=".1" stroke-width="1.5"/></pattern></defs>` +
    `<path class="tl-night" d="${night}"/><path d="${line}V${ch}H0Z" fill="url(#tl-c)" mask="url(#tl-m)"/>` +
    (state.first > from ? `<rect width="${now ? X(state.first) : tlW}" height="${ch}" fill="url(#tl-x)"/>` : '') +
    (sep ? `<path class="tl-sep" d="${sep}"/>` : '') + (now ? `<path class="tl-nowl" d="M${X(state.first)} 0V${ch}"/>` : '') +
    `<path class="tl-line" d="${line}" stroke="url(#tl-c)"/></svg><i class="tl-ph"><b></b></i>${hrs}</div>`;
  const label = ([a, b], k) => { // each day labelled with its best chance and, given room, its roughest sea and wind (too short a stub gets no label)
    if (b - a < 5) return '';
    let wave = 0, wind = 0; for (let j = a * NN; j < b * NN; j++) { wave = Math.max(wave, F.wave[j]); wind = Math.max(wind, Math.hypot(F.u[j], F.v[j])); }
    // the name that fits beside the pill (~6.5 px a letter; the pill, gap and padding ~36 px): "Yesterday", else "Sat", else none; the pill always shows
    const room = (b - a - .5) * dx - 36;
    let nm = dayName(days, k); if (nm.length * 6.5 > room) { nm = fmtT(hours[a].t, { weekday: 'short' }); if (nm.length * 6.5 > room) nm = ''; }
    return `<span class="tl-nm">${esc(nm)}</span>${dayBest([a, b])}` +
      ((b - a) * dx >= 190 ? `<small title="${esc(tr('dayWx'))}">${ic('waves', 'sm')}${nf(wave)} m${ic('wind', 'sm')}${Math.round(wind)} km/h</small>` : '') + (k === days.length - 1 ? cut : '');
  };
  const tl = $('#tl');
  if (same && one) { // another day, one at a time: the strip stays (and keeps its scroll), only its pressed chip and the chart change
    const s = tl.firstElementChild.children; s[tlFor.di].setAttribute('aria-pressed', 'false'); s[di].setAttribute('aria-pressed', 'true');
    tl.lastElementChild.outerHTML = chart;
  } else {
    tl.innerHTML = (one ? `<div class="tl-dtabs">${days.map((d, k) => `<button type="button" class="${d[1] <= state.first ? 'past' : d[0] <= state.first ? 'today' : ''}" data-day="${d[0]}" data-end="${d[1]}" aria-pressed="${k === di}">` +
      `<span>${esc(dayName(days, k))}</span>${dayBest(d)}</button>`).join('')}${cut}</div>`
      : `<div class="tl-days">${days.map((d, k) => `<span class="tl-label${d[1] <= state.first ? ' past' : d[0] <= state.first ? ' today' : ''}" style="flex:${d[1] - d[0] - (k === 0) / 2 - (k === days.length - 1) / 2}">${label(d, k)}</span>`).join('')}</div>`) + chart; // flex: the days' edges on the hairlines, half an hour before each first hour
    tl.classList.toggle('one-day', one);
  }
  Object.assign($('#hour'), { min: from, max: to - 1, value: state.h }); // the slider spans what is shown
  if (one) { // the selected day in the middle of its strip: measured in the next frame, with the frame's own layout, not forced now
    const s = tl.firstElementChild, on = s.children[di], glide = same && !matchMedia('(prefers-reduced-motion: reduce)').matches;
    requestAnimationFrame(() => s.scrollTo({ left: on.offsetLeft - (s.clientWidth - on.offsetWidth) / 2, behavior: glide ? 'smooth' : 'auto' }));
  }
  tlFor = { best, from, to, lang: state.lang, one, di, dx, ys }; tlPh = tl.querySelector('.tl-ph'); movePh();
}
function dayHour(b, want = hours[state.h].local) { // the hour a day button goes to: the hour of day `want` where that day has it (js/mobile.js turns days by a flick too)
  const d = +b.dataset.day, end = +b.dataset.end;
  let h = d; for (let k = d; k < end; k++) if (hours[k].local === want) { h = k; break; }
  return h < state.first && end > state.first ? state.first : h; // today: from now on, not back in time
}
$('#tl').addEventListener('click', e => { const b = e.target.closest('[data-day]'); if (b && F) setHour(dayHour(b)); }); // phones: the day chips
PHONE.addEventListener('change', () => { tlFor = null; if (F) drawTimeline(); }); // rotating or resizing across the phone width
let bestHour = 0;
const whenSet = {}; // what drawWhen last wrote: an hour step rewrites only what changed (the day, tags and ★ button mostly stay), so the bar's layout is left alone
const putWhen = (sel, v, html) => { if (whenSet[sel] !== v) { whenSet[sel] = v; $(sel)[html ? 'innerHTML' : 'textContent'] = v; } };
const NARROW = matchMedia('(max-width: 1180px)'); // a desktop window this narrow: the ★ button says just the time, as on phones (css/timeline.css)
NARROW.addEventListener('change', () => F && drawWhen());
function drawWhen() {
  const x = hours[state.h], t = hm(x.t), d = fmtT(x.t, { weekday: 'short', day: 'numeric', month: 'short' });
  putWhen('#when-time', t); putWhen('#when-day', d);
  $('#hour').setAttribute('aria-valuetext', `${t}, ${d}`); // a screen reader says the hour, not the slider's index
  putWhen('#when-tags', (state.h < state.first ? `<span class="tag past">${tr('pastTag')}</span>` : '') +
    `<span class="tag">${tr(x.period)}</span>${x.solunar ? `<span class="tag ${x.solunar}" title="${esc(tr(x.solunar))}">${ic('moon')}${tr('solShort')[x.solunar]}</span>` : ''}`, true);
  bestHour = state.first; // the best hour from now on: the past is only for looking back
  for (let h = state.first; h < F.T; h++) if (best[h] > best[bestHour]) bestHour = h;
  const bb = $('#best-btn'), w = whenT(hours[bestHour].t), long = tr('best', w, Math.round(best[bestHour])), short = isPhone() || NARROW.matches, hide = !(best[bestHour] >= 40);
  if (bb.hidden !== hide) bb.hidden = hide;
  putWhen('#best-btn', short ? `★ ${w}` : long); // phones and narrow windows: just the time
  const tip = short ? `${long}\n${tr('bestTip')}` : tr('bestTip'); if (bb.title !== tip) bb.title = tip;
}
