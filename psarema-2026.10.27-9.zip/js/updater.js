'use strict';
// Psarema: over-the-air web updates for the Android app (@capgo/capacitor-updater, manual mode, self-hosted).
// Turn on: set UPDATE_URL to the https folder that serves manifest.json + the zip from mobile\publish-update.ps1,
// then rebuild the APK once. The host must allow CORS (GitHub Pages does). Does nothing in a browser.
// Quiet: checked at start and on coming back after 6 h; a newer version downloads in the background and is swapped in when the
// app next leaves the screen; the next time it is seen, a small toast says it was updated. A version the plugin had to roll back
// (it never became ready) is not tried again by itself, so a bad update cannot loop.
window.PSAREMA_VERSION = '2026.10.27-9'; // version of these web files; publish-update.ps1 stamps it
(() => {
  const UPDATE_URL = 'https://giannis242.github.io/psarema-updates/'; // GitHub Pages of the Giannis242/psarema-updates repo (mobile/push-update.ps1 publishes there); '' = updater off
  const DONE = { en: 'Updated', el: 'Ενημερώθηκε' }, KEY = 'psarema-upd-v1', EVERY = 6 * 36e5;

  const cap = window.Capacitor, U = cap?.isNativePlatform?.() && cap.Plugins?.CapacitorUpdater;
  if (!U) return;
  U.notifyAppReady().catch(e => console.warn('updater:', e)); // this bundle works: stops the plugin rolling it back
  const say = (k, ...a) => typeof toast === 'function' && typeof tr === 'function' && toast(tr(k, ...a));
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
  const save = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch {} };
  const running = async () => { const b = (await U.current().catch(() => null))?.bundle; return b && b.id !== 'builtin' && b.version ? b.version : window.PSAREMA_VERSION; };
  const btn = document.getElementById('mb-update'), label = document.getElementById('mb-version');
  async function showVersion() { if (label) label.textContent = tr('appVersion', await running()); }
  if (btn) { // the ⋯ menu's "Check for updates" (Android app only)
    btn.hidden = false; showVersion(); new MutationObserver(showVersion).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    let busy = false;
    btn.addEventListener('click', async () => {
      if (!UPDATE_URL) { say('updOff'); return; }
      if (busy) return; busy = true; say('updChecking');
      try { if (!(await check(true))) say('updLatest'); } catch (e) { console.warn('updater:', e); say('updFailed'); }
      busy = false;
    });
  }

  const parts = v => String(v).split(/[.-]/).map(n => +n || 0); // '2026.10.24-3' -> [2026, 10, 24, 3]
  const newer = (a, b) => {
    const x = parts(a), y = parts(b);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  };

  // Each start: what became of the version handed to the plugin last time, and a toast when a newer one runs (over the air or a new APK).
  (async () => {
    const p = load(), v = await running(), next = (await U.getNextBundle().catch(() => null))?.version;
    if (p.trying && p.trying !== v && p.trying !== next) p.bad = p.trying; // neither running nor waiting: rolled back
    if (p.trying !== next) p.trying = null;
    if (p.seen && newer(v, p.seen)) { // when the page is on screen (a swap happens in the background), after start-up's own toasts
      const show = () => setTimeout(() => typeof toast === 'function' && toast(`${DONE[typeof state === 'object' && state.lang === 'el' ? 'el' : 'en']} · ${tr('appVersion', v)}`), 1500);
      if (document.hidden) document.addEventListener('visibilitychange', function f() { if (!document.hidden) { document.removeEventListener('visibilitychange', f); show(); } });
      else if (document.readyState === 'complete') show(); else addEventListener('load', show, { once: true });
    }
    p.seen = v; save(p);
  })().catch(e => console.warn('updater:', e));
  if (!UPDATE_URL) return;

  async function check(now) { // now: the button — install at once; else wait for the app to go to the background
    if (navigator.onLine === false) { if (now) throw new Error('offline'); return; }
    const base = UPDATE_URL.replace(/\/?$/, '/');
    const res = await fetch(base + 'manifest.json?t=' + Date.now(), { cache: 'no-store' }); // the query skips GitHub Pages' 10-minute CDN cache
    if (!res.ok) throw new Error('manifest HTTP ' + res.status);
    const m = await res.json();
    if (!m.version || !m.url || !newer(m.version, await running()) || (m.version === load().bad && !now)) return false; // the button may retry a bad one
    const waiting = await U.getNextBundle().catch(() => null);
    if (waiting?.version === m.version && !now) return true; // already downloaded, waiting for the background
    if (now) say('updDownloading');
    const next = waiting?.version === m.version ? waiting : await U.download({ url: new URL(m.url, base).href, version: m.version, checksum: m.checksum });
    save({ ...load(), trying: m.version });
    if (now) { say('updApplying'); await U.set({ id: next.id }); return true; } // switches to the new files and reloads now
    await U.next({ id: next.id }); // the plugin swaps it in when the app next goes to the background
    return true;
  }
  let last = 0;
  const tick = () => { if (Date.now() - last < EVERY) return; last = Date.now(); check().catch(e => console.warn('updater:', e)); };
  setTimeout(tick, 3000); // after start-up's own network work
  document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); }); // an app left open for days still updates
})();
