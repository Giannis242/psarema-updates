'use strict';
// The panel shell (css/catchlog.css .pn-*) that My catches, the calendar, Plan a trip and Offline areas share; this file loads first of them.
// Wide screens: a sheet over the map, one at a time, closed by its ×, the backdrop, Escape or Back (its own history entry, so Back in the
// Android app on a tablet closes the sheet, not the app). Phones: the bottom sheet's content (js/mobile.js showHtml; its × and Back close it).
//   show(key, html, fresh) draws panel `key` in place, keeping its scroll (fresh: a new view, which also opens it) → its element, or null
//   when it is closed and not fresh; root(key) → its element while open; onClose(key, fn) runs however it closes (nothing works while closed);
//   head(key, icon, title, sub) → the one header (sub: a short micro-label line, html); openSpot(i, { fish, mode, h }) → a spot from a panel:
//   its card on the map; where(i) → a spot in words; fish(s) → its cut-out picture, or '' (css .pn-cut).
const PsPanel = window.PsPanel = (() => {
  const M = {}, hooks = {};
  let wide = '', phone = '', guard = false, eat = false; // the key shown on the wide screen / in the phone sheet; guard: our Back entry is on the history
  const root = key => wide === key ? M[key].firstChild.firstChild : document.querySelector(`#m-spot:not([hidden]) > [data-pn="${key}"]`);
  const head = (key, icon, title, sub = '') => `<header class="pn-head"><span class="pn-ic">${ic(icon)}</span><div class="pn-ttl"><h2 id="${key}-t">${esc(title)}</h2>` +
    `${sub ? `<p class="lbl pn-sub">${sub}</p>` : ''}</div><button class="icon-btn pn-x" data-pn-close aria-label="${esc(tr('close'))}">${ic('close')}</button></header>`;
  const fish = s => CUT[s?.id] ? `<img class="pn-cut" src="${esc(CUT[s.id].file)}" alt="" loading="lazy" decoding="async">` : '';
  const closed = k => { if (k) hooks[k]?.(); };
  function show(key, html, fresh) {
    let r = root(key);
    if (!r && !fresh) return null;
    if (isPhone()) {
      if (r && !fresh) { r.innerHTML = html; return r; } // in place: the sheet keeps its height and scroll
      hide(); if (phone !== key) { closed(phone); phone = key; }
      PsMobile.showHtml(`<div class="pn ${key}" data-pn="${key}">${html}</div>`);
      return root(key);
    }
    let m = M[key];
    if (!m) {
      m = M[key] = Object.assign(document.createElement('div'), { id: key + '-modal', className: 'modal pn-modal', hidden: true,
        innerHTML: `<div class="sheet glass pn-sheet"><div class="pn ${key}" data-pn="${key}"></div></div>` });
      m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true'); m.setAttribute('aria-labelledby', key + '-t');
      m.addEventListener('click', e => { if (e.target === m) close(); });
      document.body.append(m);
    }
    r = m.firstChild.firstChild;
    const top = fresh ? 0 : r.scrollTop;
    r.innerHTML = html; r.scrollTop = top;
    if (wide !== key) {
      drop(); wide = key; m.hidden = false;
      if (!guard) try { history.pushState({ psPanel: 1 }, ''); guard = true; } catch {}
    }
    return r;
  }
  function drop() { const k = wide; if (!k) return; wide = ''; M[k].hidden = true; closed(k); } // the wide screen's sheet, history untouched
  function hide() { drop(); if (guard) { guard = false; if (history.state?.psPanel) { eat = true; history.back(); } } }
  function close() { hide(); if (phone && root(phone)) PsMobile.closeSpot(); }
  // phones: the sheet shows something else now (a spot, the × , Back, a swipe): that panel is closed
  new MutationObserver(() => { if (phone && !root(phone)) { const k = phone; phone = ''; closed(k); } }).observe($('#m-spot'), { childList: true });
  addEventListener('popstate', e => { // before js/mobile.js's own listener (capture): Back closes the sheet, and our own step back is no Back
    if (eat) { eat = false; e.stopImmediatePropagation(); return; }
    if (guard && !history.state?.psPanel) { guard = false; e.stopImmediatePropagation(); drop(); }
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && wide) { e.stopImmediatePropagation(); close(); } }, true);
  document.addEventListener('click', e => { if (e.target.closest('[data-pn-close]')) close(); });
  function openSpot(i, o = {}) { // the fish, method and hour first (a toast says what changed), then the spot's card, as a tap on the map
    if (!(i >= 0) || !depth[i]) return;
    close();
    const fish = o.fish && o.fish !== 'all' && o.fish !== state.sp && byId(o.fish) ? o.fish : '', mode = o.mode && o.mode !== state.mode ? o.mode : '';
    if (fish || mode) { if (mode) state.mode = mode; if (fish) state.sp = fish; refresh(); if (mode && F) rankAll(); toast(tr('pl_showing', fishName(byId(state.sp)), tr(state.mode))); }
    if (F && o.h >= 0) setHour(o.h);
    map.setView([latOf(i), lonOf(i)], Math.max(map.getZoom(), 12)); openCell(i);
  }
  const where = i => `${describe(latOf(i), lonOf(i))} · ${depth[i]} m${habPart(i)}`; // as the score card says it
  return { show, root, close, head, fish, openSpot, where, onClose: (key, fn) => { hooks[key] = fn; } };
})();

// Psarema: My catches. A catch log kept only on this device (IndexedDB): each catch or blank trip with the conditions the model saw
// then and there, your own patterns, and an opt-in personal correction of the fishing map learned from them. Nothing is sent anywhere;
// export and import are a JSON file you save or pick. Loaded after js/mobile.js.
// Hooks: [data-ct-open="list|fish|pat|learn"] opens the journal, [data-ct-log="<cell>"] logs a catch there (-1: the open spot or where
// you are); PsCatch.correction(fishId) is the per-cell × per-hour factor model.js scoreCells multiplies in; PsCatch.row(i, h) is the
// "Your own catches" row for explain().
const PsCatch = window.PsCatch = (() => {
  const DB = 'psarema-catches', ST = 'catches', PREF = 'psarema-catch-prefs', MODES = ['boat', 'shore', 'spear'], TABS = ['list', 'fish', 'pat', 'learn'];
  const NEED_C = 5, NEED_B = 2; // trips with fish and blank trips of a fish before the map learns from them
  const pref = { learn: false, map: true };
  try { Object.assign(pref, JSON.parse(localStorage.getItem(PREF))); } catch {}
  const savePref = () => { try { localStorage.setItem(PREF, JSON.stringify(pref)); } catch {} };
  let list = [], ready = false, ver = 0, form = null, quiet = false;
  const view = { kind: 'journal', tab: 'list', fish: null, open: '' }; // fish: the journal's filter ('' = all)

  /* ---------- Storage: one IndexedDB store, photos as Blobs in the entries ---------- */
  let dbp = null;
  const db = () => dbp ||= new Promise((ok, no) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST, { keyPath: 'id' });
    r.onsuccess = () => ok(r.result); r.onerror = () => { dbp = null; no(r.error); };
  });
  const run = (mode, f) => db().then(d => new Promise((ok, no) => {
    const t = d.transaction(ST, mode), q = f(t.objectStore(ST));
    t.oncomplete = () => ok(q?.result); t.onerror = t.onabort = () => no(t.error);
  }));
  const load = () => run('readonly', s => s.getAll()).then(a => { list = a.sort((x, y) => y.t - x.t); ready = true; }, e => console.warn('Catch log unavailable:', e));
  const urls = new Map(); // entry id → object URL of its photo, made when first shown
  const photoUrl = e => { if (!e.photo) return ''; let u = urls.get(e.id); if (!u) urls.set(e.id, u = URL.createObjectURL(e.photo)); return u; };
  const dropUrl = id => { const u = urls.get(id); if (u) { URL.revokeObjectURL(u); urls.delete(id); } };

  /* ---------- Helpers ---------- */
  const lim = (x, a, b) => x < a ? a : x > b ? b : x;
  const r2 = x => x == null || !Number.isFinite(+x) ? null : Math.round(x * 100) / 100;
  const caught = e => e.n > 0;
  const fishOf = id => byId(id) || ALL_FISH;
  const tripsOf = id => id ? list.filter(e => e.sp === id || (e.sp === 'all' && !e.n)) : list; // a blank trip for "all fish" counts against every fish
  const pct = f => (f >= 1 ? '+' : '−') + Math.round(Math.abs(f - 1) * 100) + '%';
  const dtLocal = t => new Date(t - new Date(t).getTimezoneOffset() * 6e4).toISOString().slice(0, 16); // for <input type="datetime-local">
  const when = t => fmtT(t, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    ...new Date(t).getFullYear() !== new Date().getFullYear() && { year: 'numeric' } });
  function seaCell(la, lo) { // the cell to score: the place itself, or the nearest sea within ~1 km (shore anglers stand on land)
    const i0 = idxAt(la, lo); if (i0 < 0) return -1;
    if (depth[i0] && !northMask[i0]) return i0;
    const x0 = i0 % W, y0 = i0 / W | 0; let best = -1, bd = 1e9;
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = x0 + dx, y = y0 + dy, j = y * W + x, d = dx * dx + dy * dy;
      if (x >= 0 && y >= 0 && x < W && y < H && depth[j] && !northMask[j] && d < bd) { bd = d; best = j; }
    }
    return best;
  }
  function sky(t) { // time of day and moon for any date (buildHours' rules), when the forecast does not cover it
    const d = new Date(t), sun = SunCalc.getTimes(d, ...CENTER), m = SunCalc.getMoonIllumination(d), rise = +sun.sunrise, set = +sun.sunset;
    const period = t >= rise - 36e5 && t <= rise + 54e5 ? 'dawn' : t >= set - 54e5 && t <= set + 36e5 ? 'dusk' : t > rise && t < set ? 'day' : 'night';
    return { period, illum: r2(m.fraction), phase: r2(m.phase), local: numT(t, { hour: 'numeric', hourCycle: 'h23' }) };
  }
  const hourOf = t => { if (!F || !hours.length) return -1; const h = Math.floor((t - hours[0].t) / 36e5); return h >= 0 && h < hours.length ? h : -1; };
  // The conditions then and there as the model saw them, without the personal part. Another fish or method is prepared for this one
  // cell and swapped in while explain() runs (it reads sp, cur and state.mode), then put back.
  function snapshot(s, mode, i, t) {
    const o = { ...sky(t), depth: depth[i], dist: r2(dist[i]) }, h = hourOf(t);
    if (h < 0) return o;
    const x = hours[h], k = h * NN, keep = [sp, cur, state.mode], swap = s !== sp || mode !== state.mode;
    quiet = true;
    try {
      if (swap) { sp = s; state.mode = mode; cur = prepare(s, mode, [i]); }
      const { score, rows } = explain(i, h), q = {};
      scoreAt(i, h, q);
      Object.assign(o, { score, rows: rows.map(r => [r[0], String(r[1]), r2(r[2]), r2(r[3])]), ws: r2(q.ws), wsEff: r2(q.wsEff), gust: r2(bil(F.gust, k, i)),
        wdir: Math.round(F.windDir[k + nearestNode(i)]), wave: r2(q.wave), wEff: r2(q.wEff), cur: r2(q.cur), sst: r2(sat.sst ? sat.sst[i] : bil(F.sst, k, i)),
        dp: r2(x.dp), cloud: Math.round(x.cloud), solunar: x.solunar, illum: r2(x.illum), period: x.period });
    } catch (err) { console.warn('Catch conditions:', err); }
    finally { quiet = false; if (swap) [sp, cur, state.mode] = keep; }
    return o;
  }

  /* ---------- Learning: a small personal correction of one fish's map ---------- */
  // Each trip's outcome minus your own catch rate R (a catch +, a blank −) is spread over (1) the sea within ~2.4 km of its spot, a
  // Gaussian of 0.8 km, and (2) every cell of alike depth (log scale) and rock / seagrass cover, at a quarter weight (a few trips at one
  // reef say more about that reef than about all rock at that depth); and over every hour of the same time of day, moon light and pressure
  // trend. Each cell or hour gets Σ w·r / (Σ w + K0): with little evidence it shrinks to 0. The factor is 1 + strength × that, capped:
  // places −20%…+25%, hours ±12%. Pure: the same log gives the same arrays.
  const SIG = .8, CUT = 2.4, HAB_W = .25, K0 = 5, A_CELL = .8, A_HOUR = .6;
  const onSea = trips => trips.filter(e => e.cell >= 0 && depth[e.cell]);
  const enough = trips => { const E = onSea(trips), c = E.filter(caught).length; return c >= NEED_C && E.length - c >= NEED_B; }; // learn() would answer
  function learn(trips) {
    const E = onSea(trips), nC = E.filter(caught).length, nB = E.length - nC;
    if (nC < NEED_C || nB < NEED_B) return null;
    const R = (nC + 1) / (E.length + 2), res = E.map(e => (caught(e) ? 1 : 0) - R);
    const S = new Float32Array(N), Wt = new Float32Array(N), rx = Math.ceil(CUT / KX), ry = Math.ceil(CUT / KY);
    E.forEach((e, k) => {
      const cx = e.cell % W, cy = e.cell / W | 0;
      for (let y = Math.max(0, cy - ry); y <= Math.min(H - 1, cy + ry); y++) for (let x = Math.max(0, cx - rx); x <= Math.min(W - 1, cx + rx); x++) {
        const d2 = ((x - cx) * KX) ** 2 + ((y - cy) * KY) ** 2; if (d2 > CUT * CUT) continue;
        const j = y * W + x, w = Math.exp(-d2 / (2 * SIG * SIG)); S[j] += w * res[k]; Wt[j] += w;
      }
    });
    const feat = c => [Math.log1p(dFit[c]), (habK[c] / 11 | 0) % 11 / 10, habK[c] % 11 / 10], fe = E.map(e => feat(e.cell));
    const pair = new Map(), cell = new Float32Array(N).fill(1); // the seabed part depends only on the (depth, seabed) pair: once per pair
    let lo = 1, hi = 1, moved = 0;
    for (let i = 0; i < N; i++) {
      if (!depth[i] || northMask[i]) continue;
      const key = dFit[i] * NHK + habK[i]; let p = pair.get(key);
      if (!p) {
        const [ld, r, g] = feat(i); let s = 0, w = 0;
        fe.forEach(([ld0, r0, g0], k) => { const v = HAB_W * Math.exp(-((ld - ld0) ** 2) / .18) * Math.max(0, 1 - .5 * (Math.abs(r - r0) + Math.abs(g - g0))); s += v * res[k]; w += v; });
        pair.set(key, p = [s, w]);
      }
      const f = cell[i] = lim(1 + A_CELL * (S[i] + p[0]) / (Wt[i] + p[1] + K0), .8, 1.25);
      if (f < lo) lo = f; if (f > hi) hi = f; if (Math.abs(f - 1) > .05) moved++;
    }
    const hour = Float32Array.from(hours, x => {
      let s = 0, w = 0;
      E.forEach((e, k) => {
        const q = e.snap; if (!q?.period || q.illum == null) return;
        const v = (q.period === x.period ? 1 : .3) * Math.exp(-((x.illum - q.illum) ** 2) / .125) * (q.dp == null ? 1 : Math.exp(-((x.dp - q.dp) ** 2) / 8));
        s += v * res[k]; w += v;
      });
      return lim(1 + A_HOUR * s / (w + K0), .88, 1.12);
    });
    let hlo = 1, hhi = 1; for (const v of hour) { if (v < hlo) hlo = v; if (v > hhi) hhi = v; }
    return { cell, hour, max: hi * hhi, lo, hi, hlo, hhi, km2: moved * KX * KY, nC, nB };
  }
  const memo = new Map(); let memoKey = null;
  function stats(id, lazy) { // learn(id), kept until the log or the forecast hours change; lazy: undefined until it is worked out
    if (!ready || id === 'all') return null;
    if (memoKey?.[0] !== ver || memoKey[1] !== hours) { memo.clear(); memoKey = [ver, hours]; }
    if (!memo.has(id)) { if (lazy && enough(tripsOf(id))) return undefined; memo.set(id, learn(tripsOf(id))); }
    return memo.get(id);
  }
  function check() { // PsCatch.check() in the console: catches lift their spot, blanks lower theirs, more trips move it more, too few move nothing
    const sea = SAMPLE.filter(i => dFit[i] > 10 && dFit[i] < 60), a = sea[50], b = sea[sea.length - 50];
    const trips = (c, nb) => [...Array(c)].map(() => ({ cell: a, n: 1, snap: { period: 'dawn', illum: .5, dp: 0 } })).concat([...Array(nb)].map(() => ({ cell: b, n: 0, snap: { period: 'day', illum: .5, dp: 0 } })));
    const few = learn(trips(5, 2)), many = learn(trips(20, 8)), dawn = hours.findIndex(x => x.period === 'dawn'), day = hours.findIndex(x => x.period === 'day');
    console.assert(!learn(trips(4, 2)) && !learn(trips(5, 1)), 'needs 5 trips with fish and 2 blank');
    console.assert(few.cell[a] > 1.05 && few.cell[b] < .95 && many.cell[a] >= few.cell[a] && many.cell[b] <= few.cell[b], 'catches lift, blanks lower, more trips more');
    console.assert(many.lo >= .8 && many.hi <= 1.25 && many.max <= 1.25 * 1.12 + 1e-6, 'capped');
    console.assert(dawn < 0 || day < 0 || few.hour[dawn] > 1 && few.hour[day] < 1, 'hours like the catches lift');
    return [few, many].map(r => [r.cell[a], r.cell[b]].map(v => +v.toFixed(3)));
  }
  const correction = id => pref.learn && !quiet && hours.length ? stats(id) : null;
  function row(i, h) { // explain()'s row: key, text, fit 0..1 (0.5 = no change), weight
    const c = correction(sp.id); if (!c) return [];
    const f = c.cell[i] * c.hour[h];
    return [['f_mine', tr('ct_rowVal', nf(f, 2), c.nC, c.nB), lim((f - .75) / .5, 0, 1), 1]];
  }

  /* ---------- On the map: the catches, and a note in the legend while your catches shape it ---------- */
  const layer = L.layerGroup();
  function drawLayer() {
    layer.clearLayers();
    if (!pref.map || !list.length) { layer.remove(); return; }
    for (const e of [...list].reverse()) L.circleMarker([e.lat, e.lon], { pane: 'spots', radius: caught(e) ? 6 : 5, weight: 2, color: caught(e) ? '#0d3321' : '#e6e6e6',
      fillColor: caught(e) ? '#4fd18b' : '#555', fillOpacity: .95 })
      .bindTooltip(() => `${esc(caught(e) ? fishName(fishOf(e.sp)) + (e.n > 1 ? ' ×' + e.n : '') : tr('ct_blankOf', fishName(fishOf(e.sp))))} · ${esc(when(e.t))}`, { direction: 'top', offset: [0, -6] })
      .on('click', ev => { L.DomEvent.stopPropagation(ev); openEntry(e.id); }).addTo(layer);
    layer.addTo(map);
  }
  let badge = null;
  function drawBadge() {
    badge ||= $('#map-legend')?.appendChild(Object.assign(document.createElement('button'), { className: 'ct-badge', type: 'button' }));
    if (!badge) return;
    const c = correction(sp.id);
    badge.hidden = !c; badge.dataset.ctOpen = 'learn'; badge.title = tr('ct_learnOn');
    if (c) badge.innerHTML = `${ic('star', 'sm')}<span>${esc(tr('ct_badge'))}</span><small>${pct(c.lo * c.hlo)}…${pct(c.hi * c.hhi)}</small>`;
  }
  function changed(rescore) { // the log or the learning switch changed: the markers, the legend note, the map's scores, an open view
    ver++; drawLayer(); drawBadge();
    if (rescore && pref.learn && F) { refresh(); rankAll(); }
    if (isOpen()) draw();
  }

  /* ---------- The view: the shared panel (PsPanel above) ---------- */
  const isOpen = () => !!PsPanel.root('ct');
  PsPanel.onClose('ct', () => { if (form?.url) URL.revokeObjectURL(form.url); form = null; });
  const close = () => { if (isOpen()) PsPanel.close(); };
  const draw = fresh => (fresh || isOpen()) && PsPanel.show('ct', view.kind === 'log' && form ? logHtml() : journalHtml(), fresh); // fresh: another view (the form, the journal)
  const chip = (act, v, on, label) => `<button type="button" data-ct="${act}" data-v="${v}" aria-pressed="${on}">${label}</button>`;

  /* ---------- Logging a catch: everything has a default, so it is Log catch → Save ---------- */
  function log(i) {
    if (form?.url) URL.revokeObjectURL(form.url);
    const at = i >= 0 ? i : sel.i, gps = fix && { k: 'ct_gps', la: fix[0], lo: fix[1] }, spot = at >= 0 && depth[at] && { k: 'ct_spot', la: latOf(at), lo: lonOf(at) };
    // where you are first; a spot you opened over a km away first instead (you are logging that spot, not your position)
    const places = (gps && spot && km([gps.la, gps.lo], [spot.la, spot.lo]).d > 1 ? [spot, gps] : [gps, spot]).filter(Boolean);
    if (!places.length && state.loc) places.push({ k: 'ct_loc', la: state.loc[0], lo: state.loc[1] });
    if (!places.length) { const c = map.getCenter(); places.push({ k: 'ct_mapc', la: c.lat, lo: c.lng }); }
    form = { got: true, sp: state.sp, target: state.sp, count: 1, mode: state.mode, places, place: 0, time: dtLocal(Date.now()), note: '', photo: null, url: '', busy: false };
    if (form.sp === 'all') form.sp = defaultFish();
    view.kind = 'log'; draw(true);
  }
  function defaultFish() { // for "all fish": the likeliest fish at the place
    const p = form.places[form.place], i = seaCell(p.la, p.lo);
    return (i >= 0 && likelyAt(i, form.mode, 1)[0]?.id) || SPECIES[0].id;
  }
  const fishOpts = (id, withAll) => (withAll ? [ALL_FISH] : []).concat([...SPECIES].sort((a, b) => fishName(a).localeCompare(fishName(b), locale())))
    .map(s => `<option value="${s.id}"${s.id === id ? ' selected' : ''}>${esc(fishName(s))}</option>`).join('');
  function logHtml() {
    const f = form, p = f.places[f.place], i = seaCell(p.la, p.lo);
    return PsPanel.head('ct', 'plus', tr('ct_logTitle'), esc(tr('ct_my'))) +
      `<div class="seg ct-got">${chip('got', 1, f.got, ic('fish', 'sm') + `<span>${tr('ct_caught')}</span>`)}${chip('got', 0, !f.got, ic('minus', 'sm') + `<span>${tr('ct_blank')}</span>`)}</div>` +
      (f.got ? '' : `<p class="hint">${esc(tr('ct_blankWhy'))}</p>`) +
      `<label class="pn-row"><span class="k">${tr(f.got ? 'ct_fish' : 'ct_target')}</span><span class="ct-fishrow"><select data-ct-f="sp">${fishOpts(f.sp, !f.got)}</select>` +
      (f.got ? `<input type="number" inputmode="numeric" min="1" max="999" value="${f.count}" data-ct-f="count" aria-label="${esc(tr('ct_count'))}" title="${esc(tr('ct_count'))}">` : '') + `</span></label>` +
      `<div class="pn-row"><span class="k">${tr('ct_method')}</span><div class="seg">${MODES.map(m => chip('mode', m, f.mode === m, ic(m, 'sm') + `<span>${tr(m)}</span>`)).join('')}</div></div>` +
      `<div class="pn-row"><span class="k">${tr('ct_place')}</span><div class="chips">${f.places.map((q, k) => chip('place', k, f.place === k, tr(q.k))).join('')}</div></div>` +
      `<p class="hint pn-indent">${esc(i >= 0 ? PsPanel.where(i) : describe(p.la, p.lo))}${p.k === 'ct_mapc' ? '<br>' + esc(tr('ct_mapcHint')) : ''}</p>` +
      `<label class="pn-row"><span class="k">${tr('ct_time')}</span><input type="datetime-local" value="${f.time}" max="${dtLocal(Date.now())}" data-ct-f="time"></label>` +
      `<div class="pn-row"><span class="k">${tr('ct_photo')}</span><span class="ct-photo-row">` +
      (f.url ? `<img src="${f.url}" alt=""><button type="button" class="btn ghost" data-ct="nophoto">${ic('close', 'sm')}${tr('ct_noPhoto')}</button>`
        : f.busy ? `<span class="hint">…</span>` : `<label class="btn">${tr('ct_camera')}<input type="file" accept="image/*" capture="environment" data-ct-photo hidden></label>` +
        `<label class="btn">${tr('ct_gallery')}<input type="file" accept="image/*" data-ct-photo hidden></label>`) + `</span></div>` +
      `<input class="ct-noteIn" type="text" maxlength="300" value="${esc(f.note)}" placeholder="${esc(tr('ct_note'))}" aria-label="${esc(tr('ct_note'))}" data-ct-f="note">` +
      `<div class="pn-acts ct-save"><button type="button" class="btn ghost" data-ct="close">${tr('ct_cancel')}</button><button type="button" class="btn primary" data-ct="save"${f.busy ? ' disabled' : ''}>${ic('check', 'sm')}${tr('ct_save')}</button></div>`;
  }
  async function shrink(file) { // ~800 px on the long side as JPEG: a phone photo is 3–8 MB, this ~100 KB
    const b = await createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => createImageBitmap(file));
    const k = Math.min(1, 800 / Math.max(b.width, b.height)), c = Object.assign(document.createElement('canvas'), { width: Math.round(b.width * k), height: Math.round(b.height * k) });
    c.getContext('2d').drawImage(b, 0, 0, c.width, c.height); b.close?.();
    return new Promise((ok, no) => c.toBlob(x => x ? ok(x) : no(new Error('no JPEG')), 'image/jpeg', .82));
  }
  async function addPhoto(file) {
    const f = form; f.busy = true; draw();
    try { const b = await shrink(file); if (form !== f) return; if (f.url) URL.revokeObjectURL(f.url); f.photo = b; f.url = URL.createObjectURL(b); }
    catch (err) { console.warn('Photo:', err); toast(tr('ct_photoErr')); }
    if (form === f) { f.busy = false; draw(); }
  }
  async function save() {
    const f = form; if (!f || f.busy) return;
    const p = f.places[f.place], t = Math.min(Date.now(), new Date(f.time).getTime() || Date.now()), i = seaCell(p.la, p.lo), s = fishOf(f.sp);
    const was = enough(tripsOf(f.sp)), e = { id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), t, sp: s.id, mode: f.mode, lat: +p.la.toFixed(5), lon: +p.lo.toFixed(5),
      cell: i, n: f.got ? lim(Math.round(+f.count) || 1, 1, 999) : 0, note: f.note.trim().slice(0, 300), photo: f.photo, snap: i >= 0 ? snapshot(s, f.mode, i, t) : sky(t) };
    try { await run('readwrite', st => st.put(e)); } catch (err) { console.warn(err); toast(tr('ct_saveErr')); return; }
    list.push(e); list.sort((a, b) => b.t - a.t);
    close(); changed(true);
    toast(!was && !pref.learn && enough(tripsOf(e.sp)) ? tr('ct_canLearn', fishName(s)) : tr('ct_saved', fishName(s), tripsOf(e.sp === 'all' ? '' : e.sp).length));
  }

  /* ---------- The journal: list, by fish, your patterns, learning ---------- */
  function open(tab) {
    view.kind = 'journal'; view.tab = TABS.includes(tab) ? tab : 'list'; view.open = '';
    view.fish ??= tripsOf(state.sp === 'all' ? '' : state.sp).length ? (state.sp === 'all' ? '' : state.sp) : '';
    draw(true);
  }
  function openEntry(id) {
    Object.assign(view, { kind: 'journal', tab: 'list', fish: '', open: id }); draw(true);
    requestAnimationFrame(() => document.querySelector(`.ct-item[data-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: 'nearest' }));
  }
  const loggedFish = () => [...new Set(list.map(e => e.sp))].filter(id => id !== 'all' && byId(id)).sort((a, b) => fishName(byId(a)).localeCompare(fishName(byId(b)), locale()));
  function journalHtml() {
    const nc = list.filter(caught).length;
    const top = PsPanel.head('ct', 'fish', tr('ct_my'), list.length ? esc(tr('ct_summary', list.length, nc, list.length - nc)) : '') +
      `<div class="pn-acts ct-tools"><button type="button" class="btn primary" data-ct="log">${ic('plus', 'sm')}${tr('ct_log')}</button>` +
      `<label class="btn ghost"><input type="checkbox" data-ct-map${pref.map ? ' checked' : ''}>${tr('ct_onMap')}</label>` +
      `<button type="button" class="btn ghost" data-ct="export"${list.length ? '' : ' disabled'}>${ic('share', 'sm')}${tr('ct_export')}</button>` +
      `<label class="btn ghost">${tr('ct_import')}<input type="file" accept=".json,application/json" data-ct-import hidden></label></div>`;
    const priv = `<p class="pn-note">${ic('shield', 'sm')}<span>${esc(tr('ct_private'))}</span></p>`;
    if (!list.length) return top + `<p class="empty">${ic('fish')}<span>${esc(tr('ct_empty'))}</span></p>` + priv;
    const ids = loggedFish(), filt = view.tab === 'list' || view.tab === 'pat';
    if (view.fish && !ids.includes(view.fish)) view.fish = '';
    return top + `<div class="pn-tabs ct-tabs" role="group">${TABS.map(k => chip('tab', k, view.tab === k, tr('ct_t_' + k))).join('')}</div>` +
      (filt ? `<select class="ct-filter" data-ct-filter aria-label="${esc(tr('ct_fish'))}"><option value="">${esc(fishName(ALL_FISH))}</option>${ids.map(id =>
        `<option value="${id}"${id === view.fish ? ' selected' : ''}>${esc(fishName(byId(id)))}</option>`).join('')}</select>` : '') +
      ({ list: listTab, fish: fishTab, pat: patTab, learn: learnTab })[view.tab]() + priv;
  }
  const listTab = () => `<div class="pn-list">${tripsOf(view.fish).map(itemHtml).join('')}</div>`;
  function itemHtml(e) { // the one list row (css/catchlog.css .pn-line): your photo or the fish's cut-out, what, when and where, the score then (a dial); opens to the conditions
    const s = fishOf(e.sp), u = photoUrl(e), q = e.snap, id = esc(e.id);
    const title = caught(e) ? esc(fishName(s)) + (e.n > 1 ? ` ×${e.n}` : '') : esc(tr('ct_blankOf', fishName(s)));
    return `<details class="pn-item ct-item${caught(e) ? '' : ' blank'}" data-id="${id}"${view.open === e.id ? ' open' : ''}><summary class="pn-line">` +
      `<span class="ct-thumb">${u ? `<img src="${u}" alt="" loading="lazy">` : PsPanel.fish(s) || ic(caught(e) ? 'fish' : 'minus')}</span>` +
      `<span class="pn-main"><b>${title}</b><small>${esc(when(e.t))} · ${esc(tr(e.mode))}</small><small>${esc(e.cell >= 0 ? PsPanel.where(e.cell) : describe(e.lat, e.lon))}</small></span>` +
      `${q?.score != null ? ring(q.score) : ''}</summary><div class="pn-body">${u ? `<img class="ct-photo" src="${u}" alt="">` : ''}${condHtml(q)}` +
      `${e.note ? `<p class="ct-note selectable">${esc(e.note)}</p>` : ''}<div class="pn-acts"><button type="button" class="btn" data-ct="goto" data-id="${id}">${ic('map', 'sm')}${tr('ct_show')}</button>` +
      `<button type="button" class="btn ghost" data-ct="del" data-id="${id}">${ic('trash', 'sm')}${tr('ct_del')}</button></div></div></details>`;
  }
  function condHtml(q) { // what the conditions were, and why the map rated the place as it did then (ui.js reasons)
    if (!q) return '';
    const K = tr('ct_k'), rows = [
      [K.time, [tr(q.period), q.solunar && tr('solShort')[q.solunar]].filter(Boolean).join(' · ')],
      q.wsEff != null && [K.wind, `${q.wdir != null ? compass(q.wdir) + ' ' : ''}${Math.round(q.wsEff)} km/h${q.gust != null ? ` · ${tr('ct_gust')} ${Math.round(q.gust)}` : ''}`],
      q.wEff != null && [K.waves, `${nf(q.wEff)} m`], q.sst != null && [K.water, `${nf(q.sst)} °C`],
      q.illum != null && [K.moon, `${Math.round(q.illum * 100)}%`], q.dp != null && [K.press, `${q.dp > .05 ? '+' : ''}${nf(q.dp)} hPa/24h`],
      q.depth && [K.depth, `${q.depth} m`]].filter(Boolean);
    const why = q.rows?.length ? reasons(q.rows) : [];
    return `<dl class="kv-list">${rows.map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join('')}</dl>` +
      (q.score != null ? `<p class="hint">${esc(tr('ct_scoreThen', q.score, rating(q.score)))}</p>` : `<p class="hint">${esc(tr('ct_noCond'))}</p>`) +
      (why.length ? `<ul class="reasons">${why.map(reasonLi).join('')}</ul>` : '');
  }
  const spotKey = e => Math.round(e.lat / .02) + ',' + Math.round(e.lon / .02); // ~2 km squares
  function fishTab() {
    const rows = loggedFish().map(id => {
      const T = tripsOf(id), C = T.filter(caught), own = C.reduce((a, e) => a + e.n, 0), spots = new Map();
      for (const e of C) spots.set(spotKey(e), [...spots.get(spotKey(e)) || [], e]);
      const best = [...spots.values()].sort((a, b) => b.length - a.length)[0]?.[0];
      return `<tr><td>${esc(fishName(byId(id)))}</td><td class="n">${T.length}</td><td class="n">${own}</td><td class="n">${T.length - C.length}</td>` +
        `<td class="n">${Math.round(C.length / T.length * 100)}%</td><td>${best ? esc(describe(best.lat, best.lon)) : '–'}</td><td>${C[0] ? esc(fmtT(C[0].t, { day: 'numeric', month: 'short' })) : '–'}</td></tr>`;
    });
    const h = tr('ct_h');
    return `<div class="ct-scroll"><table class="ct-table"><thead><tr>${h.map(x => `<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  }
  // Your patterns: trips with fish against blank trips under each condition. Counts as they are; a bucket is marked better or worse than
  // your average only with 3+ trips and when its rate, pulled 2 trips' worth toward your average, still differs by 15 points.
  const DIMS = [
    ['time', q => q?.period, ['dawn', 'day', 'dusk', 'night'], k => tr(k)],
    ['moon', q => q?.illum == null ? null : q.illum < .25 ? 'new' : q.illum > .75 ? 'full' : 'half', ['new', 'half', 'full']],
    ['press', q => q?.dp == null ? null : q.dp < -1 ? 'fall' : q.dp > 1 ? 'rise' : 'steady', ['fall', 'steady', 'rise']],
    ['wind', q => q?.wsEff == null ? null : q.wsEff < 10 ? 'calm' : q.wsEff < 20 ? 'light' : q.wsEff < 30 ? 'fresh' : 'strong', ['calm', 'light', 'fresh', 'strong']],
    ['waves', q => q?.wEff == null ? null : q.wEff < .3 ? 'flat' : q.wEff < .8 ? 'slight' : 'rough', ['flat', 'slight', 'rough']],
    ['sol', q => q?.score == null ? null : q.solunar || 'none', ['major', 'minor', 'none']],
  ];
  function bar(label, c, n, R) {
    const s = (c + 2 * R) / (n + 2), tag = n < 3 ? ['', 'ct_fewRow'] : s >= R + .15 ? ['up', 'ct_better'] : s <= R - .15 ? ['down', 'ct_worse'] : null;
    return `<div class="ct-bar"><span class="ct-bl">${esc(label)}</span><span class="ct-track"><i style="width:${Math.round(c / n * 100)}%"></i></span>` +
      `<span class="ct-bn">${esc(tr('ct_of', c, n))}${tag ? ` <em class="${tag[0]}">${esc(tr(tag[1]))}</em>` : ''}</span></div>`;
  }
  function patTab() {
    const T = tripsOf(view.fish), nc = T.filter(caught).length, R = nc / T.length, B = tr('ct_b'), D = tr('ct_dims');
    const sec = (title, rows) => rows.length ? `<section class="ct-sec"><h3>${esc(title)}</h3>${rows.join('')}</section>` : '';
    const count = (key, ks, label) => ks.map(k => { const g = T.filter(e => key(e) === k); return g.length ? bar(label(k), g.filter(caught).length, g.length, R) : ''; }).filter(Boolean);
    const spots = new Map(); for (const e of T) spots.set(spotKey(e), [...spots.get(spotKey(e)) || [], e]);
    const top = [...spots.values()].sort((a, b) => b.length - a.length).slice(0, 6);
    return (T.length < 10 ? `<p class="ct-warn">${ic('warning', 'sm')}<span>${esc(tr('ct_few', T.length))}</span></p>` : '') +
      `<p class="hint">${esc(tr('ct_avg', Math.round(R * 100), T.length))}</p>` +
      DIMS.map(([k, f, ks, label = x => B[x]]) => sec(D[k], count(e => f(e.snap), ks, label))).join('') +
      sec(D.method, count(e => e.mode, MODES, m => tr(m))) +
      sec(D.spot, top.map(g => bar(describe(g[0].lat, g[0].lon), g.filter(caught).length, g.length, R)));
  }
  let learning = 0;
  function learnTab() { // each fish's learning pass (~30 ms on a desktop) in a task of its own: the tab opens at once and fills in
    const rows = loggedFish().map(id => {
      const T = tripsOf(id).filter(e => e.cell >= 0), c = T.filter(caught).length, b = T.length - c, st = stats(id, true), on = st && pref.learn;
      if (st === undefined) { learning ||= setTimeout(() => { learning = 0; stats(id); if (view.kind === 'journal' && view.tab === 'learn') draw(); }); return `<tr><td>${esc(fishName(byId(id)))}</td><td class="n">${c}</td><td class="n">${b}</td><td>…</td></tr>`; }
      const text = !st ? tr('ct_need', Math.max(0, NEED_C - c), Math.max(0, NEED_B - b))
        : tr(on ? 'ct_changes' : 'ct_would', pct(st.lo), pct(st.hi), nf(st.km2, 0), hours.length ? Math.round(Math.max(st.hhi - 1, 1 - st.hlo) * 100) : 0);
      return `<tr class="${st ? on ? 'on' : 'ready' : ''}"><td>${esc(fishName(byId(id)))}</td><td class="n">${c}</td><td class="n">${b}</td><td>${esc(text)}</td></tr>`;
    });
    const h = tr('ct_hl');
    return `<label class="pn-check ct-switch"><input type="checkbox" data-ct-learn${pref.learn ? ' checked' : ''}><span><b>${esc(tr('ct_learn'))}</b><small>${esc(tr('ct_learnSub'))}</small></span></label>` +
      `<p>${esc(tr('ct_learnWhat'))}</p><p class="hint">${esc(tr('ct_learnHow'))}</p>` +
      `<div class="ct-scroll"><table class="ct-table"><thead><tr>${h.map(x => `<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  }

  /* ---------- Export, import, delete ---------- */
  const toData = b => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(r.error); r.readAsDataURL(b); });
  async function exportFile() { // a JSON file with the photos inline, saved by the browser like any download
    try {
      const catches = await Promise.all(list.map(async e => ({ ...e, photo: e.photo ? await toData(e.photo) : null })));
      const name = `psarema-catches-${new Date().toISOString().slice(0, 10)}.json`, json = JSON.stringify({ app: 'psarema-catches', v: 1, at: Date.now(), catches });
      if (await window.PsNative?.saveFile?.(name, json, 'application/json')) return; // the Android app: written to its cache, then the share sheet (a WebView ignores downloads)
      const a = Object.assign(document.createElement('a'), { download: name, href: URL.createObjectURL(new Blob([json], { type: 'application/json' })) });
      document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 3e4);
    } catch (err) { console.warn(err); toast(tr('ct_exportErr')); }
  }
  const num = (x, a, b) => typeof x === 'number' && x >= a && x <= b ? x : null;
  const SNAP_NUM = ['score', 'depth', 'dist', 'ws', 'wsEff', 'gust', 'wdir', 'wave', 'wEff', 'cur', 'sst', 'dp', 'cloud', 'illum', 'phase', 'local'];
  function clean(e) { // an imported entry: only known fields of the right kind; the cell is worked out again from the position
    if (!e || typeof e.id !== 'string' || !/^[\w-]{1,40}$/.test(e.id)) return null;
    const t = num(e.t, 0, Date.now() + 864e5), la = num(e.lat, 33.5, 36.5), lo = num(e.lon, 31, 35.5), n = num(e.n, 0, 999);
    if (t == null || la == null || lo == null || n == null || !(e.sp === 'all' || byId(e.sp)) || !MODES.includes(e.mode)) return null;
    const q = e.snap && typeof e.snap === 'object' ? e.snap : {}, snap = {};
    for (const k of SNAP_NUM) if (Number.isFinite(q[k])) snap[k] = q[k];
    if (['dawn', 'day', 'dusk', 'night'].includes(q.period)) snap.period = q.period;
    if (['major', 'minor', ''].includes(q.solunar)) snap.solunar = q.solunar;
    if (Array.isArray(q.rows)) snap.rows = q.rows.filter(r => Array.isArray(r) && /^f_[a-z_]+$/.test(r[0]) && Number.isFinite(r[2]) && Number.isFinite(r[3])).map(r => [r[0], String(r[1]).slice(0, 120), r[2], r[3]]);
    const m = typeof e.photo === 'string' && /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(e.photo);
    return { id: e.id, t, sp: e.sp, mode: e.mode, lat: la, lon: lo, cell: seaCell(la, lo), n: Math.round(n), note: typeof e.note === 'string' ? e.note.slice(0, 300) : '',
      photo: m ? new Blob([b64(m[2])], { type: m[1] }) : null, snap };
  }
  async function importFile(file) {
    let good;
    try { const d = JSON.parse(await file.text()); if (d?.app !== 'psarema-catches' || !Array.isArray(d.catches)) throw new Error('not a catch log'); good = d.catches.map(clean).filter(Boolean); }
    catch (err) { console.warn(err); toast(tr('ct_badFile')); return; }
    try { await run('readwrite', s => { for (const e of good) s.put(e); }); } catch (err) { console.warn(err); toast(tr('ct_saveErr')); return; }
    good.forEach(e => dropUrl(e.id)); await load(); changed(true); toast(tr('ct_imported', good.length));
  }
  async function del(id) {
    if (!confirm(tr('ct_delAsk'))) return;
    try { await run('readwrite', s => s.delete(id)); } catch (err) { console.warn(err); toast(tr('ct_saveErr')); return; }
    dropUrl(id); list = list.filter(e => e.id !== id); changed(true);
  }
  function goto(id) { // the catch's spot with its card, for its fish and method, at its hour while the forecast still covers it
    const e = list.find(x => x.id === id); if (!e) return;
    if (!pref.map) { pref.map = true; savePref(); drawLayer(); }
    if (e.cell >= 0 && F) { PsPanel.openSpot(e.cell, { fish: e.sp, mode: e.mode, h: hourOf(e.t) }); return; }
    close(); // on land, far from the sea: the place itself
    map.fitBounds(L.latLng(e.lat, e.lon).toBounds(1500), isPhone() ? PsMobile.pad() : { paddingTopLeft: [railOpen ? 350 : 20, 60] });
  }

  /* ---------- Events ---------- */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-ct-open], [data-ct-log], [data-ct]'); if (!t || t.disabled) return;
    if (t.dataset.ctOpen != null) { open(t.dataset.ctOpen); return; }
    if (t.dataset.ctLog != null) { log(+t.dataset.ctLog); return; }
    const v = t.dataset.v, f = form;
    switch (t.dataset.ct) {
      case 'close': close(); break;
      case 'got': f.got = v === '1'; if (!f.got && f.target === 'all') f.sp = 'all'; if (f.got && f.sp === 'all') f.sp = defaultFish(); draw(); break;
      case 'mode': f.mode = v; draw(); break;
      case 'place': f.place = +v; draw(); break;
      case 'nophoto': URL.revokeObjectURL(f.url); f.photo = null; f.url = ''; draw(); break;
      case 'save': save(); break;
      case 'log': log(-1); break;
      case 'tab': view.tab = v; draw(true); break;
      case 'export': exportFile(); break;
      case 'goto': goto(t.dataset.id); break;
      case 'del': del(t.dataset.id); break;
    }
  });
  const onField = e => { const k = e.target.dataset?.ctF; if (k && form) form[k] = e.target.value; };
  document.addEventListener('input', onField);
  document.addEventListener('change', e => {
    const t = e.target; onField(e);
    if (t.matches('[data-ct-photo]') && t.files[0] && form) addPhoto(t.files[0]);
    else if (t.matches('[data-ct-import]') && t.files[0]) importFile(t.files[0]);
    else if (t.matches('[data-ct-filter]')) { view.fish = t.value; draw(); }
    else if (t.matches('[data-ct-map]')) { pref.map = t.checked; savePref(); drawLayer(); }
    else if (t.matches('[data-ct-learn]')) { pref.learn = t.checked; savePref(); changed(true); if (!pref.learn && F) { refresh(); rankAll(); } toast(tr(pref.learn ? 'ct_learnOn' : 'ct_learnOff')); }
  });

  document.addEventListener('click', e => { if (e.target.closest('#lang [data-lang]')) setTimeout(() => { drawBadge(); if (isOpen()) draw(); }); }); // after ui.js applies the language
  new MutationObserver(() => drawBadge()).observe($('#fish-current'), { childList: true }); // ui.js drawFishPanel: another fish (or the forecast's hours)

  load().then(() => changed(pref.learn));
  return { open, log, correction, row, stats, check, get entries() { return list; } };
})();
