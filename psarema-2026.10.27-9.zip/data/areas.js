// Fishing areas of the Republic's coast, for area summaries (conditions, best times, gear). Centre and radius in km;
// a cell belongs to the nearest area centre within its radius. Names: English / Greek.
window.PSAREMA_AREAS = [
  { id: 'pomos', en: 'Pomos – Kato Pyrgos', el: 'Πωμός – Κάτω Πύργος', lat: 35.155, lon: 32.62, r: 12 },
  { id: 'polis', en: 'Polis – Latchi', el: 'Πόλις – Λατσί', lat: 35.05, lon: 32.42, r: 10 },
  { id: 'akamas', en: 'Akamas', el: 'Ακάμας', lat: 35.0, lon: 32.29, r: 9 },
  { id: 'paphos', en: 'Paphos – Coral Bay', el: 'Πάφος – Κοράλ Μπέι', lat: 34.80, lon: 32.38, r: 14 },
  { id: 'pissouri', en: 'Petra tou Romiou – Pissouri', el: 'Πέτρα του Ρωμιού – Πισσούρι', lat: 34.66, lon: 32.68, r: 13 },
  { id: 'akrotiri', en: 'Akrotiri – Lady\'s Mile', el: 'Ακρωτήρι – Lady\'s Mile', lat: 34.58, lon: 32.98, r: 11 },
  { id: 'limassol', en: 'Limassol', el: 'Λεμεσός', lat: 34.67, lon: 33.10, r: 10 },
  { id: 'zygi', en: 'Zygi – Mazotos', el: 'Ζύγι – Μαζωτός', lat: 34.72, lon: 33.36, r: 12 },
  { id: 'larnaca', en: 'Larnaca Bay', el: 'Κόλπος Λάρνακας', lat: 34.90, lon: 33.64, r: 14 },
  { id: 'ayianapa', en: 'Ayia Napa – Cape Greco', el: 'Αγία Νάπα – Κάβο Γκρέκο', lat: 34.97, lon: 33.99, r: 9 },
  { id: 'protaras', en: 'Protaras – Paralimni', el: 'Πρωταράς – Παραλίμνι', lat: 35.04, lon: 34.06, r: 9 },
];
