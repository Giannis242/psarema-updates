// Gear guides, part 1 (19 species).
Object.assign(window.PSAREMA_GEAR ||= {}, {
 "sargos": {
  "summary": {
   "en": "Mostly caught from rocks in the foam on float (bolognese/English) or light casting rigs with shrimp, worm or sardine; LRF soft lures and spearfishing in the surge work too.",
   "el": "Πιάνεται κυρίως από βράχια στον αφρό με φελλό (μπολονέζ/εγγλέζικο) ή ελαφρύ πεταχτάρι με γαρίδα, σκουλήκι ή σαρδέλα· δουλεύουν επίσης οι σιλικόνες LRF και το ψαροντούφεκο στα ρηχά."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "surf_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.20–0.25 mm (float) · mono 0.28–0.35 mm (casting) · PE 0.3–0.6 (LRF)",
     "leader": "fluoro 0.14–0.25 mm, 1–2 m (float) · 0.16–0.185 mm (LRF)"
    },
    "rig": [
     "float_rig",
     "bottom_rig",
     "free_line"
    ],
    "hook": "size 14–8 J for small baits, 6–2 J for big baits in rough water",
    "notes": {
     "en": "Bolognese 5–7 m close in when there is swell; English rod 3.9–4.5 m with a +1–2 g waggler in calmer water. Casting (πεταχτάρι): 3–4 m rod, 35–85 g, smallest sliding sinker that holds, hook no. 4–3. LRF: rod up to 10 g, 1000 reel, fast retrieve.",
     "el": "Μπολονέζ 5–7 μ. κοντά στα βράχια όταν έχει φουσκοθαλασσιά· εγγλέζικο 3,90–4,50 μ. με φελλό waggler +1–2 γρ. σε πιο ήρεμα νερά. Πεταχτάρι: καλάμι 3–4 μ., 35–85 γρ., το μικρότερο συρόμενο μολύβι που κρατάει, αγκίστρι Νο 4–3. LRF: καλάμι έως 10 γρ., μηχανάκι 1000, γρήγορη ανάκτηση."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm or PE 0.6–0.8",
     "leader": "fluoro 0.22–0.28 mm, 1 m"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 8–4 J",
    "notes": {
     "en": "Anchor 5–20 m off a rocky reef, light sinker (common practice 20–50 g), shrimp or sardine strips, a little groundbait down the anchor line.",
     "el": "Άγκυρα σε 5–20 μ. δίπλα σε βραχώδη ξέρα, ελαφρύ μολύβι (συνήθως 20–50 γρ.), γαρίδα ή φιλετάκι σαρδέλας και λίγη μαλάγρα στο σχοινί της άγκυρας."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Ambush (καρτέρι) in the white water over 2–8 m: hide well, scrape the rock to make them curious, back off and drop lower when they turn away. 90 cm in clear water. Licence needed; sunrise to sunset only; tow a marker buoy.",
     "el": "Καρτέρι στον αφρό σε 2–8 μ.: καλή κάλυψη, ξύσιμο της πέτρας για να τους τραβήξεις, και όταν απομακρύνονται υποχωρείς και χαμηλώνεις. 90άρι σε καθαρά νερά. Χρειάζεται άδεια· μόνο από ανατολή ως δύση· πάντα με σημαδούρα."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "note": {
     "en": "Live or fresh shrimp, whole or cut; small live shrimp (γαριδούλα) is a top float bait.",
     "el": "Ζωντανή ή φρέσκια γαρίδα, ολόκληρη ή κομμένη· η ζωντανή γαριδούλα είναι κορυφαίο δόλωμα στον φελλό."
    }
   },
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Pharaoh (φαραώ) is widely rated the best sargos bait in Cyprus and Greece; acrobat, black or American worm cut to hook size also work. Best at dusk and night.",
     "el": "Το φαραώ θεωρείται το καλύτερο δόλωμα για σαργό σε Κύπρο και Ελλάδα· δουλεύουν και ακροβάτης, μαύρο ή αμερικάνος κομμένα στο μέγεθος του αγκιστριού. Καλύτερα το σούρουπο και τη νύχτα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fresh sardine fillet, firmed with breadcrumbs, for casting in foam.",
     "el": "Φρέσκο φιλέτο σαρδέλας, σφιγμένο με φρυγανιά, για πεταχτάρι στον αφρό."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Good in harbours; tie on with elastic thread.",
     "el": "Καλό στα λιμάνια· δέστε το με λαστιχένια κλωστή."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Small crab for big fish at night.",
     "el": "Μικρό καβουράκι για μεγάλους σαργούς τη νύχτα."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Bread or cheese dough in foam over groundbait (apiko).",
     "el": "Ζυμάρι ψωμιού ή τυριού στον αφρό πάνω από μαλάγρα (απίκο)."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_worm",
    "weight": "1–5 g head",
    "size": "5–7 cm",
    "colors": [
     "natural",
     "pink"
    ],
    "note": {
     "en": "Biodegradable worms over shallow rocky flats; hop and pause.",
     "el": "Βιοδιασπώμενα σκουληκάκια σε ρηχές πλάκες· τινάγματα και παύσεις."
    }
   },
   {
    "gear": "soft_grub",
    "weight": "1–5 g head",
    "size": "4–5 cm",
    "colors": [
     "natural",
     "white"
    ],
    "note": {
     "en": "Curly tail that works even on a slow drop.",
     "el": "Κατσαρή ουρά που δουλεύει και στο αργό βύθισμα."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "3–10 g",
    "size": "3–6 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Micro jig (πλανάκι) cast far and retrieved fast with pauses on calm, clear days.",
     "el": "Πλανάκι για μακρινές ρίψεις, γρήγορη ανάκτηση με παύσεις σε ήρεμα, καθαρά νερά."
    }
   },
   {
    "gear": "minnow",
    "weight": "3–5 g",
    "size": "4–5 cm",
    "colors": [
     "natural",
     "silver"
    ],
    "note": {
     "en": "Micro minnow twitched over the shallows.",
     "el": "Μικρό minnow με τινάγματα πάνω από τα ρηχά."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 5–7 cm worms or grubs (biodegradable fish better) on 1–5 g round jig heads, or weedless on a small offset hook. Keep total lure weight within the rod’s rating, retrieve fast with pauses and let the tip drop on the pause. Colours: natural green/brown in clear water; white, pink or red when it is murky.",
    "el": "Ναι: σκουληκάκια ή grub 5–7 εκ. (τα βιοδιασπώμενα πιάνουν καλύτερα) σε στρογγυλή μολυβοκεφαλή 1–5 γρ., ή αγκίστρι offset για να μην πιάνει στα βράχια. Συνολικό βάρος μέσα στο c.w. του καλαμιού, γρήγορη ανάκτηση με παύσεις, αφήνοντας τη μύτη να πέφτει στην παύση. Χρώματα: φυσικά πράσινα/καφέ σε καθαρά νερά· λευκό, ροζ ή κόκκινο στα θολά."
   },
   "ids": [
    "soft_grub",
    "soft_worm"
   ],
   "colors": [
    "natural",
    "pink",
    "white"
   ],
   "size": "4–7 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Bread soaked in seawater with sardine mash, a little fish oil and sand, in small balls just up-current of the float. On English and bolognese rigs many anglers loose-feed maggots (bigattini, where sold) instead, 15–20 every few minutes, and use them on the hook too. Avoid fishmeal-heavy mixes; in April–May leave out flour.",
    "el": "Μουσκεμένο ψωμί με λιωμένη σαρδέλα, λίγο ψαρόλαδο και άμμο, σε μικρές μπάλες λίγο πριν από τον φελλό. Στο εγγλέζικο και στο μπολονέζ πολλοί ρίχνουν αντί γι’ αυτό μπιγκατίνι (όπου πωλείται), 15–20 κάθε λίγα λεπτά, και το βάζουν και στο αγκίστρι. Όχι πολύ ιχθυάλευρο· τον Απρίλιο–Μάιο χωρίς αλεύρι."
   }
  },
  "technique": {
   "en": "Choose a rocky point with white water and the wind behind you. Feed small balls of groundbait, set the float so the bait hangs just above the rocks (1–4 m) on a long, fine fluoro leader, and strike on the first clean dip. On calm, clear days switch to LRF and cover shallow flats with micro jigs and small soft worms.",
   "el": "Διάλεξε βραχώδη κάβο με αφρό και τον αέρα στην πλάτη. Ρίχνε μικρές μπάλες μαλάγρα, ρύθμισε τον φελλό ώστε το δόλωμα να κρέμεται λίγο πάνω από τα βράχια (1–4 μ.) με μακρύ, λεπτό παράμαλλο fluorocarbon και κάρφωσε στο πρώτο καθαρό βούλιαγμα. Σε μπουνάτσα με καθαρά νερά πέρνα σε LRF με πλανάκια και μικρές σιλικόνες στις ρηχές πλάκες."
  },
  "where": {
   "en": "Rocky capes and reefs with foam, outer side of breakwaters, boulders and gullies from 1 to 15 m. Closed areas such as the Ayia Napa marine protected area and the Pegeia sea caves are off limits.",
   "el": "Βραχώδεις κάβοι και ξέρες με αφρό, εξωτερική πλευρά λιμενοβραχιόνων, κοτρώνες και χαράδρες από 1 έως 15 μ. Οι κλειστές περιοχές, όπως η θαλάσσια προστατευόμενη περιοχή Αγίας Νάπας και οι θαλάσσιες σπηλιές της Πέγειας, απαγορεύονται."
  },
  "when": {
   "en": "October–April is best; dawn, dusk and the first hours of darkness. Onshore wind with 0.5–1.8 m waves and foam; dead calm is poor except for LRF. New moon slightly better.",
   "el": "Καλύτερα Οκτώβριο–Απρίλιο· χαράματα, σούρουπο και οι πρώτες ώρες της νύχτας. Αέρας προς την ακτή με κύμα 0,5–1,8 μ. και αφρό· η μπουνάτσα είναι κακή εκτός από το LRF. Η χάση λίγο καλύτερη."
  },
  "handling": {
   "en": "Sharp dorsal spines and strong teeth: hold with a wet cloth, unhook with pliers. Minimum size 23 cm; clip the upper tail lobe of any fish you keep.",
   "el": "Κοφτερά αγκάθια στη ράχη και δυνατά δόντια: πιάσε με βρεγμένο πανί, ξαγκίστρωσε με πένσα. Ελάχιστο μέγεθος 23 εκ.· κόψε τον πάνω λοβό της ουράς σε όσα κρατάς."
  },
  "eating": {
   "en": "Excellent grilled or baked. Large fish are decades old: keep what you need and release the big breeders.",
   "el": "Εξαιρετικός στη σχάρα ή στον φούρνο. Οι μεγάλοι σαργοί έχουν δεκαετίες ζωής: κράτα όσα χρειάζεσαι και άφησε τους μεγάλους γεννήτορες."
  },
  "sources": [
   "https://customrods.gr/contents/psarema/eggleziko/articles-about-waggler-fishing/125-eggleziko-kai-bolognese-me-stoxo-to-sargo",
   "https://www.boatfishing.gr/article-post/psarema-sargon-apo-akti-sta-vrachia-me-eggleziko-bolognese-zoka-casting-kai-apiko/",
   "https://www.boatfishing.gr/article-post/light-rock-fishing-ola-ta-mystika-gia-to-psarema-megalon-sargon-me-lrf/",
   "https://www.boatfishing.gr/article-post/oi-dyskoloi-sargoi-sto-psarontoyfeko/",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_10.html",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_11.html",
   "https://www.checkincyprus.com/article/43743/ti-allazei-sten-erasitekhnike-alieia/",
   "https://www.boatfishing.gr/article-post/psarema-lrf-me-soft-baits-technita-dolomata/"
  ]
 },
 "tsipoura": {
  "summary": {
   "en": "Usually caught by casting at dawn, dusk and night over sand–seagrass patches near rocks and in harbours with crab, mussel, worm or shrimp; LRF soft crabs and spearfishing also work.",
   "el": "Πιάνεται συνήθως με πεταχτάρι/surf χαράματα, σούρουπο και νύχτα σε άμμο με ποσειδωνία κοντά σε βράχια και σε λιμάνια, με καβούρι, μύδι, σκουλήκι ή γαρίδα· πιάνεται και με σιλικονένια καβουράκια LRF και με ψαροντούφεκο."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_l",
     "reel_spin_m",
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.25–0.28 mm on rough ground, braid allowed on clean sand; add a thicker shock leader for heavy casts · LRF PE 0.4–0.6",
     "leader": "fluoro 0.25–0.35 mm, 1–3 m (sliding) · LRF fluoro 0.20–0.22 mm"
    },
    "rig": [
     "surf_rig",
     "carolina",
     "bottom_rig"
    ],
    "hook": "size 4–1/0 J, very sharp; two hooks close together for whole crab or mussel",
    "notes": {
     "en": "Stiff rod with a high casting weight on a tripod with a bite alarm. Prefer a sliding leader with a soft bead so the fish feels no resistance. Sinker weight to suit range and swell (common practice 50–120 g on beaches, 20–40 g in harbours).",
     "el": "Σκληρό καλάμι με μεγάλο c.w. σε τρίποδο με καμπανάκι ή φωτάκι. Προτίμησε συρόμενο παράμαλλο με μαλακή χάντρα, για να μη νιώθει αντίσταση το ψάρι. Μολύβι ανάλογα με απόσταση και κύμα (συνήθως 50–120 γρ. στις παραλίες, 20–40 γρ. στα λιμάνια)."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.28–0.30 mm or PE 0.8",
     "leader": "fluoro 0.28–0.33 mm, 1–1.5 m"
    },
    "rig": [
     "bottom_rig",
     "carolina"
    ],
    "hook": "size 4–1 J",
    "notes": {
     "en": "Anchor over sand and weed next to reefs in 5–25 m, light running sinker, crab or mussel; keep the line slack (common practice).",
     "el": "Άγκυρα σε άμμο και φύκια δίπλα σε ξέρες, 5–25 μ., ελαφρύ συρόμενο μολύβι, καβούρι ή μύδι· η πετονιά λίγο χαλαρή (συνήθης πρακτική)."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "90–100 cm",
    "notes": {
     "en": "Very wary: long ambush on the sand–rock border in 3–12 m at first light, motionless and well hidden; a longer gun in clear water. Licence; sunrise to sunset only.",
     "el": "Πολύ καχύποπτη: μακρύ καρτέρι στο όριο άμμου–πέτρας σε 3–12 μ. με το πρώτο φως, ακίνητος και καλά κρυμμένος· μακρύτερο όπλο σε καθαρά νερά. Με άδεια· μόνο από ανατολή ως δύση."
    }
   }
  },
  "baits": [
   {
    "gear": "crab",
    "best": true,
    "note": {
     "en": "Whole small crab or claw: big fish take it and small fish cannot steal it.",
     "el": "Ολόκληρο καβουράκι ή δαγκάνα: το παίρνουν οι μεγάλες και δεν το κλέβουν τα μικρά."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Two or three mussels on two hooks, bound with elastic thread.",
     "el": "Δύο–τρία μύδια σε δύο αγκίστρια, δεμένα με λαστιχένια κλωστή."
    }
   },
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Whole pharaoh, American or acrobat worm threaded with a needle; Cypriot anglers rate pharaoh the best gilthead bait.",
     "el": "Ολόκληρο φαραώ, αμερικάνος ή ακροβάτης περασμένος με βελόνα· στην Κύπρο το φαραώ θεωρείται το καλύτερο δόλωμα για τσιπούρα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Live shrimp at night in harbours.",
     "el": "Ζωντανή γαρίδα τη νύχτα στα λιμάνια."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fresh sardine, head removed, for long casts.",
     "el": "Φρέσκια σαρδέλα χωρίς κεφάλι για μακρινές ρίψεις."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Small squid head or white strips in bright sun.",
     "el": "Κεφαλάκι ή λευκές λωρίδες καλαμαριού με δυνατό ήλιο."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_shrimp",
    "weight": "2–6 g head",
    "size": "2–4 cm",
    "colors": [
     "natural",
     "orange"
    ],
    "note": {
     "en": "Soft (starch) crab rigged from the side, walked along the bottom with short hops and pauses. Colours: common practice.",
     "el": "Σιλικονένιο καβουράκι (αμύλου) δεμένο από το πλάι, «περπατημένο» στον βυθό με μικρά τινάγματα και παύσεις. Χρώματα: συνήθης πρακτική."
    }
   },
   {
    "gear": "soft_worm",
    "weight": "3–6 g head",
    "size": "5–8 cm",
    "colors": [
     "natural",
     "red"
    ],
    "note": {
     "en": "Scented worm on a round or oval head; lift gently, then pause: most bites come on the pause.",
     "el": "Αρωματισμένο σκουλήκι σε στρογγυλή ή οβάλ μολυβοκεφαλή· σήκωμα απαλά και παύση: τα περισσότερα τσιμπήματα έρχονται στην παύση."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, mainly biodegradable crabs and worms on 2–6 g jig heads (up to 10 g in current) with PE 0.4–0.6 and a 0.20–0.22 mm fluoro leader. Strike hard, the mouth is bony; replace bitten tails at once. Colours: natural green/brown in clear water; white, pink or red when it is murky.",
    "el": "Ναι, κυρίως βιοδιασπώμενα καβουράκια και σκουληκάκια σε μολυβοκεφαλή 2–6 γρ. (έως 10 γρ. με ρεύμα), νήμα PE 0.4–0.6 και παράμαλλο 0,20–0,22 χιλ. Κάρφωμα δυνατό, γιατί το στόμα είναι σκληρό· άλλαξε αμέσως τις φαγωμένες ουρές. Χρώματα: φυσικά πράσινα/καφέ σε καθαρά νερά· λευκό, ροζ ή κόκκινο στα θολά."
   },
   "ids": [
    "soft_worm",
    "soft_shrimp"
   ],
   "colors": [
    "natural",
    "red"
   ],
   "size": "2–8 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not usually; in harbours a few crushed mussels or crabs near the bait can help (common practice).",
    "el": "Συνήθως όχι· στα λιμάνια λίγα σπασμένα μύδια ή καβουράκια κοντά στο δόλωμα βοηθούν (συνήθης πρακτική)."
   }
  },
  "technique": {
   "en": "Cast to the edge where sand meets weed and scattered stones, set the rod on a tripod and leave the line slightly slack so the fish can mouth the crab. Ignore the first taps and strike on the steady run. Re-bait every 20–30 minutes.",
   "el": "Ρίξε στο όριο όπου η άμμος συναντά φύκια και σκόρπιες πέτρες, βάλε το καλάμι στο τρίποδο με λίγο χαλαρή πετονιά για να «μασήσει» το καβούρι. Αγνόησε τα πρώτα τσιμπηματάκια και κάρφωσε στο σταθερό τράβηγμα. Αλλάζεις δόλωμα κάθε 20–30 λεπτά."
  },
  "where": {
   "en": "Shallow sand and posidonia mosaics with pebbles or rock patches, sheltered bays, harbours and lagoon mouths, 1–15 m; deeper in summer.",
   "el": "Ρηχά «άσπρα-μαύρα» (άμμος με ποσειδωνία) με βότσαλα ή πέτρες, προστατευμένοι κόλποι, λιμάνια και στόμια λιμνοθαλασσών, 1–15 μ.· βαθύτερα το καλοκαίρι."
  },
  "when": {
   "en": "October–January is the peak. Sunrise, sunset and night; cloudy or drizzly days are good. Light breeze and calm sea after a blow; rough water and thunderstorms are poor. In bright sun cast far.",
   "el": "Κορύφωση Οκτώβριο–Ιανουάριο. Ανατολή, δύση και νύχτα· καλές οι συννεφιασμένες ή ψιλοβροχερές μέρες. Ελαφρύ αεράκι και ήρεμη θάλασσα μετά από φουρτούνα· η φουρτούνα και οι καταιγίδες είναι κακές. Με δυνατό ήλιο, ρίξε μακριά."
  },
  "handling": {
   "en": "Crushing jaws: keep fingers out of the mouth; spiny dorsal. Use pliers and a net from rocks. Minimum size 20 cm.",
   "el": "Δυνατά σαγόνια που σπάνε όστρακα: μη βάζεις δάχτυλα στο στόμα· αγκαθωτή ράχη. Πένσα, και απόχη από τα βράχια. Ελάχιστο μέγεθος 20 εκ."
  },
  "eating": {
   "en": "Excellent; wild fish are far tastier than farmed.",
   "el": "Εξαιρετική· η άγρια είναι πολύ νοστιμότερη από την ιχθυοτροφείου."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/anazitontas-tis-%c2%b5egales-chi%c2%b5oniatikes-tsipoures/",
   "https://www.psarema.gr/blog/28-rock-fishing/2086-psareyontas-tsipoyres-me-thn-technikh-toy-light-rock-fishing-lrf",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_10.html",
   "https://www.boatfishing.gr/article-post/psarema-lrf-me-soft-baits-technita-dolomata/"
  ]
 },
 "twoband": {
  "summary": {
   "en": "A common rocky-shore bream (χαρατζίδα/κακαρέλος) taken on light float, casting or apiko rigs with shrimp, worm or dough, on LRF lures, and by spearos.",
   "el": "Συνηθισμένη χαρατζίδα (κακαρέλος) των βράχων· πιάνεται με ελαφρύ φελλό, πεταχτάρι ή απίκο με γαρίδα, σκουλήκι ή ζυμάρι, με τεχνητά LRF και με ψαροντούφεκο."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.20–0.28 mm (0.30 in rough, murky water) or PE 0.4–0.6 (LRF)",
     "leader": "fluoro 0.18–0.26 mm, about 40 cm on float · 1 m for LRF"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "hook": "size 12–10 J for small baits, 5–4 J for dough or big baits",
    "notes": {
     "en": "Rod at least 1 m longer than the depth. Small round floats in swell, slim ones only in flat calm; about 80% of the shot as one olive, the rest as small split shot. Casting with a dancer or snag-resistant sinker on rough ground.",
     "el": "Καλάμι τουλάχιστον 1 μ. μακρύτερο από το βάθος. Μικροί στρογγυλοί φελλοί στο κύμα, λεπτοί μόνο σε λάδι· περίπου 80% του βάρους σε ένα μολύβι-τορπίλη και το υπόλοιπο σε μικρά σκάγια. Στο πεταχτάρι, μολύβι που δεν κολλάει στα βράχια."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm",
     "leader": "fluoro 0.20–0.25 mm droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 8–4 J",
    "notes": {
     "en": "In summer they drop to deeper rocky ground (10–40 m): καθετή with shrimp pieces.",
     "el": "Το καλοκαίρι κατεβαίνουν σε βαθύτερο πετρώδη βυθό (10–40 μ.): καθετή με κομματάκια γαρίδας."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Ambush at holes and ledges; curious, often approaches a still diver. Licence; daylight only.",
     "el": "Καρτέρι σε τρύπες και σκαλοπάτια· περίεργη, πλησιάζει συχνά τον ακίνητο ψαροντουφεκά. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "note": {
     "en": "Live or fresh, whole or in pieces.",
     "el": "Ζωντανή ή φρέσκια, ολόκληρη ή κομμάτια."
    }
   },
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Worms are the top bait: acrobat and red sand worm first, also American or pharaoh.",
     "el": "Τα σκουλήκια υπερισχύουν: πρώτα ακροβάτης και κόκκινο της άμμου, και αμερικάνος ή φαραώ."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Bread or cheese dough on a no. 5 hook.",
     "el": "Ζυμάρι ψωμιού ή τυριού σε αγκίστρι Νο 5."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Good at night by breakwaters.",
     "el": "Καλό τη νύχτα στους λιμενοβραχίονες."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Small strips on bottom rigs.",
     "el": "Λωρίδες σαρδέλας σε σύνθεση βυθού."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_grub",
    "weight": "1–3 g head",
    "size": "4–5 cm",
    "colors": [
     "natural",
     "pink"
    ],
    "note": {
     "en": "LRF over rocky flats and gullies.",
     "el": "LRF σε βραχώδεις πλάκες και χαράδρες."
    }
   },
   {
    "gear": "soft_worm",
    "weight": "1–3 g head",
    "size": "5–7 cm",
    "colors": [
     "natural",
     "red"
    ],
    "note": {
     "en": "Slow hops with pauses near the bottom.",
     "el": "Αργά τινάγματα με παύσεις κοντά στον βυθό."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "3–7 g",
    "size": "3–5 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Micro jig, plain or tipped with a little dough or snail (δολωμένο πλανάκι); let it sink, then twitch and pause.",
     "el": "Πλανάκι, σκέτο ή δολωμένο με λίγο ζυμάρι ή σαλιγκάρι· άφησέ το να βυθιστεί, μετά τινάγματα και παύσεις."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes (common LRF practice): small grubs and worms (4–7 cm) on 0.5–3 g jig heads; give all the action yourself with small taps and pauses. Colours: natural green/brown in clear water; white, pink or red when it is murky.",
    "el": "Ναι (συνήθης πρακτική LRF): μικρά grub και σκουληκάκια (4–7 εκ.) σε μολυβοκεφαλή 0,5–3 γρ.· όλη την κίνηση τη δίνεις εσύ με χτυπηματάκια και παύσεις. Χρώματα: φυσικά πράσινα/καφέ σε καθαρά νερά· λευκό, ροζ ή κόκκινο στα θολά."
   },
   "ids": [
    "soft_grub",
    "soft_worm"
   ],
   "colors": [
    "natural",
    "pink"
   ],
   "size": "4–7 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Wet crumbled bread with herbs and sand in the shallows; mostly sand with a little fish in deeper water. Live maggots (bigattini) also work as feed.",
    "el": "Βρεγμένο τριμμένο ψωμί με μυρωδικά και άμμο στα ρηχά· στα βαθιά κυρίως άμμος με λίγο ψάρι. Και τα μπιγκατίνι δουλεύουν ως μαλάγρα."
   }
  },
  "technique": {
   "en": "Fish tight to rocky drop-offs. In swell use a short bolognese line with a round float and fine 40 cm leader; strike on any dip. At night fish the outer side of breakwaters with mussel or shrimp on a light bottom rig.",
   "el": "Ψάρευε κολλητά στα απότομα βράχια. Με φουσκοθαλασσιά μπολονέζ με στρογγυλό φελλό και λεπτό παράμαλλο 40 εκ.· κάρφωμα σε κάθε βούλιαγμα. Τη νύχτα, εξωτερική πλευρά λιμενοβραχιόνων με μύδι ή γαρίδα σε ελαφριά σύνθεση βυθού."
  },
  "where": {
   "en": "Rocky bottoms, coves with steep drops, gullies and breakwaters, 1–30 m; avoid smooth sand.",
   "el": "Πετρώδεις βυθοί, κολπίσκοι με απότομο βάθος, χαράδρες και λιμενοβραχίονες, 1–30 μ.· όχι σκέτη άμμος."
  },
  "when": {
   "en": "October–May in the shallows (summer deeper). Day and night; nights near full moon are reported good. Best with slight swell and a little turbidity.",
   "el": "Οκτώβριο–Μάιο στα ρηχά (το καλοκαίρι πιο βαθιά). Μέρα και νύχτα· οι νύχτες κοντά στην πανσέληνο θεωρούνται καλές. Καλύτερα με ελαφριά φουσκοθαλασσιά και λίγη θολούρα."
  },
  "handling": {
   "en": "Spiny dorsal; use a cloth and pliers. Minimum size 18 cm.",
   "el": "Αγκαθωτή ράχη· πανί και πένσα. Ελάχιστο μέγεθος 18 εκ."
  },
  "eating": {
   "en": "Good table fish, grilled or fried.",
   "el": "Καλό ψάρι για σχάρα ή τηγάνι."
  },
  "sources": [
   "https://www.drososfishing.gr/kakarelos-tropi-psarematos-apo-tin-akti/",
   "https://www.boatfishing.gr/article-post/sargos-kakarelos-oygena-omoiotites-kai-diafores/",
   "https://www.boatfishing.gr/article-post/light-rock-fishing-planakia-kai-silikones/",
   "https://www.boatfishing.gr/article-post/psarema-lrf-me-soft-baits-technita-dolomata/"
  ]
 },
 "annular": {
  "summary": {
   "en": "Small, abundant bream (σπάρος) of harbours and seagrass, caught on tiny hooks with worm, shrimp or bread under a light float or on a light bottom rig; a great first fish.",
   "el": "Μικρός, άφθονος σπάρος των λιμανιών και της ποσειδωνίας· πιάνεται με πολύ μικρά αγκίστρια, σκουλήκι, γαρίδα ή ψωμί σε ελαφρύ φελλό ή σύνθεση βυθού· ιδανικό πρώτο ψάρι."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm or PE 0.3–0.4",
     "leader": "fluoro 0.14–0.18 mm, 0.5–1 m"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "hook": "size 14–10 J",
    "notes": {
     "en": "Light 1–3 g float set just off the bottom over weed, or a 10–20 g sinker with two short droppers in harbours (common practice).",
     "el": "Ελαφρύς φελλός 1–3 γρ. λίγο πάνω από τα φύκια, ή μολύβι 10–20 γρ. με δύο κοντά παράμαλλα στα λιμάνια (συνήθης πρακτική)."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.20–0.25 mm",
     "leader": "fluoro 0.16–0.20 mm droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 12–8 J",
    "notes": {
     "en": "Light καθετή over posidonia 5–20 m with small pieces of shrimp or worm.",
     "el": "Ελαφριά καθετή πάνω από ποσειδωνία σε 5–20 μ. με κομματάκια γαρίδας ή σκουληκιού."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Small pieces of any sea worm.",
     "el": "Μικρά κομμάτια από οποιοδήποτε σκουλήκι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Peeled pieces the size of the hook.",
     "el": "Καθαρισμένα κομματάκια όσο το αγκίστρι."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Bread flake or dough in harbours.",
     "el": "Ψίχα ψωμιού ή ζυμάρι στα λιμάνια."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Small pieces; also as groundbait.",
     "el": "Μικρά κομμάτια· και για μαλάγρα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Firm sardine paste works on float.",
     "el": "Σφιχτό ζυμάρι σαρδέλας στον φελλό."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_worm",
    "weight": "0.5–2 g head",
    "size": "2–4 cm",
    "colors": [
     "natural",
     "pink"
    ],
    "note": {
     "en": "Takes tiny LRF worms around harbour walls (common practice).",
     "el": "Χτυπάει πολύ μικρά σκουληκάκια LRF στους τοίχους των λιμανιών (συνήθης πρακτική)."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Only tiny ones: 2–4 cm worms on 0.5–2 g heads with a small hook; scented biodegradable types work best (common practice; few local reports).",
    "el": "Μόνο πολύ μικρές: σκουληκάκια 2–4 εκ. σε μολυβοκεφαλή 0,5–2 γρ. με μικρό αγκίστρι· καλύτερα τα αρωματισμένα βιοδιασπώμενα (συνήθης πρακτική· λίγες τοπικές αναφορές)."
   },
   "ids": [
    "soft_worm"
   ],
   "colors": [
    "natural",
    "pink"
   ],
   "size": "2–4 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A little bread and sardine mash pulls them in fast; too much fills them up.",
    "el": "Λίγο ψωμί με λιωμένη σαρδέλα τους μαζεύει γρήγορα· πολλή τους χορταίνει."
   }
  },
  "technique": {
   "en": "Use the smallest hook the bait allows and strike quickly; the fish nibble and strip baits. Fish next to weed edges and harbour walls, lightly groundbaiting.",
   "el": "Βάλε το μικρότερο αγκίστρι που σηκώνει το δόλωμα και κάρφωνε γρήγορα· τσιμπολογάνε και καθαρίζουν το δόλωμα. Ψάρευε δίπλα στις άκρες των φυκιών και στους τοίχους των λιμανιών με λίγη μαλάγρα."
  },
  "where": {
   "en": "Harbours, piers, posidonia meadows and sandy-weedy bays, 1–20 m.",
   "el": "Λιμάνια, προβλήτες, λιβάδια ποσειδωνίας και αμμουδεροί κόλποι με φύκια, 1–20 μ."
  },
  "when": {
   "en": "All year, best May–October; bites all day in calm water.",
   "el": "Όλο τον χρόνο, καλύτερα Μάιο–Οκτώβριο· τσιμπάει όλη μέρα σε ήρεμα νερά."
  },
  "handling": {
   "en": "Small spines; unhook gently and release small fish. Minimum size 12 cm.",
   "el": "Μικρά αγκάθια· ξαγκίστρωσε απαλά και άφησε τα μικρά. Ελάχιστο μέγεθος 12 εκ."
  },
  "eating": {
   "en": "Fair; small fish fried whole. Low market value.",
   "el": "Μέτριο· τα μικρά τηγανητά ολόκληρα. Χαμηλή εμπορική αξία."
  },
  "sources": [
   "https://psarema-cy.blogspot.com/2013/11/blog-post_16.html",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_11.html",
   "https://www.boatfishing.gr/article-post/light-rock-fishing-planakia-kai-silikones/"
  ]
 },
 "sharpsnout": {
  "summary": {
   "en": "A wary bream of rocky surge zones (μυτάκι/ούγαινα), taken mostly by spearfishing and by float anglers using seaweed, dough or worms close to the rocks.",
   "el": "Καχύποπτο μυτάκι (ούγαινα) των βράχων με κύμα· πιάνεται κυρίως με ψαροντούφεκο και με φελλό με χορταράκι, ζυμάρι ή σκουλήκι κολλητά στα βράχια."
  },
  "best": [
   "spear",
   "shore",
   "boat"
  ],
  "setups": {
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Usually a 90 cm gun with 16–17.5 mm bands and a 6–6.25 mm shaft; 75 cm among rocks. Ambush at ledges and recesses, scrape the rock with your free hand, no bubbles; stop 2–3 m short of the edge. Early morning; light cloud and about 3 Beaufort are ideal. Licence; daylight only.",
     "el": "Συνήθως 90άρι με λάστιχα 16–17,5 χιλ. και βέργα 6–6,25 χιλ.· 75άρι μέσα στα βράχια. Καρτέρι σε σκαλοπάτια και κουφάλες, ξύσιμο της πέτρας με το ελεύθερο χέρι, χωρίς φυσαλίδες· σταματάς 2–3 μ. πριν από το σκαλί. Νωρίς το πρωί· ιδανικά λίγη συννεφιά και περίπου 3 μποφόρ. Με άδεια· μόνο με φως ημέρας."
    }
   },
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.20–0.25 mm",
     "leader": "fluoro 0.18–0.22 mm, 1–1.5 m"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "hook": "size 10–6 J (common practice)",
    "notes": {
     "en": "Fish tight to the breakwater or rock face. Rock weed stays on the hook only where you can re-bait often, i.e. from a breakwater.",
     "el": "Ψάρευε κολλητά στον μώλο ή στον βράχο. Το χορταράκι των βράχων κρατιέται στο αγκίστρι μόνο όπου ξαναδολώνεις συχνά, δηλαδή από μώλο."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.25 mm",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 8–4 J",
    "notes": {
     "en": "Occasional on καθετή near rocky reefs 10–30 m with mussel, sardine or worm.",
     "el": "Περιστασιακά στην καθετή κοντά σε ξέρες 10–30 μ. με μύδι, σαρδέλα ή σκουλήκι."
    }
   }
  },
  "baits": [
   {
    "gear": "mussel",
    "note": {
     "en": "A classic bream bait for float and bottom rigs; tie on with elastic thread (general practice, few local reports).",
     "el": "Κλασικό δόλωμα για σπαρίδες σε φελλό και βυθό· δέσ’ το με λαστιχένια κλωστή (γενική πρακτική, λίγες τοπικές αναφορές)."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Plain dough or bread flake works well.",
     "el": "Το απλό ζυμαράκι ή η ψίχα ψωμιού δουλεύουν καλά."
    }
   },
   {
    "gear": "algae",
    "best": true,
    "note": {
     "en": "Fine green weed (χορταράκι) from where the waves break: rated an excellent bait, but it stays on the hook only when fishing from a breakwater.",
     "el": "Το λεπτό πράσινο χορταράκι από εκεί που σκάει το κύμα: εξαιρετικό δόλωμα, αλλά κρατιέται στο αγκίστρι μόνο όταν ψαρεύεις από μώλο."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small pieces.",
     "el": "Μικρά κομματάκια."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Takes worms too; a fish of about 1 kg was reported on a μάνα worm.",
     "el": "Χτυπάει και σε σκουλήκια· αναφέρεται ψάρι γύρω στο κιλό με μάνα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sometimes on sardine on bottom rigs.",
     "el": "Κάποτε σε σαρδέλα σε σύνθεση βυθού."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely: it is largely herbivorous with few molars, and lures seldom work.",
    "el": "Σπάνια: είναι κυρίως φυτοφάγο με λίγους τραπεζίτες, και τα τεχνητά σπάνια δουλεύουν."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Soaked bread with crushed mussel, a little at a time (common practice).",
    "el": "Μουσκεμένο ψωμί με σπασμένα μύδια, λίγο-λίγο (συνήθης πρακτική)."
   }
  },
  "technique": {
   "en": "Approach quietly and keep low; this fish bolts at the slightest danger. Fish the bait slowly beside the rocks under a light float and strike on a steady dip.",
   "el": "Πλησίασε αθόρυβα και χαμηλά· φεύγει με τον παραμικρό κίνδυνο. Το δόλωμα αργά δίπλα στα βράχια κάτω από ελαφρύ φελλό, κάρφωμα στο σταθερό βούλιαγμα."
  },
  "where": {
   "en": "Rock stairs, recesses and algae-covered stones along the shore, 1–15 m; holes in winter.",
   "el": "Σκαλοπάτια, κουφάλες και πέτρες με φύκια κατά μήκος της ακτής, 1–15 μ.· τον χειμώνα στις τρύπες."
  },
  "when": {
   "en": "September–March; early morning. A little swell and turbidity help; calm, clear sea makes it shy.",
   "el": "Σεπτέμβριο–Μάρτιο· νωρίς το πρωί. Βοηθάει λίγη φουσκοθαλασσιά και θολούρα· με λάδι και καθαρά νερά γίνεται πολύ δύσπιστο."
  },
  "handling": {
   "en": "Spiny dorsal; use a cloth. Minimum size 18 cm.",
   "el": "Αγκαθωτή ράχη· πιάσε με πανί. Ελάχιστο μέγεθος 18 εκ."
  },
  "eating": {
   "en": "Good grilled; typical fish 250–450 g.",
   "el": "Καλό στη σχάρα· τυπικό μέγεθος 250–450 γρ."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/oygena-ta-mystika-gia-to-psarema-tis-me-psarotoyfeko/",
   "https://www.psarema.gr/sizitiseis/dolomata/2551-doloma-gia-oygaines-mytakia.html",
   "https://www.boatfishing.gr/article-post/sargos-kakarelos-oygena-omoiotites-kai-diafores/"
  ]
 },
 "melanouri": {
  "summary": {
   "en": "A schooling fish of rocky coasts (μελάνα), caught from shore on float with bread or shrimp over groundbait, on LRF micro jigs and small soft lures, and by light surface trolling with small silicones.",
   "el": "Κοπαδιαστή μελάνα των βραχωδών ακτών· πιάνεται από ακτή με φελλό, ψωμί ή γαρίδα πάνω από μαλάγρα, με πλανάκια και μικρές σιλικόνες LRF, και με συρτή αφρού με μικρές σιλικόνες."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm (float) or PE 0.3–0.6 (LRF)",
     "leader": "fluoro 0.16–0.185 mm, 1–2 m"
    },
    "rig": [
     "float_rig",
     "free_line"
    ],
    "hook": "size 12–8 J",
    "notes": {
     "en": "They feed mid-water: set the float shallow (1–2 m) inside the groundbait cloud. LRF rod 1–10 g with 0-0-0 snaps; fish currents off capes.",
     "el": "Τρώνε στα μεσόνερα: ο φελλός ρηχά (1–2 μ.) μέσα στο σύννεφο της μαλάγρας. Καλάμι LRF 1–10 γρ. με παραμάνες 0-0-0· ψάρευε τα ρέματα στις άκρες των κάβων."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm, about 30 m out",
     "leader": "fluoro 0.20–0.25 mm, 1–2 m (common practice)"
    },
    "rig": [
     "trolling_rig"
    ],
    "hook": "size 6–2 J inside the soft lure",
    "notes": {
     "en": "Light surface trolling (συρτή αφρού) at 2.5–3 knots along rocks, ledges, capes and islets; 2–3 m rod up to 30 g with a 3000 reel. Small silicones on a plain hook with no weight.",
     "el": "Συρτή αφρού με 2,5–3 κόμβους κατά μήκος βράχων, σκαλοπατιών, κάβων και νησίδων· καλάμι 2–3 μ. έως 30 γρ. με μηχανάκι 3000. Μικρές σιλικόνες σε σκέτο αγκίστρι χωρίς βάρος."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Wait mid-water near rocky points; shoals come to inspect a still diver. Licence; daylight only.",
     "el": "Περίμενε στα μεσόνερα κοντά σε βραχώδεις κάβους· τα κοπάδια έρχονται να δουν τον ακίνητο ψαροντουφεκά. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "bread",
    "best": true,
    "note": {
     "en": "Bread flake or soft dough under a float in the groundbait cloud.",
     "el": "Ψίχα ή μαλακό ζυμάρι στον φελλό μέσα στο σύννεφο της μαλάγρας."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small peeled pieces.",
     "el": "Μικρά καθαρισμένα κομματάκια."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Thin fillet strips.",
     "el": "Λεπτές λωρίδες φιλέτου."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Short pieces.",
     "el": "Κοντά κομμάτια."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_grub",
    "weight": "no weight (trolling) / 1–3 g head (LRF)",
    "size": "3–5 cm",
    "colors": [
     "pink",
     "white",
     "natural"
    ],
    "note": {
     "en": "Pink, clear or white; carry 2–3 colours and test.",
     "el": "Ροζ, διάφανες ή λευκές· έχε 2–3 χρώματα και δοκίμασε."
    }
   },
   {
    "gear": "soft_worm",
    "weight": "1–3 g head",
    "size": "4–6 cm",
    "colors": [
     "pink",
     "white"
    ],
    "note": {
     "en": "For trolling or slow LRF retrieves in current.",
     "el": "Για συρτή ή αργή ανάκτηση LRF μέσα στο ρέμα."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "5–10 g",
    "size": "3–5 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Micro jigs (around 7 g) out-fish minnows in autumn–winter.",
     "el": "Τα πλανάκια (περίπου 7 γρ.) πιάνουν καλύτερα από τα minnow φθινόπωρο–χειμώνα."
    }
   },
   {
    "gear": "pencil",
    "weight": "4–8 g",
    "size": "5–7 cm",
    "colors": [
     "silver",
     "white"
    ],
    "note": {
     "en": "Small sinking pencils and micro poppers in calm water.",
     "el": "Μικρά βυθιζόμενα pencil και μικρά popper σε ήρεμα νερά."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 3–5 cm grubs or worms. Troll them on a plain hook with the point near the tail, or fish on 1–3 g jig heads. In current retrieve gently; in still, cold water use high rod and controlled jerks.",
    "el": "Ναι: grub ή σκουληκάκια 3–5 εκ. Στη συρτή σε σκέτο αγκίστρι με τη μύτη κοντά στην ουρά, ή σε μολυβοκεφαλή 1–3 γρ. Με ρέμα ανάκτηση απαλή· σε ακίνητα κρύα νερά, καλάμι ψηλά και ελεγχόμενα τινάγματα."
   },
   "ids": [
    "soft_grub",
    "soft_worm"
   ],
   "colors": [
    "pink",
    "white"
   ],
   "size": "3–5 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Bread-based cloud with a little sardine or fish oil, thrown little and often so it hangs mid-water.",
    "el": "Μαλάγρα με βάση το ψωμί και λίγη σαρδέλα ή ψαρόλαδο, λίγη και συχνά, για να κρέμεται στα μεσόνερα."
   }
  },
  "technique": {
   "en": "Start a light, steady groundbait trail, fish a very light float shallow with a long fine leader, and strike on any movement. From a boat, troll small silicones slowly along the rocks; from shore with LRF, find the current lines off points and work micro jigs through them.",
   "el": "Ξεκίνα σταθερή, ελαφριά μαλάγρα, ψάρευε πολύ ελαφρύ φελλό ρηχά με μακρύ λεπτό παράμαλλο και κάρφωνε σε κάθε κίνηση. Με βάρκα, αργή συρτή αφρού με μικρές σιλικόνες κατά μήκος των βράχων· από ακτή με LRF, βρες τα ρέματα στους κάβους και δούλεψε πλανάκια μέσα σε αυτά."
  },
  "where": {
   "en": "Rocky capes and points with current, islets, harbour mouths and posidonia edges, 1–15 m.",
   "el": "Βραχώδεις κάβοι με ρέμα, νησίδες, μπούκες λιμανιών και άκρες ποσειδωνίας, 1–15 μ."
  },
  "when": {
   "en": "October–May from shore; summer and early autumn for trolling (early morning and afternoon). Some ripple or onshore foam helps.",
   "el": "Οκτώβριο–Μάιο από ακτή· καλοκαίρι και αρχές φθινοπώρου για συρτή αφρού (νωρίς το πρωί και απόγευμα). Βοηθάει λίγος κυματισμός ή αφρός."
  },
  "handling": {
   "en": "Easy to handle; small spines. No EU minimum size, but release fish under about 17 cm (size at maturity).",
   "el": "Εύκολο στον χειρισμό· μικρά αγκάθια. Δεν έχει ελάχιστο μέγεθος ΕΕ, αλλά άφησε όσα είναι κάτω από περίπου 17 εκ. (μέγεθος ωρίμανσης)."
  },
  "eating": {
   "en": "Good fresh, grilled or fried; ice it quickly.",
   "el": "Καλή φρέσκια, στη σχάρα ή τηγανητή· βάλ’ την γρήγορα στον πάγο."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/melanoyria-me-lrf-fthinoporo-cheimona/",
   "https://www.boatfishing.gr/article-post/syrti-afroy-melanoyria-me-silikonoycha-dolomata/",
   "https://www.drososfishing.gr/melanouria-me-silikonoucha-dolomata/",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_11.html"
  ]
 },
 "salema": {
  "summary": {
   "en": "Herbivorous shoals (σάλπα) over shallow weedy rocks, caught on float with bread, dough or green weed over bread groundbait, and by spearos. Eat with care: hallucinogenic poisoning risk.",
   "el": "Φυτοφάγα κοπάδια σάλπας σε ρηχά βράχια με φύκια· πιάνεται με φελλό με ψωμί, ζυμάρι ή πράσινο φύκι πάνω από μαλάγρα ψωμιού, και με ψαροντούφεκο. Προσοχή στην κατανάλωση: κίνδυνος παραισθησιογόνου δηλητηρίασης."
  },
  "best": [
   "shore",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.20–0.25 mm",
     "leader": "fluoro 0.18–0.26 mm, 0.5–1 m"
    },
    "rig": [
     "float_rig"
    ],
    "hook": "size 12–8 J, long shank",
    "notes": {
     "en": "Float around 4–5 g. Salema hit hard and run with the bait, so set the drag correctly and use sturdy fluoro: their teeth are sharp.",
     "el": "Φελλός περίπου 4–5 γρ. Η σάλπα χτυπάει δυνατά και φεύγει με το δόλωμα, οπότε σωστό φρένο και γερό fluorocarbon: τα δόντια της κόβουν."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Shoals graze in the shallow surge and are easy targets; take only what you will eat. Licence; daylight only.",
     "el": "Τα κοπάδια βόσκουν στα ρηχά με κύμα και είναι εύκολος στόχος· πάρε μόνο όσα θα φας. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "bread",
    "best": true,
    "note": {
     "en": "Bread shaped into a light ball that holds on the hook: the most used bait.",
     "el": "Ψωμί σε ελαφρύ μπαλάκι που κρατιέται στο αγκίστρι: το πιο διαδεδομένο δόλωμα."
    }
   },
   {
    "gear": "algae",
    "note": {
     "en": "Stringy green weed wrapped round the hook, alone or with paste.",
     "el": "Ινώδες πράσινο φύκι τυλιγμένο στο αγκίστρι, σκέτο ή με ζυμάρι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Works but less well than plant baits.",
     "el": "Δουλεύει, αλλά λιγότερο από τα φυτικά δολώματα."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Small crab bits are used in Cyprus.",
     "el": "Στην Κύπρο χρησιμοποιούνται και κομματάκια καβουριού (καρτσίνες)."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: salema are grazers and ignore lures.",
    "el": "Όχι: η σάλπα βόσκει φύκια και αγνοεί τα τεχνητά."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Soaked old bread mixed with chopped green weed and beach sand (common Mediterranean practice); avoid strong cheese.",
    "el": "Μουσκεμένο μπαγιάτικο ψωμί με ψιλοκομμένο πράσινο φύκι και άμμο (συνήθης μεσογειακή πρακτική)· όχι δυνατά τυριά."
   }
  },
  "technique": {
   "en": "Groundbait steadily beside weedy rocks, fish bread or weed just above the weed tops under a 4–5 g float and strike on the sharp dip; play the fish firmly, it fights hard.",
   "el": "Σταθερή μαλάγρα δίπλα σε βράχια με φύκια, ψωμί ή φύκι λίγο πάνω από τα φύκια κάτω από φελλό 4–5 γρ., κάρφωμα στο απότομο βούλιαγμα· κούρασέ την σταθερά, παλεύει δυνατά."
  },
  "where": {
   "en": "Shallow algae-covered rocks, posidonia and harbour walls, 0.5–10 m.",
   "el": "Ρηχά βράχια με φύκια, ποσειδωνία και τοίχοι λιμανιών, 0,5–10 μ."
  },
  "when": {
   "en": "May–November, peaking October–December in Cyprus; daytime in calm to light chop.",
   "el": "Μάιο–Νοέμβριο, με κορύφωση Οκτώβριο–Δεκέμβριο στην Κύπρο· την ημέρα, με λάδι ή ελαφρύ κυματισμό."
  },
  "handling": {
   "en": "Sharp teeth and dorsal spines; gut the fish straight away.",
   "el": "Κοφτερά δόντια και αγκάθια στη ράχη· καθάρισέ την αμέσως."
  },
  "eating": {
   "en": "Edible but can cause hallucinogenic poisoning (ichthyoallyeinotoxism) linked to the algae it eats; the head and guts are the riskiest. Remove head and guts at once, never eat the head, and release big fish if in doubt.",
   "el": "Τρώγεται, αλλά μπορεί να προκαλέσει παραισθησιογόνο δηλητηρίαση που συνδέεται με τα φύκια που τρώει· το κεφάλι και τα εντόσθια είναι τα πιο επικίνδυνα. Βγάλε αμέσως κεφάλι και εντόσθια, μην τρως ποτέ το κεφάλι, και αν έχεις αμφιβολία άφησε τις μεγάλες."
  },
  "sources": [
   "https://www.peche.com/article/49937/quels-sont-les-meilleurs-appats-pour-pecher-la-saupe",
   "https://fishingcy.blogspot.com/2013/06/blog-post_17.html"
  ]
 },
 "bogue": {
  "summary": {
   "en": "An abundant schooling fish (γόπα), caught from boats on tsapari (sabiki) and from piers and rocks on float with shrimp, bread or sardine bits; also prized as bait.",
   "el": "Άφθονη κοπαδιαστή γόπα· πιάνεται από βάρκα με τσαπαρί και από μώλους και βράχια με φελλό, γαρίδα, ψωμί ή κομματάκια σαρδέλας· πολύτιμη και ως δόλωμα."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm",
     "leader": "fine sabiki droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 7–5 (sabiki)",
    "notes": {
     "en": "Tsapari with 5–7 small hooks, tipped with shrimp pieces; works best from 20–25 m. Lower until the line stops on the shoal, then jig gently up and down. Sinker to suit the drift (common practice 30–60 g).",
     "el": "Τσαπαρί με 5–7 μικρά αγκίστρια, δολωμένα με κομματάκια γαρίδας· δουλεύει καλύτερα από 20–25 μ. Κατεβάζεις μέχρι να σταματήσει η πετονιά στο κοπάδι και μετά απαλά ανεβοκατεβάσματα. Μολύβι ανάλογα με το ρέμα (συνήθως 30–60 γρ.)."
    }
   },
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm",
     "leader": "fluoro 0.16–0.20 mm"
    },
    "rig": [
     "float_rig"
    ],
    "hook": "size 12–8 J",
    "notes": {
     "en": "Light 2–4 g float in harbours and off rocks at dusk over bread groundbait (common practice).",
     "el": "Ελαφρύς φελλός 2–4 γρ. σε λιμάνια και βράχια το σούρουπο πάνω από μαλάγρα ψωμιού (συνήθης πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small pieces on tsapari or float.",
     "el": "Κομματάκια στο τσαπαρί ή στον φελλό."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Bread flake on float in harbours.",
     "el": "Ψίχα ψωμιού στον φελλό στα λιμάνια."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Tiny strips.",
     "el": "Πολύ μικρές λωρίδες."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Thin strips stay on the hook.",
     "el": "Λεπτές λωρίδες που κρατιούνται στο αγκίστρι."
    }
   }
  ],
  "lures": [
   {
    "gear": "sabiki",
    "weight": "30–60 g sinker",
    "size": "hooks no. 7–5",
    "colors": [
     "white",
     "pink",
     "silver"
    ],
    "note": {
     "en": "Small feathers or fish skin; keep it simple. Colours: common practice.",
     "el": "Μικρά φτεράκια ή πετσάκι ψαριού· απλή αρματωσιά. Χρώματα: συνήθης πρακτική."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not needed; tsapari and bait are far better.",
    "el": "Δεν χρειάζεται· το τσαπαρί και το δόλωμα είναι πολύ καλύτερα."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A sardine or bread cloud under the boat or float holds the shoal.",
    "el": "Σύννεφο από σαρδέλα ή ψωμί κάτω από τη βάρκα ή τον φελλό κρατάει το κοπάδι."
   }
  },
  "technique": {
   "en": "Find the shoal on the sounder or by trial, groundbait lightly and keep the tsapari moving gently at that depth. Many fish at once: do not overload the hooks with bait.",
   "el": "Βρες το κοπάδι με το βυθόμετρο ή δοκιμάζοντας, ρίξε λίγη μαλάγρα και κράτα το τσαπαρί σε απαλή κίνηση σε εκείνο το βάθος. Πιάνονται πολλές μαζί: μη φορτώνεις τα αγκίστρια με δόλωμα."
  },
  "where": {
   "en": "Over reefs, sand and open water from 3 to 100 m; harbours and lit piers at night.",
   "el": "Πάνω από ξέρες, άμμο και ανοιχτά νερά από 3 έως 100 μ.· λιμάνια και φωτισμένοι μώλοι τη νύχτα."
  },
  "when": {
   "en": "October–April is best; early morning until about two hours after sunrise and the last hour before sunset.",
   "el": "Καλύτερα Οκτώβριο–Απρίλιο· νωρίς το πρωί μέχρι περίπου δύο ώρες μετά την ανατολή και την τελευταία ώρα πριν τη δύση."
  },
  "handling": {
   "en": "Harmless; keep alive in a bucket with aeration if used as live bait.",
   "el": "Ακίνδυνη· κράτα τη ζωντανή σε κουβά με αερισμό αν θα τη χρησιμοποιήσεις για ζωντανό δόλωμα."
  },
  "eating": {
   "en": "Cheap but tasty fried or grilled when very fresh; gut quickly, the guts turn bitter. Excellent live or cut bait.",
   "el": "Φτηνή αλλά νόστιμη τηγανητή ή στη σχάρα όταν είναι ολόφρεσκη· καθάρισέ τη γρήγορα, τα εντόσθια πικρίζουν. Εξαιρετικό ζωντανό ή κομμένο δόλωμα."
  },
  "sources": [
   "https://www.drososfishing.gr/tsapari-gnorimia-tropos-psarematos-ka/",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_16.html"
  ]
 },
 "porgy": {
  "summary": {
   "en": "Mainly a boat fish: bait rigs with squid or sardine, plus tai rubber, inchiku, slow jigs and heavy soft shads over deep rock-and-sand grounds of about 40–170 m.",
   "el": "Κυρίως ψάρι της βάρκας: καθετή με καλαμάρι ή σαρδέλα, καθώς και tai rubber, inchiku, slow jig και βαριές σιλικόνες σε βαθιούς πετρώδεις-αμμώδεις βυθούς περίπου 40–170 μ."
  },
  "best": [
   "boat",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "slow_jig_rod",
     "boat_rod",
     "jigging_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1.5",
     "leader": "fluoro 0.28–0.35 mm (tai rubber) · 0.50–0.60 mm, long, for heavy inchiku"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 2–2/0 J for bait · 3/0 assist on inchiku",
    "notes": {
     "en": "Tai rubber 80–120 g in 50–170 m on a baitcaster: start winding as soon as it touches bottom; do not add bait. Inchiku 160–240 g at 100–150 m with small quick lifts of up to 40 cm while winding, lifting up to 20 m then dropping again; lighter lures in shallower water (common practice 60–120 g at 40–80 m). Fish clean red-fish ground, not rough black-fish rock that cuts thin leaders.",
     "el": "Tai rubber 80–120 γρ. σε 50–170 μ. με μηχανάκι τυμπάνου: μάζευε μόλις ακουμπήσει βυθό· χωρίς δόλωμα. Inchiku 160–240 γρ. σε 100–150 μ. με μικρά γρήγορα τινάγματα έως 40 εκ. ενώ μαζεύεις, ανεβαίνοντας έως 20 μ. και ξανά κάτω· πιο ελαφριά σε ρηχότερα (συνήθως 60–120 γρ. σε 40–80 μ.). Ψάρευε καθαρούς βυθούς των «κόκκινων», όχι τραχιά πέτρα των «μαύρων» που κόβει τα λεπτά παράμαλλα."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "100–110 cm",
    "notes": {
     "en": "Rarely within free-diving range; only experienced divers at deep reef edges. Licence; daylight only.",
     "el": "Σπάνια σε βάθος ελεύθερης κατάδυσης· μόνο για έμπειρους σε βαθιά σκαλοπάτια. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Strips or whole small squid; tough and selective.",
     "el": "Λωρίδες ή ολόκληρο μικρό καλαμάρι· ανθεκτικό και επιλεκτικό."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fresh sardine or bogue, head and tail cut so it bleeds.",
     "el": "Φρέσκια σαρδέλα ή γόπα, κομμένο κεφάλι και ουρά για να «ματώνει»."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "Live small fish (bogue, picarel) on deep rough ground for the biggest porgy.",
     "el": "Ζωντανό μικρόψαρο (γόππα, μαρίδα) σε βαθιά τραχιά για τα μεγαλύτερα φαγκριά."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Whole shrimp; small fish steal it.",
     "el": "Ολόκληρη γαρίδα· την κλέβουν τα μικρά."
    }
   }
  ],
  "lures": [
   {
    "gear": "tai_rubber",
    "weight": "60–120 g",
    "size": "—",
    "colors": [
     "orange",
     "red",
     "pink"
    ],
    "note": {
     "en": "Steady retrieve from the bottom; colours are common practice.",
     "el": "Σταθερή ανάκτηση από τον βυθό· τα χρώματα είναι συνήθης πρακτική."
    }
   },
   {
    "gear": "inchiku",
    "weight": "100–240 g",
    "size": "—",
    "colors": [
     "pink",
     "gold",
     "sardine"
    ],
    "note": {
     "en": "Pink, gold and blue; preferences change by spot and day.",
     "el": "Ροζ, χρυσό και μπλε· οι προτιμήσεις αλλάζουν ανά σημείο και μέρα."
    }
   },
   {
    "gear": "slow_jig",
    "weight": "60–150 g",
    "size": "—",
    "colors": [
     "glow",
     "pink",
     "gold"
    ],
    "note": {
     "en": "Slow pitch over reef edges (common practice).",
     "el": "Slow pitch στα σκαλοπάτια των ξερών (συνήθης πρακτική)."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "90–150 g head",
    "size": "—",
    "colors": [
     "red",
     "natural"
    ],
    "note": {
     "en": "Paddle-tail soft bait on a heavy jig head, worked close to the bottom; red over mud and gravel, rock-coloured over rock.",
     "el": "Σιλικόνη με ουρά-πτερύγιο σε βαριά μολυβοκεφαλή, κοντά στον βυθό· κόκκινη σε λάσπη και χαλίκι, στο χρώμα της πέτρας σε βράχο."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, from boats: paddle-tail soft baits on 90–150 g jig heads worked just off the bottom over reef edges (lighter heads in shallower water, heavier in current). Red over mud and gravel, rock-coloured over rock; colour matters little below about 120 m. A small soft lure on a short dropper above an inchiku is one angler’s experiment, not a proven method.",
    "el": "Ναι, από σκάφος: σιλικόνες με ουρά-πτερύγιο σε μολυβοκεφαλή 90–150 γρ., λίγο πάνω από τον βυθό στις άκρες των ξερών (πιο ελαφριές στα ρηχότερα, πιο βαριές με ρέμα). Κόκκινες σε λάσπη και χαλίκι, στο χρώμα της πέτρας σε βράχο· κάτω από τα 120 μ. το χρώμα μετράει λίγο. Η μικρή σιλικόνη σε κοντό παράμαλλο πάνω από το inchiku είναι πείραμα ενός ψαρά, όχι δοκιμασμένη μέθοδος."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "red",
    "natural"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used at these depths.",
    "el": "Δεν χρησιμοποιείται σε τέτοια βάθη."
   }
  },
  "technique": {
   "en": "Drift over the edges of reefs where sand meets rock, keep the lure or bait within a few metres of the bottom, and mark every bite on the GPS. With bait, use a 2-hook rig with long droppers and strike on the second knock.",
   "el": "Ντρίφτα στις άκρες των ξερών, εκεί που η άμμος συναντά την πέτρα, κράτα το τεχνητό ή το δόλωμα λίγα μέτρα από τον βυθό και σημείωνε κάθε τσίμπημα στο GPS. Με δόλωμα, αρματωσιά με δύο αγκίστρια σε μακριά παράμαλλα και κάρφωμα στο δεύτερο χτύπημα."
  },
  "where": {
   "en": "Rocky-sandy grounds and reef edges, usually 40–170 m.",
   "el": "Πετρώδεις-αμμώδεις βυθοί και άκρες ξερών, συνήθως 40–170 μ."
  },
  "when": {
   "en": "November–April is best; dusk and dawn.",
   "el": "Καλύτερα Νοέμβριο–Απρίλιο· σούρουπο και χαράματα."
  },
  "handling": {
   "en": "Sharp spines. Fish from depth suffer barotrauma and rarely survive release: decide before you bring it up and keep only what you need. Minimum size 18 cm.",
   "el": "Κοφτερά αγκάθια. Τα ψάρια από βάθος παθαίνουν βαρότραυμα και σπάνια επιβιώνουν αν τα αφήσεις: κράτα μόνο όσα χρειάζεσαι. Ελάχιστο μέγεθος 18 εκ."
  },
  "eating": {
   "en": "Excellent: grilled, baked or in fish soup.",
   "el": "Εξαιρετικό: σχάρα, φούρνος ή ψαρόσουπα."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/psarema-apo-varka-gia-fagkria-kai-tsaoysia-me-techniki-tai-rubber/",
   "https://www.boatfishing.gr/article-post/inchiku-sta-vathia-gia-fagkria/",
   "https://www.boatfishing.gr/article-post/fagkri-treis-technikes-psarematos-paragadi-tenya-inchiku/",
   "https://www.boatfishing.gr/article-post/soft-bait-fishing-psarema-me-silikones/"
  ]
 },
 "pandora": {
  "summary": {
   "en": "The classic καθετή fish: 2–3 hook bottom rigs with shrimp or squid over sand and mud near reefs (20–120 m), plus small inchiku and tai rubber.",
   "el": "Το κλασικό ψάρι της καθετής: αρματωσιές βυθού με 2–3 αγκίστρια, γαρίδα ή καλαμάρι, σε άμμο και λάσπη κοντά σε ξέρες (20–120 μ.), καθώς και μικρά inchiku και tai rubber."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod",
     "slow_jig_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "mono 0.24–0.30 mm or PE 0.6–1.0",
     "leader": "fluoro 0.20–0.28 mm droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 8–2 J",
    "notes": {
     "en": "Deep (70–100 m): 0.30 mm main, three droppers up to 30 cm of 0.25 mm fluoro, hooks no. 6–8, 100–125 g glow sinker. Shallower: two long 60 cm droppers, hooks no. 2–6. For big fish: one 1–2 m fluoro leader of 0.24–0.28 mm with two hooks 2 cm apart and a single large bait.",
     "el": "Βαθιά (70–100 μ.): μάνα 0,30 χιλ., τρία παράμαλλα έως 30 εκ. fluorocarbon 0,25 χιλ., αγκίστρια Νο 6–8, μολύβι 100–125 γρ. φωσφοριζέ. Ρηχότερα: δύο μακριά παράμαλλα 60 εκ., αγκίστρια Νο 2–6. Για μεγάλα: ένα παράμαλλο 1–2 μ. fluorocarbon 0,24–0,28 χιλ. με δύο αγκίστρια σε απόσταση 2 εκ. και ένα μεγάλο δόλωμα."
    }
   },
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_l",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.28–0.35 mm",
     "leader": "fluoro 0.25–0.30 mm, 1 m"
    },
    "rig": [
     "bottom_rig",
     "surf_rig"
    ],
    "hook": "size 6–2 J",
    "notes": {
     "en": "Only where deep water is close (steep coasts, breakwater tips), mostly at night; occasional catch (common practice).",
     "el": "Μόνο όπου υπάρχει βαθύ νερό κοντά (απότομες ακτές, άκρες μώλων), κυρίως τη νύχτα· περιστασιακή ψαριά (συνήθης πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Whole shrimp, unpeeled in winter.",
     "el": "Ολόκληρη γαρίδα, ακαθάριστη τον χειμώνα."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Strips or a tentacle; stays on and filters small fish.",
     "el": "Λωρίδες ή πλοκάμι· κρατάει και «φιλτράρει» τα μικρά."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fillet pieces.",
     "el": "Κομμάτια φιλέτου."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Good in shallower water.",
     "el": "Καλό σε ρηχότερα νερά."
    }
   }
  ],
  "lures": [
   {
    "gear": "inchiku",
    "weight": "40–120 g",
    "size": "—",
    "colors": [
     "glow",
     "pink",
     "red"
    ],
    "note": {
     "en": "Glow and striped patterns do best below about 90 m; small, light lifts.",
     "el": "Τα φωσφοριζέ και ριγέ αποδίδουν καλύτερα κάτω από περίπου 90 μ.· μικρά, ελαφριά τινάγματα."
    }
   },
   {
    "gear": "tai_rubber",
    "weight": "40–100 g",
    "size": "—",
    "colors": [
     "orange",
     "red"
    ],
    "note": {
     "en": "Slow steady wind off the bottom (common practice).",
     "el": "Αργό σταθερό μάζεμα από τον βυθό (συνήθης πρακτική)."
    }
   },
   {
    "gear": "slow_jig",
    "weight": "40–100 g",
    "size": "—",
    "colors": [
     "glow",
     "pink"
    ],
    "note": {
     "en": "Light slow jigs near the bottom (common practice).",
     "el": "Ελαφριά slow jig κοντά στον βυθό (συνήθης πρακτική)."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not on jig heads. The silicone octopus skirts that pandora like are part of the inchiku and tai rubber (see lures); small pandora are only occasional by-catch on red soft baits over mud.",
    "el": "Όχι σε μολυβοκεφαλή. Τα σιλικονούχα χταποδάκια που τραβάνε τα λυθρίνια είναι μέρος του inchiku και του tai rubber (δες τεχνητά)· τα μικρά λυθρίνια πιάνονται μόνο περιστασιακά σε κόκκινες σιλικόνες πάνω από λάσπη."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Drift with a light current over sand and mud close to reefs, keep the sinker tapping the bottom, and strike on the sharp double knock. Pandora move in schools: mark the spot and repeat the drift.",
   "el": "Ντρίφτα με ελαφρύ ρέμα σε άμμο και λάσπη κοντά σε ξέρες, με το μολύβι να χτυπάει τον βυθό, και κάρφωσε στο απότομο διπλό χτύπημα. Τα λυθρίνια κινούνται σε κοπάδια: σημείωσε το σημείο και ξαναπέρνα."
  },
  "where": {
   "en": "Sand, mud and gravel near rocky reefs, 20–120 m; deeper in winter.",
   "el": "Άμμος, λάσπη και χαλίκι κοντά σε βραχώδεις ξέρες, 20–120 μ.· βαθύτερα τον χειμώνα."
  },
  "when": {
   "en": "All year; big fish in winter and spring. Morning is best; light current helps.",
   "el": "Όλο τον χρόνο· τα μεγάλα χειμώνα και άνοιξη. Καλύτερα το πρωί· βοηθάει ελαφρύ ρέμα."
  },
  "handling": {
   "en": "Spiny dorsal; barotrauma from depth. Minimum size 15 cm.",
   "el": "Αγκαθωτή ράχη· βαρότραυμα από το βάθος. Ελάχιστο μέγεθος 15 εκ."
  },
  "eating": {
   "en": "Excellent, one of the best-tasting breams.",
   "el": "Εξαιρετικό, από τα νοστιμότερα ψάρια."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/katheti-4-armatosies-gia-lythrinia/",
   "https://www.drososfishing.gr/inchiku-slow-lythrinia-sta-agkistria-mas/",
   "https://www.drososfishing.gr/tsapari-gnorimia-tropos-psarematos-ka/",
   "https://www.boatfishing.gr/article-post/soft-bait-fishing-psarema-me-silikones/"
  ]
 },
 "blackbream": {
  "summary": {
   "en": "Taken mostly from boats on bottom rigs over reefs of 20–60 m with squid, worm or sardine; from shore only off steep rocks with long casting gear.",
   "el": "Πιάνεται κυρίως από βάρκα με σύνθεση βυθού σε ξέρες 20–60 μ. με καλαμάρι, σκουλήκι ή σαρδέλα· από ακτή μόνο από απότομα βράχια με μακρινό πεταχτάρι."
  },
  "best": [
   "boat",
   "shore",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm or PE 0.6–0.8",
     "leader": "fluoro 0.22–0.28 mm droppers, 30–50 cm"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 6–2 J",
    "notes": {
     "en": "Fish the edges of reefs and shoals that end in sand or mud; larger fish on mixed, rough ground in deeper water (common practice for hooks and droppers).",
     "el": "Ψάρευε τις άκρες ξερών που καταλήγουν σε άμμο ή λάσπη· τα μεγαλύτερα σε μικτό, τραχύ βυθό στα βαθιά (αγκίστρια και παράμαλλα: συνήθης πρακτική)."
    }
   },
   "shore": {
    "rod": [
     "surf_rod"
    ],
    "reel": [
     "reel_spin_l"
    ],
    "line": {
     "main": "mono 0.30–0.35 mm",
     "leader": "fluoro 0.28–0.30 mm, 1–1.5 m"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 4–1 J, single hook",
    "notes": {
     "en": "Rod 4.4–4.6 m casting 100–150 g, 10000 reel, casts of 80–100 m. Tie the sinker on a 0.12–0.14 mm weak link so a snag costs only the lead.",
     "el": "Καλάμι 4,40–4,60 μ., c.w. 100–150 γρ., μηχανάκι 10000, ρίψεις 80–100 μ. Δέσε το μολύβι με «ασφάλεια» πετονιάς 0,12–0,14 χιλ., ώστε σε κόλλημα να χάνεις μόνο το μολύβι."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "90–100 cm",
    "notes": {
     "en": "Shoals mill around reef edges in 10–25 m and come to check a still diver. Licence; daylight only.",
     "el": "Τα κοπάδια κάνουν κύκλους στις άκρες των ξερών σε 10–25 μ. και πλησιάζουν τον ακίνητο ψαροντουφεκά. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Squid strips; small cuttlefish or octopus tentacle blanched for 1 minute and peeled.",
     "el": "Λωρίδες καλαμαριού· μοσχιός ή πλοκάμι χταποδιού ζεματισμένο 1 λεπτό και καθαρισμένο."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Pharaoh at any hour; American or acrobat mainly by day.",
     "el": "Φαραώ όλες τις ώρες· αμερικάνος ή ακροβάτης κυρίως τη μέρα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fillet pieces.",
     "el": "Κομμάτια φιλέτου."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Whole shrimp, head off and shell on: it always works on boat rigs.",
     "el": "Ολόκληρη γαρίδα με το κέλυφος, χωρίς κεφάλι: δουλεύει πάντα στη βάρκα."
    }
   }
  ],
  "lures": [
   {
    "gear": "inchiku",
    "weight": "40–80 g",
    "size": "—",
    "colors": [
     "pink",
     "glow"
    ],
    "note": {
     "en": "Occasional catch on light inchiku; bait is far better (common practice).",
     "el": "Περιστασιακά σε ελαφρύ inchiku· το δόλωμα είναι πολύ καλύτερο (συνήθης πρακτική)."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not with shads, grubs or worms. The only silicone used is a squid imitation, slow-trolled near the bottom with a strip of real squid on the hooks.",
    "el": "Όχι με shad, grub ή σκουληκάκια. Η μόνη σιλικόνη που χρησιμοποιείται είναι το ομοίωμα καλαμαριού σε αργή συρτή κοντά στον βυθό, με λωρίδα αληθινού καλαμαριού στα αγκίστρια."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Rarely used; a sardine chum bag on the anchor line can hold a shoal (general practice).",
    "el": "Σπάνια· ένα διχτάκι με σαρδέλα στο σχοινί της άγκυρας μπορεί να κρατήσει το κοπάδι (γενική πρακτική)."
   }
  },
  "technique": {
   "en": "Anchor or drift slowly along the reef edge, keep baits just off the bottom and strike on the second pull; black bream nibble cautiously except just after spawning.",
   "el": "Άγκυρα ή αργό ντρίφτο στην άκρη της ξέρας, δολώματα λίγο πάνω από τον βυθό και κάρφωμα στο δεύτερο τράβηγμα· τα σκαθάρια τσιμπάνε δειλά, εκτός από αμέσως μετά την ωοτοκία."
  },
  "where": {
   "en": "Reefs and shoals in 20–60 m ending in sand or mud; small fish near rocky shores.",
   "el": "Ξέρες και ρηχά σε 20–60 μ. που καταλήγουν σε άμμο ή λάσπη· τα μικρά κοντά σε βραχώδεις ακτές."
  },
  "when": {
   "en": "Winter to late spring; they feed hardest right after spawning (around May).",
   "el": "Από χειμώνα έως τέλη άνοιξης· τρώνε λαίμαργα αμέσως μετά την ωοτοκία (γύρω στον Μάιο)."
  },
  "handling": {
   "en": "Spiny dorsal; barotrauma from depth.",
   "el": "Αγκαθωτή ράχη· βαρότραυμα από το βάθος."
  },
  "eating": {
   "en": "Good, baked or grilled.",
   "el": "Καλό, στον φούρνο ή στη σχάρα."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/casting-skathari-poy-kai-pote-psareyetai/",
   "https://www.drososfishing.gr/afieroma-skathari-tropoi-psarematos-ap/"
  ]
 },
 "redmullet": {
  "summary": {
   "en": "A boat fish of muddy-sandy bottoms (20–150 m), caught on καθετή with long fine droppers and small hooks baited with thin worms or shrimp strips while drifting.",
   "el": "Ψάρι της βάρκας σε λασπώδεις-αμμώδεις βυθούς (20–150 μ.)· πιάνεται με καθετή, μακριά λεπτά παράμαλλα και μικρά αγκίστρια με λεπτά σκουλήκια ή λωρίδες γαρίδας, με ντρίφτο."
  },
  "best": [
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.22–0.28 mm or PE 0.4–0.6",
     "leader": "fluoro 0.14–0.22 mm, long droppers (the lowest touching bottom)"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 12–8 J, fine wire (common practice)",
    "notes": {
     "en": "2–3 hook rig with a toothed sinker that stirs up silt. Drift rather than anchor, drag the sinker now and then, and mark schools on the GPS.",
     "el": "Διπλάρι ή τριπλάρι με οδοντωτό μολύβι που σηκώνει λάσπη. Ντρίφτο αντί για άγκυρα, σέρνε πού και πού το μολύβι και σημείωνε τα κοπάδια στο GPS."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Thin worms (red sand worm, τριχιά) threaded with a needle; black, acrobat or American if those are not available.",
     "el": "Λεπτά σκουλήκια (κόκκινο της άμμου, τριχιά) περασμένα με βελόνα· αλλιώς μαύρο, ακροβάτης ή αμερικάνος."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Thin strips of shrimp when worms are not available.",
     "el": "Λεπτές λωρίδες γαρίδας όταν δεν υπάρχουν σκουλήκια."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: it feeds by touch with its barbels and is taken almost only on bait.",
    "el": "Όχι: τρέφεται ψάχνοντας με τα μουστάκια και πιάνεται σχεδόν μόνο με δόλωμα."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used; the toothed sinker cloud does the job.",
    "el": "Δεν χρησιμοποιείται· τη δουλειά την κάνει η λάσπη που σηκώνει το οδοντωτό μολύβι."
   }
  },
  "technique": {
   "en": "Keep the bottom hook dragging on the mud, lift the line taut every few seconds and strike on the fast rattling bites. When you find a school, repeat the same drift line.",
   "el": "Το κάτω αγκίστρι να σέρνεται στη λάσπη, τέντωνε την πετονιά κάθε λίγα δευτερόλεπτα και κάρφωνε στα γρήγορα τρεμουλιαστά τσιμπήματα. Όταν βρεις κοπάδι, ξαναπέρνα την ίδια γραμμή."
  },
  "where": {
   "en": "Mud and muddy sand 20–150 m, open bays.",
   "el": "Λάσπη και λασποαμμουδιά 20–150 μ., ανοιχτοί κόλποι."
  },
  "when": {
   "en": "October–March is best; daytime.",
   "el": "Καλύτερα Οκτώβριο–Μάρτιο· την ημέρα."
  },
  "handling": {
   "en": "Harmless; fragile scales. Minimum size 11 cm.",
   "el": "Ακίνδυνη· ευαίσθητα λέπια. Ελάχιστο μέγεθος 11 εκ."
  },
  "eating": {
   "en": "Excellent fried; eat very fresh.",
   "el": "Εξαιρετική τηγανητή· να τρώγεται ολόφρεσκη."
  },
  "sources": [
   "https://www.drososfishing.gr/katheti-mparmpoynia-sta-agkistria-mas/"
  ]
 },
 "surmullet": {
  "summary": {
   "en": "The shallower, rock-and-sand red mullet (μπαρμπούνι), caught from boats and shore on light 2–3 hook rigs with thin worms; spearos take it on shallow mixed bottoms.",
   "el": "Το μπαρμπούνι των ρηχών βυθών με πέτρα και άμμο· πιάνεται από βάρκα και από ακτή με ελαφριά διπλάρια/τριπλάρια με λεπτά σκουλήκια, και με ψαροντούφεκο σε ρηχούς μικτούς βυθούς."
  },
  "best": [
   "boat",
   "shore",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.22–0.25 mm or PE 0.4–0.6",
     "leader": "fluoro 0.14–0.22 mm, long droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 12–8 J, fine wire (common practice)",
    "notes": {
     "en": "Drift over sand with small stones and weed in 5–60 m; toothed sinker, lowest dropper on the bottom.",
     "el": "Ντρίφτο σε άμμο με πετραδάκια και φύκια σε 5–60 μ.· οδοντωτό μολύβι, το κάτω παράμαλλο στον βυθό."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "surf_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.22–0.28 mm",
     "leader": "fluoro 0.14–0.22 mm, long droppers"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 12–8 J, fine wire (common practice)",
    "notes": {
     "en": "Light toothed or spiral sinker; use the spool line clip to hit the same spot every cast and retrieve very slowly to raise silt.",
     "el": "Ελαφρύ οδοντωτό ή σπιράλ μολύβι· κλιπ στο μπομπινάκι για να πέφτεις στο ίδιο σημείο και πολύ αργό μάζεμα για να σηκώνει λάσπη."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Forages on sand beside rocks in 2–15 m; approach slowly from behind with a short gun (common practice). Licence; daylight only.",
     "el": "Ψάχνει τροφή στην άμμο δίπλα στις πέτρες σε 2–15 μ.· πλησίασε αργά από πίσω με κοντό όπλο (συνήθης πρακτική). Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Thin sand worms threaded with a needle.",
     "el": "Λεπτά σκουλήκια της άμμου περασμένα με βελόνα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Thin strips.",
     "el": "Λεπτές λωρίδες."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely; bait is far more reliable.",
    "el": "Σπάνια· το δόλωμα είναι πολύ πιο σίγουρο."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Fish a fine 2–3 hook rig with the bottom hook on the sand, move it slowly and strike on the quick shakes. Schools move slowly along the bottom: if bites stop, search nearby.",
   "el": "Λεπτή αρματωσιά με 2–3 αγκίστρια, το κάτω στην άμμο, μετακίνησέ τη αργά και κάρφωνε στα γρήγορα τινάγματα. Τα κοπάδια κινούνται αργά στον βυθό: αν σταματήσουν τα τσιμπήματα, ψάξε δίπλα."
  },
  "where": {
   "en": "Sand with scattered stones and weed patches, 2–60 m.",
   "el": "Άμμος με σκόρπιες πέτρες και φύκια, 2–60 μ."
  },
  "when": {
   "en": "September–December is best; daytime.",
   "el": "Καλύτερα Σεπτέμβριο–Δεκέμβριο· την ημέρα."
  },
  "handling": {
   "en": "Harmless. Minimum size 11 cm.",
   "el": "Ακίνδυνο. Ελάχιστο μέγεθος 11 εκ."
  },
  "eating": {
   "en": "Excellent fried.",
   "el": "Εξαιρετικό τηγανητό."
  },
  "sources": [
   "https://www.drososfishing.gr/casting-barbounia-katsoules-kaponia-enallaktiki-protasi/",
   "https://www.drososfishing.gr/katheti-mparmpoynia-sta-agkistria-mas/"
  ]
 },
 "greymullet": {
  "summary": {
   "en": "Caught in harbours, river mouths and on beaches with very light float or apiko rigs baited with bread, dough or sardine paste over groundbait; spearos ambush them in the foam.",
   "el": "Πιάνεται σε λιμάνια, εκβολές και παραλίες με πολύ ελαφρύ φελλό ή απίκο, με ψωμί, ζυμάρι ή ζύμη σαρδέλας πάνω από μαλάγρα· στο ψαροντούφεκο, καρτέρι στον αφρό."
  },
  "best": [
   "shore",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.14–0.20 mm (fine float, clear water) · 0.33–0.35 mm (apiko)",
     "leader": "fluoro 0.10–0.14 mm, short (clear water) · 0.28–0.30 mm (apiko)"
    },
    "rig": [
     "float_rig",
     "free_line"
    ],
    "hook": "size 18–12 J (fine float) · size 8–7 J or no. 6–4 spade-end (apiko)",
    "notes": {
     "en": "Slow-action rod and a long, very sensitive float with the least weight that reaches the bottom; drag at about two-thirds of the leader strength. Apiko: 7 m stiff carbon pole, rig about 6.5 m, 4–6 g conical float in calm water, round float in swell.",
     "el": "Καλάμι αργής δράσης και μακρύς, πολύ ευαίσθητος φελλός με το λιγότερο βάρος που φτάνει στον βυθό· φρένο στα δύο τρίτα της αντοχής του παράμαλλου. Απίκο: σκληρό ανθρακονήματος 7 μ., αρματωσιά περίπου 6,5 μ., κωνικός φελλός 4–6 γρ. στο λάδι, στρογγυλός στο κύμα."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Barrel length to suit visibility; double-barb shaft. Ambush still in the foam along beaches and breakwaters; after a shot the shoal moves only a few metres away. Sea bass often trail the shoal. Licence; daylight only.",
     "el": "Μήκος όπλου ανάλογα με την ορατότητα· βέργα με διπλό φτεράκι. Ακίνητο καρτέρι στον αφρό σε παραλίες και μώλους· μετά από βολή το κοπάδι απομακρύνεται μόνο λίγα μέτρα. Συχνά ακολουθούν λαβράκια στο πίσω μέρος του κοπαδιού. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "bread",
    "best": true,
    "note": {
     "en": "Bread flake, crust or soft bread-and-cheese dough; mullet suck the bait, keep it soft.",
     "el": "Ψίχα, κόρα ή μαλακό ζυμάρι ψωμιού με τυρί· ο κέφαλος ρουφάει το δόλωμα, κράτα το μαλακό."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sardine dough: 500 g mashed sardine, a quarter loaf of soaked bread, a little oil, firmed with rusk or flour.",
     "el": "Ζυμάρι σαρδέλας: 500 γρ. λιωμένη σαρδέλα, ένα τέταρτο καρβέλι μουσκεμένο ψωμί, λίγο λάδι, σφιγμένο με φρυγανιά ή αλεύρι."
    }
   },
   {
    "gear": "groundbait",
    "note": {
     "en": "Use the same flavour as the hook bait.",
     "el": "Ίδια γεύση με το δόλωμα του αγκιστριού."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: mullet almost never take lures.",
    "el": "Όχι: ο κέφαλος σχεδόν ποτέ δεν παίρνει τεχνητά."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Soaked bread with cheese or sardine mash and sand, matching the hook bait. Start with one ball, then 5–6, and add 1–2 whenever bites slow; essential in calm water. Where sold, a handful of maggots (bigattini) works as feed and, two to a hook, as bait.",
    "el": "Μουσκεμένο ψωμί με τυρί ή λιωμένη σαρδέλα και άμμο, ίδια γεύση με το δόλωμα. Ξεκίνα με μία μπάλα, μετά 5–6, και πρόσθετε 1–2 όποτε κόβουν τα τσιμπήματα· απαραίτητη στο λάδι. Όπου πωλείται, μια χούφτα μπιγκατίνι δουλεύει ως μαλάγρα και, δύο στο αγκίστρι, ως δόλωμα."
   }
  },
  "technique": {
   "en": "Sound the depth, groundbait the deepest hollow next to the quay, and fish the bait just off the bottom inside the cloud. Strike on the slightest float movement and play gently with a soft rod; land with a net.",
   "el": "Βυθομέτρησε, ρίξε μαλάγρα στο πιο βαθύ σημείο δίπλα στον ντόκο και ψάρευε το δόλωμα λίγο πάνω από τον βυθό μέσα στο σύννεφο. Κάρφωσε στην παραμικρή κίνηση του φελλού και κούρασέ τον απαλά με μαλακό καλάμι· βγάλ’ τον με απόχη."
  },
  "where": {
   "en": "Harbours next to quays, river mouths, beaches with breaking waves and lagoon outlets, 0–5 m.",
   "el": "Λιμάνια δίπλα στους ντόκους, εκβολές ποταμών, παραλίες με κύμα και στόμια λιμνοθαλασσών, 0–5 μ."
  },
  "when": {
   "en": "April–October is best, all day with peaks at dawn and dusk. Slightly murky water and moderate waves help; in clear calm water go very fine.",
   "el": "Καλύτερα Απρίλιο–Οκτώβριο, όλη μέρα, με κορυφώσεις χαράματα και σούρουπο. Βοηθάει λίγη θολούρα και μέτριο κύμα· σε καθαρά ήρεμα νερά πολύ λεπτά εργαλεία."
  },
  "handling": {
   "en": "No dangerous spines, but a soft mouth: use a net. Handle gently if releasing.",
   "el": "Δεν έχει επικίνδυνα αγκάθια, αλλά έχει μαλακό στόμα: απόχη. Απαλός χειρισμός αν τον αφήσεις."
  },
  "eating": {
   "en": "Open-sea mullet are good; fish from enclosed harbours, sewage outfalls or polluted river mouths can taste muddy and carry contaminants: avoid eating those.",
   "el": "Ο κέφαλος του ανοιχτού γιαλού είναι καλός· όσοι πιάνονται σε κλειστά λιμάνια, κοντά σε αποχετεύσεις ή σε μολυσμένες εκβολές μπορεί να μυρίζουν λάσπη και να έχουν ρύπους: καλύτερα να μην τρώγονται."
  },
  "sources": [
   "https://www.drososfishing.gr/kefalos-ta-10-mystika-epitychias-sto-psar/",
   "https://www.boatfishing.gr/article-post/apiko-psarema-kefaloy/",
   "https://www.boatfishing.gr/article-post/psarotoyfeko-psareyontas-kefaloys-sta-richa/",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_11.html"
  ]
 },
 "meagre": {
  "summary": {
   "en": "A vulnerable, mainly nocturnal rock fish (σκιός): anglers take it at dusk and night on single-hook rigs with worm, shrimp or crab; spearos take it by day at crevices. Keep one at most or release.",
   "el": "Ευάλωτος, κυρίως νυχτόβιος σκιός των βράχων: με καλάμι πιάνεται σούρουπο και νύχτα με μονάγκιστρο και σκουλήκι, γαρίδα ή καβούρι· στο ψαροντούφεκο την ημέρα στις σχισμές. Το πολύ ένα, ή απελευθέρωση."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "surf_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.28–0.35 mm (common practice)",
     "leader": "fluoro 0.28–0.35 mm, 0.5–1 m, or tie the hook straight to the main line"
    },
    "rig": [
     "bottom_rig",
     "carolina"
    ],
    "hook": "size 4–2 J, single hook",
    "notes": {
     "en": "Single hook with a sliding sinker, as light as you can cast; it fishes more naturally and snags less. If the fish bolts into a slab, give slack for 5–10 minutes and pull again.",
     "el": "Μονάγκιστρο με συρόμενη μολυβήθρα, όσο πιο ελαφριά γίνεται· ψαρεύει πιο φυσικά και κολλάει λιγότερο. Αν ο σκιός χωθεί σε πλάκα, άφησε χαλαρή πετονιά 5–10 λεπτά και ξανατράβα."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Hunt crevices, boulders and rockfalls next to posidonia; shoot outside the hole and aim for a clean first shot. Night spearfishing and lights are illegal in Cyprus. Take one fish at most and never clear out a nest.",
     "el": "Ψάξε σε χαρακιές, μονόπετρα και κατρακύλια δίπλα στην ποσειδωνία· βολή έξω από την τρύπα και καίριο πρώτο χτύπημα. Στην Κύπρο απαγορεύεται το νυχτερινό ψαροντούφεκο και ο φακός. Το πολύ ένα ψάρι, ποτέ «ξεκλήρισμα» φωλιάς."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.28–0.30 mm",
     "leader": "fluoro 0.28 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 4–1 J",
    "notes": {
     "en": "Anchor at dusk next to rock piles in 5–20 m with live shrimp or worm (common practice).",
     "el": "Άγκυρα το σούρουπο δίπλα σε σωρούς από πέτρες σε 5–20 μ. με ζωντανή γαρίδα ή σκουλήκι (συνήθης πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Pharaoh at night; black worm and μάνα also work.",
     "el": "Φαραώ τη νύχτα· δουλεύουν και το μαύρο και η μάνα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Live shrimp; it feeds mainly on shrimps and small fish.",
     "el": "Ζωντανή γαρίδα· τρέφεται κυρίως με γαριδάκια και μικρά ψάρια."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Small crab near rock slabs (general practice; worms and shrimp are better documented).",
     "el": "Καβουράκι κοντά στις πλάκες (γενική πρακτική· σκουλήκι και γαρίδα τεκμηριώνονται καλύτερα)."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: local sources describe only bait fishing (worms, shrimp, crab) and spearfishing; lure catches are not documented here.",
    "el": "Όχι: οι τοπικές πηγές περιγράφουν μόνο δόλωμα (σκουλήκι, γαρίδα, καβούρι) και ψαροντούφεκο· ψαριές με τεχνητά δεν τεκμηριώνονται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Cast accurately to the edge of big slabs between sand and weed, keep the rod in hand and strike on the firm pull. Fish move to nearby deeper spots, so a good spot may not stay good.",
   "el": "Ρίξε με ακρίβεια στην άκρη μεγάλων πλακών ανάμεσα σε άμμο και φύκια, καλάμι στο χέρι και κάρφωμα στο σταθερό τράβηγμα. Τα ψάρια μετακινούνται σε κοντινά βαθύτερα σημεία, οπότε ένα καλό σημείο δεν μένει πάντα καλό."
  },
  "where": {
   "en": "Rock piles, crevices, caves and rockfalls beside posidonia, 1–30 m.",
   "el": "Σωροί από πέτρες, χαρακιές, σπηλιές και κατρακύλια δίπλα στην ποσειδωνία, 1–30 μ."
  },
  "when": {
   "en": "May–October, at dusk and night; in winter and early spring also by day. Light breeze with small swell is best; dark moon better.",
   "el": "Μάιο–Οκτώβριο, σούρουπο και νύχτα· τον χειμώνα και αρχές άνοιξης και τη μέρα. Καλύτερα με ελαφρύ αεράκι και μικρό κύμα· καλύτερα στη χάση."
  },
  "handling": {
   "en": "Spiny fins; handle with a wet cloth and release quickly. Release fish under 31–32 cm (minimum biological size).",
   "el": "Αγκαθωτά πτερύγια· πιάσε με βρεγμένο πανί και άφησέ τον γρήγορα. Απελευθέρωσε όσους είναι κάτω από 31–32 εκ. (ελάχιστο βιολογικό μέγεθος)."
  },
  "eating": {
   "en": "Good eating, but the species is vulnerable to overfishing: at most 1–2 fish a day, and only one during the May–August spawning; catch and release is the wise choice.",
   "el": "Καλό ψάρι, αλλά το είδος είναι ευάλωτο στην υπεραλίευση: το πολύ 1–2 την ημέρα, και μόνο ένα την περίοδο ωοτοκίας Μάιο–Αύγουστο· το «πιάσε κι άφησε» είναι η σωστή επιλογή."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/casting-sikioi-me-monagkistra/",
   "https://www.boatfishing.gr/article-post/sikios-i-skios-viologia-anaptyxi-kai-anichneysi-tis-ilikias/",
   "https://www.boatfishing.gr/article-post/psarotoyfeko-sikios-ena-psari-poy-apopneei-mystirio/"
  ]
 },
 "seabass": {
  "summary": {
   "en": "Uncommon but prized: taken by spinning at dawn, dusk and night around harbours, river mouths and foamy rocks with minnows, soft shads and surface lures, on live shrimp or fish, and by spearos.",
   "el": "Όχι συχνό αλλά περιζήτητο: πιάνεται με spinning χαράματα, σούρουπο και νύχτα σε λιμάνια, εκβολές και βράχια με αφρό, με minnow, σιλικόνες shad και τεχνητά επιφανείας, με ζωντανή γαρίδα ή ψαράκι, και με ψαροντούφεκο."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.8–1.2 (light set PE 0.6–1.0)",
     "leader": "fluoro 0.28–0.35 mm, 1–1.5 m"
    },
    "rig": [
     "free_line",
     "float_rig",
     "livebait_rig"
    ],
    "hook": "lure trebles/singles · size 2–2/0 J or circle for live bait",
    "notes": {
     "en": "2.6 m rod, fast/medium, 7–35 g, with a 3000 reel; light set 2.4–2.5 m up to 20 g with a 2000–2500 reel for small soft lures; longer and stronger rod for strong headwinds. Leaders under 0.20 mm lose big fish.",
     "el": "Καλάμι 2,60 μ., γρήγορης/μεσαίας δράσης, 7–35 γρ., με μηχανάκι 3000· ελαφρύ σετ 2,40–2,50 μ. έως 20 γρ. με μηχανάκι 2000–2500 για μικρές σιλικόνες· μακρύτερο και δυνατότερο με δυνατό κόντρα αέρα. Με παράμαλλο κάτω από 0,20 χιλ. χάνονται τα μεγάλα."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "90–110 cm",
    "notes": {
     "en": "Ambush in the wash and foam at dawn; bass often trail mullet shoals. Longer gun in clear water. Licence; daylight only.",
     "el": "Καρτέρι στον αφρό και στο κύμα με το χάραμα· τα λαβράκια συχνά ακολουθούν τα κοπάδια των κεφάλων. Μακρύτερο όπλο σε καθαρά νερά. Με άδεια· μόνο με φως ημέρας."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.0–1.5",
     "leader": "fluoro 0.30–0.40 mm, 2 m"
    },
    "rig": [
     "trolling_rig"
    ],
    "hook": "lure trebles/singles",
    "notes": {
     "en": "Slow troll minnows at 2–3 knots along breakwaters and river mouths at first light, or cast to foam lines from a drifting boat (common practice).",
     "el": "Αργή συρτή με minnow 2–3 κόμβους κατά μήκος μώλων και εκβολών με το πρώτο φως, ή ρίψεις στις γραμμές του αφρού με τη βάρκα σε ντρίφτο (συνήθης πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Live shrimp hooked through the tail, especially in winter.",
     "el": "Ζωντανή γαρίδα περασμένη από την ουρά, ειδικά τον χειμώνα."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "Small live fish on a live-bait rig: σπάρος is rated the best, also small mullet or bogue; hook lightly under the skin behind the dorsal fin.",
     "el": "Μικρό ζωντανό ψάρι σε σύνθεση ζωντανού δολώματος: ο σπάρος θεωρείται το καλύτερο, και μικρός κέφαλος ή γόπα· αγκίστρωμα επιδερμικά πίσω από το ραχιαίο πτερύγιο."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fresh sardine at night in harbours.",
     "el": "Φρέσκια σαρδέλα τη νύχτα στα λιμάνια."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Big worms in murky water.",
     "el": "Μεγάλα σκουλήκια σε θολά νερά."
    }
   }
  ],
  "lures": [
   {
    "gear": "minnow",
    "weight": "10–25 g",
    "size": "10–14 cm",
    "colors": [
     "natural",
     "white",
     "sardine"
    ],
    "note": {
     "en": "Slow retrieve with twitches and irregular swimming; essential in winter.",
     "el": "Αργή ανάκτηση με τινάγματα και ακανόνιστο κολύμπι· απαραίτητο τον χειμώνα."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "5–20 g head",
    "size": "7–12 cm",
    "colors": [
     "natural",
     "white",
     "chartreuse"
    ],
    "note": {
     "en": "Light heads in the shallows, heavy in deep harbours; bright colours in murky water.",
     "el": "Ελαφριές μολυβοκεφαλές στα ρηχά, βαριές στα βαθιά λιμάνια· έντονα χρώματα στα θολά."
    }
   },
   {
    "gear": "stickbait",
    "weight": "14–40 g",
    "size": "10–14 cm",
    "colors": [
     "white",
     "sardine"
    ],
    "note": {
     "en": "Walk-the-dog in foam and over shallow ambush spots.",
     "el": "Walk-the-dog στον αφρό και πάνω από ρηχά σημεία ενέδρας."
    }
   },
   {
    "gear": "pencil",
    "weight": "14–40 g",
    "size": "9–14 cm",
    "colors": [
     "silver",
     "white"
    ],
    "note": {
     "en": "Sinking pencil for long casts into wind.",
     "el": "Βυθιζόμενο pencil για μακρινές ρίψεις με κόντρα αέρα."
    }
   },
   {
    "gear": "popper",
    "weight": "10–20 g",
    "size": "8–12 cm",
    "colors": [
     "white",
     "natural"
    ],
    "note": {
     "en": "Shallow water at first light.",
     "el": "Ρηχά νερά με το πρώτο φως."
    }
   },
   {
    "gear": "vibe",
    "weight": "10–20 g",
    "size": "6–9 cm",
    "colors": [
     "silver",
     "black"
    ],
    "note": {
     "en": "Searches deeper harbour water; black at night (common practice).",
     "el": "Ψάχνει τα βαθύτερα νερά των λιμανιών· μαύρο τη νύχτα (συνήθης πρακτική)."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, essential, especially over muddy weed beds: paddle-tail shads 7–12 cm on 5–20 g jig heads, or weightless on an offset hook in the shallows; slow with irregular twitches.",
    "el": "Ναι, απαραίτητες, ειδικά σε λασπώδεις βυθούς με φύκια: σιλικόνες shad 7–12 εκ. σε μολυβοκεφαλή 5–20 γρ., ή χωρίς βάρος σε αγκίστρι offset στα ρηχά· αργά με ακανόνιστα τινάγματα."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "natural",
    "white",
    "chartreuse"
   ],
   "size": "7–12 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used for lure fishing.",
    "el": "Δεν χρησιμοποιείται στο ψάρεμα με τεχνητά."
   }
  },
  "technique": {
   "en": "Fish low light and moving water: after or during an onshore blow, cast across the current and foam lines, retrieve slowly with twitches, and keep moving between spots with short exploratory casts. In harbours try after midnight.",
   "el": "Ψάρευε με λίγο φως και κινούμενο νερό: κατά ή μετά από αέρα προς την ακτή, ρίψεις κάθετα στο ρέμα και στον αφρό, αργή ανάκτηση με τινάγματα, και αλλαγή σημείων με σύντομες ρίψεις. Στα λιμάνια δοκίμασε μετά τα μεσάνυχτα."
  },
  "where": {
   "en": "Harbour mouths, river mouths, sandy beaches with foam, shallow rocky points and lagoon outlets, 0–5 m.",
   "el": "Μπούκες λιμανιών, εκβολές ποταμών, αμμουδιές με αφρό, ρηχοί βραχώδεις κάβοι και στόμια λιμνοθαλασσών, 0–5 μ."
  },
  "when": {
   "en": "November–March (spawning late December–March, water 13–15 °C); dusk, night and dawn. Strong onshore wind and the swell after it, strong currents; new and full moon.",
   "el": "Νοέμβριο–Μάρτιο (ωοτοκία τέλη Δεκεμβρίου–Μάρτιο, νερό 13–15 °C)· σούρουπο, νύχτα και χαράματα. Δυνατός αέρας προς την ακτή και το κύμα που αφήνει, δυνατά ρέματα· χάση και πανσέληνος."
  },
  "handling": {
   "en": "Razor-sharp gill covers and dorsal spines: use a lip grip and pliers. Minimum size 25 cm.",
   "el": "Ξυραφένια βράγχια και αγκάθια στη ράχη: λαβίδα στόματος και πένσα. Ελάχιστο μέγεθος 25 εκ."
  },
  "eating": {
   "en": "Excellent; release spawning fish in winter if you can.",
   "el": "Εξαιρετικό· άφησε όσα είναι γεμάτα αυγά τον χειμώνα αν μπορείς."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/spinning-gia-lavrakia/",
   "https://www.boatfishing.gr/article-post/lavrakia-me-spinning-mythoi-kai-alitheies-meros-1/",
   "https://www.boatfishing.gr/article-post/psarema-light-rock-fishing-stin-ellada-kai-tin-kypro-ta-psaria-exelissontai-oi-psarades/",
   "https://www.boatfishing.gr/article-post/psarotoyfeko-psareyontas-kefaloys-sta-richa/",
   "https://www.psarema.gr/blog/15-match-fishing/2188-match-fishing-me-waggler-felloto-psarema-toy-labrakioy-me-zwntanh-garda-meros-2o",
   "https://www.psarema.gr/sizitiseis/dolomata/247454-pos-dolonoume-zontano-psaraki"
  ]
 },
 "goatfish": {
  "summary": {
   "en": "An alien Red Sea goatfish common on Cypriot sand–rock edges by day; caught on small hooks with worm or shrimp on light bottom rigs, and easily speared. Local angling data are scarce (general practice).",
   "el": "Ξενικό μπαρμπούνι της Ερυθράς, συχνό στα όρια άμμου–πέτρας την ημέρα· πιάνεται με μικρά αγκίστρια, σκουλήκι ή γαρίδα σε ελαφριά σύνθεση βυθού, και εύκολα με ψαροντούφεκο. Λίγα τοπικά στοιχεία (γενική πρακτική)."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm or PE 0.3–0.6",
     "leader": "fluoro 0.16–0.20 mm"
    },
    "rig": [
     "bottom_rig",
     "drop_shot"
    ],
    "hook": "size 12–8 J, fine wire",
    "notes": {
     "en": "Light sinker on sand patches beside rocks; same approach as for striped red mullet (general practice).",
     "el": "Ελαφρύ μολύβι σε αμμουδερά σημεία δίπλα σε πέτρες· ίδια λογική με το μπαρμπούνι (γενική πρακτική)."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Forages openly on sand in 2–20 m by day; short gun, slow approach. Licence; daylight only.",
     "el": "Ψάχνει τροφή φανερά στην άμμο σε 2–20 μ. την ημέρα· κοντό όπλο, αργή προσέγγιση. Με άδεια· μόνο με φως ημέρας."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.22–0.25 mm",
     "leader": "fluoro 0.18–0.20 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "hook": "size 10–8 J",
    "notes": {
     "en": "Light καθετή on sand–rock edges 5–30 m (general practice).",
     "el": "Ελαφριά καθετή στα όρια άμμου–πέτρας 5–30 μ. (γενική πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Thin worms threaded with a needle.",
     "el": "Λεπτά σκουλήκια περασμένα με βελόνα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small strips.",
     "el": "Μικρές λωρίδες."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not an established method: there are no local reports of this goatfish on soft lures, and it feeds on small animals in the sand; bait (worm, shrimp) is the reliable option.",
    "el": "Δεν είναι καθιερωμένη μέθοδος: δεν υπάρχουν τοπικές αναφορές για σιλικόνες, και τρέφεται με μικρά ζώα της άμμου· το δόλωμα (σκουλήκι, γαρίδα) είναι η σίγουρη λύση."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Fish by day on sand patches next to rocks and seagrass, drag the bait slowly and strike on the quick shakes.",
   "el": "Ψάρευε την ημέρα σε αμμουδερά σημεία δίπλα σε πέτρες και ποσειδωνία, σέρνε αργά το δόλωμα και κάρφωνε στα γρήγορα τινάγματα."
  },
  "where": {
   "en": "Sand next to rocks and posidonia, 1–30 m.",
   "el": "Άμμος δίπλα σε πέτρες και ποσειδωνία, 1–30 μ."
  },
  "when": {
   "en": "May–November; daytime only, almost inactive at night.",
   "el": "Μάιο–Νοέμβριο· μόνο την ημέρα, τη νύχτα σχεδόν ανενεργό."
  },
  "handling": {
   "en": "Harmless.",
   "el": "Ακίνδυνο."
  },
  "eating": {
   "en": "Good, cooked like red mullet; an alien species, so keeping it does no harm to native stocks.",
   "el": "Καλό, μαγειρεύεται σαν μπαρμπούνι· είναι ξενικό είδος, οπότε το να το κρατάς δεν βλάπτει τα ντόπια αποθέματα."
  },
  "sources": [
   "https://www.drososfishing.gr/casting-barbounia-katsoules-kaponia-enallaktiki-protasi/",
   "https://www.fishbase.se/summary/Parupeneus-forsskali.html"
  ]
 },
 "rabbitfish": {
  "summary": {
   "en": "An abundant alien herbivore (κουρκούνα), caught on long float or apiko poles with bread-and-cheese dough or weed over bread groundbait near shallow rocks and in harbours; spearos take it in calm shallows. Venomous spines.",
   "el": "Άφθονη ξενική φυτοφάγα κουρκούνα· πιάνεται με μακριά καλάμια απίκο ή μπολονέζ, με ζυμάρι ψωμιού-τυριού ή φύκι πάνω από μαλάγρα ψωμιού, σε ρηχά βράχια και λιμάνια· στο ψαροντούφεκο σε ήρεμα ρηχά. Δηλητηριώδη αγκάθια."
  },
  "best": [
   "shore",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.22 mm",
     "leader": "fluoro 0.14–0.18 mm, single or double"
    },
    "rig": [
     "float_rig"
    ],
    "hook": "size 16–14 spade-end (σαλαγκιά)",
    "notes": {
     "en": "Light carbon pole or bolognese of 6–8 m. Float 2–5 g, with total shot about 1 g less than the float rating. Small mouth: small hooks.",
     "el": "Ελαφρύ καλάμι ανθρακονήματος 6–8 μ. (απίκο ή μπολονέζ). Φελλός 2–5 γρ., με συνολικό βάρος από σκάγια περίπου 1 γρ. λιγότερο από την άνωσή του. Μικρό στόμα: μικρά αγκίστρια."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Schools graze in calm shallows; easy shots. Handle the catch with gloves. Licence; daylight only.",
     "el": "Τα κοπάδια βόσκουν σε ήρεμα ρηχά· εύκολες βολές. Πιάσε την ψαριά με γάντια. Με άδεια· μόνο με φως ημέρας."
    }
   }
  },
  "baits": [
   {
    "gear": "bread",
    "best": true,
    "note": {
     "en": "Bread-and-cheese dough with scents; ready-made pastes mixed with seawater also work.",
     "el": "Ζυμάρι ψωμιού-τυριού με αρώματα· δουλεύουν και οι έτοιμες πάστες ανακατεμένες με θαλασσινό νερό."
    }
   },
   {
    "gear": "algae",
    "note": {
     "en": "Soft green weed, their natural food (common practice; Cypriot sources mainly use dough).",
     "el": "Μαλακό πράσινο φύκι, η φυσική τους τροφή (συνήθης πρακτική· οι κυπριακές πηγές χρησιμοποιούν κυρίως ζύμες)."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: herbivores that ignore lures.",
    "el": "Όχι: φυτοφάγα που αγνοούν τα τεχνητά."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Bread blended with seawater and some green weed, stiffened with flour or rusk; small balls often (common practice).",
    "el": "Ψωμί χτυπημένο με θαλασσινό νερό και λίγο πράσινο φύκι, σφιγμένο με αλεύρι ή φρυγανιά· μικρές μπάλες συχνά (συνήθης πρακτική)."
   }
  },
  "technique": {
   "en": "Groundbait close in beside weedy rocks, set the float so the dough hangs near the bottom where they graze, and strike on small dips; bites are delicate.",
   "el": "Μαλάγρα κοντά, δίπλα σε βράχια με φύκια, φελλός ρυθμισμένος ώστε το ζυμάρι να κρέμεται κοντά στον βυθό όπου βόσκουν, και κάρφωμα στα μικρά βουλιάγματα· τα τσιμπήματα είναι λεπτά."
  },
  "where": {
   "en": "Rocky and mixed bottoms with algae, harbours, breakwaters and posidonia, 0.5–10 m.",
   "el": "Πετρώδεις και μικτοί βυθοί με φύκια, λιμάνια, μώλοι και ποσειδωνία, 0,5–10 μ."
  },
  "when": {
   "en": "Inshore from mid-spring to mid-autumn (now almost all year); the first hours after sunrise and before sunset; calm water.",
   "el": "Κοντά στην ακτή από τα μέσα της άνοιξης ως τα μέσα του φθινοπώρου (πλέον σχεδόν όλο τον χρόνο)· τις πρώτες ώρες μετά την ανατολή και πριν τη δύση· ήρεμα νερά."
  },
  "handling": {
   "en": "Venomous dorsal, pelvic and anal spines: always gloves or a cloth, unhook with pliers. If stung, soak in hot (not scalding) water and seek help if pain is severe.",
   "el": "Δηλητηριώδη αγκάθια στη ράχη, στην κοιλιά και στο εδρικό πτερύγιο: πάντα γάντια ή πανί, ξαγκίστρωμα με πένσα. Σε τσίμπημα, βύθισε σε ζεστό (όχι καυτό) νερό και ζήτα βοήθεια αν ο πόνος είναι έντονος."
  },
  "eating": {
   "en": "Good and popular grilled in Cyprus; an alien species, so keeping it helps native fish. Cut the spines off before cleaning.",
   "el": "Καλή και αγαπημένη στη σχάρα στην Κύπρο· ξενικό είδος, οπότε το να την κρατάς βοηθά τα ντόπια ψάρια. Κόψε τα αγκάθια πριν το καθάρισμα."
  },
  "sources": [
   "http://fishingcy.blogspot.com/2013/06/blog-post_10.html",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_16.html",
   "https://magfishing.gr/arthra/match-fishing-bolognese/to-psarema-tou-germanou-kourkounas-me-tin-texniki-match-waggler-fishing-eggleziko-carpmatchfishing"
  ]
 },
 "parrotfish": {
  "summary": {
   "en": "Mostly speared over shallow algal reefs in summer; anglers use small hooks with shrimp, dough or weed on light float rigs right beside the rocks.",
   "el": "Κυρίως με ψαροντούφεκο σε ρηχές ξέρες με φύκια το καλοκαίρι· με καλάμι, μικρό αγκίστρι με γαρίδα, ζυμάρι ή φύκι σε ελαφρύ φελλό κολλητά στα βράχια."
  },
  "best": [
   "spear",
   "shore",
   "boat"
  ],
  "setups": {
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Shallow rocky reefs with algae in 2–15 m; groups gather near shore in summer. Ambush along the reef edge. Licence; daylight only.",
     "el": "Ρηχές βραχώδεις ξέρες με φύκια σε 2–15 μ.· το καλοκαίρι μαζεύονται κοπάδια κοντά στην ακτή. Καρτέρι στην άκρη της ξέρας. Με άδεια· μόνο με φως ημέρας."
    }
   },
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm",
     "leader": "fluoro 0.14–0.18 mm"
    },
    "rig": [
     "float_rig"
    ],
    "hook": "size 10–8 J",
    "notes": {
     "en": "Small float balanced with shot so the fish feels nothing. It takes the bait slowly and steadily: wait for a gentle sink and a pause, then strike.",
     "el": "Μικρός φελλός ζυγισμένος με σκάγια για να μη νιώθει αντίσταση. Παίρνει το δόλωμα αργά και σταθερά: περίμενε ένα απαλό βούλιαγμα και μια παύση και μετά κάρφωσε."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.20–0.25 mm",
     "leader": "fluoro 0.18–0.20 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "hook": "size 10–8 J",
    "notes": {
     "en": "Anchored close to shallow reefs with light tackle; occasional catch (general practice).",
     "el": "Με άγκυρα κοντά σε ρηχές ξέρες και ελαφριά εργαλεία· περιστασιακά (γενική πρακτική)."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small shrimp works well.",
     "el": "Το γαριδάκι δουλεύει καλά."
    }
   },
   {
    "gear": "algae",
    "note": {
     "en": "Fine green weed, its natural food (common practice; anglers report shrimp and dough more often).",
     "el": "Λεπτό πράσινο φύκι, η φυσική του τροφή (συνήθης πρακτική· οι ψαράδες αναφέρουν πιο συχνά γαρίδα και ζυμάρι)."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Dough (also with purslane) on a small hook.",
     "el": "Ζυμάρι (και με γλιστρίδα) σε μικρό αγκίστρι."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "A crab leg with some flesh.",
     "el": "Ποδαράκι καβουριού με λίγη σάρκα."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Acrobat worm.",
     "el": "Ακροβάτης."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "No: lures rarely work.",
    "el": "Όχι: τα τεχνητά σπάνια δουλεύουν."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not usually used.",
    "el": "Συνήθως δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Fish early morning beside specific rocky spots where they feed, with a fine leader and tiny float, and be patient with the slow bite.",
   "el": "Ψάρευε νωρίς το πρωί δίπλα σε συγκεκριμένα βραχώδη σημεία όπου τρώνε, με λεπτό παράμαλλο και μικρό φελλό, και έχε υπομονή στο αργό τσίμπημα."
  },
  "where": {
   "en": "Shallow rocky reefs with algae and posidonia, 1–20 m.",
   "el": "Ρηχές βραχώδεις ξέρες με φύκια και ποσειδωνία, 1–20 μ."
  },
  "when": {
   "en": "May–September; early morning (about 6–10) and dusk; calm water.",
   "el": "Μάιο–Σεπτέμβριο· νωρίς το πρωί (περίπου 6–10) και σούρουπο· ήρεμα νερά."
  },
  "handling": {
   "en": "Strong beak-like teeth can bite; keep fingers away and use pliers.",
   "el": "Τα δυνατά δόντια-ράμφος δαγκώνουν· μακριά τα δάχτυλα, ξαγκίστρωμα με πένσα."
  },
  "eating": {
   "en": "Delicious; traditionally cooked whole with the guts, so it is best caught early in the morning on an empty stomach, removing the bile through a small cut behind the right pectoral fin.",
   "el": "Νοστιμότατος· παραδοσιακά ψήνεται ολόκληρος με τα εντόσθια, γι’ αυτό καλύτερα να πιάνεται νωρίς το πρωί με άδειο στομάχι, βγάζοντας τη χολή από μια μικρή τομή πίσω από το δεξί θωρακικό πτερύγιο."
  },
  "sources": [
   "https://www.psarema.gr/sizitiseis/psaria-tis-8alassas/78226-skaros.html",
   "https://psarema-cy.blogspot.com/2013/11/blog-post_16.html"
  ]
 }
});
