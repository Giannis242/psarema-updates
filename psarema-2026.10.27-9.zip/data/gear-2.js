// Gear guides, part 2 (18 species).
Object.assign(window.PSAREMA_GEAR ||= {}, {
 "grouper": {
  "summary": {
   "en": "Dusky grouper: a heavy ambusher of rocky drop-offs that bolts for its hole when hooked. Best by boat with live bait or slow jigs at 20–80 m, or by spearfishing. Keep only fish over 45 cm, and consider releasing even those (IUCN Vulnerable).",
   "el": "Ροφός: βαρύ ψάρι-ενέδρα των βραχωδών κατωφερειών, που μόλις αγκιστρωθεί τρέχει στην τρύπα του. Καλύτερα από σκάφος με ζωντανό δόλωμα ή slow jigging στα 20–80 m, ή με ψαροντούφεκο. Κρατήστε μόνο ψάρια πάνω από 45 cm και σκεφτείτε να απελευθερώσετε κι αυτά (Ευάλωτο είδος IUCN)."
  },
  "best": [
   "boat",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "slow_jig_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 2–4",
     "leader": "fluoro 0.60–0.90 mm, 3–5 m"
    },
    "rig": [
     "livebait_rig",
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_circle",
     "hook_j",
     "assist_hook",
     "sinker",
     "swivel"
    ],
    "hook": "J 4/0–6/0 · circle 6/0–8/0 · assist 2/0–4/0",
    "notes": {
     "en": "Fish 1–3 m above the bottom, right over the structure. Drag almost locked (6–10 kg on PE 3) and win the first 5–10 m at once: a grouper that reaches its hole is usually lost. If it holes up, hold light tension for a few minutes; it often swims out. Live-bait rig: 150–400 g sinker on a 1 m weaker dropper (0.40 mm) so a snag costs only the lead, then 2–3 m of fluoro to the hook.",
     "el": "Ψαρεύετε 1–3 m πάνω από τον βυθό, πάνω στην ίδια την ξέρα. Φρένο σχεδόν κλειστό (6–10 kg σε PE 3) και κερδίστε αμέσως τα πρώτα 5–10 m: ροφός που φτάνει στην τρύπα του συνήθως χάνεται. Αν «τρυπώσει», κρατήστε ελαφριά τάση λίγα λεπτά· συχνά βγαίνει μόνος του. Αρματωσιά ζωντανού: μολύβι 150–400 g σε πιο αδύναμο κλάδο 1 m (0,40 mm), ώστε στο πιάσιμο να χάνεται μόνο το μολύβι, και 2–3 m παράμαλλο fluoro ως το αγκίστρι."
    }
   },
   "spear": {
    "gun": [
     "gun_pneu",
     "gun_band"
    ],
    "length": "90–110 cm",
    "notes": {
     "en": "Search holes, ledges and boulder piles at 10–30 m in the warm months, sliding slowly along the bottom or waiting still at a hole mouth. Aim at the head or just behind the gill cover for a clean kill; never shoot a fish deep in a hole you cannot reach. A 45 cm grouper weighs only about 1.2–1.5 kg: if in doubt, do not shoot. Always tow a float.",
     "el": "Ψάξτε τρύπες, πεζούλες και ογκόλιθους στα 10–30 m τους ζεστούς μήνες, γλιστρώντας αργά στον βυθό ή με καρτέρι στο στόμιο της τρύπας. Σημαδέψτε στο κεφάλι ή ακριβώς πίσω από το βράγχιο για καθαρό χτύπημα· ποτέ σε ψάρι βαθιά μέσα σε τρύπα που δεν μπορείτε να φτάσετε. Ροφός 45 cm ζυγίζει μόνο 1,2–1,5 kg περίπου: αν έχετε αμφιβολία, μη ρίχνετε. Πάντα με σημαδούρα."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Octopus is the classic grouper bait in Greek practice, live or fresh (even frozen works); cuttlefish and squid come next. A small whole octopus or cuttlefish on a two-hook rig.",
     "el": "Το χταπόδι είναι το κλασικό δόλωμα για ροφό στην ελληνική πρακτική, ζωντανό ή φρέσκο (πιάνει και κατεψυγμένο)· ακολουθούν σουπιά και καλαμάρι. Μικρό ολόκληρο χταπόδι ή σουπιά σε αρματωσιά με δύο αγκίστρια."
    }
   },
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Live bogue, picarel or small horse mackerel, hooked through the lips or just behind the dorsal fin, clear of the spine.",
     "el": "Ζωντανή γόπα, μαρίδα ή μικρό σαφρίδι, αγκιστρωμένο από τα χείλη ή λίγο πίσω από το ραχιαίο, χωρίς να πειραχτεί η σπονδυλική στήλη."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "A whole dead sardine works, but morays and toadfish usually find it first.",
     "el": "Ολόκληρη νεκρή σαρδέλα πιάνει, αλλά συνήθως τη βρίσκουν πρώτα οι σμέρνες και οι λαγοκέφαλοι."
    }
   }
  ],
  "lures": [
   {
    "gear": "slow_jig",
    "weight": "120–300 g",
    "size": "",
    "colors": [
     "glow",
     "red",
     "gold",
     "pink"
    ],
    "note": {
     "en": "Greek boat anglers mostly use 120–150 g at 30–60 m; go heavier in current so the line stays near vertical. Bright colours in winter and spring, darker in summer and autumn; glow when deep or in low light.",
     "el": "Οι Έλληνες ψαράδες από σκάφος χρησιμοποιούν κυρίως 120–150 g στα 30–60 m· βαρύτερο με ρεύμα ώστε η πετονιά να μένει σχεδόν κάθετη. Έντονα χρώματα χειμώνα και άνοιξη, πιο σκούρα καλοκαίρι και φθινόπωρο· φωσφοριζέ στα βαθιά ή με λίγο φως."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "40–100 g head",
    "size": "12–20 cm",
    "colors": [
     "sardine",
     "natural",
     "white"
    ],
    "note": {
     "en": "Big paddle-tail on a fairly light head (about 60 g) so it falls slowly over the rocks; Greek boat anglers favour blue tones.",
     "el": "Μεγάλη σιλικόνη με ουρά-πτερύγιο σε σχετικά ελαφριά μολυβοκεφαλή (περίπου 60 g), ώστε να πέφτει αργά πάνω από τα βράχια· οι Έλληνες ψαράδες από σκάφος προτιμούν μπλε αποχρώσεις."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "14–20 cm",
    "colors": [
     "red_head",
     "orange",
     "natural"
    ],
    "note": {
     "en": "Bottom trolling at about 3–3.5 knots, kept within about 3 m of the bottom with sinkers; metal-lipped lures in bright sun, plastic-lipped at dawn and dusk. Bright colours deep, darker in the shallows.",
     "el": "Συρτή βυθού στους 3–3,5 κόμβους περίπου, με μολύβια ώστε το τεχνητό να περνά ως 3 m πάνω από τον βυθό· μεταλλική γλώσσα με δυνατό ήλιο, πλαστική χαράματα και σούρουπο. Έντονα χρώματα στα βαθιά, πιο σκούρα στα ρηχά."
    }
   },
   {
    "gear": "inchiku",
    "weight": "100–200 g",
    "size": "",
    "colors": [
     "red",
     "gold",
     "glow"
    ],
    "note": {
     "en": "Slow lifts of 1–2 m close to the bottom; the octopus skirt flutters on the fall, where most bites come.",
     "el": "Αργά σηκώματα 1–2 m κοντά στον βυθό· το χταποδάκι ανεμίζει στην πτώση, εκεί που έρχονται τα περισσότερα τσιμπήματα."
    }
   },
   {
    "gear": "tai_rubber",
    "weight": "80–150 g",
    "size": "",
    "colors": [
     "orange",
     "red",
     "chartreuse"
    ],
    "note": {
     "en": "Touch bottom, wind steadily for 10–15 turns, drop again. No jerks; keep winding when you feel taps.",
     "el": "Ακουμπήστε βυθό, μαζέψτε σταθερά 10–15 στροφές και ξανακατεβάστε. Χωρίς τινάγματα· στα «κτυπήματα» συνεχίστε το μάζεμα."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, a main method: 12–20 cm paddle-tail shads on fairly light 40–100 g heads (about 60 g lets a big body fall slowly), hopped along rocky bottom at 15–80 m, or a big shad on a weedless 6/0–8/0 hook in very snaggy ground. Bites come on the fall, so keep the line tight. Greek boat anglers favour blue tones.",
    "el": "Ναι, βασική μέθοδος: σιλικόνες shad 12–20 cm σε σχετικά ελαφριές μολυβοκεφαλές 40–100 g (με περίπου 60 g το μεγάλο σώμα πέφτει αργά), με πηδηματάκια σε βραχώδη βυθό στα 15–80 m, ή μεγάλο shad σε αγκίστρι weedless 6/0–8/0 σε πολύ «κολλητικό» βυθό. Τα τσιμπήματα έρχονται στην πτώση: κρατάτε την πετονιά τεντωμένη. Οι Έλληνες ψαράδες από σκάφος προτιμούν μπλε αποχρώσεις."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "sardine",
    "natural",
    "white"
   ],
   "size": "12–20 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used: groupers stay on their structure, so go to them.",
    "el": "Δεν χρησιμοποιείται: ο ροφός μένει στη δομή του, πηγαίνετε εσείς σε αυτόν."
   }
  },
  "technique": {
   "en": "Slow pitch: drop to the bottom, work the first 5–10 m with short half-turn pitches and long falls, then drop again; strikes come on the fall. Live bait: lower to the bottom, lift 1–2 m and keep adjusting as the depth changes; on a bite give 2–3 seconds with a J hook, or just wind steadily with a circle. Either way, pump the fish 5–10 m up at once.",
   "el": "Slow pitch: κατεβάστε στον βυθό, δουλέψτε τα πρώτα 5–10 m με κοντά χτυπήματα μισής στροφής και μεγάλες πτώσεις, και ξανά κάτω· τα χτυπήματα έρχονται στην πτώση. Ζωντανό: κατεβάστε στον βυθό, σηκώστε 1–2 m και διορθώνετε καθώς αλλάζει το βάθος· στο τσίμπημα δώστε 2–3 δευτερόλεπτα με αγκίστρι J ή απλώς μαζέψτε σταθερά με circle. Σε κάθε περίπτωση σηκώστε αμέσως το ψάρι 5–10 m."
  },
  "where": {
   "en": "Rocky drop-offs, reef edges, boulder fields and wrecks at 20–80 m (spearos 10–30 m). In Cyprus, mainly the rocky west and south: Paphos–Pomos, Akamas outside the reserves, Cape Gata, Cape Pyla and Cape Greco outside its protected zone. Check the map’s protected areas first.",
   "el": "Βραχώδεις κατωφέρειες, άκρες από ξέρες, πεδία με ογκόλιθους και ναυάγια στα 20–80 m (ψαροντουφεκάδες 10–30 m). Στην Κύπρο κυρίως η βραχώδης δυτική και νότια ακτή: Πάφος–Πωμός, Ακάμας έξω από τις προστατευόμενες περιοχές, Κάβο Γάτα, Κάβο Πύλα και Κάβο Γκρέκο έξω από τη ζώνη προστασίας. Ελέγξτε πρώτα τις προστατευόμενες περιοχές στον χάρτη."
  },
  "when": {
   "en": "All year by boat, best May–November; spearfishing June–October when warm water brings fish shallow. Dawn and dusk, and the turn of the current.",
   "el": "Όλο τον χρόνο από σκάφος, καλύτερα Μάιο–Νοέμβριο· ψαροντούφεκο Ιούνιο–Οκτώβριο, όταν το ζεστό νερό φέρνει τα ψάρια ρηχά. Χαράματα και σούρουπο, και στην αλλαγή του ρεύματος."
  },
  "handling": {
   "en": "Sharp gill-cover spines and edges: use gloves and a lip grip, net rather than gaff a fish you may release. Fish from below 20 m often have a blown swim bladder: release fast with a descending weight rather than leaving them floating.",
   "el": "Κοφτερά αγκάθια και άκρες στα βραγχιακά καλύμματα: γάντια και λαβίδα στόματος, απόχη αντί για γάντζο σε ψάρι που ίσως απελευθερώσετε. Ψάρια από κάτω από 20 m έχουν συχνά φουσκωμένη νηκτική κύστη: απελευθερώστε τα γρήγορα με βαρίδι κατάβασης, μην τα αφήνετε να επιπλέουν."
  },
  "eating": {
   "en": "Excellent firm white flesh. But it is IUCN Vulnerable, slow-growing and changes sex from female to male as it grows, so big fish are the breeding males: keep one legal fish at most and release the rest.",
   "el": "Εξαιρετικό, σφιχτό άσπρο κρέας. Είναι όμως Ευάλωτο είδος (IUCN), μεγαλώνει αργά και αλλάζει φύλο από θηλυκό σε αρσενικό καθώς μεγαλώνει, άρα τα μεγάλα ψάρια είναι τα αρσενικά της αναπαραγωγής: κρατήστε το πολύ ένα νόμιμο ψάρι και απελευθερώστε τα υπόλοιπα."
  },
  "sources": [
   "https://www.drososfishing.gr/afieroma-rofos-tropoi-psarematos-me-sk/",
   "https://www.boatfishing.gr/article-post/afieroma-psarema-apo-varka-me-stocho-ta-mayra-psaria/",
   "https://www.boatfishing.gr/article-post/paradosiaka-psaremata-syrti-vythoy/",
   "https://www.drososfishing.gr/shore-jigging-planos-i-silikoni/",
   "https://www.psarema.gr/sizitiseis/old-genikes-erotisis/189287-%CF%80%CE%BF%CE%B9%CE%BF-%CE%B5%CE%B9%CE%BD%CE%B1%CE%B9-%CF%84%CE%BF-%CE%BA%CE%B1%CE%BB%CF%85%CF%84%CE%B5%CF%81%CE%BF-%CE%B4%CF%8C%CE%BB%CF%89%CE%BC%CE%B1-%CE%B3%CE%B9%CE%B1-%CF%84%CE%BF-%CF%88%CE%AC%CF%81%CE%B5%CE%BC%CE%B1-%CF%84%CF%89%CE%BD-%CF%81%CE%BF%CF%86%CF%8E%CE%BD",
   "https://www.fishbase.se/summary/Epinephelus-marginatus.html",
   "https://anglers-secrets.com/grouper-season-in-the-mediterranean/",
   "https://johnnyjigs.com/blogs/news/slow-pitch-jigging-for-grouper-a-primer",
   "https://oceanslegacy.co.nz/jig-weight-and-line-angle-a-key-to-successful-slow-pitch-jigging/",
   "https://adriaticnature.com/archives/6668",
   "https://www.psarema.gr/blog/19-syrti/1485-syrti-me-molyvi-fylaka-ta-vasika",
   "https://fishingbooker.com/blog/?p=54089",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "whitegrouper": {
  "summary": {
   "en": "White grouper: a grouper of the rock–sand and mud edges, roaming more than the dusky grouper. Live bait, slow jigs and tai rubbers by boat at 20–100 m; spearfishing on sand-and-rock edges. Minimum 45 cm, and most females only mature at 50–60 cm.",
   "el": "Σφυρίδα: ροφός των ορίων βράχου–άμμου και λάσπης, που κυκλοφορεί περισσότερο από τον ροφό. Ζωντανό δόλωμα, slow jigging και tai rubber από σκάφος στα 20–100 m· ψαροντούφεκο στις άκρες άμμου και βράχου. Ελάχιστο 45 cm, και τα περισσότερα θηλυκά ωριμάζουν μόλις στα 50–60 cm."
  },
  "best": [
   "boat",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "slow_jig_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 1.5–3",
     "leader": "fluoro 0.50–0.70 mm, 3–5 m"
    },
    "rig": [
     "livebait_rig",
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_circle",
     "assist_hook",
     "sinker",
     "swivel"
    ],
    "hook": "J 2/0–5/0 · circle 5/0–7/0 · assist 1/0–3/0",
    "notes": {
     "en": "Drift slowly along the line where rock patches meet sand or mud. Less hole-bound than the dusky grouper, so a slightly lighter outfit is fine, but still fight it hard off the bottom.",
     "el": "Ντριφτάρετε αργά πάνω στη γραμμή όπου οι πέτρες συναντούν την άμμο ή τη λάσπη. Τρυπώνει λιγότερο από τον ροφό, οπότε αρκεί λίγο πιο ελαφρύς εξοπλισμός, αλλά και πάλι ξεκολλήστε το αποφασιστικά από τον βυθό."
    }
   },
   "spear": {
    "gun": [
     "gun_pneu",
     "gun_band"
    ],
    "length": "90–110 cm",
    "notes": {
     "en": "Glide along rock–sand edges and lone rocks on sand at 12–30 m and wait; it often comes to look. Shoot only clearly large fish.",
     "el": "Γλιστρήστε στις άκρες βράχου–άμμου και στις μοναχικές πέτρες στην άμμο στα 12–30 m και περιμένετε· συχνά έρχεται να κοιτάξει. Χτυπήστε μόνο ξεκάθαρα μεγάλα ψάρια."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Live bogue, picarel or small mullet, fished just off the bottom.",
     "el": "Ζωντανή γόπα, μαρίδα ή μικρός κέφαλος, λίγο πάνω από τον βυθό."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Live or fresh squid or cuttlefish, whole; strong on muddy grounds.",
     "el": "Ζωντανό ή φρέσκο καλαμάρι ή σουπιά, ολόκληρο· πολύ καλό σε λασπώδεις βυθούς."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Large shrimp or prawns on a two-hook bottom rig: crustaceans are roughly a third of its diet (FishBase). They also take smaller fish.",
     "el": "Μεγάλες γαρίδες σε αρματωσιά βυθού με δύο αγκίστρια: τα καρκινοειδή είναι περίπου το ένα τρίτο της τροφής της (FishBase). Πιάνουν και μικρότερα ψάρια."
    }
   }
  ],
  "lures": [
   {
    "gear": "slow_jig",
    "weight": "120–200 g",
    "size": "",
    "colors": [
     "gold",
     "red",
     "glow",
     "pink"
    ],
    "note": {
     "en": "A knife-type slow jig of about 150 g at 40–120 m, with assist hooks front and back; Greek anglers rate gold-red highly. Short pitches in the bottom 5 m, long falls.",
     "el": "Slow jig τύπου «μαχαίρι» περίπου 150 g στα 40–120 m, με assist μπρος και πίσω· οι Έλληνες ψαράδες εμπιστεύονται το χρυσοκόκκινο. Κοντά χτυπήματα στα τελευταία 5 m από τον βυθό, μεγάλες πτώσεις."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "14–20 cm",
    "colors": [
     "orange",
     "red_head",
     "natural"
    ],
    "note": {
     "en": "Traditional bottom trolling at about 3–3.5 knots over mud with scattered rocks, lure kept within about 3 m of the bottom; plastic-lipped lures early morning and late afternoon.",
     "el": "Παραδοσιακή συρτή βυθού στους 3–3,5 κόμβους περίπου, πάνω από λάσπη με σκόρπιες πέτρες, με το τεχνητό ως 3 m πάνω από τον βυθό· πλαστική γλώσσα νωρίς το πρωί και αργά το απόγευμα."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "30–100 g",
    "size": "10–15 cm",
    "colors": [
     "natural",
     "white"
    ],
    "note": {
     "en": "Bounce it over sand and rock edges; Greek shore anglers call soft lures the way to go for white grouper.",
     "el": "Χοροπηδάτε τη σιλικόνη πάνω από άκρες άμμου και βράχου· για τους Έλληνες ψαράδες από την ακτή, για σφυρίδα οι σιλικόνες είναι «μονόδρομος»."
    }
   },
   {
    "gear": "tai_rubber",
    "weight": "60–150 g",
    "size": "",
    "colors": [
     "orange",
     "red",
     "chartreuse"
    ],
    "note": {
     "en": "Steady slow retrieve over sand edges; tai rubbers take most bottom predators, groupers included.",
     "el": "Σταθερό αργό μάζεμα πάνω από άκρες άμμου· το tai rubber πιάνει τα περισσότερα αρπακτικά του βυθού, και τους ροφούς."
    }
   },
   {
    "gear": "inchiku",
    "weight": "80–180 g",
    "size": "",
    "colors": [
     "red",
     "glow"
    ],
    "note": {
     "en": "Slow lift-and-drop on the bottom.",
     "el": "Αργό σήκωμα και πτώση στον βυθό."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 10–15 cm paddle-tail shads on 30–100 g jig heads, dragged and hopped along the sand edge; a strip of squid on the hook helps on slow days.",
    "el": "Ναι: σιλικόνες shad 10–15 cm σε μολυβοκεφαλές 30–100 g, σέρνοντας και χοροπηδώντας στην άκρη της άμμου· μια λωρίδα καλαμάρι στο αγκίστρι βοηθά στις «νεκρές» μέρες."
   },
   "ids": [
    "soft_shad"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Drift or slow-motor along the edge with jigs or tai rubbers kept in the bottom 5 m; anchor on a productive patch and fish live bait 1–2 m up. Strike firmly and keep the fish coming.",
   "el": "Ντρίφτα ή αργή μηχανή κατά μήκος της άκρης, με τζιγκ ή tai rubber στα τελευταία 5 m· αγκυροβολήστε σε καλό σημείο και ψαρέψτε ζωντανό 1–2 m πάνω από τον βυθό. Δυνατό κάρφωμα και συνεχές μάζεμα."
  },
  "where": {
   "en": "Mixed rock, sand and mud bottoms at 20–100 m, around rock patches and lone boulders; Larnaca Bay and the south coast shelf are typical Cypriot grounds.",
   "el": "Μεικτοί βυθοί με βράχο, άμμο και λάσπη στα 20–100 m, γύρω από πέτρες και μοναχικούς ογκόλιθους· ο κόλπος της Λάρνακας και η υφαλοκρηπίδα της νότιας ακτής είναι τυπικοί κυπριακοί τόποι."
  },
  "when": {
   "en": "June–October; dawn and dusk.",
   "el": "Ιούνιο–Οκτώβριο· χαράματα και σούρουπο."
  },
  "handling": {
   "en": "Gill-cover spines: gloves and a lip grip. Fish from depth suffer barotrauma: release quickly with a descending weight.",
   "el": "Αγκάθια στα βραγχιακά: γάντια και λαβίδα στόματος. Ψάρια από βαθιά παθαίνουν βαρότραυμα: απελευθέρωση γρήγορα με βαρίδι κατάβασης."
  },
  "eating": {
   "en": "Excellent. IUCN Near Threatened: release fish under about 60 cm that have probably not yet spawned, even if legal.",
   "el": "Εξαιρετικό. Σχεδόν Απειλούμενο είδος (IUCN): απελευθερώστε ψάρια κάτω από 60 cm περίπου, που μάλλον δεν έχουν ακόμη γεννήσει, ακόμη κι αν είναι νόμιμα."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/afieroma-psarema-apo-varka-me-stocho-ta-mayra-psaria/",
   "https://www.boatfishing.gr/article-post/paradosiaka-psaremata-syrti-vythoy/",
   "https://www.boatfishing.gr/article-post/sto-epikentro-rofos-stira-pigka-kai-sfyrida/",
   "https://www.drososfishing.gr/armatosia-teleferik-gia-synagrides-rofoys-sfyrides-stires-amp-magiatika/",
   "https://www.drososfishing.gr/shore-jigging-planos-i-silikoni/",
   "https://www.fishbase.se/summary/Epinephelus-aeneus.html",
   "https://oceanslegacy.co.nz/jig-weight-and-line-angle-a-key-to-successful-slow-pitch-jigging/",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "goldblotch": {
  "summary": {
   "en": "Goldblotch grouper: a curious, mid-sized grouper of rock–sand edges at 10–60 m. A classic spearfishing fish (it comes close to a still diver); by boat on slow jigs, trolled diving lures or live bait. Minimum 45 cm; juveniles live shallow in small groups.",
   "el": "Στήρα: περίεργος, μεσαίου μεγέθους ροφός στις άκρες βράχου–άμμου στα 10–60 m. Κλασικό ψάρι για ψαροντούφεκο (πλησιάζει τον ακίνητο δύτη)· από σκάφος με slow jig, συρτή με βυθιζόμενα τεχνητά ή ζωντανό. Ελάχιστο 45 cm· τα μικρά ζουν ρηχά σε μικρές ομάδες."
  },
  "best": [
   "spear",
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "slow_jig_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.5–2.5",
     "leader": "fluoro 0.45–0.60 mm, 3 m"
    },
    "rig": [
     "livebait_rig",
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_circle",
     "assist_hook",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–4/0 · circle 4/0–6/0 · assist 1/0–2/0",
    "notes": {
     "en": "Lighter than dusky-grouper tackle is enough, but keep the drag firm near the rocks.",
     "el": "Αρκεί πιο ελαφρύς εξοπλισμός από του ροφού, αλλά με σφιχτό φρένο κοντά στα βράχια."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "75–100 cm",
    "notes": {
     "en": "Lie still on the bottom at rock–sand edges at 8–25 m (aspetto) and let it approach; avoid sudden moves. Check size first: many are under 45 cm.",
     "el": "Καρτέρι ξαπλωμένοι στον βυθό στις άκρες βράχου–άμμου στα 8–25 m και αφήστε τη να πλησιάσει· χωρίς απότομες κινήσεις. Ελέγξτε πρώτα το μέγεθος: πολλές είναι κάτω από 45 cm."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Small live bogue, picarel or damselfish-sized baits.",
     "el": "Μικρή ζωντανή γόπα, μαρίδα ή ψαράκι στο μέγεθος του καλογεράκι."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid strips or a small whole squid.",
     "el": "Λωρίδες καλαμαριού ή μικρό ολόκληρο καλαμάρι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Large shrimp on a two-hook bottom rig.",
     "el": "Μεγάλη γαρίδα σε αρματωσιά βυθού με δύο αγκίστρια."
    }
   }
  ],
  "lures": [
   {
    "gear": "slow_jig",
    "weight": "80–150 g",
    "size": "",
    "colors": [
     "gold",
     "red",
     "glow",
     "pink"
    ],
    "note": {
     "en": "Short pitches and long falls in the bottom 5 m; deeper (40–120 m) Greek anglers use the same ~150 g knife jigs as for white grouper, lighter on shallow edges.",
     "el": "Κοντά χτυπήματα και μεγάλες πτώσεις στα τελευταία 5 m· στα βαθιά (40–120 m) οι Έλληνες ψαράδες χρησιμοποιούν τα ίδια slow jig «μαχαίρι» των ~150 g όπως για σφυρίδα, πιο ελαφριά στις ρηχές άκρες."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–15 cm",
    "colors": [
     "natural",
     "orange",
     "purple",
     "red"
    ],
    "note": {
     "en": "Long-lipped floating divers trolled far behind the boat at up to about 6.5 knots over shallow rises (70 m up to 15 m), running down to about 5 m; bright colours in spring, natural ones otherwise. Fit strong trebles.",
     "el": "Επιπλέοντα τεχνητά με μακριά γλώσσα, σε συρτή μακριά πίσω από το σκάφος ως 6,5 κόμβους περίπου, πάνω από ρηχές ξέρες (από 70 ως 15 m), που κατεβαίνουν ως 5 m περίπου· έντονα χρώματα την άνοιξη, φυσικά τον υπόλοιπο καιρό. Βάλτε δυνατές σαλαγκιές."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "20–60 g",
    "size": "8–12 cm",
    "colors": [
     "natural",
     "white",
     "chartreuse"
    ],
    "note": {
     "en": "Hop it along the rock line.",
     "el": "Χοροπηδάτε τη σιλικόνη στη γραμμή των βράχων."
    }
   },
   {
    "gear": "inchiku",
    "weight": "60–120 g",
    "size": "",
    "colors": [
     "red",
     "orange",
     "gold"
    ],
    "note": {
     "en": "Slow lifts near the bottom.",
     "el": "Αργά σηκώματα κοντά στον βυθό."
    }
   },
   {
    "gear": "tai_rubber",
    "weight": "60–100 g",
    "size": "",
    "colors": [
     "orange",
     "red"
    ],
    "note": {
     "en": "Steady slow wind over the sand edge.",
     "el": "Σταθερό αργό μάζεμα πάνω από την άκρη της άμμου."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 8–12 cm paddle-tail shads on 20–60 g jig heads, worked along rock–sand edges; from shore, Greek anglers call soft lures the way to go for goldblotch, best around dawn and dusk.",
    "el": "Ναι: σιλικόνες shad 8–12 cm σε μολυβοκεφαλές 20–60 g, στις άκρες βράχου–άμμου· από την ακτή, για τους Έλληνες ψαράδες οι σιλικόνες είναι «μονόδρομος» για στήρα, καλύτερα γύρω στα χαράματα και το σούρουπο."
   },
   "ids": [
    "soft_shad"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Drift the rock–sand edge with a slow jig or inchiku in the bottom few metres, troll diving minnows over shallow rises, or anchor and fish small live bait. Common Mediterranean practice; specific Cyprus data are scarce.",
   "el": "Ντρίφτα στην άκρη βράχου–άμμου με slow jig ή inchiku στα τελευταία μέτρα από τον βυθό, συρτή με βυθιζόμενα τεχνητά πάνω από ρηχές ξέρες, ή αγκυροβόλημα με μικρό ζωντανό. Συνήθης μεσογειακή πρακτική· ειδικά στοιχεία για την Κύπρο είναι λίγα."
  },
  "where": {
   "en": "Rock–sand and rock–seagrass boundaries, lone rocks on sand, 10–60 m; all around the Cypriot coast.",
   "el": "Όρια βράχου–άμμου και βράχου–ποσειδωνίας, μοναχικές πέτρες στην άμμο, 10–60 m· σε όλη την κυπριακή ακτή."
  },
  "when": {
   "en": "May–October; daytime for spearos, dawn and dusk by boat.",
   "el": "Μάιο–Οκτώβριο· μέρα για το ψαροντούφεκο, χαράματα και σούρουπο από σκάφος."
  },
  "handling": {
   "en": "Gill-cover spines: gloves and lip grip. Release undersized fish fast; use a descending weight for fish from below 20 m.",
   "el": "Αγκάθια στα βραγχιακά: γάντια και λαβίδα. Απελευθερώστε γρήγορα τα μικρά· με βαρίδι κατάβασης για ψάρια από κάτω από 20 m."
  },
  "eating": {
   "en": "Very good white flesh. A slow-growing grouper: keep only legal fish and not many.",
   "el": "Πολύ καλό άσπρο κρέας. Ροφός με αργή ανάπτυξη: κρατήστε μόνο νόμιμα ψάρια και λίγα."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/afieroma-psarema-apo-varka-me-stocho-ta-mayra-psaria/",
   "https://www.drososfishing.gr/armatosia-teleferik-gia-synagrides-rofoys-sfyrides-stires-amp-magiatika/",
   "https://www.drososfishing.gr/shore-jigging-planos-i-silikoni/",
   "https://www.boatfishing.gr/article-post/paradosiaka-psaremata-syrti-vythoy/",
   "https://www.fishbase.se/summary/Epinephelus-costae.html",
   "https://adriaticnature.com/archives/6668",
   "https://anglers-secrets.com/grouper-season-in-the-mediterranean/",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "mottledgrouper": {
  "summary": {
   "en": "Mottled grouper: a more open-water, schooling grouper of shallow reefs (5–35 m) that in Cyprus feeds heavily on rabbitfish. A prime spearfishing fish; by boat with live rabbitfish, soft shads or slow jigs. Spare the spawning aggregations of February–May.",
   "el": "Πίγγα: ροφός πιο «ανοιχτού» νερού που κινείται σε κοπάδια πάνω από ρηχές ξέρες (5–35 m) και στην Κύπρο τρώει πολύ κουρκούνα. Κορυφαίο ψάρι για ψαροντούφεκο· από σκάφος με ζωντανή κουρκούνα, σιλικόνες ή slow jig. Αφήστε ήσυχες τις συγκεντρώσεις αναπαραγωγής Φεβρουαρίου–Μαΐου."
  },
  "best": [
   "spear",
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "jigging_rod",
     "slow_jig_rod"
    ],
    "reel": [
     "reel_spin_l",
     "reel_conv"
    ],
    "line": {
     "main": "PE 2–3",
     "leader": "fluoro 0.50–0.70 mm, 3 m"
    },
    "rig": [
     "livebait_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_circle",
     "assist_hook",
     "swivel",
     "sinker"
    ],
    "hook": "J 2/0–4/0 · circle 5/0–7/0 · assist 1/0–3/0",
    "notes": {
     "en": "It hunts in mid-water above the reef, so fish the bait or lure 3–8 m above the rocks, not on them.",
     "el": "Κυνηγά στα μεσόνερα πάνω από την ξέρα: το δόλωμα ή το τεχνητό 3–8 m πάνω από τα βράχια, όχι πάνω τους."
    }
   },
   "spear": {
    "gun": [
     "gun_pneu",
     "gun_band"
    ],
    "length": "90–110 cm",
    "notes": {
     "en": "Approach reef tops and edges at 5–25 m by day; it often hangs in mid-water near cover. Glide in slowly and shoot from 2–3 m.",
     "el": "Πλησιάστε κορυφές και άκρες από ξέρες στα 5–25 m τη μέρα· συχνά στέκεται στα μεσόνερα κοντά σε κρυψώνα. Μπείτε αργά και χτυπήστε από 2–3 m."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Live rabbitfish (kourkouna) is the local favourite, and with good reason: rabbitfish are about two-thirds of its diet off Israel. Clip the venomous fin spines before hooking. Live bogue also works.",
     "el": "Η ζωντανή κουρκούνα είναι το τοπικό αγαπημένο, και με λόγο: οι κουρκούνες είναι περίπου τα δύο τρίτα της τροφής της στο Ισραήλ. Κόψτε τα δηλητηριώδη αγκάθια πριν το δόλωμα. Πιάνει και ζωντανή γόπα."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Fresh squid, whole or in big strips.",
     "el": "Φρέσκο καλαμάρι, ολόκληρο ή σε μεγάλες λωρίδες."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_shad",
    "weight": "20–60 g",
    "size": "10–15 cm",
    "colors": [
     "natural",
     "green_silver",
     "white"
    ],
    "note": {
     "en": "Rabbitfish-coloured (olive, silver) shads swum steadily above the reef.",
     "el": "Σιλικόνες στα χρώματα της κουρκούνας (λαδί, ασημί), με σταθερό μάζεμα πάνω από την ξέρα."
    }
   },
   {
    "gear": "slow_jig",
    "weight": "60–150 g",
    "size": "",
    "colors": [
     "green_silver",
     "gold",
     "glow"
    ],
    "note": {
     "en": "Work it through the mid-water layer over the reef; deeper (40–120 m) Greek anglers use the same ~150 g knife jigs as for other groupers.",
     "el": "Δουλέψτε το στα μεσαία νερά πάνω από την ξέρα· στα βαθιά (40–120 m) οι Έλληνες ψαράδες χρησιμοποιούν τα ίδια slow jig «μαχαίρι» των ~150 g όπως για τους άλλους ροφούς."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–15 cm",
    "colors": [
     "natural",
     "green_silver"
    ],
    "note": {
     "en": "Slow trolling at 2–3 knots along reef edges; common practice, little published data for this species.",
     "el": "Αργή συρτή στους 2–3 κόμβους κατά μήκος των ξερών· συνήθης πρακτική, με λίγα δημοσιευμένα στοιχεία για αυτό το είδος."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 10–15 cm paddle-tail shads in olive/silver (rabbitfish colours) on 20–60 g heads, retrieved steadily 3–8 m above the reef.",
    "el": "Ναι: σιλικόνες shad 10–15 cm σε λαδί/ασημί (χρώματα κουρκούνας) σε μολυβοκεφαλές 20–60 g, με σταθερό μάζεμα 3–8 m πάνω από την ξέρα."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "green_silver",
    "natural"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Drift live rabbitfish over shallow reef tops by day, or cast and swim soft shads over the reef. Strike firmly and lift it away from the rocks.",
   "el": "Ντρίφτα με ζωντανή κουρκούνα πάνω από ρηχές ξέρες τη μέρα, ή ρίψεις με σιλικόνες πάνω από την ξέρα. Δυνατό κάρφωμα και σηκώστε το μακριά από τα βράχια."
  },
  "where": {
   "en": "Shallow rocky reefs and reef edges at 5–35 m where rabbitfish graze; all Cypriot rocky coasts.",
   "el": "Ρηχές βραχώδεις ξέρες και άκρες τους στα 5–35 m, εκεί που βόσκουν οι κουρκούνες· σε όλες τις βραχώδεις ακτές της Κύπρου."
  },
  "when": {
   "en": "All year; daytime. Leave fish alone in spawning aggregations, February–May.",
   "el": "Όλο τον χρόνο· τη μέρα. Αφήστε ήσυχα τα ψάρια στις συγκεντρώσεις αναπαραγωγής, Φεβρουάριο–Μάιο."
  },
  "handling": {
   "en": "Gill-cover spines: gloves and a lip grip. If you use rabbitfish as bait, mind their venomous spines too.",
   "el": "Αγκάθια στα βραγχιακά: γάντια και λαβίδα. Αν χρησιμοποιείτε κουρκούνα για δόλωμα, προσοχή και στα δηλητηριώδη αγκάθια της."
  },
  "eating": {
   "en": "Excellent. No EU minimum size, but the look-alike Epinephelus groupers must be 45 cm or more: be sure of the species.",
   "el": "Εξαιρετικό. Δεν έχει ελάχιστο μέγεθος ΕΕ, όμως οι ροφοί Epinephelus που της μοιάζουν πρέπει να είναι 45 cm και πάνω: βεβαιωθείτε για το είδος."
  },
  "sources": [
   "https://www.avidag.co.il/wp-content/uploads/2012/01/ECOLOGY-OF-THE-MOTTLED-GROUPER.pdf",
   "https://www.boatfishing.gr/article-post/afieroma-psarema-apo-varka-me-stocho-ta-mayra-psaria/",
   "https://www.boatfishing.gr/article-post/sto-epikentro-rofos-stira-pigka-kai-sfyrida/",
   "https://www.fishbase.se/summary/Mycteroperca-rubra.html",
   "https://adriaticnature.com/archives/6668",
   "https://anglers-secrets.com/grouper-season-in-the-mediterranean/"
  ]
 },
 "dentex": {
  "summary": {
   "en": "Common dentex: the prized predator of rocky banks at 20–80 m. By boat with live squid on a trolled lead, slow jigs or deep-diving lures; by spearfishing from ambush. Best in spring and autumn. IUCN Vulnerable: release small fish.",
   "el": "Συναγρίδα: το περιζήτητο αρπακτικό των βραχωδών ξερών στα 20–80 m. Από σκάφος με ζωντανό καλαμάρι στη συρτή με μολύβι φύλακα, slow jigging ή βαθιά τεχνητά· με ψαροντούφεκο σε καρτέρι. Καλύτερα άνοιξη και φθινόπωρο. Ευάλωτο είδος (IUCN): αφήστε τα μικρά."
  },
  "best": [
   "boat",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod",
     "slow_jig_rod"
    ],
    "reel": [
     "reel_conv"
    ],
    "line": {
     "main": "mono 0.30–0.35 mm (40–50 lb) / PE 1.5–2.5",
     "leader": "fluoro 0.50–0.65 mm, 5–18 m"
    },
    "rig": [
     "livebait_rig",
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "assist_hook",
     "sinker",
     "swivel"
    ],
    "hook": "J 4/0–7/0 ×2–3 (5/0 suits most) · assist 1/0–3/0",
    "notes": {
     "en": "Trolled-lead rig: 300 g lead at 40–60 m, 400 g deeper, on a 1–1.5 m dropper of 40 lb; long 0.60 mm leader with two hooks, the upper one sliding to fit the bait. Troll at under 1.5 knots so the squid swims naturally; a 2.1 m 16–30 lb rod with a soft tip shows the shy bites.",
     "el": "Μολύβι φύλακας: 300 g στα 40–60 m, 400 g πιο βαθιά, σε κλάδο 1–1,5 m από 40 lb· μακρύ παράμαλλο 0,60 mm με δύο αγκίστρια, το πάνω συρόμενο για να ταιριάζει στο δόλωμα. Συρτή κάτω από 1,5 κόμβο ώστε το καλαμάρι να κολυμπά φυσικά· καλάμι 2,1 m 16–30 lb με μαλακή κορυφή δείχνει τα «ντροπαλά» τσιμπήματα."
    }
   },
   "shore": {
    "rod": [
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 1.5–2.5",
     "leader": "fluoro 0.45–0.55 mm, 1–1.5 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook"
    ],
    "hook": "assist 1/0–3/0",
    "notes": {
     "en": "Shore jigging from breakwaters and rocks that drop fast into deep water: rod up to 3.2 m casting 50–180 g, 4000–6000 reel, jigs 40–120 g.",
     "el": "Shore jigging από λιμενοβραχίονες και βράχια που πέφτουν γρήγορα σε βαθιά νερά: καλάμι ως 3,2 m για 50–180 g, μηχανή 4000–6000, τζιγκ 40–120 g."
    }
   },
   "spear": {
    "gun": [
     "gun_pneu",
     "gun_band"
    ],
    "length": "100–115 cm",
    "notes": {
     "en": "Ambush (aspetto): dive to the edge of a drop-off at 10–25 m, hide behind a rock and stay still; dentex come in fast and curious, then turn. Shoot early, at the first broadside.",
     "el": "Καρτέρι: βουτήξτε στην άκρη μιας κατωφέρειας στα 10–25 m, κρυφτείτε πίσω από πέτρα και μείνετε ακίνητοι· η συναγρίδα έρχεται γρήγορα και περίεργη, μετά γυρίζει. Χτυπήστε νωρίς, στο πρώτο πλάγιο πέρασμα."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Live squid is one of the top dentex baits. Use medium squid, with a sliding hook in the tail and a fixed one in the siphon (a third hook for big fish); keep them in a live-well. If none, fresh squid with a small sinker in the belly.",
     "el": "Το ζωντανό καλαμάρι είναι από τα κορυφαία δολώματα για συναγρίδα. Μεσαίου μεγέθους, με το συρόμενο αγκίστρι στην ουρά και το σταθερό στο σιφόνι (τρίτο αγκίστρι για μεγάλα ψάρια)· κρατήστε τα σε δεξαμενή ζωντανών. Αλλιώς νωπό καλαμάρι με μικρό βαρίδι στην κοιλιά."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "Live small fish: wrasse (Greek longliners rate the red \"onion\" wrasse first), bogue or red mullet, or horse mackerel and mackerel caught on a sabiki. Single circle hook, and wait rather than strike.",
     "el": "Ζωντανό μικρόψαρο: καλόγρια (οι Έλληνες παραγαδιάρηδες βάζουν πρώτη την κόκκινη καλόγρια, το «κρεμμύδι»), γόπα ή μπαρμπούνι, ή σαφρίδι και κολιός από τσαπαρί. Ένα circle αγκίστρι, και περιμένετε αντί να καρφώσετε."
    }
   }
  ],
  "lures": [
   {
    "gear": "slow_jig",
    "weight": "100–300 g",
    "size": "",
    "colors": [
     "pink",
     "green_silver",
     "silver",
     "glow"
    ],
    "note": {
     "en": "Greek guides suggest 150–200 g at 60–80 m and 200–300 g at 80–120 m, lighter in slack water; pastel pink, green and silver. Slow strokes, pauses and long falls; keep the drag firm near the rocks.",
     "el": "Οι ελληνικοί οδηγοί προτείνουν 150–200 g στα 60–80 m και 200–300 g στα 80–120 m, λιγότερο χωρίς ρεύμα· παστέλ ροζ, πράσινο και ασημί. Αργά χτυπήματα, παύσεις και μεγάλες πτώσεις· φρένο σφιχτό κοντά στα βράχια."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "14–20 cm",
    "colors": [
     "red_head",
     "orange",
     "pink"
    ],
    "note": {
     "en": "Bottom trolling at about 3.5–4 knots (slower towards dusk), kept within about 3 m of the rocks with sinkers. Red, orange, yellow and pink, brighter as it gets deeper; shallow (to 35–40 m) in summer and early autumn.",
     "el": "Συρτή βυθού στους 3,5–4 κόμβους περίπου (πιο αργά προς το σούρουπο), με μολύβια ώστε το τεχνητό να περνά ως 3 m πάνω από τα βράχια. Κόκκινο, πορτοκαλί, κίτρινο και ροζ, πιο έντονα όσο βαθαίνει· ρηχά (ως 35–40 m) το καλοκαίρι και αρχές φθινοπώρου."
    }
   },
   {
    "gear": "tai_rubber",
    "weight": "",
    "size": "",
    "colors": [
     "red",
     "orange"
    ],
    "note": {
     "en": "Also used for dentex, not just red porgy. Red head with an orange skirt is the proven combination; drop to the bottom, wind steadily for about a fifth of the depth, drop again, and strike as soon as you feel weight. Use the lightest head that reaches bottom.",
     "el": "Χρησιμοποιείται και για συναγρίδα, όχι μόνο για φαγκρί. Κόκκινο κεφάλι με πορτοκαλί φούστα είναι ο δοκιμασμένος συνδυασμός· κατεβάστε στον βυθό, μαζέψτε σταθερά περίπου το ένα πέμπτο του βάθους, ξανακατεβάστε, και καρφώστε μόλις νιώσετε βάρος. Το πιο ελαφρύ κεφάλι που φτάνει στον βυθό."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "30–80 g",
    "size": "12–18 cm",
    "colors": [
     "white",
     "pink",
     "natural"
    ],
    "note": {
     "en": "Heavy soft lures worked near the bottom, not too fast; from shore, Greek anglers rate soft lures and jigs equally for dentex.",
     "el": "Βαριές σιλικόνες κοντά στον βυθό, όχι γρήγορα· από την ακτή, οι Έλληνες ψαράδες θεωρούν σιλικόνη και πλάνο εξίσου καλά για συναγρίδα."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "40–120 g",
    "size": "",
    "colors": [
     "silver",
     "pink",
     "sardine"
    ],
    "note": {
     "en": "Shore jigging from deep rocks.",
     "el": "Shore jigging από βαθιά βράχια."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 12–18 cm paddle-tail shads on 30–80 g heads, slowly hopped near the bottom on rocky banks; from shore they work best in the half-hours around dawn and sunset.",
    "el": "Ναι: σιλικόνες shad 12–18 cm σε μολυβοκεφαλές 30–80 g, με αργά πηδηματάκια κοντά στον βυθό σε βραχώδεις ξέρες· από την ακτή δουλεύουν καλύτερα το μισάωρο του χαράματος και της δύσης."
   },
   "ids": [
    "soft_shad"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Troll live squid on a lead along the drop-off, tapping bottom every minute and lifting 1–2 m; on a bite give line for a few seconds, then strike. With jigs: slow pitch, long falls, and keep the jig in the bottom 10 m.",
   "el": "Συρτή με ζωντανό καλαμάρι και μολύβι φύλακα κατά μήκος της κατωφέρειας, ακουμπώντας τον βυθό κάθε λεπτό και σηκώνοντας 1–2 m· στο τσίμπημα δώστε λίγα δευτερόλεπτα και καρφώστε. Με τζιγκ: slow pitch, μεγάλες πτώσεις, και το τζιγκ στα τελευταία 10 m."
  },
  "where": {
   "en": "Rocky banks, reef edges and drop-offs at 20–80 m (deeper in winter, 30–60 m in summer); headlands with current. In Cyprus the steep west and south coasts.",
   "el": "Βραχώδεις ξέρες, άκρες υφάλων και κατωφέρειες στα 20–80 m (βαθύτερα τον χειμώνα, 30–60 m το καλοκαίρι)· κάβοι με ρεύμα. Στην Κύπρο οι απότομες δυτικές και νότιες ακτές."
  },
  "when": {
   "en": "April–May and October–November are best; dawn and the first hours of light, and calm bright days.",
   "el": "Απρίλιο–Μάιο και Οκτώβριο–Νοέμβριο είναι τα καλύτερα· χαράματα και πρώτες ώρες του φωτός, και ήρεμες φωτεινές μέρες."
  },
  "handling": {
   "en": "Strong canine teeth: lip grip and pliers. Use a net for fish you may release.",
   "el": "Δυνατά κυνόδοντα δόντια: λαβίδα στόματος και πένσα. Απόχη για ψάρια που ίσως απελευθερώσετε."
  },
  "eating": {
   "en": "Superb white flesh. IUCN Vulnerable: release small dentex and do not take more than you need.",
   "el": "Εξαιρετικό άσπρο κρέας. Ευάλωτο είδος (IUCN): αφήστε τις μικρές συναγρίδες και μην παίρνετε περισσότερα απ’ όσα χρειάζεστε."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/syrti-fylakas-synagrides-me-zontano-kalamari/",
   "https://www.drososfishing.gr/jigging-psarema-tis-synagridas/",
   "https://www.drososfishing.gr/syrti-vythoy-synagrida-to-aprosmeno-thi/",
   "https://www.boatfishing.gr/article-post/psarema-me-tin-techniki-toy-tai-rubber/",
   "https://www.boatfishing.gr/article-post/psare-a-apo-skafos-oi-protes-synagrides-toy-cheimona/",
   "https://www.hellasfishing.gr/%CF%88%CE%AC%CF%81%CE%B5%CE%BC%CE%B1-%CF%83%CF%85%CE%BD%CE%B1%CE%B3%CF%81%CE%AF%CE%B4%CE%B1%CF%82-%CE%BC%CE%B5-%CE%B3%CF%8D%CE%BB%CE%BF-%CE%BA%CE%B1%CE%B9-%CF%84%CF%81%CF%8C%CF%80%CE%BF%CE%B9-%CE%BD/",
   "https://www.psarema.gr/sizitiseis/paragadi/10687-synagrides",
   "https://www.boatfishing.gr/article-post/paradosiaka-psaremata-syrti-vythoy/",
   "https://www.psarema.gr/blog/19-syrti/1485-syrti-me-molyvi-fylaka-ta-vasika",
   "https://www.psarema.gr/sizitiseis/sirti/2275-%CF%83%CF%85%CF%81%CF%84%CE%AE-%CE%BC%CE%B5-%CE%BC%CE%BF%CE%BB%CF%8D%CE%B2%CE%B9-%CF%86%CF%8D%CE%BB%CE%B1%CE%BA%CE%B1",
   "https://rodhouse.com/en/blogs/rodbuilding/amberjack-dentex-mediterranean-slow-jigging-slow-trolling",
   "https://www.psarema.gr/blog/25-jigging/1877-shore-jigging-xekinwntas-apo-to-mhden",
   "https://adriaticnature.com/archives/6668",
   "https://www.fishbase.se/summary/Dentex-dentex.html"
  ]
 },
 "amberjack": {
  "summary": {
   "en": "Greater amberjack: a powerful reef and wreck predator that fights to the bottom. Speed jigging with long jigs, live bait and topwater by boat; shore jigging from deep rocks; big guns for spearfishing. Peaks September–December.",
   "el": "Μαγιάτικο: δυνατό αρπακτικό από ξέρες και ναυάγια, που παλεύει προς τον βυθό. Γρήγορο jigging με μακριά τζιγκ, ζωντανό και επιφανειακά από σκάφος· shore jigging από βαθιά βράχια· μεγάλα όπλα στο ψαροντούφεκο. Κορυφώνεται Σεπτέμβριο–Δεκέμβριο."
  },
  "best": [
   "boat",
   "shore",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "jigging_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_spin_l",
     "reel_conv"
    ],
    "line": {
     "main": "PE 3–5",
     "leader": "fluoro/mono 0.70–1.00 mm (60–100 lb), 3–5 m"
    },
    "rig": [
     "livebait_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook",
     "hook_circle",
     "swivel"
    ],
    "hook": "assist 3/0–7/0 · circle 6/0–9/0",
    "notes": {
     "en": "Heavy drag (8–12 kg on PE 4) and a rod that lifts: the first run goes straight to the rocks or the wreck. Pump short and fast.",
     "el": "Δυνατό φρένο (8–12 kg σε PE 4) και καλάμι που σηκώνει: το πρώτο φευγιό πάει ίσια στα βράχια ή στο ναυάγιο. Κοντά και γρήγορα «τραβήγματα»."
    }
   },
   "shore": {
    "rod": [
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 2–3",
     "leader": "fluoro 0.50–0.70 mm, 1–1.5 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook"
    ],
    "hook": "assist 2/0–4/0",
    "notes": {
     "en": "Shore jigging from deep rocks and breakwaters: rod up to 3.2 m casting 50–180 g, 5000–6000 reel, jigs 40–100 g. A net or a helper is needed to land fish.",
     "el": "Shore jigging από βαθιά βράχια και λιμενοβραχίονες: καλάμι ως 3,2 m για 50–180 g, μηχανή 5000–6000, τζιγκ 40–100 g. Χρειάζεται απόχη ή βοηθός για το ανέβασμα."
    }
   },
   "spear": {
    "gun": [
     "gun_pneu",
     "gun_band"
    ],
    "length": "110–130 cm",
    "notes": {
     "en": "Ambush on points and drop-offs at 10–25 m, or a slow descent in blue water near the reef; they circle a still diver. Use a strong shaft and a float line: a hit fish runs hard, so shoot only good shots.",
     "el": "Καρτέρι σε κάβους και κατωφέρειες στα 10–25 m, ή αργή κατάβαση στο μπλε κοντά στην ξέρα· κάνουν κύκλους γύρω από τον ακίνητο δύτη. Δυνατή βέργα και σχοινί σημαδούρας: το χτυπημένο ψάρι τραβά πολύ, ρίχνετε μόνο καθαρές βολές."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Live horse mackerel, mackerel, bogue, garfish or small mullet, on a circle hook just off the bottom, or slow-trolled on a lead at under 1 knot with a 10–20 m leader of 0.55–0.70 mm.",
     "el": "Ζωντανό σαφρίδι, κολιός, γόπα, ζαργάνα ή μικρός κέφαλος, σε circle αγκίστρι λίγο πάνω από τον βυθό, ή σε συρτή με μολύβι φύλακα κάτω από 1 κόμβο με παράμαλλο 10–20 m των 0,55–0,70 mm."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Live squid (autumn and winter) or live cuttlefish (spring), slow-trolled on a lead, also take big amberjack.",
     "el": "Ζωντανό καλαμάρι (φθινόπωρο και χειμώνα) ή ζωντανή σουπιά (άνοιξη), σε αργή συρτή με μολύβι φύλακα, πιάνουν κι αυτά μεγάλα μαγιάτικα."
    }
   }
  ],
  "lures": [
   {
    "gear": "metal_jig",
    "weight": "150–300 g",
    "size": "18–25 cm",
    "colors": [
     "sardine",
     "pink",
     "green_silver",
     "glow"
    ],
    "note": {
     "en": "Long 200–250 g jigs worked with fast, vigorous lifts from the bottom up through the school: most hits come near the bottom, many on the way up. Blue-pink or green by day, glow at dusk.",
     "el": "Μακρόστενοι πλάνοι 200–250 g με γρήγορα, δυνατά τινάγματα από τον βυθό προς τα πάνω μέσα από το κοπάδι: τα περισσότερα χτυπήματα κοντά στον βυθό, πολλά στο ανέβασμα. Μπλε-ροζ ή πράσινο τη μέρα, φωσφοριζέ το σούρουπο."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "40–100 g",
    "size": "",
    "colors": [
     "silver",
     "sardine",
     "pink"
    ],
    "note": {
     "en": "From shore: cast far, let it sink to the bottom, then a fast jerk-and-wind retrieve.",
     "el": "Από ακτή: μακριά ρίψη, πάτωμα και γρήγορο τίναγμα-μάζεμα."
    }
   },
   {
    "gear": "popper",
    "weight": "40–80 g",
    "size": "15–20 cm",
    "colors": [
     "white",
     "sardine"
    ],
    "note": {
     "en": "Over shallow reefs at dawn when fish show on the surface.",
     "el": "Πάνω από ρηχές ξέρες τα χαράματα, όταν τα ψάρια φαίνονται στην επιφάνεια."
    }
   },
   {
    "gear": "stickbait",
    "weight": "40–100 g",
    "size": "16–22 cm",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "Floating or sinking stickbait swept hard over the reef.",
     "el": "Επιπλέον ή βυθιζόμενο stickbait με δυνατά σαρώματα πάνω από την ξέρα."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Secondary: Greek shore anglers list amberjack among the fish that take both jigs and soft lures. Big paddle-tail shads on 40–100 g heads, retrieved fast, can work when jigs are refused.",
    "el": "Δευτερεύον: οι Έλληνες ψαράδες από την ακτή βάζουν το μαγιάτικο στα ψάρια που παίρνουν και πλάνο και σιλικόνη. Μεγάλες σιλικόνες shad σε μολυβοκεφαλές 40–100 g, με γρήγορο μάζεμα, πιάνουν όταν τα πλάνα δεν δουλεύουν."
   },
   "ids": [
    "soft_shad"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Find bait schools on the sonar over reefs and wrecks, drop the jig to the bottom and work it fast up through the school; when fish are on top, switch to popper or stickbait. With live bait, let the fish turn for a second, then lock and wind.",
   "el": "Βρείτε κοπάδια δολωματόψαρων στο βυθόμετρο πάνω από ξέρες και ναυάγια, πατώστε το τζιγκ και δουλέψτε το γρήγορα ως πάνω από το κοπάδι· όταν τα ψάρια βγαίνουν στον αφρό, αλλάξτε σε popper ή stickbait. Με ζωντανό, αφήστε το ψάρι να γυρίσει ένα δευτερόλεπτο, μετά κλείστε και μαζέψτε."
  },
  "where": {
   "en": "Wrecks, offshore banks, steep drop-offs and current-swept points at 20–80 m; around Paphos, Akrotiri and Cape Greco (outside its protected zone).",
   "el": "Ναυάγια, ανοιχτές ξέρες, απότομες κατωφέρειες και κάβοι με ρεύμα στα 20–80 m· γύρω από Πάφο, Ακρωτήρι και Κάβο Γκρέκο (έξω από τη ζώνη προστασίας)."
  },
  "when": {
   "en": "September–December is the peak, with a second run in May–early June; dawn and dusk are best, but they feed all day.",
   "el": "Κορύφωση Σεπτέμβριο–Δεκέμβριο, με δεύτερη περίοδο Μάιο–αρχές Ιουνίου· χαράματα και σούρουπο καλύτερα, αλλά τρώνε όλη μέρα."
  },
  "handling": {
   "en": "No spines of note, but a big fish thrashes hard: gloves, a lip grip and a big net; keep fingers clear of trebles.",
   "el": "Χωρίς επικίνδυνα αγκάθια, αλλά το μεγάλο ψάρι χτυπιέται δυνατά: γάντια, λαβίδα και μεγάλη απόχη· τα δάχτυλα μακριά από τις σαλαγκιές."
  },
  "eating": {
   "en": "Very good firm flesh; bleed and ice it at once. No size limit, but let small fish (under about 3 kg) go so they can grow.",
   "el": "Πολύ καλό σφιχτό κρέας· ματώστε το και βάλτε το αμέσως στον πάγο. Δεν έχει όριο μεγέθους, αλλά αφήστε τα μικρά (κάτω από 3 kg περίπου) να μεγαλώσουν."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/magiatika-sto-jigging/",
   "https://www.drososfishing.gr/syrti-fylakas-zontano-gia-megala-magiatika/",
   "https://www.drososfishing.gr/shore-jigging-planos-i-silikoni/",
   "https://rodhouse.com/en/blogs/rodbuilding/amberjack-dentex-mediterranean-slow-jigging-slow-trolling",
   "https://adriaticnature.com/archives/6668",
   "https://www.psarema.gr/blog/25-jigging/1877-shore-jigging-xekinwntas-apo-to-mhden",
   "https://psarema.gr/sizitiseis/sirti-apekso-spinning/223088-shore-jigging-jigging-%CE%B1%CF%80%CF%8C-%CF%84%CE%B7%CE%BD-%CE%B1%CE%BA%CF%84%CE%AE",
   "https://fishingbooker.com/blog/?p=54089",
   "https://www.fishbase.se/summary/Seriola-dumerili.html"
  ]
 },
 "dolphinfish": {
  "summary": {
   "en": "Dolphinfish: a fast offshore schooling fish that gathers under anything floating. Troll small lures or cast to floating debris and FADs offshore; light spinning gear is the most fun. August–November.",
   "el": "Κυνηγός (λαμπούγκα): γρήγορο ψάρι των ανοιχτών που κινείται σε κοπάδια και μαζεύεται κάτω από ό,τι επιπλέει. Συρτή με μικρά τεχνητά ή ρίψεις σε επιπλέοντα αντικείμενα και σκιές στα ανοιχτά· με ελαφρύ spinning έχει τη μεγαλύτερη πλάκα. Αύγουστο–Νοέμβριο."
  },
  "best": [
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "spinning_rod",
     "trolling_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 2–3.5 / mono 0.40–0.50 mm",
     "leader": "fluoro 0.50–0.60 mm, 2–3 m"
    },
    "rig": [
     "trolling_rig",
     "free_line"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 1/0–4/0",
    "notes": {
     "en": "Troll 2–4 small lures 15–40 m behind the boat at 5–8 knots; when a school shows, stop and cast with 2.4–2.7 m spinning rods (10–50 g) and 4000 reels.",
     "el": "Συρτή με 2–4 μικρά τεχνητά 15–40 m πίσω από το σκάφος στους 5–8 κόμβους· όταν φανεί κοπάδι, σταματάτε και ρίχνετε με καλάμια spinning 2,4–2,7 m (10–50 g) και μηχανές 4000."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "note": {
     "en": "A small live fish free-lined near a floating object.",
     "el": "Μικρό ζωντανό ψαράκι ελεύθερο κοντά σε επιπλέον αντικείμενο."
    }
   },
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Cut pieces of fresh sardine (or squid) thrown to hold the school at the boat once fish are found, with a baited hook drifted among them while others spin.",
     "el": "Κομμάτια φρέσκιας σαρδέλας (ή καλαμαριού) που ρίχνονται για να κρατήσουν το κοπάδι στο σκάφος μόλις βρεθούν ψάρια, με ένα δολωμένο αγκίστρι ανάμεσά τους ενώ οι άλλοι ψαρεύουν spinning."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid strips on a free line.",
     "el": "Λωρίδες καλαμαριού σε ελεύθερη πετονιά."
    }
   }
  ],
  "lures": [
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–14 cm",
    "colors": [
     "green_silver",
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Hard minnows of 12–14 cm trolled at 4.5–6 knots, one shallow-running and one diving to 3–4 m: the usual Greek offshore method.",
     "el": "Σκληρά τεχνητά 12–14 cm σε συρτή στους 4,5–6 κόμβους, ένα ρηχό και ένα που βουτά στα 3–4 m: η συνηθισμένη ελληνική μέθοδος στα ανοιχτά."
    }
   },
   {
    "gear": "trolling_skirt",
    "weight": "",
    "size": "8–15 cm",
    "colors": [
     "green_silver",
     "chartreuse",
     "pink",
     "sardine"
    ],
    "note": {
     "en": "Small skirts and soft squids at 5–8 knots; green/yellow is the classic dolphinfish colour.",
     "el": "Μικρά χταποδάκια και σιλικονένια καλαμαράκια στους 5–8 κόμβους· το πράσινο/κίτρινο είναι το κλασικό χρώμα για κυνηγό."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "20–40 g",
    "size": "",
    "colors": [
     "silver",
     "green_silver",
     "pink"
    ],
    "note": {
     "en": "Cast past the floating object, let it sink a few metres, fast retrieve.",
     "el": "Ρίψη πέρα από το αντικείμενο, βύθιση λίγων μέτρων, γρήγορο μάζεμα."
    }
   },
   {
    "gear": "popper",
    "weight": "15–30 g",
    "size": "9–12 cm",
    "colors": [
     "chartreuse",
     "white"
    ],
    "note": {
     "en": "When fish are on the surface.",
     "el": "Όταν τα ψάρια είναι στην επιφάνεια."
    }
   },
   {
    "gear": "feather",
    "weight": "",
    "size": "8–12 cm",
    "colors": [
     "white",
     "pink",
     "chartreuse"
    ],
    "note": {
     "en": "Trolled feathers with a small weighted head.",
     "el": "Φτερά συρτής με μικρό βαρύ κεφάλι."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: small soft fish and soft eels of 4–12 cm trolled slowly (2.5–4 knots) near the surface, usually unweighted (add a 20–30 g sinker if bites are scarce); blue-pearl, clear-pearl, white and red are the favourite colours. Can also be cast on a light jig head.",
    "el": "Ναι: μικρά σιλικονούχα ψαράκια και χελάκια 4–12 cm σε αργή συρτή (2,5–4 κόμβοι) κοντά στην επιφάνεια, συνήθως χωρίς βάρος (μολύβι 20–30 g αν δεν τσιμπάνε)· αγαπημένα χρώματα μπλε-περλέ, διάφανο-περλέ, λευκό και κόκκινο. Ρίχνονται και με ελαφριά μολυβοκεφαλή."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "sardine",
    "white",
    "red"
   ],
   "size": "4–12 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Light chum of sardine pieces once a school is at the boat keeps it there.",
    "el": "Λίγη μάλαγρα με κομμάτια σαρδέλας, μόλις το κοπάδι έρθει στο σκάφος, το κρατά εκεί."
   }
  },
  "technique": {
   "en": "Look for floating debris, weed lines, FADs and birds; troll past them, not over them. Keep the first hooked fish in the water: the school follows it and the others take cast lures or baits.",
   "el": "Ψάξτε επιπλέοντα αντικείμενα, γραμμές από φύκια, σκιές (κανιζάδες) και πουλιά· περάστε δίπλα τους με τη συρτή, όχι από πάνω. Κρατήστε το πρώτο ψάρι στο νερό: το κοπάδι το ακολουθεί και τα άλλα πιάνουν σε ρίψεις ή δολώματα."
  },
  "where": {
   "en": "Offshore blue water, from a few miles out, around anything that floats.",
   "el": "Ανοιχτά, σε μπλε νερό, από λίγα μίλια έξω, γύρω από ό,τι επιπλέει."
  },
  "when": {
   "en": "August–November; morning hours are best.",
   "el": "Αύγουστο–Νοέμβριο· καλύτερα οι πρωινές ώρες."
  },
  "handling": {
   "en": "Very lively on deck: use a net or lift by the tail into a fish box quickly; keep clear of flying hooks.",
   "el": "Πολύ ζωηρό στο κατάστρωμα: απόχη ή σηκώστε το από την ουρά κατευθείαν στο ψυγείο· προσοχή στα αγκίστρια που πετούν."
  },
  "eating": {
   "en": "Excellent fresh. Ice it at once: like tuna, dolphinfish can cause histamine (scombroid) poisoning if left warm.",
   "el": "Εξαιρετικό φρέσκο. Στον πάγο αμέσως: όπως ο τόνος, ο κυνηγός μπορεί να προκαλέσει δηλητηρίαση ισταμίνης αν μείνει ζεστός."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/psarema-apo-varka-gia-kynigoys-sta-vathia/",
   "https://www.boatfishing.gr/article-post/syrti-afroy-me-silikonoycha-dolomata-gia-kynigoys-tonakia/",
   "https://fishingbooker.com/blog/?p=54089",
   "https://adriaticnature.com/archives/6668",
   "https://www.barcheamotore.com/?p=5699",
   "https://www.fishbase.se/summary/Coryphaena-hippurus.html"
  ]
 },
 "albacore": {
  "summary": {
   "en": "Albacore: Cyprus’s classic summer tuna, a few miles offshore over deep water from mid-June. Trolling feathers and small skirts at 6–8 knots is the method. Bag limit 3 per licensed angler and 9 per boat; declare albacore on your boat licence.",
   "el": "Μακρύπτερος τόνος: ο κλασικός καλοκαιρινός τόνος της Κύπρου, λίγα μίλια ανοιχτά πάνω από βαθιά νερά από τα μέσα Ιουνίου. Η μέθοδος είναι συρτή με φτερά και μικρά χταποδάκια στους 6–8 κόμβους. Όριο 3 ανά αδειούχο ψαρά και 9 ανά σκάφος· δηλώστε τον στην άδεια σκάφους."
  },
  "best": [
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "trolling_rod"
    ],
    "reel": [
     "reel_conv"
    ],
    "line": {
     "main": "mono 0.50–0.60 mm (20–30 lb)",
     "leader": "mono/fluoro 0.70–0.90 mm, 3–5 m"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 5/0–7/0",
    "notes": {
     "en": "Run 4–6 lines staggered 20–60 m back, shortest in the wake. Drag at about a third of line strength; when a fish hits, keep the boat moving a little so others in the school bite.",
     "el": "Ρίξτε 4–6 πετονιές κλιμακωτά στα 20–60 m, τις κοντύτερες στα απόνερα. Φρένο περίπου στο ένα τρίτο της αντοχής· όταν χτυπήσει ψάρι, κρατήστε το σκάφος να κινείται λίγο για να χτυπήσουν κι άλλα από το κοπάδι."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "note": {
     "en": "Used by some crews as chunks to hold a school after a strike; trolling lures remain the main method.",
     "el": "Κάποια πληρώματα τη ρίχνουν σε κομμάτια για να κρατήσουν το κοπάδι μετά από χτύπημα· η κύρια μέθοδος μένει η συρτή."
    }
   }
  ],
  "lures": [
   {
    "gear": "feather",
    "weight": "",
    "size": "10–15 cm",
    "colors": [
     "white",
     "pink",
     "purple",
     "red"
    ],
    "note": {
     "en": "Feathers are the classic albacore lure: red/white, pink/white, purple/black.",
     "el": "Τα φτερά είναι το κλασικό τεχνητό για μακρύπτερο: κόκκινο/άσπρο, ροζ/άσπρο, μωβ/μαύρο."
    }
   },
   {
    "gear": "trolling_skirt",
    "weight": "",
    "size": "10–18 cm",
    "colors": [
     "sardine",
     "pink",
     "purple",
     "green_silver"
    ],
    "note": {
     "en": "Small skirts, soft-plastic squids and cedar-plug style lures among the feathers, at 6–8 knots.",
     "el": "Μικρά καλαμαράκια (skirts), σιλικονούχα καλαμαράκια και τεχνητά τύπου cedar plug ανάμεσα στα φτερά, στους 6–8 κόμβους."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–16 cm",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "High-speed diving minnows on the long lines.",
     "el": "Minnow για μεγάλη ταχύτητα στις μακριές πετονιές."
    }
   },
   {
    "gear": "stickbait",
    "weight": "30–60 g",
    "size": "12–16 cm",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "Cast to breaking fish with a strong spinning rod.",
     "el": "Ρίψεις σε ψάρια που σπάνε στον αφρό με δυνατό καλάμι spinning."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not as jig-head soft lures. Soft-plastic squids and skirts are trolled for albacore; they are listed under lures (trolling skirts).",
    "el": "Όχι ως σιλικόνες σε μολυβοκεφαλή. Για τον μακρύπτερο συρτάρονται σιλικονούχα καλαμαράκια και skirts· θα τα βρείτε στα τεχνητά (καλαμαράκια συρτής)."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not normally used for recreational trolling.",
    "el": "Συνήθως δεν χρησιμοποιείται στην ερασιτεχνική συρτή."
   }
  },
  "technique": {
   "en": "Troll at 6–8 knots over 500 m+ of water, zig-zagging across temperature breaks; watch for birds, jumping fish and flying fish. After a strike, slow down but keep moving and clear the other lines fast.",
   "el": "Συρτή στους 6–8 κόμβους πάνω από βάθη 500 m και πάνω, κάνοντας ζιγκ-ζαγκ στις αλλαγές θερμοκρασίας· προσέξτε πουλιά, ψάρια που πηδούν και χελιδονόψαρα. Μετά το χτύπημα κόψτε ταχύτητα αλλά συνεχίστε, και μαζέψτε γρήγορα τις άλλες πετονιές."
  },
  "where": {
   "en": "Deep water a few miles off the south coast, especially off Limassol, Paphos and Larnaca.",
   "el": "Βαθιά νερά λίγα μίλια έξω από τη νότια ακτή, ιδίως έξω από Λεμεσό, Πάφο και Λάρνακα."
  },
  "when": {
   "en": "Mid-June to August, peaking in July; early morning best.",
   "el": "Μέσα Ιουνίου ως Αύγουστο, με κορύφωση τον Ιούλιο· καλύτερα νωρίς το πρωί."
  },
  "handling": {
   "en": "Gaff or net only fish you keep and count. Bluefin tuna may not be kept by recreational anglers in Cyprus: albacore have very long pectoral fins reaching past the second dorsal fin; release anything else in the water.",
   "el": "Γάντζος ή απόχη μόνο για ψάρια που κρατάτε και μετράτε. Ο ερυθρός τόνος δεν επιτρέπεται για ερασιτέχνες στην Κύπρο: ο μακρύπτερος έχει πολύ μακριά θωρακικά που φτάνουν πέρα από το δεύτερο ραχιαίο· οτιδήποτε άλλο απελευθερώνεται μέσα στο νερό."
  },
  "eating": {
   "en": "Excellent pale meat. Bleed immediately and ice: tuna left warm can cause histamine (scombroid) poisoning.",
   "el": "Εξαιρετικό ανοιχτόχρωμο κρέας. Ματώστε αμέσως και στον πάγο: ο τόνος που μένει ζεστός μπορεί να προκαλέσει δηλητηρίαση ισταμίνης."
  },
  "sources": [
   "https://fishingbooker.com/blog/?p=54089",
   "https://fishingbooker.com/sr/charters/view/47942",
   "https://www.barcheamotore.com/?p=5699",
   "http://www.cylaw.org/KDP/data/2019_1_416.pdf",
   "https://www.fishbase.se/summary/Thunnus-alalunga.html",
   "https://www.boatfishing.gr/article-post/syrti-gia-megala-pelagika-mia-techniki-psarematos-poy-chanetai/",
   "https://www.yachtingnews.com/deep-sea-trolling-mediterranean/"
  ]
 },
 "leerfish": {
  "summary": {
   "en": "Leerfish: a big, fast silver predator of beaches, river mouths and rocky points. Spin topwater lures and big minnows at dawn and dusk, or fish a live mullet or garfish. Best September–December.",
   "el": "Λίτσα: μεγάλο, γρήγορο ασημί αρπακτικό σε παραλίες, εκβολές και βραχώδεις κάβους. Spinning με επιφανειακά και μεγάλα minnow χαράματα και σούρουπο, ή ζωντανός κέφαλος ή ζαργάνα. Καλύτερα Σεπτέμβριο–Δεκέμβριο."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 1.5–2.5",
     "leader": "fluoro 0.50–0.70 mm, 1–1.5 m"
    },
    "rig": [
     "livebait_rig",
     "float_rig",
     "free_line"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_circle",
     "hook_j",
     "swivel"
    ],
    "hook": "single 1/0–3/0 · circle 4/0–6/0",
    "notes": {
     "en": "Rod 2.7–3.0 m casting 20–80 g, 4000–6000 reel with smooth drag. For live bait, a mullet or garfish free-lined or under a big float, fished from rocks into deep water or along a beach.",
     "el": "Καλάμι 2,7–3,0 m για 20–80 g, μηχανή 4000–6000 με ομαλό φρένο. Για ζωντανό, κέφαλος ή ζαργάνα ελεύθερα ή κάτω από μεγάλο φελλό, από βράχια σε βαθιά νερά ή κατά μήκος παραλίας."
    }
   },
   "boat": {
    "rod": [
     "boat_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_l"
    ],
    "line": {
     "main": "mono 0.40–0.50 mm / PE 2–3",
     "leader": "fluoro 0.60–0.80 mm, 3–5 m"
    },
    "rig": [
     "livebait_rig",
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_circle",
     "swivel"
    ],
    "hook": "circle 4/0–6/0",
    "notes": {
     "en": "Slow-troll a live mullet or garfish at 1–1.5 knots just outside the surf line and along points.",
     "el": "Αργή συρτή με ζωντανό κέφαλο ή ζαργάνα στον 1–1,5 κόμβο, λίγο έξω από το κύμα και κατά μήκος των κάβων."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "90–110 cm",
    "notes": {
     "en": "In shallow, slightly murky water by beaches and river mouths, wait on the bottom; leerfish come to look. Long shot, so a powerful gun.",
     "el": "Σε ρηχά, λίγο θολά νερά σε παραλίες και εκβολές, καρτέρι στον βυθό· η λίτσα έρχεται να κοιτάξει. Μεγάλη απόσταση βολής, άρα δυνατό όπλο."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "Live mullet or garfish, nose- or back-hooked: the best bait for big leerfish, which are wary and rarely take lures.",
     "el": "Ζωντανός κέφαλος ή ζαργάνα, από τη μύτη ή την πλάτη: το καλύτερο δόλωμα για μεγάλες λίτσες, που είναι καχύποπτες και σπάνια χτυπούν τεχνητά."
    }
   }
  ],
  "lures": [
   {
    "gear": "stickbait",
    "weight": "20–60 g",
    "size": "13–18 cm",
    "colors": [
     "sardine",
     "silver",
     "white"
    ],
    "note": {
     "en": "Walk-the-dog surface lures or skipping stickbaits at medium to high speed; Greek spinning guides name leerfish as a main surface-lure target.",
     "el": "Τεχνητά επιφανείας walk-the-dog ή skipping σε μέτρια ως γρήγορη ταχύτητα· οι ελληνικοί οδηγοί spinning βάζουν τη λίτσα στους βασικούς στόχους των τεχνητών επιφανείας."
    }
   },
   {
    "gear": "popper",
    "weight": "20–40 g",
    "size": "12–16 cm",
    "colors": [
     "white",
     "sardine"
    ],
    "note": {
     "en": "At first light when fish chase bait on top.",
     "el": "Με το πρώτο φως, όταν κυνηγούν στον αφρό."
    }
   },
   {
    "gear": "pencil",
    "weight": "20–40 g",
    "size": "13–16 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Sinking pencil for long casts into wind.",
     "el": "Βυθιζόμενο pencil για μακριές ρίψεις κόντρα στον αέρα."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "13–17 cm",
    "colors": [
     "silver",
     "sardine",
     "green_silver"
    ],
    "note": {
     "en": "Large floating or sinking minnows; 13 cm and over.",
     "el": "Μεγάλα επιπλέοντα ή βυθιζόμενα minnow· 13 cm και πάνω."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Sometimes: 12–18 cm slim soft jerkbaits or shads on 10–30 g heads or weighted swimbait hooks, retrieved fast near the surface. Less proven than live bait and hard surface lures; sources on soft plastics for this species are thin.",
    "el": "Μερικές φορές: λεπτές σιλικόνες jerkbait ή shad 12–18 cm σε μολυβοκεφαλές 10–30 g ή βαρυμένα αγκίστρια swimbait, με γρήγορο μάζεμα κοντά στην επιφάνεια. Λιγότερο δοκιμασμένες από το ζωντανό και τα σκληρά τεχνητά επιφανείας· οι πηγές για σιλικόνες σε αυτό το είδος είναι λίγες."
   },
   "ids": [
    "soft_shad",
    "soft_worm"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used directly; chumming for mullet can draw leerfish to the area.",
    "el": "Όχι απευθείας· η μάλαγρα για κέφαλους μπορεί να φέρει λίτσες στην περιοχή."
   }
  },
  "technique": {
   "en": "Cover water: cast topwater and minnows across points and river-mouth currents, retrieving at medium-high speed. With live bait, let the leerfish run for a few seconds with the bait, then tighten on the circle hook.",
   "el": "Καλύψτε νερό: ρίψεις με επιφανειακά και minnow σε κάβους και ρεύματα εκβολών, με μεσαία-γρήγορη ταχύτητα. Με ζωντανό, αφήστε τη λίτσα να τρέξει λίγα δευτερόλεπτα με το δόλωμα και μετά τεντώστε στο circle."
  },
  "where": {
   "en": "Sandy bays, river and stream mouths, harbour mouths and rocky points with bait and current; 0–15 m.",
   "el": "Αμμώδεις κόλποι, εκβολές ποταμών και ρεμάτων, είσοδοι λιμανιών και βραχώδεις κάβοι με δολωματόψαρα και ρεύμα· 0–15 m."
  },
  "when": {
   "en": "September–December; dawn and dusk, and rough days with coloured water.",
   "el": "Σεπτέμβριο–Δεκέμβριο· χαράματα και σούρουπο, και μέρες με φουρτούνα και θολό νερό."
  },
  "handling": {
   "en": "Abrasive jaws and sharp dorsal spines in front of the fin: lip grip and gloves; use a net from rocks.",
   "el": "Τραχιά σαγόνια και κοφτερά αγκαθάκια μπροστά από το ραχιαίο: λαβίδα και γάντια· απόχη από τα βράχια."
  },
  "eating": {
   "en": "Good, firm flesh, best from medium fish; big fish make fine steaks.",
   "el": "Καλό, σφιχτό κρέας, καλύτερο στα μεσαία ψάρια· τα μεγάλα δίνουν ωραίες φέτες."
  },
  "sources": [
   "https://www.hellasfishing.gr/%CE%BB%CE%AF%CF%84%CF%83%CE%B1/",
   "https://www.boatfishing.gr/article-post/spinning-surface-maches-ston-afro/",
   "https://adriaticnature.com/archives/6668",
   "https://www.psarema.gr/sizitiseis/erotisis-gia-spinning/119160-%CE%B1%CE%BD%CF%84%CE%B9%CE%BA%CE%B1%CF%84%CE%AC%CF%83%CF%84%CE%B1%CF%83%CE%B7-%CF%83%CF%85%CF%81%CE%BC%CE%AC%CF%84%CE%B9%CE%BD%CE%BF%CF%85-%CF%80%CE%B1%CF%81%CE%AC%CE%BC%CE%B1%CE%BB%CE%BF%CF%85-%CE%BC%CE%B5-%CF%80%CE%B5%CF%84%CE%BF%CE%BD%CE%B9%CE%AC-fluorocarbon",
   "https://www.psarema.gr/blog/32-spinning/1959-spinning-gia-labrakia-kai-gofaria-se-ekboles-potamwn",
   "https://www.fishbase.se/summary/Lichia-amia.html"
  ]
 },
 "barracuda": {
  "summary": {
   "en": "Barracudas: several species in Cyprus, including the yellowmouth and Red Sea invaders. Schooling predators of harbours, points and drop-offs. Spin minnows and soft shads at dusk and at night under harbour lights, or slow-troll at dawn.",
   "el": "Λούτσοι: στην Κύπρο ζουν πολλά είδη, μαζί με τον κιτρινόστομο και είδη από την Ερυθρά. Αρπακτικά σε κοπάδια σε λιμάνια, κάβους και κατωφέρειες. Spinning με minnow και σιλικόνες σούρουπο και νύχτα κάτω από τα φώτα των λιμανιών, ή αργή συρτή τα χαράματα."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.5",
     "leader": "fluoro 0.40–0.45 mm, 1 m, or a short wire trace"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "swivel"
    ],
    "hook": "treble 4–1 · single 1–1/0",
    "notes": {
     "en": "Rod 2.4–2.7 m casting 7–30 g, 3000 reel. Fluoro of 0.40 mm or more survives most bites; go to 0.50 mm or a short wire in big-fish spots.",
     "el": "Καλάμι 2,4–2,7 m για 7–30 g, μηχανή 3000. Fluoro 0,40 mm και πάνω αντέχει στα περισσότερα δαγκώματα· 0,50 mm ή κοντό σύρμα εκεί που έχει μεγάλα ψάρια."
    }
   },
   "boat": {
    "rod": [
     "trolling_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.35–0.45 mm",
     "leader": "wire, or fluoro 0.50–0.60 mm, 2–3 m"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "swivel"
    ],
    "hook": "treble 2–1/0",
    "notes": {
     "en": "Slow troll minnows at 2–3.5 knots along drop-offs and points at first light.",
     "el": "Αργή συρτή με minnow στους 2–3,5 κόμβους σε κατωφέρειες και κάβους με το πρώτο φως."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "75–100 cm",
    "notes": {
     "en": "Schools hang in mid-water near points and harbour entrances; approach slowly from below and to the side.",
     "el": "Τα κοπάδια στέκονται στα μεσόνερα κοντά σε κάβους και εισόδους λιμανιών· πλησιάστε αργά από κάτω και από το πλάι."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "note": {
     "en": "Live or very fresh garfish, whole or as a long fillet strip, is the number-one natural bait; small live fish under a float at night also work. Use a wire trace.",
     "el": "Ζωντανή ή ολόφρεσκη ζαργάνα, ολόκληρη ή σε μακριά λωρίδα φιλέτο, είναι το νούμερο ένα φυσικό δόλωμα· πιάνουν και μικρά ζωντανά ψαράκια με φελλό τη νύχτα. Με συρμάτινο παράμαλλο."
    },
    "best": true
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Half a sardine on a float rig near lights.",
     "el": "Μισή σαρδέλα με φελλό κοντά στα φώτα."
    }
   }
  ],
  "lures": [
   {
    "gear": "minnow",
    "weight": "",
    "size": "10–18 cm",
    "colors": [
     "silver",
     "red_head",
     "chartreuse",
     "white"
    ],
    "note": {
     "en": "Slim floating minnows (10–15 cm at night, 17 cm and over for big fish), slow twitch-and-pause across the light line; by boat, 14–18 cm surface lures trolled at about 3.5 knots. Natural colours in good light, bright or flashy ones in low light; red heads work.",
     "el": "Λεπτά επιπλέοντα minnow (10–15 cm τη νύχτα, 17 cm και πάνω για μεγάλα ψάρια), αργά τινάγματα και παύσεις κατά μήκος της γραμμής του φωτός· από σκάφος, τεχνητά επιφανείας 14–18 cm σε συρτή στους 3,5 κόμβους περίπου. Φυσικά χρώματα με καλό φως, έντονα ή γυαλιστερά με λίγο φως· τα κόκκινα κεφάλια πιάνουν."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "7–20 g",
    "size": "7–12 cm",
    "colors": [
     "white",
     "chartreuse",
     "natural"
    ],
    "note": {
     "en": "On a light jig head so it falls slowly; very effective, but teeth take many tails.",
     "el": "Σε ελαφριά μολυβοκεφαλή ώστε να πέφτει αργά· πολύ αποδοτική, αλλά τα δόντια κόβουν πολλές ουρές."
    }
   },
   {
    "gear": "vibe",
    "weight": "",
    "size": "",
    "colors": [],
    "note": {
     "en": "Productive when fish sit deeper: keep it in the water and retrieve slowly with twitches.",
     "el": "Αποδοτικό όταν τα ψάρια είναι πιο βαθιά: κρατήστε το μέσα στο νερό και μαζέψτε αργά με τινάγματα."
    }
   },
   {
    "gear": "stickbait",
    "weight": "10–30 g",
    "size": "9–13 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Sinking stickbaits at dusk.",
     "el": "Βυθιζόμενα stickbait το σούρουπο."
    }
   },
   {
    "gear": "spoon",
    "weight": "10–25 g",
    "size": "",
    "colors": [
     "silver",
     "gold"
    ],
    "note": {
     "en": "Simple and effective by day.",
     "el": "Απλό και αποδοτικό τη μέρα."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: slim paddle-tail shads on light jig heads, swum slowly on the retrieve and the fall, or tail-less soft worms twitched and paused near the bottom; 7–12 cm is typical. Very effective, but expect bitten-off tails: softer plastics catch more and tear more.",
    "el": "Ναι: λεπτές σιλικόνες shad σε ελαφριές μολυβοκεφαλές, αργά στο μάζεμα και στην πτώση, ή σιλικόνες-σκουλήκια χωρίς ουρά με τινάγματα και παύσεις κοντά στον βυθό· συνήθως 7–12 cm. Πολύ αποδοτικές, αλλά περιμένετε κομμένες ουρές: οι πιο μαλακές πιάνουν περισσότερο και σκίζονται πιο εύκολα."
   },
   "ids": [
    "soft_shad",
    "soft_worm"
   ],
   "colors": [
    "white",
    "chartreuse",
    "natural"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not needed; harbour lights already gather the bait.",
    "el": "Δεν χρειάζεται· τα φώτα του λιμανιού ήδη μαζεύουν τα ψαράκια."
   }
  },
  "technique": {
   "en": "At night, cast past the edge between light and shadow and retrieve back across it; barracudas sit on the dark side. Slow, steady retrieves beat fast ones.",
   "el": "Τη νύχτα ρίξτε πέρα από το όριο φωτός και σκιάς και μαζέψτε περνώντας το· οι λούτσοι στέκονται στη σκοτεινή πλευρά. Το αργό σταθερό μάζεμα αποδίδει περισσότερο από το γρήγορο."
  },
  "where": {
   "en": "Harbour entrances, breakwaters, lit jetties (where fishing is allowed), points and drop-offs; 0–30 m.",
   "el": "Είσοδοι λιμανιών, λιμενοβραχίονες, φωτισμένες προβλήτες (όπου επιτρέπεται το ψάρεμα), κάβοι και κατωφέρειες· 0–30 m."
  },
  "when": {
   "en": "All year, best in autumn; dusk and night, or dawn by boat.",
   "el": "Όλο τον χρόνο, καλύτερα το φθινόπωρο· σούρουπο και νύχτα, ή χαράματα από σκάφος."
  },
  "handling": {
   "en": "Razor teeth: never put fingers near the mouth. Lip grip plus long pliers.",
   "el": "Ξυραφένια δόντια: ποτέ δάχτυλα κοντά στο στόμα. Λαβίδα και μακριά πένσα."
  },
  "eating": {
   "en": "Good when fresh, grilled or fried; best eaten the same day.",
   "el": "Καλό φρέσκο, ψητό ή τηγανητό· καλύτερα την ίδια μέρα."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/spinning-oi-loytsoi-sto-stochastro/",
   "https://www.drososfishing.gr/afieroma-loytsos-tropoi-psarematos-ap/",
   "https://www.giornaledellavela.com/2023/08/15/fishing-from-the-boat-we-try-spinning-during-summer-cruises/?lang=en",
   "https://www.psarema.gr/sizitiseis/erotisis-gia-spinning/87560-spinning-to-vrady",
   "https://fishingbooker.com/charters/view/49787",
   "https://www.fishbase.se/summary/Sphyraena-viridensis.html"
  ]
 },
 "littletunny": {
  "summary": {
   "en": "Little tunny: a fast small tuna that drives bait to the surface along harbour walls and points. Cast 20–40 g metal jigs or poppers into the boils at dawn, or troll small feathers. September–December.",
   "el": "Καρβούνι: γρήγορος μικρός τόνος που βγάζει τα ψαράκια στον αφρό δίπλα σε λιμενοβραχίονες και κάβους. Ρίψεις με τζιγκ 20–40 g ή popper μέσα στα «βρασίματα» τα χαράματα, ή συρτή με μικρά φτερά. Σεπτέμβριο–Δεκέμβριο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 1.2–2",
     "leader": "fluoro 0.40–0.50 mm, 1–1.5 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook",
     "swivel"
    ],
    "hook": "assist 1/0–2/0 · treble 2–1",
    "notes": {
     "en": "Rod 2.7–3.0 m casting 20–60 g, 4000–5000 reel with fast retrieve. Expect a long first run: fill the spool.",
     "el": "Καλάμι 2,7–3,0 m για 20–60 g, μηχανή 4000–5000 με γρήγορο μάζεμα. Το πρώτο φευγιό είναι μακρύ: γεμάτη μπομπίνα."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod",
     "trolling_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 1.5–2 / mono 0.40–0.50 mm",
     "leader": "fluoro 0.45–0.60 mm"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 1/0–3/0",
    "notes": {
     "en": "Troll feathers and small spoons at 5–7 knots; approach breaking schools from upwind and cast, do not run through them.",
     "el": "Συρτή με φτερά και μικρά κουταλάκια στους 5–7 κόμβους· πλησιάστε τα κοπάδια που σπάνε από την πλευρά του αέρα και ρίξτε, μην περνάτε από μέσα τους."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "note": {
     "en": "A live sand smelt or small horse mackerel free-lined into a working school.",
     "el": "Ζωντανή αθερίνα ή μικρό σαφρίδι ελεύθερο μέσα στο κοπάδι που τρώει."
    }
   }
  ],
  "lures": [
   {
    "gear": "casting_jig",
    "weight": "20–60 g",
    "size": "",
    "colors": [
     "sardine",
     "silver",
     "red_head",
     "pink"
    ],
    "note": {
     "en": "Mid- or front-weighted jigs, 40–60 g from shore; long cast, short sink, very fast retrieve with pauses and taps. Natural sardine colours in clear calm water, more flash in rough or coloured water.",
     "el": "Πλάνοι μεσόβαροι ή εμπροσθόβαροι, 40–60 g από την ακτή· μακρινή βολή, λίγη βύθιση, πολύ γρήγορο μάζεμα με παύσεις και χτυπηματάκια. Φυσικά χρώματα σαρδέλας σε καθαρά ήρεμα νερά, περισσότερη λάμψη σε κύμα ή θολά νερά."
    }
   },
   {
    "gear": "popper",
    "weight": "20–40 g",
    "size": "9–12 cm",
    "colors": [
     "white",
     "sardine"
    ],
    "note": {
     "en": "Into the boils; a 40 g popper is a good all-round size from a boat. Sharp twitches just under the surface.",
     "el": "Μέσα στα «βρασίματα»· popper 40 g είναι καλό μέγεθος για όλα από σκάφος. Κοφτά τινάγματα λίγο κάτω από την επιφάνεια."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "9–12 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Heavy sinking minnows, fast.",
     "el": "Βαριά βυθιζόμενα minnow, γρήγορα."
    }
   },
   {
    "gear": "feather",
    "weight": "",
    "size": "6–10 cm",
    "colors": [
     "white",
     "pink",
     "chartreuse"
    ],
    "note": {
     "en": "Trolled at 5–7 knots.",
     "el": "Συρτή στους 5–7 κόμβους."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely: tunny want speed and flash, so metal jigs and hard lures work better. Greek light-trolling anglers do take small tunas on small soft fish trolled slowly (2.5–4 knots) in autumn.",
    "el": "Σπάνια: τα τονάκια θέλουν ταχύτητα και λάμψη, οπότε τα πλάνα και τα σκληρά τεχνητά δουλεύουν καλύτερα. Στην ελαφριά συρτή αφρού πάντως πιάνονται τονάκια και με μικρά σιλικονούχα ψαράκια σε αργή συρτή (2,5–4 κόμβοι) το φθινόπωρο."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used from shore.",
    "el": "Δεν χρησιμοποιείται από την ακτή."
   }
  },
  "technique": {
   "en": "Watch for diving birds and surface boils, cast beyond them and burn the jig back through. When schools sound, let the jig sink deeper before the fast retrieve.",
   "el": "Προσέξτε πουλιά που βουτούν και βρασίματα, ρίξτε πέρα από αυτά και περάστε το τζιγκ από μέσα με μεγάλη ταχύτητα. Όταν τα κοπάδια βυθίζονται, αφήστε το τζιγκ να κατέβει περισσότερο πριν το γρήγορο μάζεμα."
  },
  "where": {
   "en": "Harbour walls, breakwaters and points with deep water close in; from boat along the coast to 200 m depth.",
   "el": "Λιμενοβραχίονες, μώλοι και κάβοι με βαθιά νερά κοντά· από σκάφος κατά μήκος της ακτής ως τα 200 m βάθος."
  },
  "when": {
   "en": "September–December; dawn and dusk in calm weather, all day in rough weather.",
   "el": "Σεπτέμβριο–Δεκέμβριο· χαράματα και σούρουπο με καλό καιρό, όλη μέρα με φουρτούνα."
  },
  "handling": {
   "en": "Keep fingers clear of trebles on a kicking fish. Bluefin tuna must be released: little tunny have dark spots under the pectoral fin and wavy lines on the back.",
   "el": "Τα δάχτυλα μακριά από τις σαλαγκιές όταν το ψάρι χτυπιέται. Ο ερυθρός τόνος απελευθερώνεται: το καρβούνι έχει σκούρες βούλες κάτω από το θωρακικό και κυματιστές γραμμές στην πλάτη."
  },
  "eating": {
   "en": "Dark, strong meat: bleed and ice immediately, remove the dark band. Histamine risk if left warm.",
   "el": "Σκούρο, έντονο κρέας: ματώστε και στον πάγο αμέσως, βγάλτε τη σκούρη λωρίδα. Κίνδυνος ισταμίνης αν μείνει ζεστό."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/spinning-shore-jigging-stocheyontas-ta-tonoeidi/",
   "https://www.boatfishing.gr/article-post/syrti-afroy-me-silikonoycha-dolomata-gia-kynigoys-tonakia/",
   "https://adriaticnature.com/archives/6668",
   "https://www.decathlon.it/tutti-gli-sport/pesca-in-mare/artificiali-da-spinning-in-mare",
   "https://www.psarema.gr/blog/25-jigging/1877-shore-jigging-xekinwntas-apo-to-mhden",
   "https://www.fishbase.se/summary/Euthynnus-alletteratus.html"
  ]
 },
 "bonito": {
  "summary": {
   "en": "Atlantic bonito: a toothy small tuna of headlands and harbours in the cooler months. Troll small feathers, spoons or minnows at 5–7 knots, or cast metal jigs into bait schools at dawn. October–April.",
   "el": "Παλαμίδα: μικρός τόνος με δόντια, σε κάβους και λιμάνια τους δροσερούς μήνες. Συρτή με μικρά φτερά, κουταλάκια ή minnow στους 5–7 κόμβους, ή ρίψεις με τζιγκ στα κοπάδια τα χαράματα. Οκτώβριο–Απρίλιο."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "trolling_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.35–0.45 mm / PE 1.2–2",
     "leader": "fluoro 0.45–0.55 mm, 2–4 m"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 1/0–3/0",
    "notes": {
     "en": "Troll 2–4 lines 20–50 m back at 5–7 knots off headlands; a small sinker or a diving minnow gets a lure down to 3–5 m on bright days.",
     "el": "Συρτή με 2–4 πετονιές στα 20–50 m, 5–7 κόμβους έξω από κάβους· ένα μικρό μολύβι ή minnow που βουτά κατεβάζει το τεχνητό στα 3–5 m τις φωτεινές μέρες."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.2–2",
     "leader": "fluoro 0.40–0.50 mm, 1–1.5 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook"
    ],
    "hook": "assist 1/0–2/0 · treble 2–1",
    "notes": {
     "en": "Rod 2.7–3.0 m casting 20–60 g, 4000 reel.",
     "el": "Καλάμι 2,7–3,0 m για 20–60 g, μηχανή 4000."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "note": {
     "en": "Small live fish or a sardine strip trolled slowly or free-lined.",
     "el": "Μικρό ζωντανό ψαράκι ή λωρίδα σαρδέλας σε αργή συρτή ή ελεύθερα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sardine strip on a float in a harbour mouth.",
     "el": "Λωρίδα σαρδέλας με φελλό στην είσοδο του λιμανιού."
    }
   }
  ],
  "lures": [
   {
    "gear": "feather",
    "weight": "",
    "size": "6–10 cm",
    "colors": [
     "white",
     "pink",
     "red"
    ],
    "note": {
     "en": "Classic bonito trolling lure.",
     "el": "Το κλασικό τεχνητό συρτής για παλαμίδα."
    }
   },
   {
    "gear": "spoon",
    "weight": "10–30 g",
    "size": "",
    "colors": [
     "silver",
     "gold"
    ],
    "note": {
     "en": "Trolled or cast; silver by day, gold on dull days.",
     "el": "Στη συρτή ή σε ρίψεις· ασημί τη μέρα, χρυσό με συννεφιά."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "20–60 g",
    "size": "",
    "colors": [
     "silver",
     "sardine",
     "pink"
    ],
    "note": {
     "en": "Fast retrieve through bait schools.",
     "el": "Γρήγορο μάζεμα μέσα από τα κοπάδια."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–20 cm",
    "colors": [
     "sardine",
     "silver",
     "orange",
     "purple"
    ],
    "note": {
     "en": "Trolled at 5–7 knots or cast: 12–20 cm covers most trolling, 15–20 cm when big fish are about. Natural colours first, but yellow, orange, purple and red often do better.",
     "el": "Σε συρτή στους 5–7 κόμβους ή σε ρίψεις: τα 12–20 cm καλύπτουν τις περισσότερες ανάγκες της συρτής, 15–20 cm όταν κυκλοφορούν μεγάλα ψάρια. Πρώτα φυσικά χρώματα, αλλά συχνά πιάνουν καλύτερα κίτρινο, πορτοκαλί, μωβ και κόκκινο."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Seldom: sharp teeth shred soft lures and speed matters more. Greek trolling writers call soft lures on a jig head a promising option, but hard lures, feathers and spoons are the mainstream.",
    "el": "Σπάνια: τα κοφτερά δόντια κομματιάζουν τις σιλικόνες και μετράει περισσότερο η ταχύτητα. Έλληνες συντάκτες της συρτής αναφέρουν τη σιλικόνη σε μολυβοκεφαλή ως πολλά υποσχόμενη επιλογή, αλλά τα σκληρά τεχνητά, τα φτερά και τα κουτάλια είναι ο κανόνας."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not normally used.",
    "el": "Συνήθως δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Troll along headlands and the edges of harbour mouths at first light, turning through any bird activity; from shore, fan-cast jigs and retrieve fast.",
   "el": "Συρτή κατά μήκος των κάβων και στις άκρες των εισόδων λιμανιών με το πρώτο φως, στρίβοντας μέσα από όποια δράση πουλιών· από ακτή, ρίψεις σε βεντάλια και γρήγορο μάζεμα."
  },
  "where": {
   "en": "Headlands, harbour mouths and the open coast to 100 m depth; schools move along the coast.",
   "el": "Κάβοι, είσοδοι λιμανιών και ανοιχτή ακτή ως τα 100 m βάθος· τα κοπάδια κινούνται κατά μήκος της ακτής."
  },
  "when": {
   "en": "October–April; dawn is best.",
   "el": "Οκτώβριο–Απρίλιο· καλύτερα τα χαράματα."
  },
  "handling": {
   "en": "Sharp teeth: unhook with pliers. Release any bluefin tuna.",
   "el": "Κοφτερά δόντια: ξαγκίστρωμα με πένσα. Απελευθερώστε κάθε ερυθρό τόνο."
  },
  "eating": {
   "en": "Very good; bleed and ice at once (histamine risk if warm).",
   "el": "Πολύ καλό· ματώστε και στον πάγο αμέσως (κίνδυνος ισταμίνης αν μείνει ζεστό)."
  },
  "sources": [
   "https://www.boatfishing.gr/article-post/syrti-afroy-anazitontas-tis-cheimoniatikes-palamides/",
   "https://www.boatfishing.gr/article-post/spinning-shore-jigging-stocheyontas-ta-tonoeidi/",
   "https://adriaticnature.com/archives/6668",
   "https://www.psarema.gr/blog/19-syrti/1588-i-texni-tis-syrtis-a-meros",
   "https://www.barcheamotore.com/?p=5699",
   "https://www.fishbase.se/summary/Sarda-sarda.html"
  ]
 },
 "bluefish": {
  "summary": {
   "en": "Bluefish: an aggressive, razor-toothed predator of harbour mouths, surf beaches and current-swept points. Spin big minnows, poppers and metal jigs at dusk; fish strips or live bait at night. October–March.",
   "el": "Γοφάρι: επιθετικό αρπακτικό με ξυραφένια δόντια σε εισόδους λιμανιών, παραλίες με κύμα και κάβους με ρεύμα. Spinning με μεγάλα minnow, popper και τζιγκ το σούρουπο· λωρίδες ψαριού ή ζωντανό τη νύχτα. Οκτώβριο–Μάρτιο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "surf_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_spin_l"
    ],
    "line": {
     "main": "PE 1.2–2",
     "leader": "fluoro 0.50–0.70 mm / wire 20–40 lb"
    },
    "rig": [
     "surf_rig",
     "float_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "single 1/0–2/0 · J 1/0–3/0",
    "notes": {
     "en": "Fast-tip rod 2.7–3.0 m casting 15–60 g, 3000–4000 reel with a strong drag. Big minnows (17–20 cm) keep the teeth away from the leader; single hooks hold better on jumping fish.",
     "el": "Καλάμι 2,7–3,0 m για 15–60 g με γρήγορη κορυφή, μηχανή 3000–4000 με δυνατό φρένο. Τα μεγάλα minnow (17–20 cm) κρατούν τα δόντια μακριά από το παράμαλλο· τα μονά αγκίστρια κρατάνε καλύτερα στα σάλτα."
    }
   },
   "boat": {
    "rod": [
     "trolling_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.35–0.45 mm",
     "leader": "wire 30–40 lb / fluoro 0.60–0.70 mm"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "swivel"
    ],
    "hook": "treble 1–2/0",
    "notes": {
     "en": "Troll minnows at 3–5 knots along the coast at dusk.",
     "el": "Συρτή με minnow στους 3–5 κόμβους κατά μήκος της ακτής το σούρουπο."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Sardine fillet or half sardine on a long-shank hook, surf or float rig, at night.",
     "el": "Φιλέτο ή μισή σαρδέλα σε αγκίστρι με μακρύ λαιμό, σε σύνθεση surf ή με φελλό, τη νύχτα."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "Small live fish (sand smelt, horse mackerel) free-lined or under a float.",
     "el": "Μικρό ζωντανό ψαράκι (αθερίνα, σαφρίδι) ελεύθερο ή με φελλό."
    }
   }
  ],
  "lures": [
   {
    "gear": "minnow",
    "weight": "",
    "size": "12–20 cm",
    "colors": [
     "silver",
     "sardine",
     "red_head"
    ],
    "note": {
     "en": "Heavy long-casting minnows; a steady retrieve in strong current.",
     "el": "Βαριά minnow μακριάς ρίψης· σταθερό μάζεμα στο δυνατό ρεύμα."
    }
   },
   {
    "gear": "popper",
    "weight": "20–40 g",
    "size": "12–15 cm",
    "colors": [
     "white",
     "sardine"
    ],
    "note": {
     "en": "Surface feeding at dawn and dusk.",
     "el": "Όταν τρώνε στην επιφάνεια, χαράματα και σούρουπο."
    }
   },
   {
    "gear": "metal_jig",
    "weight": "30–60 g",
    "size": "",
    "colors": [
     "silver",
     "sardine",
     "chartreuse"
    ],
    "note": {
     "en": "Fast retrieve from rocks and surf.",
     "el": "Γρήγορο μάζεμα από βράχια και παραλία."
    }
   },
   {
    "gear": "stickbait",
    "weight": "20–40 g",
    "size": "12–16 cm",
    "colors": [
     "silver",
     "white"
    ],
    "note": {
     "en": "Skipping stickbaits on top.",
     "el": "Stickbait με skipping στην επιφάνεια."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not recommended: bluefish chop soft plastics in one bite. Use hard lures.",
    "el": "Δεν συνιστάται: το γοφάρι κόβει τις σιλικόνες με μια δαγκωνιά. Σκληρά τεχνητά."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "At night from piers, a light sardine-and-bread chum draws small fish and the bluefish behind them.",
    "el": "Τη νύχτα από προβλήτες, ελαφριά μάλαγρα με σαρδέλα και ψωμί φέρνει ψαράκια και πίσω τους τα γοφάρια."
   }
  },
  "technique": {
   "en": "At dusk, cast across the current and keep the lure moving fast; when they stop, change lure colour or go to the surface. At night, bait on a surf rig with a short wire or heavy mono trace.",
   "el": "Το σούρουπο ρίξτε κόντρα στο ρεύμα και κρατήστε το τεχνητό σε γρήγορη κίνηση· όταν σταματήσουν, αλλάξτε χρώμα ή πάτε στην επιφάνεια. Τη νύχτα δόλωμα σε σύνθεση surf με κοντό σύρμα ή χοντρό παράμαλλο."
  },
  "where": {
   "en": "Harbour mouths, river mouths, sandy surf beaches and points with current; 0–30 m.",
   "el": "Είσοδοι λιμανιών, εκβολές, αμμουδιές με κύμα και κάβοι με ρεύμα· 0–30 m."
  },
  "when": {
   "en": "October–March; dusk, dawn and the first hours of night.",
   "el": "Οκτώβριο–Μάρτιο· σούρουπο, χαράματα και οι πρώτες ώρες της νύχτας."
  },
  "handling": {
   "en": "Razor-sharp teeth that snap even on deck: never by hand; long pliers and a lip grip.",
   "el": "Ξυραφένια δόντια που δαγκώνουν ακόμη και στο κατάστρωμα: ποτέ με το χέρι· μακριά πένσα και λαβίδα."
  },
  "eating": {
   "en": "Oily, tasty fresh; bleed and ice, eat the same day or next.",
   "el": "Λιπαρό, νόστιμο φρέσκο· ματώστε και στον πάγο, φάτε το την ίδια ή την επόμενη μέρα."
  },
  "sources": [
   "https://www.psarema.gr/blog/32-spinning/1987-spinning-gia-gofaria-se-dynata-thalassia-reymata",
   "https://www.psarema.gr/blog/32-spinning/1959-spinning-gia-labrakia-kai-gofaria-se-ekboles-potamwn",
   "https://www.psarema.gr/sizitiseis/ta-texnita/31676-texnita-gia-gofaria",
   "https://adriaticnature.com/archives/6668",
   "https://www.fishbase.se/summary/Pomatomus-saltatrix.html"
  ]
 },
 "horsemackerel": {
  "summary": {
   "en": "Horse mackerel: a schooling small pelagic of harbours and marinas, hungry from dusk into the night under lights. Sabiki rigs, tiny baits or ultra-light jigs with groundbait. Also the best live bait for bigger predators. Minimum 15 cm.",
   "el": "Σαφρίδι: μικρό αφρόψαρο σε κοπάδια σε λιμάνια και μαρίνες, που τρώει από το σούρουπο ως τη νύχτα κάτω από τα φώτα. Τσαπαρί, μικρά δολώματα ή υπερελαφριά τζιγκ με μάλαγρα. Και το καλύτερο ζωντανό δόλωμα για μεγάλα αρπακτικά. Ελάχιστο 15 cm."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm / PE 0.3–0.6",
     "leader": "fluoro 0.16–0.20 mm"
    },
    "rig": [
     "float_rig",
     "drop_shot"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 10–14",
    "notes": {
     "en": "LRF (ajing) rod 0.5–8 g with a 1000–2500 reel for tiny jigs, or a 4–6 m bolognese with a light float for baits. Sabiki with a 10–30 g sinker on a spinning rod for the fast route.",
     "el": "Καλάμι LRF (ajing) 0,5–8 g με μηχανή 1000–2500 για μικρά τζιγκ, ή μπολονέζ 4–6 m με ελαφρύ φελλό για δολώματα. Τσαπαρί με μολύβι 10–30 g σε καλάμι spinning για τον γρήγορο δρόμο."
    }
   },
   "boat": {
    "rod": [
     "boat_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.5",
     "leader": "sabiki 0.20–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "sinker",
     "swivel"
    ],
    "hook": "sabiki 8–12",
    "notes": {
     "en": "Sabiki with a 40–80 g sinker at the bottom, jigged gently through the school shown on the sonar at 20–60 m.",
     "el": "Τσαπαρί με μολύβι 40–80 g στο τέλος, με απαλά τινάγματα μέσα από το κοπάδι που δείχνει το βυθόμετρο στα 20–60 m."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small pieces of peeled shrimp, on a float or on the sabiki hooks themselves; a little bait on the sabiki helps on slow days.",
     "el": "Μικρά κομμάτια ξεφλουδισμένης γαρίδας, με φελλό ή πάνω στα ίδια τα αγκίστρια του τσαπαριού· λίγο δόλωμα στο τσαπαρί βοηθά τις δύσκολες μέρες."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Tiny strips of sardine or fish on a size 12 hook.",
     "el": "Μικρές λωρίδες σαρδέλας ή ψαριού σε αγκίστρι 12."
    }
   }
  ],
  "lures": [
   {
    "gear": "sabiki",
    "weight": "10–80 g",
    "size": "#8–12",
    "colors": [
     "natural",
     "pink",
     "white",
     "glow"
    ],
    "note": {
     "en": "The standard method. Simple small-hook rigs (fish skin, small feathers, glow beads) beat ones with big fish or squid imitations; best in the two hours after dawn and before sunset. Release fish under 15 cm straight away.",
     "el": "Η βασική μέθοδος. Τα απλά τσαπαριά με μικρά αγκίστρια (δέρμα ψαριού, φτεράκια, φωσφοριζέ χάντρες) πιάνουν καλύτερα από αυτά με μεγάλα ομοιώματα ψαριού ή καλαμαριού· καλύτερα τις δύο ώρες μετά το χάραμα και πριν τη δύση. Ψάρια κάτω από 15 cm απελευθερώνονται αμέσως."
    }
   },
   {
    "gear": "soft_worm",
    "weight": "0.8–3 g",
    "size": "3–5 cm",
    "colors": [
     "glow",
     "pink",
     "white"
    ],
    "note": {
     "en": "Ajing, the Japanese horse-mackerel technique: a pin-tail micro soft lure on a light jig head, drifted slowly with the current. Practised by some local LRF anglers; little local data.",
     "el": "Ajing, η ιαπωνική τεχνική για σαφρίδια: μικροσκοπική σιλικόνη pin-tail σε ελαφριά μολυβοκεφαλή, που παρασύρεται αργά με το ρεύμα. Την εφαρμόζουν κάποιοι ψαράδες LRF εδώ· λίγα τοπικά στοιχεία."
    }
   },
   {
    "gear": "metal_jig",
    "weight": "5–15 g",
    "size": "",
    "colors": [
     "silver",
     "pink"
    ],
    "note": {
     "en": "Micro jigs worked in short hops.",
     "el": "Μικρά τζιγκ με κοντά πηδηματάκια."
    }
   },
   {
    "gear": "feather",
    "weight": "",
    "size": "",
    "colors": [
     "white",
     "pink"
    ],
    "note": {
     "en": "Feather rigs (as sabiki) on light trolling or vertical.",
     "el": "Σύνθεση με φτερά (όπως τσαπαρί), σε ελαφριά συρτή ή κάθετα."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, in miniature: 3–5 cm pin-tail soft lures on 0.8–3 g jig heads (ajing), drifted slowly under the lights. A Japanese technique practised by some local LRF anglers; local published data are thin, and sabiki remains the main method.",
    "el": "Ναι, σε μικρογραφία: σιλικόνες pin-tail 3–5 cm σε μολυβοκεφαλές 0,8–3 g (ajing), που παρασύρονται αργά κάτω από τα φώτα. Ιαπωνική τεχνική που εφαρμόζουν κάποιοι ψαράδες LRF εδώ· τα τοπικά δημοσιευμένα στοιχεία είναι λίγα και το τσαπαρί μένει η βασική μέθοδος."
   },
   "ids": [
    "soft_worm"
   ]
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Yes: bread and minced sardine (sardine oil helps), in small handfuls every few minutes, little and often; avoid places with strong surface current.",
    "el": "Ναι: ψωμί και πολτός σαρδέλας (βοηθά το λάδι σαρδέλας), λίγη λίγη κάθε λίγα λεπτά· αποφύγετε σημεία με δυνατό επιφανειακό ρεύμα."
   }
  },
  "technique": {
   "en": "Chum, then fish sabiki or tiny jigs at the depth where the school holds; start mid-water and go deeper as night falls. Lift gently: their mouths tear.",
   "el": "Μάλαγρα, και μετά τσαπαρί ή μικρά τζιγκ στο βάθος που στέκεται το κοπάδι· ξεκινήστε από τα μεσόνερα και κατεβαίνετε όσο νυχτώνει. Απαλό σήκωμα: το στόμα σκίζεται."
  },
  "where": {
   "en": "Harbours, marinas and fishing shelters (where allowed), breakwaters and lit jetties; from boat over 20–60 m.",
   "el": "Λιμάνια, μαρίνες και καταφύγια (όπου επιτρέπεται), λιμενοβραχίονες και φωτισμένες προβλήτες· από σκάφος στα 20–60 m."
  },
  "when": {
   "en": "October–April; dusk into the night.",
   "el": "Οκτώβριο–Απρίλιο· από το σούρουπο ως τη νύχτα."
  },
  "handling": {
   "en": "Harmless, but the scutes along the tail are sharp. Keep live baits in an aerated bucket.",
   "el": "Ακίνδυνο, αλλά οι φολίδες στην πλευρική γραμμή κόβουν. Τα ζωντανά δολώματα σε κουβά με οξυγόνο."
  },
  "eating": {
   "en": "Good fried or grilled; release under 15 cm.",
   "el": "Καλό τηγανητό ή ψητό· τα κάτω από 15 cm πίσω."
  },
  "sources": [
   "https://www.drososfishing.gr/tsapari-gnorimia-tropos-psarematos-ka/",
   "https://www.boatfishing.gr/article-post/tsapari-psare%C2%B5a-choris-dolo%C2%B5a/",
   "https://www.psarema.gr/sizitiseis/sirti-apekso-spinning/67660-%CF%84%CF%83%CE%B1%CF%80%CE%B1%CF%81%CE%AF-%CE%B1%CF%80%CE%BF-%CE%AD%CE%BE%CF%89",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "mackerel": {
  "summary": {
   "en": "Atlantic chub mackerel: a fast schooling fish of harbour walls and breakwaters. Sabiki rigs or small metal jigs with groundbait at dawn and dusk. Minimum 18 cm. Excellent live bait.",
   "el": "Κολιός: γρήγορο ψάρι σε κοπάδια σε λιμενοβραχίονες και μώλους. Τσαπαρί ή μικρά τζιγκ με μάλαγρα χαράματα και σούρουπο. Ελάχιστο 18 cm. Εξαιρετικό ζωντανό δόλωμα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "lrf_rod",
     "bolognese_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1 / mono 0.20–0.25 mm",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "float_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–12 · sabiki 6–10",
    "notes": {
     "en": "Spinning rod 2.4–2.7 m casting 5–30 g for sabiki or small jigs; bolognese for float baits.",
     "el": "Καλάμι spinning 2,4–2,7 m για 5–30 g για τσαπαρί ή μικρά τζιγκ· μπολονέζ για δολώματα με φελλό."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.5",
     "leader": "sabiki 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "sinker",
     "swivel"
    ],
    "hook": "sabiki 6–10",
    "notes": {
     "en": "Sabiki with a 40–80 g sinker through schools marked on the sonar.",
     "el": "Τσαπαρί με μολύβι 40–80 g μέσα από κοπάδια στο βυθόμετρο."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Small sardine strip on a float.",
     "el": "Μικρή λωρίδα σαρδέλας με φελλό."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp pieces.",
     "el": "Κομματάκια γαρίδας."
    }
   }
  ],
  "lures": [
   {
    "gear": "sabiki",
    "weight": "15–80 g",
    "size": "#6–10",
    "colors": [
     "white",
     "pink",
     "silver"
    ],
    "note": {
     "en": "Main method: lift and drop through the school; size 6 hooks suit chub mackerel.",
     "el": "Βασική μέθοδος: σήκωμα και κατέβασμα μέσα στο κοπάδι· για κολιούς ταιριάζουν αγκίστρια Νο 6."
    }
   },
   {
    "gear": "metal_jig",
    "weight": "10–30 g",
    "size": "",
    "colors": [
     "silver",
     "sardine",
     "green_silver"
    ],
    "note": {
     "en": "Small jigs cast and retrieved fast.",
     "el": "Μικρά τζιγκ, ρίψη και γρήγορο μάζεμα."
    }
   },
   {
    "gear": "feather",
    "weight": "",
    "size": "",
    "colors": [
     "white",
     "chartreuse"
    ],
    "note": {
     "en": "Feather strings, trolled slowly or jigged.",
     "el": "Αρμαθιές με φτερά, σε αργή συρτή ή κάθετα."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not needed: sabiki and small metal are more effective.",
    "el": "Δεν χρειάζεται: το τσαπαρί και τα μικρά μεταλλικά αποδίδουν περισσότερο."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Yes: bread with minced sardine and a little sardine oil keeps the school in front of you.",
    "el": "Ναι: ψωμί με πολτό σαρδέλας και λίγο λάδι σαρδέλας κρατά το κοπάδι μπροστά σας."
   }
  },
  "technique": {
   "en": "Chum steadily, cast the sabiki, let it sink and lift-drop slowly back; do not wind in on the first fish, wait for more to load the rig.",
   "el": "Σταθερή μάλαγρα, ρίξτε το τσαπαρί, αφήστε το να κατέβει και φέρτε το με αργά σηκώματα· μη μαζεύετε στο πρώτο ψάρι, περιμένετε να πιαστούν κι άλλα."
  },
  "where": {
   "en": "Harbour walls, breakwaters, fishing shelters and points; boat over 20–100 m.",
   "el": "Λιμενοβραχίονες, μώλοι, καταφύγια και κάβοι· από σκάφος στα 20–100 m."
  },
  "when": {
   "en": "October–May; dawn and dusk.",
   "el": "Οκτώβριο–Μάιο· χαράματα και σούρουπο."
  },
  "handling": {
   "en": "Harmless; unhook quickly and release under 18 cm. For live bait, use an aerated tank: mackerel die quickly.",
   "el": "Ακίνδυνος· γρήγορο ξαγκίστρωμα, κάτω από 18 cm πίσω. Για ζωντανό, δεξαμενή με οξυγόνο: ο κολιός πεθαίνει γρήγορα."
  },
  "eating": {
   "en": "Very good grilled or salted; ice at once (histamine risk).",
   "el": "Πολύ καλός ψητός ή παστός· στον πάγο αμέσως (κίνδυνος ισταμίνης)."
  },
  "sources": [
   "https://www.drososfishing.gr/tsapari-gnorimia-tropos-psarematos-ka/",
   "https://www.boatfishing.gr/article-post/tsapari-psare%C2%B5a-choris-dolo%C2%B5a/",
   "https://www.psarema.gr/sizitiseis/sirti-apekso-spinning/67660-%CF%84%CF%83%CE%B1%CF%80%CE%B1%CF%81%CE%AF-%CE%B1%CF%80%CE%BF-%CE%AD%CE%BE%CF%89",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj",
   "https://www.fishbase.se/summary/Scomber-colias.html"
  ]
 },
 "garfish": {
  "summary": {
   "en": "Garfish: a slim surface fish of calm clear water by rocks and harbours. A thin bait just under a float, or slim spoons and small minnows; light gear. November–April. Also a top live bait for leerfish and amberjack.",
   "el": "Βελονίδα (ζαργάνα): λεπτό αφρόψαρο σε ήρεμα καθαρά νερά κοντά σε βράχια και λιμάνια. Λεπτό δόλωμα λίγο κάτω από φελλό, ή λεπτά κουταλάκια και μικρά minnow· ελαφρύς εξοπλισμός. Νοέμβριο–Απρίλιο. Και κορυφαίο ζωντανό για λίτσα και μαγιάτικο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "spinning_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm / PE 0.4–0.8",
     "leader": "fluoro 0.16–0.20 mm"
    },
    "rig": [
     "float_rig",
     "free_line"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–12",
    "notes": {
     "en": "Bolognese 4–6 m with a 1–3 g float set 0.3–1 m deep, or a long thin \"garfish\" float cast with a spinning rod. A long-shank hook stops the fish cutting the line or swallowing deep.",
     "el": "Μπολονέζ 4–6 m με φελλό 1–3 g σε βάθος 0,3–1 m, ή μακρύς λεπτός φελλός για ζαργάνα με καλάμι spinning. Το αγκίστρι με μακρύ λαιμό εμποδίζει το ψάρι να κόψει την πετονιά ή να το καταπιεί βαθιά."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.18–0.22 mm"
    },
    "rig": [
     "float_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j"
    ],
    "hook": "J 8–10",
    "notes": {
     "en": "Drift with floats off rocky shores, with a little chum.",
     "el": "Ντρίφτα με φελλούς έξω από βραχώδεις ακτές, με λίγη μάλαγρα."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Thin strip of sardine or garfish fillet cut to look like a sand smelt.",
     "el": "Λεπτή λωρίδα σαρδέλας ή φιλέτο ζαργάνας κομμένο σαν αθερίνα."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Thin worm (American worm or \"acrobat\"); some Greek forum anglers rate it the best garfish bait.",
     "el": "Λεπτό σκουλήκι (αμερικάνικο ή «ακροβάτης»)· για κάποιους Έλληνες ψαράδες του φόρουμ το καλύτερο δόλωμα για ζαργάνα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small shrimp pieces just under the surface.",
     "el": "Κομματάκια γαρίδας λίγο κάτω από την επιφάνεια."
    }
   }
  ],
  "lures": [
   {
    "gear": "spoon",
    "weight": "7–20 g",
    "size": "",
    "colors": [
     "silver",
     "gold"
    ],
    "note": {
     "en": "Slim spoons retrieved fairly fast near the surface.",
     "el": "Λεπτά κουταλάκια με σχετικά γρήγορο μάζεμα κοντά στην επιφάνεια."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "5–9 cm",
    "colors": [
     "silver",
     "green_silver"
    ],
    "note": {
     "en": "Small slim minnows; expect many missed bites on trebles.",
     "el": "Μικρά λεπτά minnow· να περιμένετε πολλά χαμένα τσιμπήματα στις σαλαγκιές."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "7–15 g",
    "size": "",
    "colors": [
     "silver",
     "green_silver"
    ],
    "note": {
     "en": "Small casting jigs, fast and high in the water.",
     "el": "Μικρά casting jig, γρήγορα και ψηλά στο νερό."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely used. The traditional Greek alternative is the matasina, a silk or wool thread lure (no hook) that tangles in the teeth; forum reports are mixed, and it seems to work better from a boat.",
    "el": "Σπάνια. Η παραδοσιακή ελληνική εναλλακτική είναι η ματασίνα, μεταξωτό ή μάλλινο κορδονάκι (χωρίς αγκίστρι) που μπλέκεται στα δόντια· οι αναφορές στα φόρουμ διαφέρουν, και φαίνεται να δουλεύει καλύτερα από σκάφος."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Yes: a light sardine-based chum drifting on the surface brings schools close, and a handful of maggots thrown in also gathers them. Common practice; garfish-specific sources are thin.",
    "el": "Ναι: μια ελαφριά μαλάγρα με βάση τη σαρδέλα που παρασύρεται στην επιφάνεια φέρνει τα κοπάδια κοντά, και μια χούφτα μπικατίνι επίσης τα μαζεύει. Συνήθης πρακτική· οι πηγές ειδικά για ζαργάνα είναι λίγες."
   }
  },
  "technique": {
   "en": "Fish the bait shallow, 30 cm to 1 m down, drifting with the chum; strike at once when the float moves, with a gentle sweep. With lures, keep them high and fairly fast.",
   "el": "Δόλωμα ρηχά, 30 cm ως 1 m, να ταξιδεύει με τη μάλαγρα· καρφώστε αμέσως μόλις κουνηθεί ο φελλός, με απαλή κίνηση. Με τεχνητά, ψηλά και σχετικά γρήγορα."
  },
  "where": {
   "en": "Calm clear water off rocks, jetties and harbour walls, and around floating weed.",
   "el": "Ήρεμα καθαρά νερά έξω από βράχια, προβλήτες και λιμενοβραχίονες, και γύρω από επιπλέοντα φύκια."
  },
  "when": {
   "en": "November–April; calm days, morning and afternoon.",
   "el": "Νοέμβριο–Απρίλιο· ήρεμες μέρες, πρωί και απόγευμα."
  },
  "handling": {
   "en": "Long beak with small sharp teeth: hold behind the head and unhook with pliers.",
   "el": "Μακρύ ράμφος με μικρά κοφτερά δόντια: πιάστε πίσω από το κεφάλι και ξαγκιστρώστε με πένσα."
  },
  "eating": {
   "en": "Good fried. The green bones are natural and harmless.",
   "el": "Καλή τηγανητή. Τα πράσινα κόκκαλα είναι φυσιολογικά και ακίνδυνα."
  },
  "sources": [
   "https://www.drososfishing.gr/spinning-zarganes-bobarda/",
   "https://www.psarema.gr/sizitiseis/psaria-kai-to-psarema-tous/247110-to-psarema-tis-zarganas",
   "https://www.fishbase.se/summary/Belone-belone.html"
  ]
 },
 "pompano": {
  "summary": {
   "en": "Pompano: a small, fast, silver jack of sandy beaches and the surf line. Cast small metal jigs or minnows into the surf, or shrimp and worm on a light leger; dawn, June–October. Keep well clear of swimmers.",
   "el": "Λιτσούι: μικρό, γρήγορο ασημί ψάρι των αμμουδιών και του κύματος. Ρίψεις με μικρά τζιγκ ή minnow στο κύμα, ή γαρίδα και σκουλήκι σε ελαφριά σύνθεση βυθού· χαράματα, Ιούνιο–Οκτώβριο. Μακριά από τους λουόμενους."
  },
  "best": [
   "shore",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "lrf_rod",
     "surf_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1.2",
     "leader": "fluoro 0.25–0.30 mm, 1 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 6–2 · treble 8–6",
    "notes": {
     "en": "Light spinning rod 2.4–2.7 m casting 5–30 g, 2500–3000 reel. For bait, a light surf or Carolina rig with a 20–60 g sinker and a 1–1.5 m leader.",
     "el": "Ελαφρύ καλάμι spinning 2,4–2,7 m για 5–30 g, μηχανή 2500–3000. Για δόλωμα, ελαφριά σύνθεση surf ή Carolina με μολύβι 20–60 g και παράμαλλο 1–1,5 m."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Schools patrol the shallow surf; only outside bathing areas. Short gun for close, quick shots.",
     "el": "Τα κοπάδια περιπολούν στο ρηχό κύμα· μόνο έξω από περιοχές κολύμβησης. Κοντό όπλο για κοντινές, γρήγορες βολές."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Live or fresh shrimp on a size 4–2 hook.",
     "el": "Ζωντανή ή φρέσκια γαρίδα σε αγκίστρι 4–2."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm on a light surf rig.",
     "el": "Σκουλήκι σε ελαφριά σύνθεση surf."
    }
   }
  ],
  "lures": [
   {
    "gear": "metal_jig",
    "weight": "10–30 g",
    "size": "",
    "colors": [
     "silver",
     "gold",
     "sardine"
    ],
    "note": {
     "en": "Small slim jigs cast beyond the surf, fast retrieve with pauses.",
     "el": "Μικρά λεπτά τζιγκ πέρα από το κύμα, γρήγορο μάζεμα με παύσεις."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "6–9 cm",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Small sinking minnows.",
     "el": "Μικρά βυθιζόμενα minnow."
    }
   },
   {
    "gear": "popper",
    "weight": "7–15 g",
    "size": "6–8 cm",
    "colors": [
     "white",
     "silver"
    ],
    "note": {
     "en": "Small poppers at first light.",
     "el": "Μικρά popper με το πρώτο φως."
    }
   },
   {
    "gear": "spoon",
    "weight": "7–20 g",
    "size": "",
    "colors": [
     "silver"
    ],
    "note": {
     "en": "Simple and effective.",
     "el": "Απλό και αποδοτικό."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Sometimes: small sand-eel style paddle-tails (about 5–8 cm) on 5–10 g heads, retrieved through the wash. Small metal jigs and minnows are more usual; sources for this species are thin.",
    "el": "Μερικές φορές: μικρές σιλικόνες τύπου αμμοχέλι με ουρά-πτερύγιο (περίπου 5–8 cm) σε μολυβοκεφαλές 5–10 g, με μάζεμα μέσα στον αφρό. Τα μικρά πλάνα και τα minnow είναι πιο συνηθισμένα· οι πηγές για αυτό το είδος είναι λίγες."
   },
   "ids": [
    "soft_shad"
   ]
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not normally used in the surf.",
    "el": "Συνήθως όχι στο κύμα."
   }
  },
  "technique": {
   "en": "Walk the beach at dawn casting small jigs along and beyond the surf line; fish move in schools, so keep moving until you meet them.",
   "el": "Περπατήστε την παραλία τα χαράματα ρίχνοντας μικρά τζιγκ κατά μήκος και πέρα από το κύμα· τα ψάρια κινούνται σε κοπάδια, συνεχίστε μέχρι να τα συναντήσετε."
  },
  "where": {
   "en": "Sandy beaches with surf, and beach-rock edges; 0–10 m.",
   "el": "Αμμουδιές με κύμα και άκρες από πλάκες (beach-rock)· 0–10 m."
  },
  "when": {
   "en": "June–October; dawn before the beaches fill, and small fish at night from rocky shores.",
   "el": "Ιούνιο–Οκτώβριο· χαράματα πριν γεμίσουν οι παραλίες, και μικρά ψάρια τη νύχτα από βραχώδεις ακτές."
  },
  "handling": {
   "en": "Small sharp spines in front of the dorsal and anal fins: hold with a cloth. Keep casts far from swimmers.",
   "el": "Μικρά κοφτερά αγκαθάκια μπροστά από το ραχιαίο και το εδρικό: πιάστε με πανί. Οι ρίψεις μακριά από λουόμενους."
  },
  "eating": {
   "en": "Very good grilled.",
   "el": "Πολύ καλό ψητό."
  },
  "sources": [
   "https://www.fishbase.se/summary/Trachinotus-ovatus.html",
   "https://en.wikipedia.org/wiki/Trachinotus_ovatus",
   "https://www.decathlon.it/tutti-gli-sport/pesca-in-mare/artificiali-da-spinning-in-mare"
  ]
 },
 "swordfish": {
  "summary": {
   "en": "Swordfish: recreational and sport fishing for it is banned in Cyprus. Do not target it. This entry covers only what to do if one is hooked by accident: keep it in the water and release it alive.",
   "el": "Ξιφίας: η ερασιτεχνική και αθλητική αλιεία του απαγορεύεται στην Κύπρο. Μην τον στοχεύετε. Εδώ υπάρχει μόνο τι κάνετε αν πιαστεί κατά λάθος: τον κρατάτε στο νερό και τον απελευθερώνετε ζωντανό."
  },
  "best": [],
  "setups": {},
  "baits": [],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not applicable: no targeting.",
    "el": "Δεν ισχύει: δεν επιτρέπεται η στόχευση."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not applicable.",
    "el": "Δεν ισχύει."
   }
  },
  "technique": {
   "en": "Accidental hook-up: do not fight it to exhaustion. Bring it close quickly, keep the boat moving slowly ahead so water flows over the gills, and cut the leader as close to the hook as you can safely reach. Never gaff it, lift it or bring it aboard.",
   "el": "Αν πιαστεί κατά λάθος: μην τον κουράζετε ως την εξάντληση. Φέρτε τον γρήγορα κοντά, κρατήστε το σκάφος να προχωρά αργά ώστε να περνά νερό από τα βράγχια, και κόψτε το παράμαλλο όσο πιο κοντά στο αγκίστρι φτάνετε με ασφάλεια. Ποτέ γάντζο, ποτέ σήκωμα, ποτέ πάνω στο σκάφος."
  },
  "where": {
   "en": "Not applicable: it lives far offshore over deep water.",
   "el": "Δεν ισχύει: ζει πολύ ανοιχτά πάνω από βαθιά νερά."
  },
  "when": {
   "en": "Not applicable.",
   "el": "Δεν ισχύει."
  },
  "handling": {
   "en": "The bill is a weapon: a swordfish that thrashes alongside can injure badly. Keep hands, legs and bodies away from the bill; wear gloves only for holding the leader, never wrap it around your hand. If it is green and lively, cut the line rather than bring it close.",
   "el": "Το ξίφος είναι όπλο: ξιφίας που χτυπιέται δίπλα στο σκάφος μπορεί να τραυματίσει σοβαρά. Χέρια, πόδια και σώματα μακριά από το ξίφος· γάντια μόνο για να κρατήσετε το παράμαλλο, ποτέ τυλιγμένο στο χέρι. Αν είναι ακόμη δυνατός, κόψτε την πετονιά αντί να τον φέρετε κοντά."
  },
  "eating": {
   "en": "Not to be kept or eaten when caught recreationally in Cyprus: release it alive.",
   "el": "Δεν κρατιέται ούτε τρώγεται όταν πιαστεί ερασιτεχνικά στην Κύπρο: απελευθερώνεται ζωντανός."
  },
  "sources": [
   "https://iccat.int/com2024/Addendum/COC_301_Addendum1.pdf",
   "https://eur-lex.europa.eu/eli/reg/2019/1154/oj",
   "https://eur-lex.europa.eu/eli/reg_del/2018/191/oj",
   "https://www.fisheries.noaa.gov/species/north-atlantic-swordfish/seafood"
  ]
 }
});
