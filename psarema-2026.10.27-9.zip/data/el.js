// Greek texts for the data files (species.js, protected.js). Interface strings live in psarema.html.
window.PSAREMA_EL = {
  species: {
    sargos: 'Σαργός', tsipoura: 'Τσιπούρα', grouper: 'Ροφός', dentex: 'Συναγρίδα', amberjack: 'Μαγιάτικο',
    dolphinfish: 'Κυνηγός (Λαμπούκα)', albacore: 'Μακρύπτερος τόνος', leerfish: 'Λίτσα', barracuda: 'Λούτσος',
    parrotfish: 'Σκάρος', rabbitfish: 'Κουρκούνα', lionfish: 'Λεοντόψαρο (ξενικό)', squid: 'Καλαμάρι',
    cuttlefish: 'Σουπιά', octopus: 'Χταπόδι',
  },

  // Built from the parts of the English rules text, which uses the same few clauses for every species.
  regulations(en) {
    if (!en) return '';
    const size = en.match(/EU minimum size (\d+) cm/);
    let s = size ? `Ελάχιστο μέγεθος ΕΕ ${size[1]} cm ολικό μήκος (Καν. (ΕΕ) 2019/1241, Παράρτημα IX· ισχύει και για την ερασιτεχνική αλιεία, και με καλάμι από την ακτή). ` : '';
    if (/albacore/.test(en)) s += 'Όριο σκάφους στην Κύπρο: 3 τονάκια (μακρύπτεροι τόνοι) + 5 kg άλλων ειδών ανά σκάφος, ανά έξοδο/24 ώρες, όσοι αδειούχοι κι αν είναι πάνω (Καν. 17Β· όροι αδειών ΤΑΘΕ 2026 §20). Απαγορεύεται 1–31 Μαρτίου και 1 Οκτωβρίου–30 Νοεμβρίου (§10)· δηλώστε το σκάφος για αλιεία τόνου στην αίτηση άδειας. ';
    if (/Spearfishing:/.test(en)) s += 'Υποβρύχια αλιεία: άδεια, ηλικία 15+, μόνο με ελεύθερη κατάδυση, από την ανατολή ως τη δύση του ηλίου, χωρίς φώτα ή αναπνευστική συσκευή, όχι σε περιοχές κολύμβησης· έως 5 kg + 1 ψάρι την ημέρα. ';
    if (/Boat: licence/.test(en)) s += 'Σκάφος: άδεια· έως 10 kg, ή 5 kg + 1 ψάρι, ανά έξοδο/24 ώρες. ';
    if (/tail lobe/.test(en)) s += 'Κόβεται ο πάνω λοβός της ουράς· απαγορεύεται η πώληση.';
    return s.trim() || en;
  },

  zoneKind: { 'no-take': 'πλήρης απαγόρευση', restricted: 'περιορισμοί', protected: 'προστατευόμενη' },

  zoneName(en) {
    const fixed = this.zoneNames[en];
    if (fixed) return fixed;
    let m = en.match(/^Fish farm 100 m zone \((.*)\)$/);
    if (m) return `Ζώνη 100 m ιχθυοκαλλιέργειας (${m[1]})`;
    m = en.match(/^Seamark restricted area \((.*)\)$/);
    if (m) return `Περιορισμένη περιοχή σημαδούρας (${m[1]})`;
    return en;
  },
  zoneNames: {
    'Dasoudi (Limassol) artificial-reef MPA': 'ΘΠΠ τεχνητού υφάλου Δασουδίου (Λεμεσός)',
    'Amathounta MPA - core': 'ΘΠΠ Αμαθούντας – πυρήνας',
    'Amathounta MPA - neutral zone': 'ΘΠΠ Αμαθούντας – ουδέτερη ζώνη',
    'Larnaca artificial-reef MPA (wrecks LEF1, Elpida)': 'ΘΠΠ τεχνητού υφάλου Λάρνακας (ναυάγια LEF1, Ελπίδα)',
    'Ayia Napa artificial-reef MPA (MUSAN, Kyrenia replica wreck)': 'ΘΠΠ τεχνητού υφάλου Αγίας Νάπας (MUSAN, αντίγραφο πλοίου Κερύνειας)',
    'Cape Greco MPA - core': 'ΘΠΠ Κάβο Γκρέκο – πυρήνας',
    'Cape Greco MPA - neutral zone (north)': 'ΘΠΠ Κάβο Γκρέκο – ουδέτερη ζώνη (βόρεια)',
    'Cape Greco MPA - neutral zone (south-west)': 'ΘΠΠ Κάβο Γκρέκο – ουδέτερη ζώνη (νοτιοδυτικά)',
    'Cape Greco MPA - full reported extent': 'ΘΠΠ Κάβο Γκρέκο – πλήρης δηλωμένη έκταση',
    'Paralimni artificial-reef MPA': 'ΘΠΠ τεχνητού υφάλου Παραλιμνίου',
    'Geroskipou artificial-reef MPA (Laboe wreck)': 'ΘΠΠ τεχνητού υφάλου Γεροσκήπου (ναυάγιο Laboe)',
    'Bania (Paphos) MPA': 'ΘΠΠ Μπάνια (Πάφος)',
    'Pegeia sea caves MPA - core': 'ΘΠΠ θαλάσσιων σπηλιών Πέγειας – πυρήνας',
    'Pegeia sea caves MPA - neutral zone': 'ΘΠΠ θαλάσσιων σπηλιών Πέγειας – ουδέτερη ζώνη',
    'Pegeia sea caves MPA - full reported extent': 'ΘΠΠ θαλάσσιων σπηλιών Πέγειας – πλήρης δηλωμένη έκταση',
    'Kakoskali MPA - core': 'ΘΠΠ Κακοσκάλι – πυρήνας',
    'Kakoskali MPA - neutral zone': 'ΘΠΠ Κακοσκάλι – ουδέτερη ζώνη',
    'Chalavro (Halavro) MPA': 'ΘΠΠ Χαλαυρού',
    'Agios Georgios Alamanou MPA': 'ΘΠΠ Αγίου Γεωργίου Αλαμάνου',
    'Ayia Napa sea caves MPA': 'ΘΠΠ θαλάσσιων σπηλιών Αγίας Νάπας',
    'Larnaca desalination plant zone': 'Ζώνη μονάδας αφαλάτωσης Λάρνακας',
    'Zenobia wreck (500 m)': 'Ναυάγιο Zenobia (500 m)',
    'Lara-Toxeftra turtle reserve': 'Περιοχή προστασίας χελωνών Λάρας–Τοξεύτρας',
    'Mazotos ancient shipwreck': 'Αρχαίο ναυάγιο Μαζωτού',
    'Moulia marine area (Natura 2000 CY4000006)': 'Θαλάσσια περιοχή Μουλιά (Natura 2000 CY4000006)',
    'Nisia marine area, Ayia Napa (Natura 2000 CY3000006)': 'Θαλάσσια περιοχή Νησιά, Αγία Νάπα (Natura 2000 CY3000006)',
    'Oceanid (Natura 2000 SPA/SCI)': 'Oceanid (Natura 2000 ΖΕΠ/ΤΚΣ)',
    'Polis - Gialia (Natura 2000 SCI)': 'Πόλη – Γιαλιά (Natura 2000 ΤΚΣ)',
    'Cape Aspro - Petra tou Romiou (Natura 2000)': 'Κάβο Άσπρο – Πέτρα του Ρωμιού (Natura 2000)',
    'Akamas Peninsula (Natura 2000 SCI)': 'Χερσόνησος Ακάμα (Natura 2000 ΤΚΣ)',
    'Akamas Peninsula (Natura 2000 SPA)': 'Χερσόνησος Ακάμα (Natura 2000 ΖΕΠ)',
    'Cape Greco (Natura 2000 SCI)': 'Κάβο Γκρέκο (Natura 2000 ΤΚΣ)',
    'Cape Greco (Natura 2000 SPA)': 'Κάβο Γκρέκο (Natura 2000 ΖΕΠ)',
  },

  zoneRules: {
    'All fishing banned, including recreational (KDP 29/2021). Motor boats only in the marked transit corridor (state, sailing-club safety and flagged dive boats excepted).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 29/2021). Μηχανοκίνητα σκάφη μόνο στον σημαδεμένο διάδρομο διέλευσης (εκτός από κρατικά σκάφη, σκάφη ασφαλείας ναυτικών ομίλων και σκάφη καταδύσεων με σημαία).',
    'All fishing banned, including recreational; motor-boat passage banned except state and flagged dive boats (KDP 445/2017).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική· απαγορεύεται η διέλευση μηχανοκίνητων σκαφών, εκτός από κρατικά και σκάφη καταδύσεων με σημαία (ΚΔΠ 445/2017).',
    'All fishing banned, including recreational, except licensed small-scale coastal fishing vessels of categories A and B (KDP 445/2017).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική, εκτός από αδειούχα σκάφη παράκτιας αλιείας μικρής κλίμακας κατηγορίας Α και Β (ΚΔΠ 445/2017).',
    'All fishing banned, including recreational (KDP 124/2020). Motor boats banned within 200 m of wrecks LEF1 and Elpida (state and flagged dive boats excepted).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 124/2020). Απαγορεύονται τα μηχανοκίνητα σκάφη σε απόσταση 200 m από τα ναυάγια LEF1 και Ελπίδα (εκτός από κρατικά και σκάφη καταδύσεων με σημαία).',
    'All fishing banned, including recreational (KDP 322/2021). No boats within 150 m of the Kyrenia wreck point (state and flagged dive boats excepted).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 322/2021). Κανένα σκάφος σε απόσταση 150 m από το ναυάγιο «Κερύνεια» (εκτός από κρατικά και σκάφη καταδύσεων με σημαία).',
    'All fishing banned, including recreational (KDP 115/2018, as tagged in OSM; order text not retrieved).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 115/2018, σύμφωνα με το OpenStreetMap· το κείμενο της πράξης δεν ανακτήθηκε).',
    'All fishing banned except holders of a professional coastal fishing licence; recreational fishing banned (KDP 115/2018, as tagged in OSM; order text not retrieved).':
      'Απαγορεύεται κάθε αλιεία εκτός από κατόχους επαγγελματικής άδειας παράκτιας αλιείας· η ερασιτεχνική αλιεία απαγορεύεται (ΚΔΠ 115/2018, σύμφωνα με το OpenStreetMap· το κείμενο της πράξης δεν ανακτήθηκε).',
    'Officially reported MPA extent (EEA NatDA CY073), larger than the 2018 core/neutral zones. Rules outside those zones not confirmed: assume no recreational fishing; check with DFMR.':
      'Επίσημα δηλωμένη έκταση της ΘΠΠ (ΕΟΠ NatDA CY073), μεγαλύτερη από τις ζώνες πυρήνα και τις ουδέτερες ζώνες του 2018. Οι κανόνες εκτός αυτών των ζωνών δεν επιβεβαιώθηκαν: θεωρήστε ότι η ερασιτεχνική αλιεία απαγορεύεται· ρωτήστε το ΤΑΘΕ.',
    'All fishing banned, including recreational (KDP 404/2017).': 'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 404/2017).',
    'All fishing banned, including recreational (KDP 489/2014). Boats banned within 150 m of the Laboe wreck point except for mooring.':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 489/2014). Απαγορεύονται τα σκάφη σε απόσταση 150 m από το ναυάγιο Laboe, εκτός για πρόσδεση.',
    'All fishing banned, including recreational (KDP 66/2017).': 'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 66/2017).',
    'All fishing banned, including rod fishing from the shore; boat passage and anchoring banned (KDP 98/2025).':
      'Απαγορεύεται κάθε αλιεία, και με καλάμι από την ακτή· απαγορεύονται η διέλευση και η αγκυροβολία σκαφών (ΚΔΠ 98/2025).',
    'All fishing banned, including rod fishing from the shore, except holders of a professional coastal fishing licence; boat passage and anchoring banned (KDP 98/2025).':
      'Απαγορεύεται κάθε αλιεία, και με καλάμι από την ακτή, εκτός από κατόχους επαγγελματικής άδειας παράκτιας αλιείας· απαγορεύονται η διέλευση και η αγκυροβολία σκαφών (ΚΔΠ 98/2025).',
    'Whole MPA (EEA NatDA CY079): all fishing banned except licensed professional coastal fishers in the neutral zone; no boats or anchoring (KDP 98/2025).':
      'Ολόκληρη η ΘΠΠ (ΕΟΠ NatDA CY079): απαγορεύεται κάθε αλιεία, εκτός από αδειούχους επαγγελματίες παράκτιους αλιείς στην ουδέτερη ζώνη· χωρίς σκάφη ή αγκυροβολία (ΚΔΠ 98/2025).',
    'All fishing banned, including recreational (KDP 258/2019).': 'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική (ΚΔΠ 258/2019).',
    'All fishing banned, including recreational, except holders of a professional coastal fishing licence (KDP 258/2019).':
      'Απαγορεύεται κάθε αλιεία, και η ερασιτεχνική, εκτός από κατόχους επαγγελματικής άδειας παράκτιας αλιείας (ΚΔΠ 258/2019).',
    'All fishing banned, including rod fishing from the shore; all boat passage banned (KDP 91/2023).':
      'Απαγορεύεται κάθε αλιεία, και με καλάμι από την ακτή· απαγορεύεται κάθε διέλευση σκαφών (ΚΔΠ 91/2023).',
    'All fishing banned, including rod fishing from the shore; boat passage and anchoring banned (KDP 47/2023). Shore to 5 m depth.':
      'Απαγορεύεται κάθε αλιεία, και με καλάμι από την ακτή· απαγορεύονται η διέλευση και η αγκυροβολία σκαφών (ΚΔΠ 47/2023). Από την ακτή ως βάθος 5 m.',
    'All fishing banned, including rod fishing from the shore (KDP 46/2023). Boat passage and anchoring banned 1 Nov-30 Apr.':
      'Απαγορεύεται κάθε αλιεία, και με καλάμι από την ακτή (ΚΔΠ 46/2023). Η διέλευση και η αγκυροβολία σκαφών απαγορεύονται από 1 Νοεμβρίου ως 30 Απριλίου.',
    'All fishing banned (KDP 379/2021).': 'Απαγορεύεται κάθε αλιεία (ΚΔΠ 379/2021).',
    "All fishing banned within 500 m of the wreck point 34°53.830'N 33°39.450'E (KDP 379/2021).":
      "Απαγορεύεται κάθε αλιεία σε ακτίνα 500 m από το σημείο του ναυαγίου 34°53.830'N 33°39.450'E (ΚΔΠ 379/2021).",
    '1 Jun-30 Sep: no boat passage or anchoring and no fishing of any kind except from the shore. May and Oct: boat passage banned (licensed small-scale coastal fishers excepted). Rules from OSM tags (Fisheries Regulations); confirm with DFMR.':
      '1 Ιουνίου – 30 Σεπτεμβρίου: απαγορεύονται η διέλευση και η αγκυροβολία σκαφών και κάθε είδους αλιεία εκτός από την ακτή. Μάιο και Οκτώβριο: απαγορεύεται η διέλευση σκαφών (εκτός από αδειούχους παράκτιους αλιείς μικρής κλίμακας). Κανόνες από ετικέτες του OpenStreetMap (Περί Αλιείας Κανονισμοί)· επιβεβαιώστε με το ΤΑΘΕ.',
    'All fishing banned (OSM tag citing Antiquities Law Cap. 31 s.18C and KDP 237/2019; not verified).':
      'Απαγορεύεται κάθε αλιεία (ετικέτα του OpenStreetMap που παραπέμπει στον Περί Αρχαιοτήτων Νόμο Κεφ. 31, άρθρο 18Γ, και στην ΚΔΠ 237/2019· δεν επαληθεύτηκε).',
    'Within 100 m of fish-farm installations: no spearfishing, no fishing with lights or compressed air, no nets, longlines, handlines or any hook gear (KDP 533/2002 reg. 14). Farm outline from OSM + 100 m.':
      'Σε απόσταση 100 m από εγκαταστάσεις ιχθυοκαλλιέργειας: απαγορεύονται η υποβρύχια αλιεία, η αλιεία με φώτα ή πεπιεσμένο αέρα, τα δίχτυα, τα παραγάδια, οι πετονιές και κάθε εργαλείο με αγκίστρι (ΚΔΠ 533/2002, κανονισμός 14). Περίγραμμα μονάδας από το OpenStreetMap + 100 m.',
    'OpenStreetMap seamark: no fishing and no anchoring. Legal basis not stated in OSM; check with DFMR.':
      'Σήμανση OpenStreetMap: απαγορεύονται η αλιεία και η αγκυροβολία. Η νομική βάση δεν αναφέρεται· ρωτήστε το ΤΑΘΕ.',
    'Trawling and coastal fishing methods (as defined in the Fisheries Law) banned; anchoring banned except within 200 m of two set points (KDP 264/2025). Recreational fishing not addressed; check with DFMR.':
      'Απαγορεύονται η τράτα και οι μέθοδοι παράκτιας αλιείας (όπως ορίζονται στον Περί Αλιείας Νόμο)· η αγκυροβολία απαγορεύεται, εκτός σε ακτίνα 200 m από δύο καθορισμένα σημεία (ΚΔΠ 264/2025). Η ερασιτεχνική αλιεία δεν ρυθμίζεται ρητά· ρωτήστε το ΤΑΘΕ.',
    'Trawling and coastal fishing methods (as defined in the Fisheries Law) banned; anchoring banned at 15-40 m depth (KDP 263/2025). Recreational fishing not addressed; check with DFMR.':
      'Απαγορεύονται η τράτα και οι μέθοδοι παράκτιας αλιείας (όπως ορίζονται στον Περί Αλιείας Νόμο)· απαγορεύεται η αγκυροβολία σε βάθος 15–40 m (ΚΔΠ 263/2025). Η ερασιτεχνική αλιεία δεν ρυθμίζεται ρητά· ρωτήστε το ΤΑΘΕ.',
    'Natura 2000 site; no fishing ban confirmed. Fishing rules not confirmed; check with DFMR.':
      'Περιοχή Natura 2000· δεν επιβεβαιώθηκε απαγόρευση αλιείας. Ρωτήστε το ΤΑΘΕ για τους κανόνες.',
    'Special Environmental Protection Area (northern Cyprus). Fishing rules not confirmed; outside DFMR control, check with local authorities.':
      'Ειδική Περιοχή Περιβαλλοντικής Προστασίας (βόρεια Κύπρος). Οι κανόνες αλιείας δεν επιβεβαιώθηκαν· εκτός ελέγχου του ΤΑΘΕ.',
  },
};
