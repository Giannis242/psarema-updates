'use strict';
// Psarema: the Leaflet map, its layers and the score image.
Object.assign(I18N.en, { hl_weak: s => `Best now: ${s}, a weak hour`, 
  hlRel: 'Each fish is coloured over its own scores for the hour shown, from the lowest shown to its best, so its best water always stands out. The numbers are the real scores.' });
Object.assign(I18N.el, { hl_weak: s => `Καλύτερο τώρα: ${s}, αδύναμη ώρα`, 
  hlRel: 'Κάθε ψάρι χρωματίζεται στο δικό του εύρος για την ώρα που φαίνεται, από τη χαμηλότερη βαθμολογία ως την καλύτερη, ώστε τα καλύτερα νερά του να ξεχωρίζουν πάντα. Οι αριθμοί είναι οι πραγματικές βαθμολογίες.' });
console.assert(HEAT.every(([s, c]) => getComputedStyle(document.documentElement).getPropertyValue('--heat-' + s).trim() === `rgb(${c.slice(0, 3).join(' ')})`), 'css/tokens.css --heat-* match core.js HEAT');
/* ---------- Map ---------- */
const map = L.map('map', { preferCanvas: true, zoomControl: false, maxBounds: L.latLngBounds(VIEW).pad(.25), maxBoundsViscosity: 1, zoomSnap: .5, maxZoom: 17,
  bounceAtZoomLimits: false }).setView([35.05, 33.3], 9);
// Round 11 (the owner: zooming out past the island "shows the rest of the countries for a split second"): nothing past the allowed view at any
// moment. A pinch stops at the floor (bounceAtZoomLimits) and keeps its centre inside maxBounds (Leaflet's pinch ignores them until it ends);
// a fling glides to the bounds instead of past them and back; the imagery is clipped to the mask's box (PaddedTiles), and past the mask's
// drawn extent the map's own ground is the mask's colour (css/map-fx.css): whatever a gesture uncovers is the same dark sea.
{
  const move = map._move, anim = map._animateZoom, panBy = map.panBy; // ponytail: Leaflet 1.9.4 internals, as PaddedTiles
  map._move = function (c, z, d, s) { if (d?.pinch && this.options.maxBounds) c = this._limitCenter(L.latLng(c), z, this.options.maxBounds); return move.call(this, c, z, d, s); };
  map._animateZoom = function (c, z, ...a) { if (this.options.maxBounds) c = this._limitCenter(L.latLng(c), z, this.options.maxBounds); return anim.call(this, c, z, ...a); }; // a pinch's own end
  map.panBy = function (off, o) {
    const mb = this.options.maxBounds; if (!mb || !this._loaded) return panBy.call(this, off, o);
    const z = this.getZoom(), c = this.project(this.getCenter(), z), to = this._limitCenter(this.unproject(c.add(L.point(off)), z), z, mb);
    return panBy.call(this, this.project(to, z).subtract(c), o);
  };
}
let fitted = false;
const COAST = [[34.56, 32.27], [35.71, 34.61]]; // the island itself (data/coast.js): phones fit it, as VIEW's sea margins cost a small screen too much
function fitView() {
  const phone = isPhone(), s = map.getSize(), pad = phone && (window.PsMobile?.fitPad() || s.x < s.y && [[0, 70], [0, 190]]), b = phone ? COAST : VIEW;
  if (phone && !pad) return; // before js/mobile.js a phone on its side waits for it: the portrait guess gave zoom 6.5, wider than maxBounds, and the map slid 200 px before the real fit
  const [tl, br] = !phone ? [[350, 60], [10, 10]] // the coast clear of the panel
    : pad.map(p => L.point(p).add([8, 8])); // phones: between the top bar and the sheet (js/mobile.js), 8 px clear
  const room = s.subtract(L.point(tl).add(br));
  if (room.x < 50 || room.y < 50) return; // no size yet (a page opened in a hidden tab), or the phone layout not in place yet: a later call fits
  const whole = !fitted || map.getZoom() <= map.getMinZoom(); // first fit, or still showing the whole island
  if (map._panAnim?._inProgress) { // a rotation's pan back inside the new maxBounds (js/mobile.js)
    if (!whole) { map.once('moveend', () => requestAnimationFrame(fitView)); return; } // a new floor's zoom would cut it short: after it
    // the fit replaces it (waiting showed a 250 ms slide, then a jump); its last 'moveend' must not start it again
    map.off('moveend', map._panInsideMaxBounds); map._panAnim.stop(); map.on('moveend', map._panInsideMaxBounds);
  }
  fitted = true;
  map.options.minZoom = 0; // getBoundsZoom never answers below the current floor: without this the floor could only rise (turned on its side, a phone kept the portrait zoom)
  const z = map.getBoundsZoom(b, false, L.point(tl).add(br)); // after a rotation or resize the floor follows the new size
  if (whole) map.fitBounds(b, { paddingTopLeft: tl, paddingBottomRight: br, animate: false });
  map.setMinZoom(z); // after the fit: raised first, it starts an animated zoom that swallows the fit
}
fitView();
map.on('resize', () => requestAnimationFrame(fitView)); // a frame later: js/mobile.js re-measures its sheet after a rotation in the same frame
addEventListener('DOMContentLoaded', fitView); // again once js/mobile.js has measured the sheet: the map may not change size when it does
new ResizeObserver(() => map.invalidateSize()).observe(map.getContainer()); // a map that starts hidden or unsized fits once it has a size
const zoomCtl = L.control.zoom({ position: 'bottomright' }).addTo(map);
{ // no "Leaflet" link; the data credits (a licence condition) fold into a small (i) button that opens on tap
  map.attributionControl.setPrefix(false);
  const a = map.attributionControl.getContainer(); a.classList.add('folded'); a.title = tr('credits');
  L.DomEvent.on(a, 'click', e => { if (a.classList.contains('folded')) L.DomEvent.preventDefault(e); a.classList.toggle('folded'); });
}
const LocateCtl = L.Control.extend({ options: { position: 'bottomright' }, onAdd() {
  const box = L.DomUtil.create('div', 'leaflet-bar locate'), a = L.DomUtil.create('a', '', box);
  a.href = '#'; a.innerHTML = ic('my-location') || '◎'; a.setAttribute('role', 'button');
  L.DomEvent.on(a, 'click', e => { L.DomEvent.preventDefault(e); L.DomEvent.stopPropagation(e); locateMe(); });
  this._a = a; return box;
} });
const locateCtl = new LocateCtl().addTo(map);
// Follow me (round 9): a second tap on a locate button (ui.js locateMe) keeps the dot in the middle as fixes come in (ui.js onFix → fix);
// a drag, or anything else moving the map away from you (a spot opened), stops it. Pinch and wheel zoom about the middle meanwhile.
// Every locate button ([data-ui="locate"], the map's own) says so: aria-pressed and the class "following" (css/map-fx.css).
const PsFollow = window.PsFollow = (() => {
  let on = false, at = null, own = 0;
  const btns = () => [locateCtl._a, ...document.querySelectorAll('[data-ui="locate"]')];
  function set(v) {
    if (on === !!v) return; on = !!v;
    map.options.touchZoom = map.options.scrollWheelZoom = on ? 'center' : true;
    for (const b of btns()) { b.classList.toggle('following', on); b.setAttribute('aria-pressed', on); }
    map.getContainer().classList.toggle('ps-following', on);
    document.dispatchEvent(new CustomEvent('ps:follow', { detail: on }));
    if (on && at) fix(at);
  }
  function fix(ll) { at = L.latLng(ll); if (!on) return; own++; map.panTo(at, { animate: true, duration: .4 }); map.once('moveend', () => own--); }
  map.on('dragstart', () => set(false));
  map.on('moveend', () => { if (on && !own && at && map.latLngToContainerPoint(at).distanceTo(map.getSize().divideBy(2)) > 40) set(false); });
  const tap = ll => { fix(ll); if (!map.getBounds().pad(-.1).contains(at)) return false; set(true); return true; }; // a locate tap: with you on screen, follow (else the caller flies to you)
  return { set, fix, tap, get on() { return on; } };
})();
// Leaflet keeps each pane's canvas once made, empty or not: each is a GPU layer 1.2× the screen (2× pixels on phones), re-sized, cleared
// and composited at every move. One goes once its last shape does (contours and spots below their zoom, zones, a cleared ring);
// map.getRenderer puts it back with the next shape. A frame later: a clear-and-redraw keeps its canvas, and the redraw a removal asks for
// has run (Leaflet 1.9.4 leaves it pending after a moveend's own redraw: removed sooner, the renderer drew with no canvas, a TypeError).
map.on('layerremove', ({ layer: { _renderer: r } }) => {
  if (!r || r._dropCheck) return;
  r._dropCheck = requestAnimationFrame(() => {
    r._dropCheck = 0;
    if (!map.hasLayer(r) || Object.keys(r._layers).length) return;
    map.removeLayer(r); r._redrawRequest = null; // Leaflet cancels that frame but keeps its id: back on the map, the renderer never asked for another
  });
});
for (const [name, z] of [['heat', 410], ['zones', 415], ['contours', 420], ['prot', 425], ['sight', 428], ['spots', 430], ['labels', 640], ['mask', 650]]) map.createPane(name).style.zIndex = z;
for (const p of ['labels', 'mask', 'zones']) map.getPane(p).style.pointerEvents = 'none';
// Tiles load half a screen beyond the view, so dragging uncovers imagery that is already there.
// Round 11 (the owner: "make the map load better when I zoom in and out"): an animated zoom of more than a level made Leaflet 1.9.4 reset
// each layer to the old level at its start and prune it to the few tiles under the new view (40% of the screen blank for a frame zooming
// in), and zooming out it asked for nothing wider until the end (the old tiles shrank into a dark ring). During the animation each layer
// now works at the zoom it goes to: the new level's tiles for the whole new view are asked for at once, the old level stays until they are in.
const MASK_BOX = L.latLngBounds(VIEW).pad(.04); // what the dark mask leaves clear (below)
const PaddedTiles = L.TileLayer.extend({
  createTile(c, done) { // a tile across the mask's box shows only its part inside (zoomed out, the stored tiles reach the neighbours' coasts)
    const el = L.TileLayer.prototype.createTile.call(this, c, done), m = this._map, [nw, se] = this._tileCoordsToNwSe(c);
    const p0 = m.project(nw, c.z), p1 = m.project(se, c.z), q0 = m.project(MASK_BOX.getNorthWest(), c.z), q1 = m.project(MASK_BOX.getSouthEast(), c.z);
    const w = p1.x - p0.x, h = p1.y - p0.y, f = v => (Math.max(0, v) * 100).toFixed(2) + '%';
    const ins = [(q0.y - p0.y) / h, (p1.x - q1.x) / w, (p1.y - q1.y) / h, (q0.x - p0.x) / w];
    if (ins.some(v => v > 0)) el.style.clipPath = `inset(${ins.map(f).join(' ')})`;
    return el;
  },
  _getTiledPixelBounds(center) { const b = L.TileLayer.prototype._getTiledPixelBounds.call(this, center), pad = b.getSize().divideBy(2); return L.bounds(b.min.subtract(pad), b.max.add(pad)); },
  _update(center) {
    const m = this._map; if (!m?._animatingZoom) return L.TileLayer.prototype._update.call(this, center);
    const z = m._zoom; m._zoom = m._animateToZoom; // ponytail: Leaflet 1.9.4 internals (as js/chart.js HalfGrid); recheck on a Leaflet upgrade
    try { return L.TileLayer.prototype._update.call(this, center); } finally { m._zoom = z; }
  },
});
const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/', TILE_BOUNDS = L.latLngBounds(VIEW).pad(.1); // TILE_BOUNDS: js/app.js's prefetch (no stored tiles)
const DATA_ATTR = 'EMODnet &middot; Copernicus Marine &middot; <a href="https://open-meteo.com/">Open-Meteo</a> &middot; GBIF/OBIS &middot; &copy; OpenStreetMap';
const tileOpts = { maxZoom: 17, maxNativeZoom: 17, bounds: TILE_BOUNDS, keepBuffer: 6, updateWhenIdle: false, updateWhenZooming: false };
const LOCAL_TILES = window.PSAREMA_TILES, BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACw=';
const imagery = L.layerGroup().addTo(map); // the Satellite map style; js/chart.js swaps it for the Depth chart
if (LOCAL_TILES) { // the island's imagery is stored with the app, so it is there at once; sharper online imagery only beyond it
  // Padded too: zooming out, the old level's margin covers the wider view (and the online layer dropping out) until the new tiles arrive, instead of a dark ring.
  // The minZooms sit half a step early: Leaflet picks tiles at the rounded zoom but drops them all below minZoom, so with an integer floor
  // the half step under it (zoomSnap .5) fetched the layer's tiles and threw them away on every move: flashing squares, ~50 requests a pan.
  const full = LOCAL_TILES.coastalOnlyFrom ? LOCAL_TILES.coastalOnlyFrom - 1 : LOCAL_TILES.maxZoom;
  // Their bounds are the stored area's (tiles.js): TILE_BOUNDS reaches past it, and the ring of tiles in between were 404s.
  new PaddedTiles(LOCAL_TILES.url, { maxZoom: 17, minNativeZoom: LOCAL_TILES.minZoom, maxNativeZoom: full, bounds: LOCAL_TILES.bounds, keepBuffer: 10, updateWhenIdle: false,
    errorTileUrl: BLANK, attribution: `${LOCAL_TILES.attribution} &middot; ${DATA_ATTR}` }).addTo(imagery);
  if (LOCAL_TILES.coastalOnlyFrom) new PaddedTiles(LOCAL_TILES.url, { minZoom: LOCAL_TILES.coastalOnlyFrom - .5, maxZoom: 17, minNativeZoom: LOCAL_TILES.coastalOnlyFrom,
    maxNativeZoom: LOCAL_TILES.maxZoom, bounds: LOCAL_TILES.bounds, keepBuffer: 10, updateWhenIdle: false, errorTileUrl: BLANK }).addTo(imagery);
  new PaddedTiles(ESRI + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', { ...tileOpts, minZoom: LOCAL_TILES.maxZoom + .5, attribution: 'Esri, Maxar, Earthstar Geographics' }).addTo(imagery);
} else new PaddedTiles(ESRI + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', { ...tileOpts, attribution: `Imagery &copy; Esri, Maxar, Earthstar Geographics &middot; ${DATA_ATTR}` }).addTo(imagery);
// Place names: js/map-marks.js draws our own (offline, in the app's language); Esri's reference labels (Greek and Latin twice, online only) are gone.
const labels = null;
// Preload: once the map rests, the next zoom level in and out of what is on screen goes into the browser's cache, so a pinch or a
// double tap shows imagery at once instead of blank squares. Each tile is asked for once; idle time only, and not when offline.
{
  const asked = new Set(); let t = 0;
  const preload = () => {
    if (navigator.onLine === false) return;
    const z = map.getZoom(), v = map.getPixelBounds();
    map.eachLayer(l => {
      // online layers only: the stored tiles are there at once (padded, they also cover a zoom out), so asking scoreAhead only cost requests
      if (!(l instanceof L.TileLayer) || !l._url || l._url === LOCAL_TILES?.url || !l.options.bounds) return;
      const o = l.options, lb = L.latLngBounds(o.bounds), tb = L.bounds(map.project(lb.getNorthWest(), z), map.project(lb.getSouthEast(), z));
      // only the view inside the layer's bounds, as Leaflet asks: beyond them were 404s (local) and labels under the mask, 7× the tiles on screen at startup
      const x0 = Math.max(v.min.x, tb.min.x), y0 = Math.max(v.min.y, tb.min.y), x1 = Math.min(v.max.x, tb.max.x), y1 = Math.min(v.max.y, tb.max.y);
      if (x0 > x1 || y0 > y1) return;
      for (const dz of [1, -1]) {
        const z2 = Math.round(z) + dz; if (z2 < (o.minZoom ?? 0) || z2 > o.maxZoom) continue;
        const nz = Math.max(o.minNativeZoom ?? 0, Math.min(o.maxNativeZoom ?? z2, z2)), s = map.getZoomScale(nz, z) / 256; // the zoom its tiles exist at
        for (let x = Math.floor(x0 * s); x <= Math.floor(x1 * s); x++) for (let y = Math.floor(y0 * s); y <= Math.floor(y1 * s); y++) {
          const url = L.Util.template(l._url, { ...o, x, y, z: nz }); if (asked.has(url)) continue;
          asked.add(url); new Image().src = url;
        }
      }
    });
  };
  map.on('moveend', () => { clearTimeout(t); t = setTimeout(() => (window.requestIdleCallback || setTimeout)(preload), 600); });
}
{ // everything outside the island's waters (e.g. the mainland on large low-zoom tiles) goes dark
  const v = MASK_BOX, [s, w, n, e] = [v.getSouth(), v.getWest(), v.getNorth(), v.getEast()];
  // SVG, not canvas: a flat fill around a rectangle draws as solid-colour and empty tiles that need no GPU memory, where a canvas
  // was one more full-screen texture (2× pixels on phones) blended at every frame
  // Its colour is css/map-fx.css's --mask (the graded open sea), over the fill given here and the one js/mobile.js sets on phones
  L.polygon([[[20, 20], [20, 50], [50, 50], [50, 20]], [[s, w], [n, w], [n, e], [s, e]]], { pane: 'mask', renderer: L.svg({ pane: 'mask' }), interactive: false, stroke: false, fillColor: '#05080b', fillOpacity: 1, className: 'ps-mask' }).addTo(map);
  // Its edge, and the heat's at the grid's (just inside), fade into it over ~6% of the box: the chart sinks into the sea instead of ending
  // in a hard rectangle (a phone shows all four sides at the start). Static vector, drawn with the mask; 6% keeps Cape Andreas clear.
  const fade = (id, v) => `<linearGradient id="${id}"${v ? ' x2="0" y2="1"' : ''}>${[[0, 1], [.3, .72], [.6, .3], [1, 0]].map(([o, a]) => `<stop offset="${o}" style="stop-color:var(--mask,#05080b)" stop-opacity="${a}"/>`).join('')}</linearGradient>`;
  const svg = L.SVG.create('svg'); svg.setAttribute('viewBox', '0 0 100 100'); svg.setAttribute('preserveAspectRatio', 'none');
  svg.innerHTML = `<defs>${fade('fe-x')}${fade('fe-y', 1)}</defs><g fill="url(#fe-x)"><rect width="6" height="100"/><rect width="6" height="100" transform="matrix(-1 0 0 1 100 0)"/></g>` +
    `<g fill="url(#fe-y)"><rect width="100" height="8"/><rect width="100" height="8" transform="matrix(1 0 0 -1 0 100)"/></g>`;
  L.svgOverlay(svg, v, { pane: 'mask', interactive: false }).addTo(map);
}
// Round 11: the heat (softCells, paintFine) and the depth chart (js/chart.js) also fade out over the grid's last 4 km themselves, so where
// the grid's edge shows inside the mask's box (the west) they end in open sea, not in a hard line.
const FADE_C = 16, edgeF = (k, n) => Math.min(1, (k + .5) / FADE_C, (n - k - .5) / FADE_C);
const EFX = Float32Array.from({ length: W }, (_, x) => edgeF(x, W)), EFY = Float32Array.from({ length: H }, (_, y) => edgeF(y, H));
// The heat image: two layers in one box (L.SVGOverlay places any element over the bounds, as an image overlay does), repainted in place
// (paint), so a settled change cross-fades from the old picture to the new (css/map-fx.css) and scrubbing swaps at once. Each layer is a
// coarse canvas (the whole grid: a pixel a cell, zoomed out one per d×d cells: softCells, boxDown), zoomed in a fine one over the view (paintFine), and the
// chance lines at 50 / 65 / 80 over the view at the screen's own resolution (drawIso). All three sit inside the shoreline clip.
// willReadFrequently keeps them plain (CPU) canvases, drawn like images: a GPU canvas is a texture layer of its own, and the shoreline
// clip-path on it then became a mask and an offscreen pass every frame anything on screen hourMoved. Here the clip is drawn in once per zoom.
const heatBox = L.DomUtil.create('div', 'heat-box');
const heatLayers = [0, 1].map(n => {
  const el = L.DomUtil.create('div', 'heat-layer', heatBox), [c, fine, iso] = [0, 1, 2].map(() => L.DomUtil.create('canvas', '', el));
  el.style.cssText = 'position:absolute;inset:0' + (n ? ';visibility:hidden' : ''); // layout inline, so it needs no stylesheet
  for (const e of [c, fine, iso]) e.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%';
  c.width = W; c.height = H; fine.style.display = iso.style.display = 'none';
  const ctx = e => e.getContext('2d', { willReadFrequently: true });
  return { el, ctx: ctx(c), fine, fctx: ctx(fine), iso, ictx: ctx(iso), cut: null, isoAt: null };
});
let liveLayer = 0; // the layer on show
const heat = L.svgOverlay(heatBox, GRID_BOUNDS, { pane: 'heat', interactive: false });
// The clip below trims the heat at the water's edge (and the north's line): the spread (zoomed out) may then run onto the land, and over the line
const CLIP = !!window.PSAREMA_COAST, NCLIP = CLIP && !!NORTH_AREA?.outline;
if (CLIP) { // clip the heat at the real shoreline (data/coast.js): 250 m cells would otherwise spill onto beaches and rocks
  const m = d => Math.log(Math.tan(Math.PI / 4 + d * Math.PI / 360)), mN = m(NORTH), mS = m(NORTH - H * RES); // the image is stretched in Mercator
  const fx = lo => ((lo - WEST) / (W * RES)).toFixed(5), fy = la => ((mN - m(la)) / (mN - mS)).toFixed(5);
  let d = 'M0 0H1V1H0Z', n = d; // the sea = the whole image minus every land ring (even-odd); n: minus the north's area, which has no data
  for (const r of PSAREMA_COAST) { d += 'M'; for (let k = 0; k < r.length; k += 2) d += `${k ? 'L' : ''}${fx(r[k + 1])} ${fy(r[k])}`; d += 'Z'; }
  for (const r of NORTH_AREA?.outline || []) n += 'M' + r.map(([la, lo]) => `${fx(lo)} ${fy(la)}`).join('L') + 'Z';
  // The north's line too, so the heat (spread over it zoomed out: NCLIP) ends there crisply: the clip of a clip is their intersection
  document.body.insertAdjacentHTML('beforeend', `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><clipPath id="south-clip" clipPathUnits="objectBoundingBox"><path clip-rule="evenodd" d="${n}"/></clipPath>` +
    `<clipPath id="sea-clip" clipPathUnits="objectBoundingBox"${NCLIP ? ' clip-path="url(#south-clip)"' : ''}><path id="sea-path" clip-rule="evenodd" d="${d}"/></clipPath>` +
    `<clipPath id="coast-clip" clipPathUnits="objectBoundingBox"><use href="#sea-path"/></clipPath></svg>`); // the shore alone, the north's waters too (js/chart.js seabed relief)
  heat.on('add', () => { heat.getElement().style.clipPath = 'url(#sea-clip)'; });
}
const pins = L.layerGroup(), zones = L.layerGroup(); // zones: the chance lines' switch (ui.js LAYER_OBJ); the lines themselves are drawn in the heat (drawIso)
const spotRenderer = L.canvas({ pane: 'spots', tolerance: 4 }), sightLayer = L.layerGroup(), sightRenderer = L.canvas({ pane: 'sight' });
const spotLayers = { fishing: L.layerGroup(), structure: L.layerGroup(), access: L.layerGroup(), beach: L.layerGroup() };
const px = new Uint8ClampedArray(N * 4), px32 = new Uint32Array(px.buffer), heatData = new ImageData(px, W, H); // the heat image: RGBA, rows top-down (heatData shares px)

for (const s of SPOTS) {
  const [name, t, la, lo] = s, g = SPOT_GROUP[t]; if (!g) continue;
  L.circleMarker([la, lo], { renderer: spotRenderer, radius: g === 'fishing' ? 4.5 : g === 'beach' ? 3 : 3.5, weight: 1, color: '#05080b',
    fillColor: GROUP_COLOR[g], fillOpacity: g === 'beach' ? .75 : .95, bubblingMouseEvents: false })
    .bindTooltip(() => esc(name || tr('spot')[t]), { direction: 'top', offset: [0, -4] })
    .on('click', () => openSpot(s))
    .addTo(spotLayers[g]);
}
for (const g in spotCount) $('#n-' + g).textContent = spotCount[g].toLocaleString();

const protLayer = L.layerGroup();
let protCount = 0;
for (const z of PROT?.zones || []) {
  const r0 = z.rings[0], c = r0.reduce((a, p) => [a[0] + p[0] / r0.length, a[1] + p[1] / r0.length], [0, 0]);
  if (inNorth(...c)) continue; // the north has no data
  protCount++;
  const [weight, opacity, fillOpacity] = { 'no-take': [1.6, .95, .42], restricted: [1.3, .8, .22] }[z.kind] || [1, .5, 0]; // white dashes on darkened water, unlike the warm best-area outlines
  L.polygon(z.rings, { pane: 'prot', color: '#fff', weight, opacity, dashArray: '5 4', fillColor: '#000', fillOpacity })
    .bindTooltip(() => `<b>${esc(zoneName(z))}</b><br>${esc(tr('kind')[z.kind])}: ${esc(zoneRules(z))}`, { sticky: true }).addTo(protLayer);
}
$('#n-protected').textContent = PROT ? String(protCount) : '–';

// Each fish's markers are made once (All fish: ~1,500, ~12 ms) and kept; a method change leaves the set on the map as it is.
const sightSets = new Map(); let sightOn = null;
function drawSightings() { // recorded sightings of the selected fish; All fish: every fish's, drawn lighter
  if (sightOn === sp.id) return;
  sightLayer.clearLayers(); sightOn = sp.id;
  let set = sightSets.get(sp.id);
  if (!set) {
    const all = !!sp.all, pts = [];
    for (const id of all ? Object.keys(SIGHT) : [sp.id]) { const s = all ? byId(id) : sp; if (s) for (const r of SIGHT[id] || []) if (!inNorth(r[0], r[1])) pts.push([r, s]); }
    sightSets.set(sp.id, set = pts.map(([[la, lo, yr], s]) => L.circleMarker([la, lo], { renderer: sightRenderer, pane: 'sight', radius: all ? 2 : 3, stroke: !all, weight: 1,
      color: '#05080b', fillColor: '#5ee0b0', fillOpacity: all ? .55 : .9 }).bindTooltip(() => `${esc(fishName(s))}${yr ? ` · ${yr}` : ''}`, { direction: 'top' })));
  }
  $('#n-sightings').textContent = window.PSAREMA_SIGHTINGS ? String(set.length) : '–';
  for (const m of set) sightLayer.addLayer(m);
}

let contours = null;
function buildContours() { contours = window.PsChart?.lines || null; } // Depth lines: the depth chart's lines and numbers over the satellite (js/chart.js)

/* ---------- Rendering ---------- */
const LUT = new Uint8ClampedArray(101 * 4), LUT32 = new Uint32Array(LUT.buffer); // LUT32: the same bytes, one pixel per entry
// Contour bands (a layer option): each score drawn in its 10-point band's middle colour (40–49 as 45), so the chance reads as iso-bands
const BAND = Uint8Array.from({ length: 101 }, (_, s) => Math.min(100, s - s % 10 + 5)), LUTB = new Uint8ClampedArray(101 * 4), LUTB32 = new Uint32Array(LUTB.buffer);
const ON = new Uint8Array(101); // 1 where a score shows (paintFine interpolates between those only)
// Round 9: each fish is coloured over its own range for the hour on the map, so a fish whose best is poor still shows WHERE it is best: the
// ramp (core.js HEAT, one for the whole app) runs from the lowest score shown (Hide below, or the best minus 55) to the hour's best (rangeHi,
// workHour). Every number stays the real score (pins, the tap card, the legend's ends), and Hide below cuts on real scores. A fish whose best
// is 95 is drawn as the dials colour it; weaker ones are stretched, and the legend says so ("40 … 49").
// Hide below hides real scores, except a fish's best 25 points of the hour: dusky grouper at its best 52 had 462 of its 23,649 cells at 40+,
// a few specks; its best 25 points draw where it is best ("27 … 52", and a note under the legend).
let rangeHi = 95;
const rangeCut = () => Math.min(state.min, Math.max(1, rangeHi - 25)); // scores under this are not drawn
const rangeLo = () => Math.max(rangeCut(), rangeHi - 55, 1);
const rel = s => { const lo = rangeLo(), t = s < lo ? 40 + s - lo : 40 + (s - lo) * 55 / Math.max(rangeHi - lo, 1); return t < 0 ? 0 : t > 100 ? 100 : t; };
const mapRgba = s => heatRgba(rel(s));
const tint = v => `rgb(${mapRgba(v).slice(0, 3).map(c => c + (255 - c) * .55 | 0)})`; // a chance line's colour: its score's, lighter than the water around it
const absTint = v => `rgb(${heatRgba(v).slice(0, 3).map(c => c + (255 - c) * .3 | 0)})`; // a real score's own colour (the legend's numbers, as the dials)
function buildLut() {
  const cut = rangeCut();
  for (let s = 0; s <= 100; s++) LUT.set(s < cut || !s ? [0, 0, 0, 0] : mapRgba(s), s * 4);
  for (let s = 0; s <= 100; s++) { LUTB32[s] = s < cut || !s ? 0 : LUT32[BAND[s]]; ON[s] = LUT[s * 4 + 3] ? 1 : 0; }
  drawLegend();
}
console.assert((() => { const h = rangeHi, m = state.min; rangeHi = 95; state.min = 40; const ok = rel(40) === 40 && rel(95) === 95; rangeHi = 49; const ok2 = rel(49) === 95 && rel(24) === 40 && rangeCut() === 24; rangeHi = h; state.min = m; return ok && ok2; })(), 'relative ramp');
// The legend, built here over index.html's simple one (same ids): the bar from the lowest score shown to the hour's best, those two real
// scores at its ends and the chance lines' scores (50 · 65 · 80) under notches where they fall inside; a weak hour says so under it.
{
  const bar = $('#legend'), words = bar?.nextElementSibling;
  if (bar) {
    if (words?.classList.contains('legend-words')) words.remove();
    bar.outerHTML = `<div class="hl" data-i18n-title="hlRel"><div class="hl-t lbl">${ic('fish', 'sm')}<span data-i18n="l_heat"></span></div>` + // phones: the fish alone names it (css/map-fx.css)
      `<div class="hl-bar" id="legend"></div><div class="hl-n" id="hl-n"></div><div class="hl-note" id="hl-note" hidden></div></div>`;
  }
}
{ const sw = $('#lay-zones')?.nextElementSibling; if (sw?.classList.contains('sw')) sw.style.color = absTint(80); } // the Chance lines switch's swatch: the ramp's (index.html's own is its fallback)
let legendKey = '';
function drawLegend() {
  const bar = $('#legend'), nums = $('#hl-n'), note = $('#hl-note'); if (!bar || !nums) return;
  const lo = rangeCut(), hi = rangeHi, key = `${lo} ${hi} ${state.lang}`; if (key === legendKey) return; legendKey = key;
  const span = Math.max(hi - lo, 1), at = s => ((s - lo) / span * 100).toFixed(1);
  if (hi < lo) { bar.style.background = 'rgb(255 255 255 / .08)'; nums.innerHTML = ''; }
  else {
    bar.style.background = `linear-gradient(90deg,${Array.from({ length: 9 }, (_, k) => { const s = lo + span * k / 8, c = mapRgba(s); return `rgba(${c.slice(0, 3)},${Math.max(.35, c[3] / 255).toFixed(2)}) ${k * 12.5}%`; })})`;
    const mid = [50, 65, 80].filter(s => s > lo + span * .12 && s < hi - span * .12);
    bar.innerHTML = mid.map(s => `<i style="left:${at(s)}%"></i>`).join('');
    nums.innerHTML = [lo, ...mid, hi].map((s, k, a) => `<span style="left:${k === a.length - 1 ? 100 : at(s)}%;color:${absTint(s)}">${s}</span>`).join('');
  }
  const weak = hi < 50 || lo < state.min ? tr('hl_weak', hi) : '';
  note.hidden = !weak; note.textContent = weak;
}
new MutationObserver(drawLegend).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
console.assert(BAND[40] === 45 && BAND[49] === 45 && BAND[100] === 100, 'bands');
{ // the Contour bands option, under Fishing chance in Layers (an option of that layer, so not counted as a layer of its own)
  const row = L.DomUtil.create('div', 'lp-sub'), lab = L.DomUtil.create('label', '', row);
  lab.innerHTML = '<input type="checkbox" id="lay-bands"> <span data-i18n="l_bands"></span>'; lab.dataset.i18nTitle = 'bandsTip';
  $('#lay-heat')?.closest('label')?.after(row);
  const box = lab.firstChild; box.checked = !!state.layers?.bands;
  box.addEventListener('change', () => { state.layers.bands = box.checked; savePrefs(); if (F) paint(); });
}
// Round 10: "My catches" under Fishing chance, once js/personal.js offers a switch: PsPersonal.enabled() / setEnabled(on) (it rescores itself)
addEventListener('DOMContentLoaded', () => {
  const P = window.PsPersonal; if (typeof P?.setEnabled !== 'function' || $('#lay-mine')) return;
  const row = L.DomUtil.create('div', 'lp-sub'), lab = L.DomUtil.create('label', '', row);
  lab.innerHTML = `<input type="checkbox" id="lay-mine"> <span data-i18n="l_mine">${esc(tr('l_mine'))}</span>`; lab.dataset.i18nTitle = 'mineTip'; lab.title = tr('mineTip');
  ($('#lay-bands')?.closest('.lp-sub') || $('#lay-heat')?.closest('label'))?.after(row);
  const box = lab.firstChild; box.checked = !!P.enabled?.();
  box.addEventListener('change', () => { try { P.setEnabled(box.checked); } catch (e) { console.warn(e); } });
  for (const ev of ['ps:personal', 'ps:catches']) document.addEventListener(ev, () => { box.checked = !!P.enabled?.(); }); // the catch log's own switch moves it too
});
// Round 11: the chance covers the same water at every zoom (the owner: patches must not grow zoomed out and shrink zoomed in). Rounds 9–10
// spread each score over ±0.5–1.5 km under zoom 11, glowed ~7 px under 9.5 and blurred the small image in screen pixels; now every zoom
// draws one field: each cell's score, lightly blurred over the cells that show (3×3, as soften), with a soft edge where the share of showing
// cells around falls from .42 to .12: about half a cell either side of the line mid-way between a showing cell and one that does not, the same
// in metres at every zoom. Zoomed in, paintFine draws that field finer over the view; zoomed out (a cell under ¾ of a screen px), blocks of
// d×d cells are averaged (premultiplied: no pixel takes paint where no water shows; a block partly covered keeps its water's colour and shows
// at √ of its cover, so a thin reef band stays readable without reaching past its own pixels).
let paintedD = 0, paintStale = false; // paintedD: the cells per image pixel last painted (1: one a cell)
const cellPx = () => RES * 256 * 2 ** map.getZoom() / 360; // a cell's width on screen, in px
const DIVS = [1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30, 60]; // each tiles the grid exactly (W and H are multiples of 60)
const lowFor = sx => DIVS.find(d => d * sx >= .75) || 60;
console.assert(W % 60 === 0 && H % 60 === 0 && lowFor(1) === 1 && lowFor(.32) === 3 && lowFor(.05) === 15, 'lowFor');
const EDGE = Float32Array.from({ length: 17 }, (_, n) => Math.min(1, Math.max(0, (n / 16 - .12) / .3))); // cover (n of 16) → alpha, as paintFine's edge
let fH = null, fN = null, fN32 = null, f8 = null; // the row pass of the blur (sums of scores and of showing cells), and the field the chance lines follow (image rows)
function softCells(src, lut32, rnd) { // px32 (image rows): each cell's blurred score in the ramp's colour, faded by cover; true if any shows
  if (!fH) { fH = new Uint16Array(N); fN = new Uint8Array(N); fN32 = new Uint32Array(fN.buffer); f8 = new Uint8Array(N); }
  fH.fill(0); fN.fill(0); px32.fill(0); f8.fill(0);
  const on = ON, h = fH, n1 = fN;
  for (const [list, len] of [[shownIdx, shownN], [CLIP && COASTAL || shownIdx, CLIP && COASTAL ? COASTAL.length : 0]]) for (let k = 0; k < len; k++) { // the cells that score (0 off shownIdx: workHour), and the shore's land cells toShore lent a score
    const i = list[k], v = src[i]; if (!v || !on[v]) continue;
    const x = i % W; h[i] += 2 * v; n1[i] += 2; if (x) { h[i - 1] += v; n1[i - 1]++; } if (x < W - 1) { h[i + 1] += v; n1[i + 1]++; }
  }
  let vis = 0;
  for (let y = 0, W4 = W >> 2; y < H; y++) {
    const g = MROW[y], r0 = g * W, ru = g ? r0 - W : r0, rd = g < H - 1 ? r0 + W : r0, ku = g ? 1 : 0, kd = g < H - 1 ? 1 : 0, o = y * W, ey = EFY[g]; // the grid's first and last rows: no row past them
    for (let w = 0; w < W4; w++) {
      if (!(fN32[(r0 >> 2) + w] | fN32[(ru >> 2) + w] | fN32[(rd >> 2) + w])) continue; // four cells with nothing showing around
      for (let x = w << 2, e = x + 4; x < e; x++) {
        const i = r0 + x, n = 2 * fN[i] + ku * fN[ru + x] + kd * fN[rd + x], t = EDGE[n] * ey * EFX[x]; if (!t) continue; // the grid's edge: fading out
        const s = (2 * fH[i] + ku * fH[ru + x] + kd * fH[rd + x]) / n, c = lut32[s + rnd | 0]; if (!c) continue;
        px32[o + x] = t === 1 ? c : c & 0xffffff | (c >>> 24) * t << 24; vis = 1;
        if (t === 1) f8[o + x] = s + .5 | 0; // the lines: inside a patch only (its edge shows in the colour), as paintFine
      }
    }
  }
  return vis;
}
const lowImgs = [];
const lowImg = d => lowImgs[d] ||= (() => { const img = new ImageData(W / d, H / d); return { img, p32: new Uint32Array(img.data.buffer) }; })();
let boxS = new Float32Array(0);
function boxDown(d) { // px32 → a pixel per d×d cells
  const o = lowImg(d), w = W / d, h = H / d, q = o.p32, d2 = d * d;
  if (boxS.length < w * 5) boxS = new Float32Array(w * 5);
  const S = boxS;
  for (let by = 0; by < h; by++) {
    S.fill(0, 0, w * 5);
    for (let y = by * d, ye = y + d; y < ye; y++) for (let x = 0, k = y * W; x < W; x++, k++) {
      const p = px32[k]; if (!p) continue;
      const a = p >>> 24, b = (x / d | 0) * 5;
      S[b] += (p & 255) * a; S[b + 1] += (p >>> 8 & 255) * a; S[b + 2] += (p >>> 16 & 255) * a; S[b + 3] += a; S[b + 4]++;
    }
    for (let bx = 0, b = 0, k = by * w; bx < w; bx++, b += 5, k++) {
      const A = S[b + 3]; if (!A) { q[k] = 0; continue; }
      q[k] = (Math.round(A / S[b + 4] * Math.sqrt(S[b + 4] / d2)) << 24 | Math.round(S[b + 2] / A) << 16 | Math.round(S[b + 1] / A) << 8 | Math.round(S[b] / A)) >>> 0;
    }
  }
  return o.img;
}
// Leaflet stretches the image evenly in Web Mercator, but grid rows are evenly spaced in latitude: left as is, the heat sits
// up to ~1.7 rows (~400 m) too far north, i.e. on the south coast's beaches. So each image row reads the grid row at its real latitude.
const imgLat = (() => { const m = d => Math.log(Math.tan(Math.PI / 4 + d * Math.PI / 360)), mN = m(NORTH), mS = m(NORTH - H * RES);
  return y => (2 * Math.atan(Math.exp(mN - y / H * (mN - mS))) - Math.PI / 2) * 180 / Math.PI; })(); // the latitude at image row y (0 at the top, H at the bottom)
const MROW = Int16Array.from({ length: H }, (_, y) => Math.min(H - 1, Math.max(0, Math.floor((NORTH - imgLat(y + .5)) / RES))));
const shore = new Uint8Array(N);
let COASTAL = null; // inner land cells with a sea neighbour: the rest of the land has only land (0) around it
function toShore(src) { // land cells next to the sea take their best sea neighbour; the shoreline clip then trims them at the water's edge
  if (!COASTAL) {
    const a = [];
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; if (!depth[i] && (depth[i - 1] || depth[i + 1] || depth[i - W] || depth[i + W])) a.push(i); }
    COASTAL = Int32Array.from(a);
  }
  shore.set(src);
  for (const i of COASTAL) shore[i] = Math.max(src[i - 1], src[i + 1], src[i - W], src[i + W]);
  return shore;
}
// fade: into the hidden layer, then that layer fades in over the other (a settled change: workHour); else into the layer on show, at once.
// quick (scrubbing): the chance lines wait for the settle (drawZones), so a drag only recolours.
let isoF = null, isoStale = false, freeT = 0; // isoF: the field the lines follow, the one just painted: sample (i, j) sits at box fraction (ox + (i + .5)·kx, oy + (j + .5)·ky)
function paint(fade = false, quick = false) {
  if (!map.hasLayer(heat) || document.hidden) { paintStale = true; return; } // off, or a hidden page: painted when it is back (freeHeat)
  paintStale = false;
  const src = CLIP ? toShore(scores) : scores, bands = !!state.layers?.bands; // the shore's land cells take their sea's score: the shoreline clip trims them
  const d = paintedD = lowFor(cellPx()), vis = softCells(src, bands ? LUTB32 : LUT32, bands ? 0 : .5), img = d > 1 ? boxDown(d) : heatData; // bands: each score's band (floor), else the nearest
  isoF = vis ? { f: f8, w: W, h: H, ox: 0, oy: 0, kx: 1 / W, ky: 1 / H } : null; // the lines follow the cells (zoomed in: the fine image, paintFine)
  // The pixels go straight into the layer's canvas: no image file per hour (a 3 MB BMP blob + object URL cost ~36 ms a frame on a phone)
  const lay = heatLayers[fade ? liveLayer ^ 1 : liveLayer], cut = lay.cut = fineCut(), cv = lay.ctx.canvas;
  if (cv.width !== img.width || cv.height !== img.height) Object.assign(cv, { width: img.width, height: img.height }); // another block size, or freed: a cleared canvas
  if (!vis) lay.ctx.clearRect(0, 0, cv.width, cv.height); else lay.ctx.putImageData(img, 0, 0);
  if (cut && vis) { paintFine(lay, cut, src, bands); lay.ctx.clearRect(cut.x0, cut.y0, cut.x1 - cut.x0, cut.y1 - cut.y0); } // the fine image in place of that part
  else lay.fine.style.display = 'none';
  if (!vis) isoF = null;
  if (quick) { lay.iso.style.display = 'none'; lay.isoAt = null; isoStale = true; } else drawIso(lay);
  // The fade: the new picture over the old (z-index), its opacity 0 → 1 in 180 ms on the compositor; the old stays whole under it until then,
  // so the map never dims mid-way (two half-faded layers did). Anything else (scrubbing) ends a running fade at once.
  const old = heatLayers.find(l => l !== lay); // fading: the one on show; else the one fading out, if any
  for (const a of lay.el.getAnimations()) a.finish();
  if (fade) {
    liveLayer ^= 1; Object.assign(lay.el.style, { visibility: '', opacity: '', zIndex: 1 }); old.el.style.zIndex = 0;
    clearTimeout(hideT);
    if (REDUCE.matches) old.el.style.visibility = 'hidden';
    else { lay.el.animate({ opacity: [0, 1] }, { duration: 180, easing: 'ease-out' }); hideT = setTimeout(() => { old.el.style.visibility = 'hidden'; }, 200); }
    clearTimeout(freeT); freeT = setTimeout(() => freeLayer(old), 1500); // the faded-out layer's pixels go once it rests (playing: never)
  } else if (hideT) { clearTimeout(hideT); hideT = 0; old.el.style.visibility = 'hidden'; }
}
const REDUCE = matchMedia('(prefers-reduced-motion: reduce)');
let hideT = 0;
const freeLayer = l => { for (const c of [l.ctx.canvas, l.fine, l.iso]) c.width = c.height = 0; l.cut = l.isoAt = null; }; // a 0×0 canvas holds no pixels
function freeHeat() { heatLayers.forEach(freeLayer); fineImg = null; fineF = new Float32Array(0); fH = fN = fN32 = f8 = isoF = null; paintStale = true; } // ~8–18 MB on a phone
heat.on('remove', freeHeat);
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (map.hasLayer(heat)) freeHeat(); } else if (paintStale && F && scored && map.hasLayer(heat)) paint(); });
// Zoomed in (from zoom 11, where a 250 m cell is ~3.6 px), the browser's smoothing between cells shows their staircase. So the part of
// the image under the view (and a quarter screen around it, for panning) is also drawn finer, a pixel per 3–4 screen px (16 a cell at
// most), from the score itself interpolated between cell centres and then coloured: edges, bands and lines follow smooth curves. Inside a
// patch the interpolation is cubic (Catmull-Rom, kept within its four cells' range, so it never shows a chance no cell has): no creases
// along the cells' edges. At a patch's edge only the corners that show count, bilinearly, so the colour fades out there instead of running
// down the ramp to 0 (a blue rim on everything). Its cost follows the screen, not the zoom. In its place the coarse canvas is left clear.
function fineCut() { // that part, in image pixels (columns and Mercator rows), and the fine image's size; null when cells are small
  const a = map.latLngToContainerPoint([NORTH, WEST]), b = map.latLngToContainerPoint([NORTH - H * RES, WEST + W * RES]), sx = (b.x - a.x) / W, sy = (b.y - a.y) / H;
  if (!(sx >= 3)) return null;
  const s = map.getSize(), mx = s.x / 4, my = s.y / 4, ix = v => Math.min(W, Math.max(0, (v - a.x) / sx)), iy = v => Math.min(H, Math.max(0, (v - a.y) / sy));
  const c = { x0: Math.floor(ix(-mx)), x1: Math.ceil(ix(s.x + mx)), y0: Math.floor(iy(-my)), y1: Math.ceil(iy(s.y + my)), view: [ix(0), iy(0), ix(s.x), iy(s.y)], z: map.getZoom() };
  if (c.x1 <= c.x0 || c.y1 <= c.y0) return null;
  const k = Math.max(Math.min(Math.max(sx / 1.5, 3), 4), sx / 16); // screen px a fine pixel: 3–4, 1.2+ a cell; past 16 px a cell the browser's own smoothing is as good
  c.fw = Math.ceil((c.x1 - c.x0) * sx / k); c.fh = Math.ceil((c.y1 - c.y0) * sy / k); c.sx = sx;
  return c;
}
const cubicW = (t, w, o) => { const t2 = t * t, t3 = t2 * t; w[o] = (2 * t2 - t3 - t) / 2; w[o + 1] = (3 * t3 - 5 * t2 + 2) / 2; w[o + 2] = (4 * t2 - 3 * t3 + t) / 2; w[o + 3] = (t3 - t2) / 2; }; // Catmull-Rom
let fineImg = null, fineF = new Float32Array(0), fineCol = new Int32Array(0), fineWx = new Float32Array(0), fineCW = new Float32Array(0);
let colV = new Float32Array(0), colN = colV, colC = colV, colLo = colV, colHi = colV, colIn = new Uint8Array(0); // per cell column of the cut, for one fine row
let softV = new Float32Array(0), softC = softV, softH = softV, softO = new Uint8Array(0), softN = softO; // the cut's cells: value, cover; the blur's inputs and row pass
// A light blur of the cells first (binomial, over the cells that show only): zoomed in, the model's cell-to-cell grain (a few points, in
// stripes 3–4 cells apart) read as a mosaic or a weave and drew the lines as squiggles, and patch edges followed the cells' staircase. Each
// cell gets the blurred value of the showing cells around it and how much of its window shows (cover, 0–1): edges then run where cover is
// ½, rounded, mid-way between a showing cell and one that does not. 3×3 at every zoom (round 11: a 5×5 under 6 px a cell moved the edges
// at zoom 11.5, and softCells draws the same field zoomed out). The pins still give each peak's own score.
function soften(f, ca, rA, rw, rh) {
  const m = rw * rh;
  if (softV.length < m) { softV = new Float32Array(m); softC = new Float32Array(m); softH = new Float32Array(m); softO = new Uint8Array(m); softN = new Uint8Array(m); }
  const v = softV, cv = softC, hs = softH, o = softO, hn = softN, on = ON, R = 1, K = [1, 2, 1], KK = 16;
  for (let y = 0, k = 0; y < rh; y++) for (let x = 0, i = (rA + y) * W + ca; x < rw; x++, k++, i++) { const s = f[i], u = on[s]; o[k] = u; v[k] = u * s; }
  // Each pass unrolled away from the borders (a loop over the kernel cost ~3× as much: ~5 → ~1.5 ms zoomed in on a desktop); at them, the taps that exist
  const edge = (a, b, k, i, d, n) => { let s = 0, c = 0; for (let t = -R; t <= R; t++) if (i + t >= 0 && i + t < n) { const q = K[t + R]; s += q * a[k + t * d]; c += q * b[k + t * d]; } return [s, c]; };
  for (let y = 0; y < rh; y++) for (let x = 0, k = y * rw; x < rw; x++, k++) {
    if (x < R || x >= rw - R) { [hs[k], hn[k]] = edge(v, o, k, x, 1, rw); continue; }
    hs[k] = v[k - 1] + v[k + 1] + 2 * v[k]; hn[k] = o[k - 1] + o[k + 1] + 2 * o[k];
  }
  const r1 = rw;
  for (let y = 0, k = 0; y < rh; y++) for (let x = 0; x < rw; x++, k++) {
    let s, n;
    if (y < R || y >= rh - R) [s, n] = edge(hs, hn, k, y, rw, rh);
    else { s = hs[k - r1] + hs[k + r1] + 2 * hs[k]; n = hn[k - r1] + hn[k + r1] + 2 * hn[k]; }
    v[k] = n ? s / n : 0; cv[k] = n / KK;
  }
}
function paintFine(lay, c, f, bands) {
  const { x0, x1, y0, y1, fw, fh } = c, lut32 = bands ? LUTB32 : LUT32, rnd = bands ? 0 : .5, on = ON; // bands: each score's band (floor), else the nearest score
  if (lay.fine.width !== fw || lay.fine.height !== fh) Object.assign(lay.fine, { width: fw, height: fh });
  if (fineImg?.width !== fw || fineImg.height !== fh) fineImg = new ImageData(fw, fh);
  if (fineF.length < fw * fh) fineF = new Float32Array(fw * fh);
  const d32 = new Uint32Array(fineImg.data.buffer), fv = fineF; d32.fill(0); fv.fill(0, 0, fw * fh);
  if (fineCol.length < fw + 1) { fineCol = new Int32Array(fw + 1); fineWx = new Float32Array(fw); fineCW = new Float32Array(fw * 4); }
  const fc = fineCol, fwx = fineWx, cw = fineCW;
  for (let fx = 0; fx < fw; fx++) { const g = Math.min(W - 1.001, Math.max(0, x0 + (fx + .5) * (x1 - x0) / fw - .5)), col = g | 0; fc[fx] = col; fwx[fx] = g - col; cubicW(g - col, cw, fx * 4); }
  fc[fw] = -1; // ends the last run of pixels between the same two cell columns
  const ca = Math.max(0, fc[0] - 1), cb = Math.min(W - 1, fc[fw - 1] + 2), nc = cb - ca + 1; // the cell columns a row reads
  if (colIn.length < nc + 2) { [colV, colN, colC, colLo, colHi] = [0, 0, 0, 0, 0].map(() => new Float32Array(nc + 2)); colIn = new Uint8Array(nc + 2); }
  const cV = colV, cN = colN, cC = colC, cLo = colLo, cHi = colHi, cI = colIn;
  cI[nc] = cI[nc + 1] = 0; // past the grid's last column: never inside
  const gy = fy => Math.min(H - 1.001, Math.max(0, (NORTH - imgLat(y0 + (fy + .5) * (y1 - y0) / fh)) / RES - .5)); // the grid row (fractional) under fine row fy
  const rA = Math.max(0, (gy(0) | 0) - 1), rh = Math.min(H - 1, (gy(fh - 1) | 0) + 2) - rA + 1;
  const n0 = .12, n1 = .42; // the edge's fade, in cover (a lone showing cell peaks at ¼, a one-cell band at ½): softCells' EDGE
  soften(f, ca, rA, nc, rh);
  const sv = softV, sc = softC;
  for (let fy = 0; fy < fh; fy++) {
    const g = gy(fy), r = g | 0, wy = g - r, uy = 1 - wy, o = fy * fw;
    const R0 = (Math.max(0, r - 1) - rA) * nc, R1 = (r - rA) * nc, R2 = R1 + nc, R3 = (Math.min(H - 1, r + 2) - rA) * nc, y2 = wy * wy, y3 = y2 * wy;
    const a0 = (2 * y2 - y3 - wy) / 2, a1 = (3 * y3 - 5 * y2 + 2) / 2, a2 = (4 * y2 - 3 * y3 + wy) / 2, a3 = (y3 - y2) / 2; // cubicW, inline
    let any = 0;
    for (let j = 0; j < nc; j++) { // down each column once: the cubic, and the bilinear weighted by cover (n: the cover there)
      const c1 = sc[R1 + j], c2 = sc[R2 + j], n = c1 * uy + c2 * wy;
      cN[j] = n;
      if (!n) { cI[j] = cC[j] = 0; continue; } // nothing shows here
      const p0 = sv[R0 + j], p1 = sv[R1 + j], p2 = sv[R2 + j], p3 = sv[R3 + j];
      cV[j] = a0 * p0 + a1 * p1 + a2 * p2 + a3 * p3; cC[j] = p1 * c1 * uy + p2 * c2 * wy;
      cLo[j] = p1 < p2 ? p1 : p2; cHi[j] = p1 < p2 ? p2 : p1; cI[j] = +(sc[R0 + j] === 1 && c1 === 1 && c2 === 1 && sc[R3 + j] === 1); any = 1;
    }
    if (!any) continue;
    for (let fx = 0, end; fx < fw; fx = end) { // a run of pixels between the same two cell columns: their values read once
      const j = fc[fx] - ca, nL = cN[j], nR = cN[j + 1];
      for (end = fx + 1; fc[end] === fc[fx];) end++;
      if (nL + nR === 0) continue;
      if (j && nL > .999 && nR > .999 && cI[j - 1] & cI[j] & cI[j + 1] & cI[j + 2]) { // inside a patch: cubic across too, within the four cells' range
        const v0 = cV[j - 1], v1 = cV[j], v2 = cV[j + 1], v3 = cV[j + 2], lo = cLo[j] < cLo[j + 1] ? cLo[j] : cLo[j + 1], hi = cHi[j] > cHi[j + 1] ? cHi[j] : cHi[j + 1];
        for (let x = fx, q = fx * 4; x < end; x++, q += 4) {
          let s = cw[q] * v0 + cw[q + 1] * v1 + cw[q + 2] * v2 + cw[q + 3] * v3; s = s < lo ? lo : s > hi ? hi : s;
          d32[o + x] = lut32[s + rnd | 0]; fv[o + x] = s;
        }
        continue;
      }
      const vL = cC[j], vR = cC[j + 1];
      for (let x = fx; x < end; x++) {
        const wx = fwx[x], n = nL + (nR - nL) * wx; if (n <= n0) continue;
        const s = (vL + (vR - vL) * wx) / n, k = s + rnd | 0;
        if (n >= n1) { d32[o + x] = lut32[k]; fv[o + x] = s; continue; }
        const t = (n - n0) / .3; // over a patch's edge: fading out; no lines there (-1), or all three bunched along every edge
        d32[o + x] = lut32[k] & 0xffffff | (lut32[k] >>> 24) * t << 24; fv[o + x] = -1;
      }
    }
  }
  window.PsFine?.over(c, d32, fv, fw, fh, lut32, rnd); // round 13: zoomed in on water with fine data, the ~50 m sub-cells' own scores over this picture (js/fine.js)
  if (x0 < FADE_C || x1 > W - FADE_C || rA < FADE_C || rA + rh > H - FADE_C) for (let fy = 0, o = 0; fy < fh; fy++) { // by the grid's edge: fading out, as softCells
    const ey = EFY[gy(fy) | 0];
    for (let fx = 0; fx < fw; fx++, o++) { const e = ey * EFX[fc[fx]], p = d32[o]; if (e < 1 && p) d32[o] = p & 0xffffff | (p >>> 24) * e << 24; }
  }
  lay.fctx.putImageData(fineImg, 0, 0);
  Object.assign(lay.fine.style, { display: '', left: x0 / W * 100 + '%', top: y0 / H * 100 + '%', width: (x1 - x0) / W * 100 + '%', height: (y1 - y0) / H * 100 + '%' });
  isoF = { f: fv, w: fw, h: fh, ox: x0 / W, oy: y0 / H, kx: (x1 - x0) / fw / W, ky: (y1 - y0) / fh / H };
}
console.assert((() => { const w = new Float32Array(4); cubicW(.3, w, 0); return Math.abs(w[0] + w[1] + w[2] + w[3] - 1) < 1e-6; })(), 'cubic weights sum to 1');
// The chance lines (the "zones" layer): where the field just painted crosses 50, 65 and 80, by marching squares over a sample every ~4
// screen px, the crossings stitched into lines and drawn through their midpoints as smooth curves, over the view and a tenth of a screen
// around it at the screen's own resolution: thin, crisp, a dark casing under each so it reads on bright shallows and the dark chart alike;
// the 80 line with a soft glow; rings under 8 px (specks) left out, and nothing along a patch's own edge (its colour shows it; there all
// three lines bunched into stripes): only where the chance crosses them inside the water. Stitched, a line is one stroke: as many short segments, their seams
// showed as beads. They replace the 65+ outlines (Leaflet polylines: busy zoomed out, and they ran along the shore over the land).
const ISO = [[50, 1, .5], [65, 1.3, .85], [80, 1.6, .95]]; // score, width (CSS px), opacity
function isolines(f, w, i0, i1, j0, j1, st, lv, Ax, Bx, Ay, By) { // each level's lines, { h, t: points (canvas px), ring }
  const n = lv.length, open = lv.map(() => new Map()), done = lv.map(() => []), lo = lv[0], hi = lv[n - 1], sw = st * w;
  for (let y = j0; y + st <= j1; y += st) for (let x = i0, i = y * w + i0; x + st <= i1; x += st, i += st) {
    const a = f[i], b = f[i + st], d = f[i + sw], c = f[i + sw + st]; // corners clockwise from the top left: a b / d c
    const mn = a < b ? (a < c ? (a < d ? a : d) : c < d ? c : d) : b < c ? (b < d ? b : d) : c < d ? c : d; if (mn >= hi || mn <= 0) continue; // ≤ 0: a patch's edge or nothing: the colour shows the edge
    const mx = a > b ? (a > c ? (a > d ? a : d) : c > d ? c : d) : b > c ? (b > d ? b : d) : c > d ? c : d; if (mx < lo) continue;
    for (let k = 0; k < n; k++) {
      const L = lv[k]; if (mn >= L || mx < L) continue;
      const id = (a >= L) << 3 | (b >= L) << 2 | (c >= L) << 1 | (d >= L);
      const e = id === 5 || id === 10 ? ((id === 5) === ((a + b + c + d) / 4 >= L) ? SADDLE[0] : SADDLE[1]) : SEG[id]; // a saddle: by the middle
      for (let s = 0; s < e.length; s += 2) {
        const g1 = e[s], g2 = e[s + 1];
        join(open[k], done[k], edgeKey(g1, i, st, sw), Ax * edgeX(g1, x, a, b, c, d, L, st) + Bx, Ay * edgeY(g1, y, a, b, c, d, L, st) + By,
          edgeKey(g2, i, st, sw), Ax * edgeX(g2, x, a, b, c, d, L, st) + Bx, Ay * edgeY(g2, y, a, b, c, d, L, st) + By);
      }
    }
  }
  return done.map((out, k) => { for (const [key, q] of open[k]) if (key === q.s) out.push(q); return out; }); // an open line is in its map at both ends
}
const edgeX = (g, x, a, b, c, d, L, st) => g === 0 ? x + st * (L - a) / (b - a) : g === 1 ? x + st : g === 2 ? x + st * (L - d) / (c - d) : x; // where edge g crosses L
const edgeY = (g, y, a, b, c, d, L, st) => g === 0 ? y : g === 1 ? y + st * (L - b) / (c - b) : g === 2 ? y + st : y + st * (L - a) / (d - a);
const edgeKey = (g, i, st, sw) => g === 0 ? 2 * i : g === 1 ? 2 * (i + st) + 1 : g === 2 ? 2 * (i + sw) : 2 * i + 1; // an edge's id: its first sample, across (even) or down (odd)
// edges 0 top, 1 right, 2 bottom, 3 left; each case's segments as edge pairs (corner bits a 8, b 4, c 2, d 1)
const SEG = [, [3, 2], [2, 1], [3, 1], [0, 1], , [0, 2], [0, 3], [0, 3], [0, 2], , [0, 1], [3, 1], [1, 2], [3, 2]], SADDLE = [[0, 3, 1, 2], [0, 1, 3, 2]];
// A line is points h reversed, then t (h takes points added at its start), between edges s and e; flipping it is a swap
const flipLine = q => { [q.h, q.t] = [q.t, q.h]; [q.s, q.e] = [q.e, q.s]; };
const linePts = q => { const p = []; for (let m = q.h.length - 2; m >= 0; m -= 2) p.push(q.h[m], q.h[m + 1]); for (const v of q.t) p.push(v); return p; };
function join(open, done, k1, x1, y1, k2, x2, y2) { // a segment from edge k1 to edge k2 onto the lines that end there
  const f = open.get(k1), g = open.get(k2);
  if (!f && !g) { const q = { h: [], t: [x1, y1, x2, y2], s: k1, e: k2, ring: false }; open.set(k1, q); open.set(k2, q); return; }
  if (f) open.delete(k1); if (g) open.delete(k2);
  if (f && g) {
    if (f === g) { f.ring = true; done.push(f); return; } // its two ends meet
    if (f.e !== k1) flipLine(f); if (g.s !== k2) flipLine(g); // f … k1 → k2 … g
    for (const v of linePts(g)) f.t.push(v);
    f.e = g.e; open.set(f.e, f); return;
  }
  if (f) { if (f.e !== k1) flipLine(f); f.t.push(x2, y2); f.e = k2; open.set(k2, f); }
  else { if (g.s !== k2) flipLine(g); g.h.push(x1, y1); g.s = k1; open.set(k1, g); }
}
console.assert((() => { // a 3×3 field with a peak in the middle: one ring around it
  const L = isolines(Float32Array.of(1, 1, 1, 1, 9, 1, 1, 1, 1), 3, 0, 2, 0, 2, 1, [5], 1, 0, 1, 0)[0]; // i1, j1: the last sample
  return L.length === 1 && L[0].ring && linePts(L[0]).length === 8;
})(), 'chance lines stitch');
function drawIso(lay) { // the lines over the view, from isoF
  const cv = lay.iso, g = lay.ictx; isoStale = false;
  const a = map.latLngToContainerPoint([NORTH, WEST]), b = map.latLngToContainerPoint([NORTH - H * RES, WEST + W * RES]), bw = b.x - a.x, bh = b.y - a.y, s = map.getSize();
  const L0 = Math.max(-s.x / 10, a.x) - a.x, T0 = Math.max(-s.y / 10, a.y) - a.y, R0 = Math.min(s.x * 1.1, b.x) - a.x, B0 = Math.min(s.y * 1.1, b.y) - a.y; // in the box's px
  lay.isoAt = { z: map.getZoom(), x0: L0 / bw, y0: T0 / bh, x1: R0 / bw, y1: B0 / bh };
  const lv = ISO.filter(([v]) => v >= rangeCut());
  if (!isoF || !state.layers.zones || !lv.length || R0 <= L0 || B0 <= T0) { cv.style.display = 'none'; return; }
  const dpr = Math.min(2, devicePixelRatio || 1), w = Math.ceil((R0 - L0) * dpr), h = Math.ceil((B0 - T0) * dpr);
  if (cv.width !== w || cv.height !== h) Object.assign(cv, { width: w, height: h }); else g.clearRect(0, 0, w, h);
  Object.assign(cv.style, { display: '', left: L0 / bw * 100 + '%', top: T0 / bh * 100 + '%', width: w / dpr / bw * 100 + '%', height: h / dpr / bh * 100 + '%' });
  const { f, w: fw, h: fh, ox, oy, kx, ky } = isoF, Ax = kx * bw * dpr, Bx = ((ox + kx / 2) * bw - L0) * dpr, Ay = ky * bh * dpr, By = ((oy + ky / 2) * bh - T0) * dpr;
  const clampI = (v, n) => Math.min(n - 1, Math.max(0, v | 0)), st = Math.max(1, Math.round(4 * dpr / Ax)); // only the samples under the canvas (and one around), ~4 px apart
  const on = v => v - v % st; // the samples marched on stay put as the view moves, so redrawn lines do not shift
  const lines = isolines(f, fw, on(clampI(-Bx / Ax - st, fw)), clampI((w - Bx) / Ax + st, fw), on(clampI(-By / Ay - st, fh)), clampI((h - By) / Ay + st, fh), st, lv.map(([v]) => v), Ax, Bx, Ay, By);
  const P = lines.map(qs => { // through the midpoints of each line's points: a smooth curve that still passes each crossing closely
    const p = new Path2D();
    for (const q of qs) {
      const v = linePts(q), n = v.length;
      if (q.ring) { let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; for (let m = 0; m < n; m += 2) { x0 = Math.min(x0, v[m]); x1 = Math.max(x1, v[m]); y0 = Math.min(y0, v[m + 1]); y1 = Math.max(y1, v[m + 1]); } if (x1 - x0 < 8 * dpr && y1 - y0 < 8 * dpr) continue; }
      p.moveTo(v[0], v[1]);
      for (let m = 2; m < n - 2; m += 2) p.quadraticCurveTo(v[m], v[m + 1], (v[m] + v[m + 2]) / 2, (v[m + 1] + v[m + 3]) / 2);
      p.lineTo(v[n - 2], v[n - 1]); if (q.ring) p.closePath();
    }
    return p;
  });
  g.lineJoin = g.lineCap = 'round';
  if (lv.at(-1)[0] === 80) { g.strokeStyle = tint(90); for (const [lw, al] of [[10, .06], [6, .1], [3.5, .16]]) { g.globalAlpha = al; g.lineWidth = lw * dpr; g.stroke(P.at(-1)); } } // the glow
  g.strokeStyle = '#000'; lv.forEach(([, lw], k) => { g.globalAlpha = .4; g.lineWidth = (lw + 1.6) * dpr; g.stroke(P[k]); });
  lv.forEach(([v, lw, al], k) => { g.strokeStyle = tint(v); g.globalAlpha = al; g.lineWidth = lw * dpr; g.stroke(P[k]); });
  g.globalAlpha = 1;
}
heat.on('add', () => { if (paintStale && F) paint(); });
console.assert(MROW[0] === 0 && MROW[H - 1] === H - 1 && MROW.every((v, y) => !y || v >= MROW[y - 1]), 'heat rows follow Mercator');
console.assert(W % 4 === 0, 'paint reads whole 32-bit words per row');
map.on('moveend', () => { // a new zoom's block size or sharpness, or the view past the fine image's margin: paint again (~1 ms zoomed in);
  if (!F || !map.hasLayer(heat)) return; // past the lines' margin only: the lines again, from the same field
  const z = map.getZoom(), lay = heatLayers[liveLayer], p = lay.cut, c = fineCut();
  if (lowFor(cellPx()) !== paintedD || !c !== !p || c && (c.z !== p.z || c.view[0] < p.x0 || c.view[1] < p.y0 || c.view[2] > p.x1 || c.view[3] > p.y1)) paint();
  else if (state.layers.zones && isoF) {
    const q = lay.isoAt, a = map.latLngToContainerPoint([NORTH, WEST]), b = map.latLngToContainerPoint([NORTH - H * RES, WEST + W * RES]), s = map.getSize();
    const v = [-a.x / (b.x - a.x), -a.y / (b.y - a.y), (s.x - a.x) / (b.x - a.x), (s.y - a.y) / (b.y - a.y)].map(t => Math.min(1, Math.max(0, t)));
    if (!q || q.z !== z || v[0] < q.x0 - 1e-6 || v[1] < q.y0 - 1e-6 || v[2] > q.x1 + 1e-6 || v[3] > q.y1 + 1e-6) drawIso(lay);
  }
});
function drawZones() { if (F && scored && map.hasLayer(heat)) drawIso(heatLayers[liveLayer]); } // the chance lines on or off (ui.js), or after a scrub (settle)
// Scrubbing the timeline, holding an arrow key or playing can ask for many renders a frame: after a render, the next waits for the
// next frame and draws the latest hour, fish and method. renderNow() draws at once.
let renderQueued = false, renderedAt = -1e9, scored = false, hiddenPlay = false;
const flushRender = () => { if (renderQueued) renderNow(); };
function render() {
  if (document.hidden && state.playing) { hiddenPlay = true; return; } // playing in a hidden page: nothing to see, the hour shows when it is back
  if (renderQueued) return;
  if (performance.now() - renderedAt > 50) { renderNow(); return; }
  renderQueued = true; requestAnimationFrame(flushRender); setTimeout(flushRender, 50); // the timer: pages that get no frames (hidden) still draw
}
// Each hour's map is kept: its scores along cur.idx, a byte a cell, for this cur only (curGen, model.js). An hour is scored in slices of
// SLICE_MS, so a tap, a drag or the timeline never waits behind a big map (a pelagic fish or All fish by boat: ~525k cells, ~40 ms an hour
// on a desktop, several times that on a phone); the old picture stays until the new one is whole. Once the hour has been moved, a slow map's
// neighbouring hours are scored ahead in background slices (HOURS_AROUND each way, HOURS_MB at most, never in a hidden page), so scrubbing
// and playing then show them at once. ponytail: main thread only; a worker would need its own copy of the model's grids (~100 MB on a phone).
const hourMaps = new Map(), SLICE_MS = 8, HOURS_AROUND = 12, HOURS_MB = 24;
let hourGen = -1, hourMs = 0, hourMoved = false, hourLast = -1, hourJob = null, hourJobT = false, aheadTask = false;
let shownIdx = new Int32Array(0), shownN = 0, shownGen = -1; // the cells `scores` holds a score for (0 off them): cur.idx when it was shown
const soonTask = (f, bg) => window.scheduler?.postTask ? scheduler.postTask(f, { priority: bg ? 'background' : 'user-visible' }) : setTimeout(f, bg ? 20 : 0);
function hourMap(h) {
  if (hourGen !== curGen) { hourMaps.clear(); hourGen = curGen; hourMs = 0; hourMoved = false; }
  let e = hourMaps.get(h);
  if (!e) hourMaps.set(h, e = { a: new Uint8Array(cur.n), j: 0, ms: 0 });
  return e;
}
function scoreSlice(e, h, until) { // more of hour h's map, until the deadline; true once it is whole
  while (e.j < cur.n) {
    const t = performance.now(), j1 = Math.min(cur.n, e.j + 8192);
    scoreCells(cur, h, h + 1, cur.idx, e.j, j1, 0, e.a); e.j = j1; e.ms += performance.now() - t;
    if (e.j === cur.n) hourMs = e.ms;
    else if (performance.now() > until) return false;
  }
  return true;
}
let settleTimer = 0;
function renderNow() {
  renderQueued = false;
  // While scrubbing (renders < 300 ms apart) the spot list, outlines and open card wait until it settles: they cost ~20 ms a frame on a phone.
  // The heat fades from the old hour (or fish) to the new only when not scrubbing: playing, Now, ★, a tap.
  const busy = performance.now() - renderedAt < 300;
  drawConditions(); drawTimeline(); drawWhen();
  hourMap(state.h); if (hourLast !== state.h) { hourMoved ||= hourLast >= 0; hourLast = state.h; }
  hourJob = { h: state.h, fade: !busy, busy }; workHour(); // a small map is whole after the first slice: on the map at once, as it always was
  renderedAt = performance.now();
}
const pumpHour = () => { hourJobT = false; workHour(); };
function workHour() { // the hour waiting for its map: a slice of it, then onto the map once whole
  if (!hourJob) return;
  const e = hourMap(hourJob.h);
  if (!scoreSlice(e, hourJob.h, performance.now() + SLICE_MS)) { if (!hourJobT) { hourJobT = true; soonTask(pumpHour); } return; }
  const { fade, busy } = hourJob; hourJob = null;
  if (shownGen !== hourGen) { shownIdx = cur.idx.slice(0, cur.n); shownN = cur.n; shownGen = hourGen; } // prepare() reuses cur.idx: a copy
  let hi = 0; scores.fill(0); for (let j = 0, a = e.a; j < shownN; j++) { const v = scores[shownIdx[j]] = a[j]; if (v > hi) hi = v; }
  if (hi !== rangeHi) { rangeHi = hi; buildLut(); } // the fish's own range this hour: the ramp's top (round 9)
  scored = true;
  paint(fade, busy);
  clearTimeout(settleTimer);
  if (busy) settleTimer = setTimeout(settle, 180); else settle();
  scoreAhead();
}
function scoreAhead() { // the next hour around the one shown (nearest first) of a slow map, in a background slice
  if (aheadTask || hourJob || !hourMoved || hourMs < 12 || document.hidden) return;
  let h = -1;
  for (let d = 1; d <= HOURS_AROUND && h < 0; d++) for (const k of [state.h + d, state.h - d]) if (k >= 0 && k < F.T && !(hourMaps.get(k)?.j === cur.n)) { h = k; break; }
  if (h < 0) return;
  while ((hourMaps.size + 1) * cur.n > HOURS_MB * 1e6) { // the farthest hour goes
    let far = state.h; for (const k of hourMaps.keys()) if (Math.abs(k - state.h) > Math.abs(far - state.h)) far = k;
    if (Math.abs(far - state.h) <= Math.abs(h - state.h)) return; hourMaps.delete(far);
  }
  aheadTask = true;
  soonTask(() => { aheadTask = false; if (hourGen === curGen && !hourJob && !document.hidden) { scoreSlice(hourMap(h), h, performance.now() + SLICE_MS); scoreAhead(); } }, true);
}
document.addEventListener('visibilitychange', () => { if (document.hidden) return; if (hiddenPlay) { hiddenPlay = false; if (F) render(); } else if (F) scoreAhead(); });
function settle() { const f = state.focus; if (isoStale) drawZones(); drawTop(); if (state.focus !== f) drawConditions(); refreshOpen(); } // drawTop may move the focus spot the readings follow (renderNow drew them for the old one)

function describe(la, lo) {
  let b = null;
  for (const [name, , sla, slo] of NAMED) { const r = km([sla, slo], [la, lo]); if (r.d < 2.5 && (!b || r.d < b.d)) b = { ...r, name: placeName(name) }; }
  if (!b) for (const [en, el, pla, plo] of PLACES) { const r = km([pla, plo], [la, lo]); if (!b || r.d < b.d) b = { ...r, name: state.lang === 'el' ? el : en }; }
  return b.d < .25 ? tr('at', b.name) : tr('of', fmtKm(b.d), compass(b.bearing), b.name);
}
let tops = [];
const B6 = 6, BW = Math.ceil(W / B6), blockBest = new Int32Array(BW * Math.ceil(H / B6));
// The 8 numbered pins are made once and hourMoved: rebuilt each settle, their DOM was redone and their pop restarted at every hour.
// Each: a ring at the spot itself with its rank in it (css/map-fx.css); the three best in view also wear a dark tag on a stem over it,
// "#rank" and the score as a dial (core.js ring()), so the peaks read at a glance and the rest stay quiet. Its element is kept: drawTop
// sets only the score and colour, and only when they change; a move only swaps which three wear the tag (markDials).
const pinEls = [], pinSet = [];
map.createPane('tops').style.zIndex = 646; // over the catch and sighting pins (js/pins.js, 645): the best spots' dials stay readable; under the north's mask (650)
const pinMarks = Array.from({ length: 8 }, (_, n) => {
  const el = pinEls[n] = L.DomUtil.create('div', n ? 'tp' : 'tp tp1');
  el.innerHTML = `<i class="tp-ring"><b>${n + 1}</b></i><span class="tp-cap"><b>#${n + 1}</b><span class="ring sm"><b></b></span></span>`;
  return L.marker([0, 0], { icon: L.divIcon({ className: 'top-pin', html: el, iconSize: [0, 0] }), keyboard: false, pane: 'tops' }).on('click', () => tops[n] && openCell(tops[n].i));
});
function drawTop() {
  // The best cell of each 6×6 block (the first in reading order on a tie), from the cells that can score only (scores are 0 off shownIdx): ~2 ms → ~0.1
  const cands = []; blockBest.fill(-1);
  for (let k = 0; k < shownN; k++) {
    const i = shownIdx[k], s = scores[i]; if (s < 40) continue;
    const b = ((i / W | 0) / B6 | 0) * BW + (i % W / B6 | 0), j = blockBest[b];
    if (j < 0 || s > scores[j] || s === scores[j] && i < j) blockBest[b] = i;
  }
  for (const i of blockBest) if (i >= 0) cands.push([scores[i], i]);
  cands.sort((a, b) => b[0] - a[0]); // stable: ties keep block order
  const gap = state.mode === 'boat' ? 3 : 1.5;
  tops = [];
  for (const [s, i] of cands) {
    const p = [latOf(i), lonOf(i)];
    if (tops.every(t => km(t.p, p).d > gap)) tops.push({ s, i, p });
    if (tops.length === 8) break;
  }
  drawSpotList(tops); // the Spots tab (ui.js)
  tops.forEach((t, n) => {
    pinMarks[n].setLatLng(t.p);
    const el = pinEls[n], key = t.s + state.lang; if (pinSet[n] === key) return;
    pinSet[n] = key; el.style.setProperty('--c', solid(t.s)); el.style.setProperty('--p', t.s); el.lastChild.lastChild.firstChild.textContent = t.s; el.title = `#${n + 1} · ${t.s} · ${rating(t.s)}`;
  });
  spacePins();
  if (!state.picked && tops[0]) state.focus = tops[0].i; // conditions follow the best spot until a cell is clicked
}
function spacePins() { // zoomed out, a pin whose capsule would touch a better-ranked one's stays off the map (the list keeps every spot)
  const shown = [];
  pinMarks.forEach((m, n) => {
    const p = n < tops.length && map.latLngToLayerPoint(m.getLatLng());
    if (p && shown.every(q => Math.abs(q.x - p.x) >= 62 || Math.abs(q.y - p.y) >= 36)) { shown.push(p); pins.addLayer(m); } else pins.removeLayer(m);
  });
  markDials();
  // round 9: up to the coast's villages (zoom 11) the place names (js/map-marks.js) keep clear of the pins: the three best shown with their tag over them
  window.PsAreas?.space(); // the fishing areas' names give way to the pins too (js/areas.js)
  window.PsMarks?.avoid(map.getZoom() < 11 ? pinMarks.filter(m => pins.hasLayer(m)).map((m, k) => { const ll = m.getLatLng(); return [ll.lat, ll.lng, k < 3 ? [-38, -52, 38, 12] : [-12, -12, 12, 12]]; }) : []);
}
function markDials() { // the three best-ranked pins in view wear the tag (8 bounds checks a move)
  const v = map.getBounds(); let k = 0;
  pinMarks.forEach((m, n) => { const on = k < 3 && pins.hasLayer(m) && v.contains(m.getLatLng()); k += on; pinEls[n].classList.toggle('dial', on); });
}
map.on('zoomend', spacePins);
map.on('moveend', markDials);
// Round 9: the whole island (under zoom 9.5) is the best spots' view: the live wind / current chips (js/obs.js, css/map-fx.css) sat on their tags
const zoomClass = () => map.getContainer().classList.toggle('ps-zlo', map.getZoom() < 9.5);
map.on('zoomend', zoomClass); zoomClass();

const arrow = deg => `<svg width="11" height="11" viewBox="0 0 10 10" style="transform:rotate(${deg}deg)" aria-hidden="true"><path d="M5 .5l3 4H6v5H4v-5H2z" fill="currentColor"/></svg>`;
const seaNear = ll => { let b = SAMPLE[0], bd = Infinity; for (const j of SAMPLE) { const d = (latOf(j) - ll.lat) ** 2 + ((lonOf(j) - ll.lng) * .82) ** 2; if (d < bd) { bd = d; b = j; } } return b; }; // nearest scoreable sea cell
function nextWindow(list, t) { const w = list.find(([, b]) => b > t); return w ? `${hm(w[0])}–${hm(w[1])}` : '–'; }
function drawConditions() { // the readings that matter most, as mini instruments (js/instruments.js: built once, patched each hour); the drawer has the rest (moreConditions in ui.js)
  if (F) PsInst.strip($('#strip'), state.focus >= 0 ? state.focus : seaNear(map.getCenter()), state.h); // nothing scores yet (a fish that is not biting): the sea mid-map
}
let tlFor = null, tlPh = null; // tlPh: the playhead, all an hour step moves
const tlDays = (from = 0) => { const d = []; for (let h = from; h < F.T; h++) h === from || hours[h].local === 0 ? d.push([h, h + 1]) : d[d.length - 1][1] = h + 1; return d; }; // [from, to) per local day
function dayName(days, k) { // Yesterday, Today, Tomorrow, else e.g. "Thu 29"
  const r = k - days.findIndex(([a, b]) => state.first >= a && state.first < b);
  return r === -1 ? tr('yesterday') : r === 0 ? tr('cToday') : r === 1 ? tr('cTomorrow') : fmtT(hours[days[k][0]].t, { weekday: 'short', day: 'numeric' });
}
// The best chance anywhere, hour by hour, as one smooth curve coloured along its length by each hour's chance, its area fading down;
// night hours darker bands, the past hatched and greyed, now a dashed line, the hour on the map a white line with a knob on the curve.
// Wide screens: the whole range, a hairline and a label (name, best chance, roughest sea and wind) per day. Phones, and wide screens with
// under 2.5 px an hour: one day at a time, so each hour is wide enough to tap, picked from a strip of day chips that scrolls sideways.
// Drawn in px (again when the width changes), so lines and knob keep their size. Hour k sits at k·dx, where the native slider over it puts it.
let tlW = 0; // the track's width (it does not depend on what is drawn in it)
new ResizeObserver(([e]) => { const w = Math.round(e.contentRect.width); if (w !== tlW) { tlW = w; tlFor = null; if (F) drawTimeline(); } }).observe($('#tl'));
const tlH = () => 36; // the chart's height: css/timeline.css lays #hour over it at the same height
const greyed = s => { const c = heatRgba(Math.max(s, 50)), l = (3 * c[0] + 6 * c[1] + c[2]) / 10; return `rgb(${c.slice(0, 3).map(v => (v + 3 * l) / 4 | 0)})`; }; // the past: its chance's colour, mostly grey
function monotone(ys, dx) { // an SVG path through (k·dx, ys[k]): cubic and monotone between hours (as d3's curveMonotoneX), so it never shows a chance no hour has
  const n = ys.length, s = ys.slice(1).map((y, k) => (y - ys[k]) / dx), f = v => v.toFixed(1);
  const m = ys.map((_, k) => k === 0 ? s[0] : k === n - 1 ? s[n - 2] : (Math.sign(s[k - 1]) + Math.sign(s[k])) * Math.min(Math.abs(s[k - 1]), Math.abs(s[k]), Math.abs(s[k - 1] + s[k]) / 4));
  let p = `M0,${f(ys[0])}`;
  for (let k = 1; k < n; k++) p += `C${f((k - 2 / 3) * dx)},${f(ys[k - 1] + m[k - 1] * dx / 3)} ${f((k - 1 / 3) * dx)},${f(ys[k] - m[k] * dx / 3)} ${f(k * dx)},${f(ys[k])}`;
  return n > 1 ? p : p + `H${f(dx)}`; // a one-hour stub: flat across
}
const movePh = () => { const k = state.h - tlFor.from; tlPh.style.transform = `translateX(${(k * tlFor.dx).toFixed(1)}px)`; tlPh.firstChild.style.transform = `translateY(${tlFor.ys[k].toFixed(1)}px)`; };
function drawTimeline() {
  tlW ||= $('#tl').clientWidth; // before the observer's first call (it waits for a frame: none in a hidden page)
  const one = isPhone() || tlW < F.T * 2.5, days = tlDays(), di = Math.max(0, days.findIndex(([a, b]) => state.h >= a && state.h < b)), day = days[di];
  const [from, to] = one ? day : [0, F.T];
  const same = tlFor && tlFor.best === best && tlFor.lang === state.lang && tlFor.one === one; // the same days, scale and labels
  if (same && tlFor.from === from && tlFor.to === to) { movePh(); return; } // the same chart: only the playhead moves
  const hi = Math.max(...best), span = Math.max(hi - Math.min(...best), 20); // one scale for all days so they compare; the best hour at the top
  const dayBest = ([a, b]) => pill(Math.round(Math.max(...best.slice(a, b))));
  const cut = F.cutAt ? `<span class="tl-cut">${esc(tr('noWavesAfter', whenT(F.cutAt)))}</span>` : ''; // the wave forecast ended early: so does the timeline
  const n = to - from, ch = tlH(), dx = tlW / Math.max(1, n - 1), X = h => ((h - from) * dx).toFixed(1);
  const every = one ? 3 : [6, 12].find(s => s * dx >= 24) || 24; // hour labels where they fit (phones: every 3 h)
  const ys = best.slice(from, to).map(sc => 6 + (ch - 8) * (hi ? .86 * clamp((hi - sc) / span) : .94)); // 6 px over the top for the knob; nothing scores (banned or closed fish): flat
  let stops = '', night = '', hrs = '', n0 = 0;
  for (let h = from; h < to; h++) {
    const x = hours[h];
    stops += `<stop offset="${n > 1 ? ((h - from) / (n - 1)).toFixed(4) : 0}" stop-color="${h < state.first || !hi ? greyed(best[h]) : solid(best[h])}"/>`;
    if (x.period === 'night') {
      if (h === from || hours[h - 1].period !== 'night') n0 = h;
      if (h === to - 1 || hours[h + 1].period !== 'night') night += `M${Math.max(0, (n0 - from - .5) * dx).toFixed(1)} 0H${Math.min(tlW, (h - from + .5) * dx).toFixed(1)}V${ch}H${Math.max(0, (n0 - from - .5) * dx).toFixed(1)}Z`;
    }
    if (x.local && x.local % every === 0 && hours[h - 1]?.local !== x.local) hrs += `<em style="left:${X(h)}px">${String(x.local).padStart(2, '0')}</em>`; // once on the night the clocks go back
  }
  const line = monotone(ys, dx), now = state.first >= from && state.first < to;
  const sep = one ? '' : days.slice(1).map(([a]) => `M${(+X(a) - dx / 2).toFixed(1)} 0V${ch}`).join('');
  const chart = `<div class="tl-chart"><svg width="${tlW}" height="${ch}" viewBox="0 0 ${tlW} ${ch}" aria-hidden="true"><defs>` +
    `<linearGradient id="tl-c" gradientUnits="userSpaceOnUse" x2="${tlW}">${stops}</linearGradient>` +
    `<linearGradient id="tl-v" x2="0" y2="1"><stop stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity=".02"/></linearGradient>` +
    `<mask id="tl-m"><rect width="100%" height="100%" fill="url(#tl-v)"/></mask>` +
    `<pattern id="tl-x" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V5" stroke="#fff" stroke-opacity=".1" stroke-width="1.5"/></pattern></defs>` +
    `<path class="tl-night" d="${night}"/><path d="${line}V${ch}H0Z" fill="url(#tl-c)" mask="url(#tl-m)"/>` +
    (state.first > from ? `<rect width="${now ? X(state.first) : tlW}" height="${ch}" fill="url(#tl-x)"/>` : '') +
    (sep ? `<path class="tl-sep" d="${sep}"/>` : '') + (now ? `<path class="tl-nowl" d="M${X(state.first)} 0V${ch}"/>` : '') +
    `<path class="tl-line" d="${line}" stroke="url(#tl-c)"/></svg><i class="tl-ph"><b></b></i>${hrs}</div>`;
  const label = ([a, b], k) => { // each day labelled with its best chance and, given room, its roughest sea and wind (too short a stub gets no label)
    if (b - a < 5) return '';
    let wave = 0, wind = 0; for (let j = a * NN; j < b * NN; j++) { wave = Math.max(wave, F.wave[j]); wind = Math.max(wind, Math.hypot(F.u[j], F.v[j])); }
    // the name that fits beside the pill (~6.5 px a letter; the pill, gap and padding ~36 px): "Yesterday", else "Sat", else none; the pill always shows
    const room = (b - a - .5) * dx - 36;
    let nm = dayName(days, k); if (nm.length * 6.5 > room) { nm = fmtT(hours[a].t, { weekday: 'short' }); if (nm.length * 6.5 > room) nm = ''; }
    return `<span class="tl-nm">${esc(nm)}</span>${dayBest([a, b])}` +
      ((b - a) * dx >= 190 ? `<small title="${esc(tr('dayWx'))}">${ic('waves', 'sm')}${nf(wave)} m${ic('wind', 'sm')}${Math.round(wind)} km/h</small>` : '') + (k === days.length - 1 ? cut : '');
  };
  const tl = $('#tl');
  if (same && one) { // another day, one at a time: the strip stays (and keeps its scroll), only its pressed chip and the chart change
    const s = tl.firstElementChild.children; s[tlFor.di].setAttribute('aria-pressed', 'false'); s[di].setAttribute('aria-pressed', 'true');
    tl.lastElementChild.outerHTML = chart;
  } else {
    tl.innerHTML = (one ? `<div class="tl-dtabs">${days.map((d, k) => `<button type="button" class="${d[1] <= state.first ? 'past' : d[0] <= state.first ? 'today' : ''}" data-day="${d[0]}" data-end="${d[1]}" aria-pressed="${k === di}">` +
      `<span>${esc(dayName(days, k))}</span>${dayBest(d)}</button>`).join('')}${cut}</div>`
      : `<div class="tl-days">${days.map((d, k) => `<span class="tl-label${d[1] <= state.first ? ' past' : d[0] <= state.first ? ' today' : ''}" style="flex:${d[1] - d[0] - (k === 0) / 2 - (k === days.length - 1) / 2}">${label(d, k)}</span>`).join('')}</div>`) + chart; // flex: the days' edges on the hairlines, half an hour before each first hour
    tl.classList.toggle('one-day', one);
  }
  Object.assign($('#hour'), { min: from, max: to - 1, value: state.h }); // the slider spans what is shown
  if (one) { // the selected day in the middle of its strip: measured in the next frame, with the frame's own layout, not forced now
    const s = tl.firstElementChild, on = s.children[di], glide = same && !matchMedia('(prefers-reduced-motion: reduce)').matches;
    requestAnimationFrame(() => s.scrollTo({ left: on.offsetLeft - (s.clientWidth - on.offsetWidth) / 2, behavior: glide ? 'smooth' : 'auto' }));
  }
  tlFor = { best, from, to, lang: state.lang, one, di, dx, ys }; tlPh = tl.querySelector('.tl-ph'); movePh();
}
function dayHour(b, want = hours[state.h].local) { // the hour a day button goes to: the hour of day `want` where that day has it (js/mobile.js turns days by a flick too)
  const d = +b.dataset.day, end = +b.dataset.end;
  let h = d; for (let k = d; k < end; k++) if (hours[k].local === want) { h = k; break; }
  return h < state.first && end > state.first ? state.first : h; // today: from now on, not back in time
}
$('#tl').addEventListener('click', e => { const b = e.target.closest('[data-day]'); if (b && F) setHour(dayHour(b)); }); // phones: the day chips
PHONE.addEventListener('change', () => { tlFor = null; if (F) drawTimeline(); }); // rotating or resizing across the phone width
let bestHour = 0;
const whenSet = {}; // what drawWhen last wrote: an hour step rewrites only what changed (the day, tags and ★ button mostly stay), so the bar's layout is left alone
const putWhen = (sel, v, html) => { if (whenSet[sel] !== v) { whenSet[sel] = v; $(sel)[html ? 'innerHTML' : 'textContent'] = v; } };
const NARROW = matchMedia('(max-width: 1180px)'); // a desktop window this narrow: the ★ button says just the time, as on phones (css/timeline.css)
NARROW.addEventListener('change', () => F && drawWhen());
function drawWhen() {
  const x = hours[state.h], t = hm(x.t), d = fmtT(x.t, { weekday: 'short', day: 'numeric', month: 'short' });
  putWhen('#when-time', t); putWhen('#when-day', d);
  $('#hour').setAttribute('aria-valuetext', `${t}, ${d}`); // a screen reader says the hour, not the slider's index
  putWhen('#when-tags', (state.h < state.first ? `<span class="tag past">${tr('pastTag')}</span>` : '') +
    `<span class="tag">${tr(x.period)}</span>${x.solunar ? `<span class="tag ${x.solunar}" title="${esc(tr(x.solunar))}">${ic('moon')}${tr('solShort')[x.solunar]}</span>` : ''}`, true);
  bestHour = state.first; // the best hour from now on: the past is only for looking back
  for (let h = state.first; h < F.T; h++) if (best[h] > best[bestHour]) bestHour = h;
  const bb = $('#best-btn'), w = whenT(hours[bestHour].t), long = tr('best', w, Math.round(best[bestHour])), short = isPhone() || NARROW.matches, hide = !(best[bestHour] >= 40);
  if (bb.hidden !== hide) bb.hidden = hide;
  putWhen('#best-btn', short ? `★ ${w}` : long); // phones and narrow windows: just the time
  const tip = short ? `${long}\n${tr('bestTip')}` : tr('bestTip'); if (bb.title !== tip) bb.title = tip;
}
