'use strict';
/* Psarema area in 3D, street view (round 13): js/area3d.js loads this file when the panel's "Street view" toggle is first turned on.
   Where real-life street imagery exists, as markers standing on the terrain: 360° panoramas and flat photos (two icons), from the open,
   keyless sources scripts/street/build.mjs collects into data/street/<area>.json: Panoramax, KartaView and Wikimedia Commons (thinned to
   one marker per ~80 m of a sequence, ~40 m for Commons). One THREE.Points draw: a dot far away, an icon close up; nothing is built or
   fetched until the toggle is on, and nothing runs per frame but its few uniforms.
   A tap on a marker: the place, its source, author, licence and date, "View" and links out (the source's own page, Google Street View,
   Mapillary). "View" opens the picture here (phase 2): a 360° one on a sphere to drag round, a flat one fitted to the screen.
   A tap or a long press on the land or the shore: "Open in Google Street View here" (the official Maps URL, no key) and Mapillary.
   API: PsArea3DStreet.toggle(S, button), S: js/area3d.js's open view ({ el, a, view }); .back(event): Back and Escape, before js/area3d.js. */
(function () {
  const SRC = ['Panoramax', 'KartaView', 'Wikimedia Commons'];
  const PANO = 'M12 3.5a8.5 8.5 0 1 1 0 17a8.5 8.5 0 1 1 0-17zM3.5 12c0 1.8 3.8 3.3 8.5 3.3s8.5-1.5 8.5-3.3M12 3.5c-2.2 2.3-3.3 5.1-3.3 8.5M15.3 14.6l2.2 1.1-1.1 2.1'; // a sphere, its equator, a turn
  const PHOTO = 'M4.5 8h3l1.6-2.3h5.8L16.5 8h3a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5v-8A1.5 1.5 0 0 1 4.5 8zM12 10.3a3.2 3.2 0 1 0 0 6.4a3.2 3.2 0 1 0 0-6.4z'; // a camera
  const svg = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
  const files = new Map(), ST = new WeakMap(), SZ = [12000, 12, 30]; // a marker's size on screen: SZ[0] / its distance, from SZ[1] to SZ[2] px
  const size = d => Math.min(SZ[2], Math.max(SZ[1], SZ[0] / d));
  const load = id => files.get(id) || files.set(id, fetch(`data/street/${id}.json`).then(r => r.ok ? r.json() : null).catch(() => null).then(d => d || (files.delete(id), null))).get(id);
  const link = (href, text, main) => `<a class="sv-btn${main ? ' main' : ''}" href="${esc(href)}" target="_blank" rel="noopener noreferrer">${ic('external')}${esc(text)}</a>`;
  const gsv = (la, lo) => `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${la.toFixed(6)},${lo.toFixed(6)}`;
  const mly = (la, lo) => `https://www.mapillary.com/app/?lat=${la.toFixed(6)}&lng=${lo.toFixed(6)}&z=17`;
  const place = (la, lo) => typeof describe === 'function' ? describe(la, lo) : `${la.toFixed(5)}, ${lo.toFixed(5)}`;
  const month = s => { const [y, m] = String(s || '').split('-').map(Number); return !y ? '' : !m ? String(y) : new Date(y, m - 1, 15).toLocaleDateString(state.lang === 'el' ? 'el-GR' : 'en-GB', { month: 'short', year: 'numeric' }); };

  let cur = null; // the open 3D view's session (for Back)
  function toggle(S, btn) {
    const s = ST.get(S) || ST.set(S, { on: false }).get(S); cur = S;
    s.on = !s.on; btn.setAttribute('aria-pressed', String(s.on)); S.el.classList.toggle('sv-on', s.on);
    if (!s.on) { closeViewer(S, s); if (s.pts) s.pts.visible = false; card(S, s, null); S.view?.V.wake(); return; }
    status(S, tr('sv_loading'));
    Promise.all([load(S.a.id), new Promise(ok => { const t = () => S.view ? ok() : S.el.isConnected && setTimeout(t, 150); t(); })]).then(([d]) => {
      if (!s.on || !S.el.isConnected) return;
      s.d = d;
      const n = d?.p.length || 0;
      status(S, !d ? tr('sv_none') : n ? tr('sv_count', n.toLocaleString(state.lang === 'el' ? 'el-GR' : 'en-GB'), [...new Set(d.p.map(p => SRC[p[2] >> 1]))].join(', ')) : tr('sv_none'));
      if (s.view !== S.view) attach(S, s);
      if (s.pts) s.pts.visible = true;
      S.view.V.wake();
    });
  }
  const status = (S, text) => { const el = S.el.querySelector('.a3-svs'); if (el) el.textContent = text; };

  // the markers: one point each (x, the true ground height, z); the shaders lift them by the view's height scale, size them by distance
  // (SZ) and raise each icon over its point
  function attach(S, s) {
    const T = window.THREE, v = S.view, B = v.V.B, span = v.span, half = span / 2, d = s.d;
    s.view = v; s.pts = null; s.sel = -1;
    const xOf = lo => (lo - B.lo0) / (B.lo1 - B.lo0) * span - half, zOf = la => (B.la1 - la) / (B.la1 - B.la0) * span - half;
    const list = (d?.p || []).map(p => { const la = d.lat + p[0] / 1e5, lo = d.lon + p[1] / 1e5; return { la, lo, x: xOf(lo), z: zOf(la), k: p[2], ref: p[3], id: p[4] }; }).filter(p => Math.abs(p.x) < half && Math.abs(p.z) < half);
    s.list = list;
    if (list.length) {
      const pos = new Float32Array(list.length * 3), kind = new Float32Array(list.length), idx = new Float32Array(list.length);
      list.forEach((p, i) => { pos.set([p.x, 0, p.z], i * 3); kind[i] = p.k & 1; idx[i] = i; });
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3)); g.setAttribute('pano', new T.BufferAttribute(kind, 1)); g.setAttribute('idx', new T.BufferAttribute(idx, 1));
      const U = { atlas: { value: atlas(T) }, ex: { value: 1 }, pr: { value: 1 }, ppu: { value: 1000 }, sel: { value: -1 } };
      const m = new T.ShaderMaterial({ uniforms: U, transparent: true, depthWrite: false,
        vertexShader: `attribute float pano, idx; uniform float ex, pr, ppu, sel; varying float vP;
void main() { vec4 mv = modelViewMatrix * vec4(position.x, position.y * ex + 2.0, position.z, 1.0); float d = max(-mv.z, 1.0);
  float s = clamp(${SZ[0].toFixed(1)} / d, ${SZ[1].toFixed(1)}, ${SZ[2].toFixed(1)}) * (abs(idx - sel) < 0.5 ? 1.4 : 1.0); mv.y += s * 0.5 / ppu * d; vP = pano;
  gl_PointSize = s * pr; gl_Position = projectionMatrix * mv; }`,
        fragmentShader: `uniform sampler2D atlas; varying float vP; void main() { vec4 c = texture2D(atlas, vec2((gl_PointCoord.x + vP) * 0.5, 1.0 - gl_PointCoord.y)); if (c.a < 0.04) discard; gl_FragColor = c; }` });
      const pts = s.pts = new T.Points(g, m); pts.frustumCulled = false; pts.renderOrder = 7; s.U = U; s.M = -1;
      pts.onBeforeRender = (r, sc, cam) => { // the height scale and the surface (the pack replaces the coarse one) as they are now
        U.ex.value = v.mode === 'real' ? 1 : v.ex; U.pr.value = r.getPixelRatio(); U.ppu.value = r.domElement.clientHeight / (2 * Math.tan(cam.fov * Math.PI / 360)) || 1000;
        if (s.M !== v.M) { s.M = v.M; list.forEach((p, i) => { pos[i * 3 + 1] = v.ground(p.x, p.z); }); g.attributes.position.needsUpdate = true; }
      };
      v.scene.add(pts);
    }
    input(S, s, v);
  }
  function atlas(T) { // two icons side by side, 64 px each: the camera, the 360° sphere; white on a dark disc with a light rim
    const cv = Object.assign(document.createElement('canvas'), { width: 128, height: 64 }), g = cv.getContext('2d');
    [PHOTO, PANO].forEach((d, k) => { // u 0–0.5 a photo, 0.5–1 a 360° (the shader: (x + pano) / 2)
      g.setTransform(1, 0, 0, 1, k * 64, 0);
      g.beginPath(); g.arc(32, 32, 28, 0, 2 * Math.PI); g.fillStyle = 'rgba(28,28,28,.94)'; g.fill(); g.lineWidth = 3.5; g.strokeStyle = k ? '#ffffff' : 'rgba(200,200,200,.8)'; g.stroke();
      g.setTransform(1.75, 0, 0, 1.75, k * 64 + 32 - 21, 11); g.lineWidth = 1.9; g.lineCap = g.lineJoin = 'round'; g.strokeStyle = '#fff'; g.stroke(new Path2D(d));
    });
    const t = new T.CanvasTexture(cv); t.minFilter = T.LinearFilter; t.generateMipmaps = false;
    return t;
  }

  // taps: a marker within reach of the finger, else the land under it; a long press (0.55 s, still) the same
  function input(S, s, v) {
    const cv = v.renderer.domElement; let down = null, timer = 0;
    const at = (x, y) => { const r = cv.getBoundingClientRect(); return [x - r.left, y - r.top, r.width, r.height]; };
    cv.addEventListener('pointerdown', e => {
      if (!s.on || down) { down = null; clearTimeout(timer); return; } // a second finger: a pinch, not a tap
      down = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId };
      timer = setTimeout(() => { if (down) { const p = at(down.x, down.y); down = null; tap(S, s, v, p[0], p[1], p[2], p[3]); } }, 550);
    });
    cv.addEventListener('pointermove', e => { if (down && e.pointerId === down.id && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 8) { down = null; clearTimeout(timer); } });
    const up = e => {
      clearTimeout(timer);
      if (!down || e.pointerId !== down.id) return;
      const ok = e.type === 'pointerup' && performance.now() - down.t < 450 && Math.hypot(e.clientX - down.x, e.clientY - down.y) <= 8; down = null;
      if (ok && s.on) { const p = at(e.clientX, e.clientY); tap(S, s, v, p[0], p[1], p[2], p[3]); }
    };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  }
  function tap(S, s, v, px, py, w, h) {
    if (S.view !== v) return;
    const T = window.THREE, cam = v.camera, ex = v.mode === 'real' ? 1 : v.ex, q = new T.Vector3(), ppu = h / (2 * Math.tan(cam.fov * Math.PI / 360));
    let best = -1, bd = 1e9;
    (s.list || []).forEach((p, i) => { // the icon's centre on screen, as the vertex shader puts it
      q.set(p.x, v.ground(p.x, p.z) * ex + 2, p.z).applyMatrix4(cam.matrixWorldInverse); const d = -q.z; if (d <= 1) return;
      const sz = size(d); q.y += sz * .5 / ppu * d; q.applyMatrix4(cam.projectionMatrix);
      const dd = Math.hypot((q.x + 1) / 2 * w - px, (1 - q.y) / 2 * h - py);
      if (dd < Math.max(16, sz * .6 + 6) && dd < bd) { bd = dd; best = i; }
    });
    if (best >= 0) { card(S, s, s.list[best], best); return; }
    const g = ground(v, (px / w) * 2 - 1, 1 - (py / h) * 2, ex);
    if (!g) { card(S, s, null); return; }
    const B = v.V.B, span = v.span, lo = B.lo0 + (g.x / span + .5) * (B.lo1 - B.lo0), la = B.la1 - (g.z / span + .5) * (B.la1 - B.la0);
    card(S, s, { here: true, la, lo });
  }
  function ground(v, nx, ny, ex) { // where the ray under the finger meets the land or the sea's surface: marched, then halved; null over open sea
    const T = window.THREE, cam = v.camera, o = cam.position, dir = new T.Vector3(nx, ny, .5).unproject(cam).sub(o).normalize(), half = v.span / 2;
    const above = t => { const x = o.x + dir.x * t, z = o.z + dir.z * t; return o.y + dir.y * t - Math.max(v.ground(x, z) * ex, 0); };
    let t0 = 0, t = Math.max(1, cam.near);
    for (let n = 0; n < 4000 && above(t) > 0; n++) { t0 = t; t += Math.max(2, t * .01); if (t > v.span * 4) return null; }
    for (let k = 0; k < 14; k++) { const m = (t0 + t) / 2; if (above(m) > 0) t0 = m; else t = m; }
    const x = o.x + dir.x * t, z = o.z + dir.z * t;
    return Math.abs(x) < half && Math.abs(z) < half && v.ground(x, z) > -4 ? { x, z } : null; // land, or the shallows at its edge
  }

  // what a marker shows: its source, author, licence and date, its own page, and how to get its picture (url: null when none here)
  function info(s, p) {
    const d = s.d, src = p.k >> 1, pano = p.k & 1, r = src < 2 ? d.seq[p.ref] : d.com[p.ref], la = p.la.toFixed(6), lo = p.lo.toFixed(6);
    const hex = src === 0 && p.id ? [...atob(p.id.replace(/-/g, '+').replace(/_/g, '/'))].map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('') : '';
    const uuid = hex && `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`, tpl = src === 0 && d.tpl?.[r[5]];
    const wide = coarse() ? 2048 : 4096; // a 360° Commons picture's width: phones' memory
    return { src, pano, who: d.who[r[src < 2 ? 2 : 1]], lic: d.lic[r[src < 2 ? 3 : 2]], when: month(r[src < 2 ? 4 : 3]), file: src === 2 ? r[0].replace(/\.[a-z]+$/i, '') : '', head: p.h,
      own: src === 0 ? `https://api.panoramax.xyz/#focus=${uuid ? `pic&pic=${uuid}&` : 'map&'}map=19/${la}/${lo}`
        : src === 1 ? `https://kartaview.org/details/${encodeURIComponent(r[1])}/${p.id ?? 0}/track-info` : `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(r[0].replace(/ /g, '_'))}`,
      url: src === 0 ? tpl && uuid ? async () => tpl.replace('{p}', `${hex.slice(0, 2)}/${hex.slice(2, 4)}/${hex.slice(4, 6)}/${hex.slice(6, 8)}/${uuid.slice(9)}`) : null // the instance's 2048 px "sd" picture
        : src === 1 ? async () => { const j = await fetch(`https://api.kartaview.org/2.0/photo/?sequenceId=${encodeURIComponent(r[1])}&sequenceIndex=${p.id ?? 0}`).then(x => x.json()), q = j?.result?.data?.[0]; return q?.imageProcUrl || q?.fileurlProc; }
        : pano ? async () => (await fetch(`https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&origin=*&prop=imageinfo&iiprop=url&iiurlwidth=${wide}&titles=${encodeURIComponent('File:' + r[0])}`).then(x => x.json()))?.query?.pages?.[0]?.imageinfo?.[0]?.thumburl
        : async () => `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(r[0])}?width=1600` };
  }
  const coarse = () => matchMedia('(pointer: coarse)').matches;
  const credit = I => `${I.file ? `<b>${esc(I.file)}</b><br>` : ''}${esc([SRC[I.src], tr('sv_by', I.who), I.lic, I.when].filter(Boolean).join(' · '))}`;
  const kindOf = I => tr(I.pano ? (I.src < 2 ? 'sv_pano' : 'sv_cpano') : I.src < 2 ? 'sv_photo' : 'sv_cphoto');

  // the card: a marker's place, source, author, licence and date, a button for its picture here and its links; or the point tapped on the land
  function card(S, s, p, i = -1) {
    let el = S.el.querySelector('.sv-card');
    if (s.U) { s.U.sel.value = p && !p.here ? i : -1; S.view?.V.wake(); }
    s.cardP = p;
    if (!p) { if (el) el.hidden = true; return; }
    if (!el) {
      el = Object.assign(document.createElement('div'), { className: 'sv-card' }); el.setAttribute('role', 'dialog');
      el.addEventListener('click', e => { const b = e.target.closest('[data-sv]'); if (b?.dataset.sv === 'x') card(S, s, null); else if (b?.dataset.sv === 'view' && s.cardP) viewer(S, s, s.cardP); });
      S.el.querySelector('.a3-panel').before(el);
    }
    const where = esc(place(p.la, p.lo)), x = `<button type="button" class="sv-x" data-sv="x" aria-label="${esc(tr('sv_close'))}">${ic('close') || '×'}</button>`;
    let html;
    if (p.here) {
      html = `<div class="sv-hd"><span class="sv-ic">${svg(PANO)}</span><div class="sv-tt"><b>${esc(tr('sv_here'))}</b><small>${where}</small></div>${x}</div>
<p class="sv-meta">${esc(tr('sv_hereTxt'))}</p><div class="sv-acts">${link(gsv(p.la, p.lo), tr('sv_gsvHere'), true)}${link(mly(p.la, p.lo), tr('sv_mly'))}</div>`;
    } else {
      const I = info(s, p);
      html = `<div class="sv-hd"><span class="sv-ic">${svg(I.pano ? PANO : PHOTO)}</span><div class="sv-tt"><b>${esc(kindOf(I))}</b><small>${where}</small></div>${x}</div>
<p class="sv-meta">${credit(I)}</p>
<div class="sv-acts">${I.url ? `<button type="button" class="sv-btn main" data-sv="view">${svg(I.pano ? PANO : PHOTO)}${esc(tr(I.pano ? 'sv_view360' : 'sv_viewPhoto'))}</button>` : ''}${link(I.own, tr('sv_open', SRC[I.src]), !I.url)}${link(gsv(p.la, p.lo), tr('sv_gsv'))}${link(mly(p.la, p.lo), tr('sv_mly'))}</div>`;
    }
    el.innerHTML = html; el.setAttribute('aria-label', el.querySelector('.sv-tt b').textContent); el.hidden = false;
  }

  // the picture viewer, over the 3D view (which draws nothing meanwhile: view.paused): a 360° picture on the inside of a sphere, dragged
  // round and pinched (or the wheel) to zoom; a flat one fitted to the screen; its author and licence always at the foot. ‹, Back or Escape
  // return to the 3D view as it was.
  async function viewer(S, s, p) {
    const v = S.view, I = info(s, p); if (!v || !I.url) return;
    closeViewer(S, s);
    const el = Object.assign(document.createElement('div'), { className: 'sv-view' }); el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', kindOf(I));
    el.innerHTML = `<div class="sv-stage"></div>
<header class="sv-vtop"><button type="button" class="sv-x" data-sv="back" aria-label="${esc(tr('nav_back'))}">${ic('chevron-left') || '‹'}</button><div class="sv-tt"><b>${esc(kindOf(I))}</b><small>${esc(place(p.la, p.lo))}</small></div></header>
<div class="sv-vfoot">${I.pano ? `<p class="sv-vhint">${esc(tr('sv_drag'))}</p>` : ''}<p class="sv-meta">${credit(I)}</p><div class="sv-acts">${link(I.own, tr('sv_open', SRC[I.src]))}</div></div>
<div class="sv-msg" role="status"><span class="a3-spin"></span><span>${esc(tr('sv_loadingPic'))}</span></div>`;
    el.addEventListener('click', e => { if (e.target.closest('[data-sv="back"]')) closeViewer(S, s); });
    S.el.append(el); v.paused = true;
    const me = s.viewer = { el, stop: null };
    el.querySelector('[data-sv="back"]').focus({ preventScroll: true });
    try {
      const url = await I.url(); if (s.viewer !== me) return;
      if (!url) throw new Error('no picture');
      const fw = v.controls.target.clone().sub(v.camera.position), H = Math.atan2(fw.x, -fw.z) * 180 / Math.PI; // where the 3D view looks, ° from north
      me.stop = await (I.pano ? sphere(el, url, I.head != null ? 180 + H - I.head : 180) : photo(el, url));
      if (s.viewer !== me) { me.stop(); return; }
      el.querySelector('.sv-msg').hidden = true;
    } catch (e) {
      if (s.viewer !== me) return;
      console.warn('Psarema street view:', e?.message || e);
      el.querySelector('.sv-msg').innerHTML = `<span>${esc(tr('sv_failPic'))}</span>`;
    }
  }
  function closeViewer(S, s) {
    const me = s.viewer; if (!me) return false;
    s.viewer = null; me.stop?.(); me.el.remove();
    if (S.view) { S.view.paused = false; S.view.V.wake(); }
    S.el.querySelector('.sv-card [data-sv="view"]')?.focus({ preventScroll: true });
    return true;
  }
  function photo(el, url) { // resolves to its stop()
    return new Promise((ok, fail) => {
      const im = Object.assign(new Image(), { className: 'sv-img', alt: '', decoding: 'async', referrerPolicy: 'no-referrer' });
      im.onload = () => ok(() => { im.src = ''; }); im.onerror = () => fail(new Error('picture: ' + url));
      im.src = url; el.querySelector('.sv-stage').append(im);
    });
  }
  // an equirectangular picture inside a sphere: u = lon / 360 (lon 180: its middle, which faces "head"), drawn only when it moves
  function sphere(el, url, lon) {
    return new Promise((ok, fail) => {
      const T = window.THREE, stage = el.querySelector('.sv-stage'), r = new T.WebGLRenderer({ antialias: false }), cam = new T.PerspectiveCamera(75, 1, 1, 1100), sc = new T.Scene();
      r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); stage.append(r.domElement);
      const g = new T.SphereGeometry(500, 64, 32); g.scale(-1, 1, 1);
      const m = new T.MeshBasicMaterial(), ptr = new Map(), at = new T.Vector3();
      let lat = 0, raf = 0, w = 0, h = 0, tex = null, pinch = 0;
      const draw = () => {
        raf = 0;
        if (stage.clientWidth !== w || stage.clientHeight !== h) { w = stage.clientWidth; h = stage.clientHeight; r.setSize(w, h, false); cam.aspect = w / h || 1; cam.updateProjectionMatrix(); }
        const ph = (90 - lat) * Math.PI / 180, th = lon * Math.PI / 180;
        cam.lookAt(at.set(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th))); r.render(sc, cam);
      };
      const ask = () => { raf ||= requestAnimationFrame(draw); };
      const zoom = f => { cam.fov = Math.min(95, Math.max(25, cam.fov * f)); cam.updateProjectionMatrix(); ask(); };
      const cv = r.domElement, hint = el.querySelector('.sv-vhint');
      cv.addEventListener('pointerdown', e => { cv.setPointerCapture?.(e.pointerId); ptr.set(e.pointerId, [e.clientX, e.clientY]); pinch = 0; if (hint) hint.hidden = true; });
      cv.addEventListener('pointermove', e => {
        const q = ptr.get(e.pointerId); if (!q) return;
        if (ptr.size === 1) { const k = cam.fov / (h || 1); lon -= (e.clientX - q[0]) * k; lat = Math.max(-85, Math.min(85, lat + (e.clientY - q[1]) * k)); ask(); } // the picture follows the finger
        q[0] = e.clientX; q[1] = e.clientY;
        if (ptr.size === 2) { const [a, b] = [...ptr.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinch) zoom(pinch / d); pinch = d; }
      });
      const up = e => { ptr.delete(e.pointerId); pinch = 0; };
      cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
      cv.addEventListener('wheel', e => { e.preventDefault(); zoom(Math.exp(e.deltaY * .0012)); }, { passive: false });
      const ro = new ResizeObserver(ask); ro.observe(stage);
      const stop = () => { cancelAnimationFrame(raf); ro.disconnect(); tex?.dispose(); g.dispose(); m.dispose(); r.dispose(); r.forceContextLoss(); cv.remove(); };
      new T.TextureLoader().setCrossOrigin('anonymous').load(url, t => {
        tex = t; t.minFilter = T.LinearFilter; t.generateMipmaps = false; m.map = t; m.needsUpdate = true; sc.add(new T.Mesh(g, m)); draw(); ok(stop);
      }, undefined, () => { stop(); fail(new Error('picture: ' + url)); });
    });
  }

  // Back and Escape (js/area3d.js calls this before its own listeners): the viewer, then the card, close; the 3D view's history step stays
  function back(e) {
    const S = cur, s = S && ST.get(S);
    if (!s || !S.el.isConnected || !(closeViewer(S, s) || (s.cardP && (card(S, s, null), true)))) return;
    e.stopImmediatePropagation(); if (e.type === 'keydown') e.preventDefault();
    if (e.type === 'popstate') try { history.pushState({ ...(history.state || {}), psArea3d: 1 }, ''); } catch {}
  }

  window.PsArea3DStreet ||= { toggle, back }; // a second load (a quick double tap while the first was on its way) keeps the first one's state
})();
