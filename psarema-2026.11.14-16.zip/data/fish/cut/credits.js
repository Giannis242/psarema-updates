// Fish cut-outs: Wikimedia Commons photos with the background removed (derivatives keep the source licence).
window.PSAREMA_FISH_CUT = {
 "sargos": {
  "file": "data/fish/cut/sargos.png",
  "title": "File:Sargo común (Diplodus sargus), Madeira, Portugal, 2019-05-31, DD 29.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargo_com%C3%BAn_(Diplodus_sargus),_Madeira,_Portugal,_2019-05-31,_DD_29.jpg",
  "derived": "background removed"
 },
 "tsipoura": {
  "file": "data/fish/cut/tsipoura.png",
  "title": "File:Sparus aurata Sardegna.jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sparus_aurata_Sardegna.jpg",
  "derived": "background removed"
 },
 "grouper": {
  "file": "data/fish/cut/grouper.png",
  "title": "File:Mero (Epinephelus marginatus), Madeira, Portugal, 2019-05-31, DD 24.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mero_(Epinephelus_marginatus),_Madeira,_Portugal,_2019-05-31,_DD_24.jpg",
  "derived": "background removed"
 },
 "dentex": {
  "file": "data/fish/cut/dentex.png",
  "title": "File:Dentex dentex Canary.jpg",
  "author": "michael_bommerer",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dentex_dentex_Canary.jpg",
  "derived": "background removed"
 },
 "amberjack": {
  "file": "data/fish/cut/amberjack.png",
  "title": "File:Seriola dumerili - Sanc2431.jpg",
  "author": "NOAA Photo Library",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Seriola_dumerili_-_Sanc2431.jpg",
  "derived": "background removed"
 },
 "dolphinfish": {
  "file": "data/fish/cut/dolphinfish.png",
  "title": "File:Coryphène commune (Coryphaena hippurus) (Ifremer 00763-87546).jpg",
  "author": "Hugues Evano (IFREMER)",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Coryph%C3%A8ne_commune_(Coryphaena_hippurus)_(Ifremer_00763-87546).jpg",
  "derived": "background removed"
 },
 "albacore": {
  "file": "data/fish/cut/albacore.png",
  "title": "File:Thon germon (Thunnus alalunga) (Ifremer 00764-87615).jpg",
  "author": "Hugues Evano (IFREMER)",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Thon_germon_(Thunnus_alalunga)_(Ifremer_00764-87615).jpg",
  "derived": "background removed"
 },
 "leerfish": {
  "file": "data/fish/cut/leerfish.png",
  "title": "File:Lichia amia 1.jpg",
  "author": "Brian Gratwicke",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Lichia_amia_1.jpg",
  "derived": "background removed"
 },
 "barracuda": {
  "file": "data/fish/cut/barracuda.png",
  "title": "File:Sphyraena sphyraena.jpg",
  "author": "Etrusko25",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sphyraena_sphyraena.jpg",
  "derived": "background removed"
 },
 "parrotfish": {
  "file": "data/fish/cut/parrotfish.png",
  "title": "File:Sparisoma cretense.jpg",
  "author": "Fernando Herranz Martín",
  "license": "CC BY-SA 2.5 es",
  "url": "https://commons.wikimedia.org/wiki/File:Sparisoma_cretense.jpg",
  "derived": "background removed"
 },
 "rabbitfish": {
  "file": "data/fish/cut/rabbitfish.png",
  "title": "File:Sigano jaspeado (Siganus rivulatus), Yeda, Arabia Saudita, 2025-05-19, DD 86.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sigano_jaspeado_(Siganus_rivulatus),_Yeda,_Arabia_Saudita,_2025-05-19,_DD_86.jpg",
  "derived": "background removed"
 },
 "lionfish": {
  "file": "data/fish/cut/lionfish.png",
  "title": "File:Common lionfish at Shaab El Erg reef.JPG",
  "author": "Alexander Vasenin",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Common_lionfish_at_Shaab_El_Erg_reef.JPG",
  "derived": "background removed"
 },
 "squid": {
  "file": "data/fish/cut/squid.png",
  "title": "File:Loligo vulgaris.jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Loligo_vulgaris.jpg",
  "derived": "background removed"
 },
 "cuttlefish": {
  "file": "data/fish/cut/cuttlefish.png",
  "title": "File:Sepia común (Sepia officinalis), Parque natural de la Arrábida, Portugal, 2020-07-21, DD 62.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sepia_com%C3%BAn_(Sepia_officinalis),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2020-07-21,_DD_62.jpg",
  "derived": "background removed"
 },
 "octopus": {
  "file": "data/fish/cut/octopus.png",
  "title": "File:Octopus vulgaris2.jpg",
  "author": "Beckmannjan",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Octopus_vulgaris2.jpg",
  "derived": "background removed"
 },
 "twoband": {
  "file": "data/fish/cut/twoband.png",
  "title": "File:Mojarra (Diplodus vulgaris), Cabo de Palos, España, 2022-07-15, DD 20.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mojarra_(Diplodus_vulgaris),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-15,_DD_20.jpg",
  "derived": "background removed"
 },
 "annular": {
  "file": "data/fish/cut/annular.png",
  "title": "File:Diplodus annularis Minorca.jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Diplodus_annularis_Minorca.jpg",
  "derived": "background removed"
 },
 "sharpsnout": {
  "file": "data/fish/cut/sharpsnout.png",
  "title": "File:Sargo picudo (Diplodus puntazzo), Cabo de Palos, España, 2022-07-16, DD 46.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargo_picudo_(Diplodus_puntazzo),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-16,_DD_46.jpg",
  "derived": "background removed"
 },
 "melanouri": {
  "file": "data/fish/cut/melanouri.png",
  "title": "File:Oblada (Oblada melanura), Ċirkewwa, Malta, Malta, 2021-08-24, DD 26.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Oblada_(Oblada_melanura),_%C4%8Airkewwa,_Malta,_Malta,_2021-08-24,_DD_26.jpg",
  "derived": "background removed"
 },
 "salema": {
  "file": "data/fish/cut/salema.png",
  "title": "File:Salema (Sarpa salpa), Catania, Sicilia, Italia, 2025-04-04, DD 90.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Salema_(Sarpa_salpa),_Catania,_Sicilia,_Italia,_2025-04-04,_DD_90.jpg",
  "derived": "background removed"
 },
 "bogue": {
  "file": "data/fish/cut/bogue.png",
  "title": "File:Boga (Boops boops), franja marina Teno-Rasca, Tenerife, España, 2022-01-08, DD 99.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Boga_(Boops_boops),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-08,_DD_99.jpg",
  "derived": "background removed"
 },
 "porgy": {
  "file": "data/fish/cut/porgy.png",
  "title": "File:Pagrus pagrus 20-10-06.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Pagrus_pagrus_20-10-06.jpg",
  "derived": "background removed"
 },
 "pandora": {
  "file": "data/fish/cut/pandora.png",
  "title": "File:Pagellus erythrinus - Julien Renoult - 585827535.jpeg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pagellus_erythrinus_-_Julien_Renoult_-_585827535.jpeg",
  "derived": "background removed"
 },
 "blackbream": {
  "file": "data/fish/cut/blackbream.png",
  "title": "File:Spondyliosoma cantharus.jpg",
  "author": "Gronk",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Spondyliosoma_cantharus.jpg",
  "derived": "background removed"
 },
 "redmullet": {
  "file": "data/fish/cut/redmullet.png",
  "title": "File:Mullus barbatus - Julien Renoult - 585826858.jpeg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mullus_barbatus_-_Julien_Renoult_-_585826858.jpeg",
  "derived": "background removed"
 },
 "surmullet": {
  "file": "data/fish/cut/surmullet.png",
  "title": "File:Mullus surmuletus.jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mullus_surmuletus.jpg",
  "derived": "background removed"
 },
 "greymullet": {
  "file": "data/fish/cut/greymullet.png",
  "title": "File:Mugil cephalus Minorca (cropped).jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mugil_cephalus_Minorca_(cropped).jpg",
  "derived": "background removed"
 },
 "meagre": {
  "file": "data/fish/cut/meagre.png",
  "title": "File:Corvina negra (Sciaena umbra), Regga, Gozo, Malta, 2021-08-23, DD 19.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Corvina_negra_(Sciaena_umbra),_Regga,_Gozo,_Malta,_2021-08-23,_DD_19.jpg",
  "derived": "background removed"
 },
 "seabass": {
  "file": "data/fish/cut/seabass.png",
  "title": "File:Dicentrarchus labrax LoroParqueTenerife seabass IMG 4959.JPG",
  "author": "Bjoertvedt",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dicentrarchus_labrax_LoroParqueTenerife_seabass_IMG_4959.JPG",
  "derived": "background removed"
 },
 "goatfish": {
  "file": "data/fish/cut/goatfish.png",
  "title": "File:Parupeneus forsskali - Libby Keatley - 602015885.jpeg",
  "author": "Libby Keatley",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Parupeneus_forsskali_-_Libby_Keatley_-_602015885.jpeg",
  "derived": "background removed"
 },
 "littletunny": {
  "file": "data/fish/cut/littletunny.png",
  "title": "File:Euthynnus alletteratus Italy 01.JPG",
  "author": "Etrusko25",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Euthynnus_alletteratus_Italy_01.JPG",
  "derived": "background removed"
 },
 "bonito": {
  "file": "data/fish/cut/bonito.png",
  "title": "File:Sarda sarda 1.jpg",
  "author": "Etrusko25",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sarda_sarda_1.jpg",
  "derived": "background removed"
 },
 "bluefish": {
  "file": "data/fish/cut/bluefish.png",
  "title": "File:Fish4397 - Flickr - NOAA Photo Library.jpg",
  "author": "SEFSC Pascagoula Laboratory; Collection of Brandi Noble, NOAA/NMFS/SEFSC.",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Fish4397_-_Flickr_-_NOAA_Photo_Library.jpg",
  "derived": "background removed"
 },
 "horsemackerel": {
  "file": "data/fish/cut/horsemackerel.png",
  "title": "File:Jurel blanco o mediterráneo (Trachurus mediterraneus).jpeg",
  "author": "Foundling",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Jurel_blanco_o_mediterr%C3%A1neo_(Trachurus_mediterraneus).jpeg",
  "derived": "background removed"
 },
 "mackerel": {
  "file": "data/fish/cut/mackerel.png",
  "title": "File:Scomber colias.jpg",
  "author": "Etrusko25",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Scomber_colias.jpg",
  "derived": "background removed"
 },
 "garfish": {
  "file": "data/fish/cut/garfish.png",
  "title": "File:Belone belone - Garfish.jpg",
  "author": "Zeynel Cebeci",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Belone_belone_-_Garfish.jpg",
  "derived": "background removed"
 },
 "pompano": {
  "file": "data/fish/cut/pompano.png",
  "title": "File:Trachinotus ovatus Alonissos.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Trachinotus_ovatus_Alonissos.jpg",
  "derived": "background removed"
 },
 "swordfish": {
  "file": "data/fish/cut/swordfish.png",
  "title": "File:Swordfish-0016.png",
  "author": "User:Citron; derivative by User:MathKnight",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Swordfish-0016.png",
  "derived": "background removed"
 },
 "cornetfish": {
  "file": "data/fish/cut/cornetfish.png",
  "title": "File:Cornetfish - Fistularia commersonii.jpg",
  "author": "Francois Libert",
  "license": "CC BY-SA 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Cornetfish_-_Fistularia_commersonii.jpg",
  "derived": "background removed"
 },
 "shortfinsquid": {
  "file": "data/fish/cut/shortfinsquid.png",
  "title": "File:Encornet rouge (Illex coindetii) (Ifremer 00710-82219 - 35063).jpg",
  "author": "Isabelle Cheret (IFREMER)",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Encornet_rouge_(Illex_coindetii)_(Ifremer_00710-82219_-_35063).jpg",
  "derived": "background removed"
 },
 "whitegrouper": {
  "file": "data/fish/cut/whitegrouper.png",
  "title": "File:Epinephelus aeneus Greece.jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Epinephelus_aeneus_Greece.jpg",
  "derived": "background removed"
 },
 "goldblotch": {
  "file": "data/fish/cut/goldblotch.png",
  "title": "File:Falso abadejo (Epinephelus costae), Cabo de Palos, España, 2022-07-15, DD 22.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Falso_abadejo_(Epinephelus_costae),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-15,_DD_22.jpg",
  "derived": "background removed"
 },
 "mottledgrouper": {
  "file": "data/fish/cut/mottledgrouper.png",
  "title": "File:Abadejo rojo (Mycteroperca rubra), Regga, Gozo, Malta, 2021-08-23, DD 07.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Abadejo_rojo_(Mycteroperca_rubra),_Regga,_Gozo,_Malta,_2021-08-23,_DD_07.jpg",
  "derived": "background removed"
 },
 "comber": {
  "file": "data/fish/cut/comber.png",
  "title": "File:Pez cabra (Serranus cabrilla), Parque natural de la Arrábida, Portugal, 2021-09-09, DD 52.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_cabra_(Serranus_cabrilla),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2021-09-09,_DD_52.jpg",
  "derived": "background removed"
 },
 "paintedcomber": {
  "file": "data/fish/cut/paintedcomber.png",
  "title": "File:Serranus scriba Greece.jpg",
  "author": "shaharchaikin",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Serranus_scriba_Greece.jpg",
  "derived": "background removed"
 },
 "scorpionfish": {
  "file": "data/fish/cut/scorpionfish.png",
  "title": "File:Red Scorpionfish.jpg",
  "author": "Vicmicallef",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Red_Scorpionfish.jpg",
  "derived": "background removed"
 },
 "blackscorpion": {
  "file": "data/fish/cut/blackscorpion.png",
  "title": "File:Brauner Drachenkopf - 6615.jpg",
  "author": "Amada44",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Brauner_Drachenkopf_-_6615.jpg",
  "derived": "background removed"
 },
 "moray": {
  "file": "data/fish/cut/moray.png",
  "title": "File:Mediterranean moray (Muraena helena), Tunisia 2022-07-18 01.jpg",
  "author": "Houss 2020",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mediterranean_moray_(Muraena_helena),_Tunisia_2022-07-18_01.jpg",
  "derived": "background removed"
 },
 "conger": {
  "file": "data/fish/cut/conger.png",
  "title": "File:Conger conger 222980675.jpg",
  "author": "vtzanatos",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Conger_conger_222980675.jpg",
  "derived": "background removed"
 },
 "rainbowwrasse": {
  "file": "data/fish/cut/rainbowwrasse.png",
  "title": "File:Coris julis 14-07-05 female.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Coris_julis_14-07-05_female.jpg",
  "derived": "background removed"
 },
 "ornatewrasse": {
  "file": "data/fish/cut/ornatewrasse.png",
  "title": "File:Female Thalassoma pavo.JPG",
  "author": "Matthieu Sontag (User:Mirgolth)",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Female_Thalassoma_pavo.JPG",
  "derived": "background removed"
 },
 "squirrelfish": {
  "file": "data/fish/cut/squirrelfish.png",
  "title": "File:Sargocentron rubrum.jpg",
  "author": "Matthieu Sontag (User:Mirgolth)",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargocentron_rubrum.jpg",
  "derived": "background removed"
 },
 "leatherjacket": {
  "file": "data/fish/cut/leatherjacket.png",
  "title": "File:Stephanolepis diaspros 222159502 (cropped).jpg",
  "author": "Sarah Faulwetter",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Stephanolepis_diaspros_222159502_(cropped).jpg",
  "derived": "background removed"
 },
 "toadfish": {
  "file": "data/fish/cut/toadfish.png",
  "title": "File:Lagokefalos Koroni.jpg",
  "author": "Theaviator",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Lagokefalos_Koroni.jpg",
  "derived": "background removed"
 },
 "weever": {
  "file": "data/fish/cut/weever.png",
  "title": "File:Trachinus draco Stefano Guerrieri.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Trachinus_draco_Stefano_Guerrieri.jpg",
  "derived": "background removed"
 }
};
// >>> round 11 species inventory (eval/species-inventory/new-species.mjs): do not edit by hand
Object.assign(window.PSAREMA_FISH_CUT, {
 "stripedbream": {
  "file": "data/fish/cut/stripedbream.png",
  "title": "File:Pez herrera (Lithognathus mormyrus), franja marina Teno-Rasca, Tenerife, España, 2022-01-06, DD 38.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_herrera_(Lithognathus_mormyrus),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-06,_DD_38.jpg",
  "derived": "background removed"
 },
 "picarel": {
  "file": "data/fish/cut/picarel.png",
  "title": "File:Spicara smaris 166033799.jpg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Spicara_smaris_166033799.jpg",
  "derived": "background removed"
 },
 "axillary": {
  "file": "data/fish/cut/axillary.png",
  "title": "File:Aligote (Pagellus acarne).JPG",
  "author": "Foundling",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Aligote_(Pagellus_acarne).JPG",
  "derived": "background removed"
 },
 "bluerunner": {
  "file": "data/fish/cut/bluerunner.png",
  "title": "File:Caranx crysos (S0909) (12599879365).jpg",
  "author": "Smithsonian Environmental Research Center",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Caranx_crysos_(S0909)_(12599879365).jpg",
  "derived": "background removed"
 },
 "triggerfish": {
  "file": "data/fish/cut/triggerfish.png",
  "title": "File:Pez ballesta (Balistes capriscus), Parque natural de la Arrábida, Portugal, 2020-07-31, DD 27.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_ballesta_(Balistes_capriscus),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2020-07-31,_DD_27.jpg",
  "derived": "background removed"
 },
 "razorfish": {
  "file": "data/fish/cut/razorfish.png",
  "title": "File:Pez peine (Xyrichtys novacula), franja marina Teno-Rasca, Tenerife, España, 2022-01-09, DD 33.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_peine_(Xyrichtys_novacula),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-09,_DD_33.jpg",
  "derived": "background removed"
 },
 "shidrum": {
  "file": "data/fish/cut/shidrum.png",
  "title": "File:Umbrina cirrosa ro.jpg",
  "author": "Rvalette",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Umbrina_cirrosa_ro.jpg",
  "derived": "background removed"
 },
 "bluefin": {
  "file": "data/fish/cut/bluefin.png",
  "title": "File:Bluefin-big.jpg",
  "author": "Unknown authorUnknown author",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Bluefin-big.jpg",
  "derived": "background removed"
 },
 "bullettuna": {
  "file": "data/fish/cut/bullettuna.png",
  "title": "File:Auxis rochei (USNM-403144).jpg",
  "author": "The U.S. Food and Drug Administration",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Auxis_rochei_(USNM-403144).jpg",
  "derived": "background removed"
 },
 "damselfish": {
  "file": "data/fish/cut/damselfish.png",
  "title": "File:Castañuela (Chromis chromis), Catania, Sicilia, Italia, 2025-04-04, DD 60.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Casta%C3%B1uela_(Chromis_chromis),_Catania,_Sicilia,_Italia,_2025-04-04,_DD_60.jpg",
  "derived": "background removed"
 },
 "lizardfish": {
  "file": "data/fish/cut/lizardfish.png",
  "title": "File:Synodus saurus France.jpg",
  "author": "jujurenoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Synodus_saurus_France.jpg",
  "derived": "background removed"
 },
 "stargazer": {
  "file": "data/fish/cut/stargazer.png",
  "title": "File:Uranoscopus scaber 1.jpg",
  "author": "Georges Cuvier",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Uranoscopus_scaber_1.jpg",
  "derived": "background removed"
 },
 "peacockwrasse": {
  "file": "data/fish/cut/peacockwrasse.png",
  "title": "File:Tordo (Symphodus tinca), Catania, Sicilia, Italia, 2025-04-05, DD 26.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Tordo_(Symphodus_tinca),_Catania,_Sicilia,_Italia,_2025-04-05,_DD_26.jpg",
  "derived": "background removed"
 },
 "yellowpuffer": {
  "file": "data/fish/cut/yellowpuffer.png",
  "title": "File:Tetraodóntido (Torquigener flavimaculosus), Pistol Bay, Pafos, Chipre, 2021-12-12, DD 11.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Tetraod%C3%B3ntido_(Torquigener_flavimaculosus),_Pistol_Bay,_Pafos,_Chipre,_2021-12-12,_DD_11.jpg",
  "derived": "background removed"
 },
 "stingray": {
  "file": "data/fish/cut/stingray.png",
  "title": "File:Dasyatis pastinaca 24933880.jpg",
  "author": "Chris Taklis",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dasyatis_pastinaca_24933880.jpg",
  "derived": "background removed"
 },
 "electricray": {
  "file": "data/fish/cut/electricray.png",
  "title": "File:Torpedo marmorata2.jpg",
  "author": "Philippe Guillaume",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Torpedo_marmorata2.jpg",
  "derived": "background removed"
 },
 "guitarfish": {
  "file": "data/fish/cut/guitarfish.png",
  "title": "File:Rhinobatos Rhinobatos.jpg",
  "author": "Esquilo",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Rhinobatos_Rhinobatos.jpg",
  "derived": "background removed"
 },
 "thornback": {
  "file": "data/fish/cut/thornback.png",
  "title": "File:Raja clavata (juv).jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Raja_clavata_(juv).jpg",
  "derived": "background removed"
 },
 "reefsquid": {
  "file": "data/fish/cut/reefsquid.png",
  "title": "File:Calamar de arrecifes (Sepioteuthis lessoniana), Nosy Iranja, Madagascar, 2025-09-17, DD 90.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Calamar_de_arrecifes_(Sepioteuthis_lessoniana),_Nosy_Iranja,_Madagascar,_2025-09-17,_DD_90.jpg",
  "derived": "background removed"
 }
});
// <<< round 11 species inventory
