// Fish photos from Wikimedia Commons; see each entry for author, licence and source page.
window.PSAREMA_FISH_IMG = {
 "sargos": {
  "file": "data/fish/sargos.jpg",
  "title": "File:Sargo común (Diplodus sargus), Madeira, Portugal, 2019-05-31, DD 29.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargo_com%C3%BAn_(Diplodus_sargus),_Madeira,_Portugal,_2019-05-31,_DD_29.jpg"
 },
 "tsipoura": {
  "file": "data/fish/tsipoura.jpg",
  "title": "File:SardinianFish.jpg",
  "author": "David Blaikie",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:SardinianFish.jpg"
 },
 "grouper": {
  "file": "data/fish/grouper.jpg",
  "title": "File:Mero (Epinephelus marginatus), Madeira, Portugal, 2019-05-31, DD 24.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mero_(Epinephelus_marginatus),_Madeira,_Portugal,_2019-05-31,_DD_24.jpg"
 },
 "dentex": {
  "file": "data/fish/dentex.jpg",
  "title": "File:Dentex dentex Canary.jpg",
  "author": "michael_bommerer",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dentex_dentex_Canary.jpg"
 },
 "amberjack": {
  "file": "data/fish/amberjack.jpg",
  "title": "File:Seriola dumerili - Sanc2431.jpg",
  "author": "NOAA Photo Library",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Seriola_dumerili_-_Sanc2431.jpg"
 },
 "dolphinfish": {
  "file": "data/fish/dolphinfish.jpg",
  "title": "File:Female Dolphin Fish.jpg",
  "author": "Distad",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Female_Dolphin_Fish.jpg"
 },
 "albacore": {
  "file": "data/fish/albacore.jpg",
  "title": "File:Thon germon (Thunnus alalunga) (Ifremer 00764-87615).jpg",
  "author": "Hugues Evano (IFREMER)",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Thon_germon_(Thunnus_alalunga)_(Ifremer_00764-87615).jpg"
 },
 "leerfish": {
  "file": "data/fish/leerfish.jpg",
  "title": "File:Lichia amia 1.jpg",
  "author": "Brian Gratwicke",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Lichia_amia_1.jpg"
 },
 "barracuda": {
  "file": "data/fish/barracuda.jpg",
  "title": "File:Sphyraena sphyraena.jpg",
  "author": "Etrusko25",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sphyraena_sphyraena.jpg"
 },
 "parrotfish": {
  "file": "data/fish/parrotfish.jpg",
  "title": "File:Sparisoma cretense.jpg",
  "author": "Fernando Herranz Martín",
  "license": "CC BY-SA 2.5 es",
  "url": "https://commons.wikimedia.org/wiki/File:Sparisoma_cretense.jpg"
 },
 "rabbitfish": {
  "file": "data/fish/rabbitfish.jpg",
  "title": "File:Sigano jaspeado (Siganus rivulatus), Yeda, Arabia Saudita, 2025-05-19, DD 86.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sigano_jaspeado_(Siganus_rivulatus),_Yeda,_Arabia_Saudita,_2025-05-19,_DD_86.jpg"
 },
 "lionfish": {
  "file": "data/fish/lionfish.jpg",
  "title": "File:Common lionfish at Shaab El Erg reef.JPG",
  "author": "Alexander Vasenin",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Common_lionfish_at_Shaab_El_Erg_reef.JPG"
 },
 "squid": {
  "file": "data/fish/squid.jpg",
  "title": "File:Loligo vulgaris.jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Loligo_vulgaris.jpg"
 },
 "cuttlefish": {
  "file": "data/fish/cuttlefish.jpg",
  "title": "File:Sepia común (Sepia officinalis), Parque natural de la Arrábida, Portugal, 2020-07-21, DD 62.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sepia_com%C3%BAn_(Sepia_officinalis),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2020-07-21,_DD_62.jpg"
 },
 "octopus": {
  "file": "data/fish/octopus.jpg",
  "title": "File:Octopus vulgaris2.jpg",
  "author": "Beckmannjan",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Octopus_vulgaris2.jpg"
 },
 "twoband": {
  "file": "data/fish/twoband.jpg",
  "title": "File:Diplodus vulgaris.jpg",
  "author": "Anders Finn Jørgensen from Copenhagen, Denmark",
  "license": "CC BY-SA 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Diplodus_vulgaris.jpg"
 },
 "annular": {
  "file": "data/fish/annular.jpg",
  "title": "File:Diplodus annularis Minorca.jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Diplodus_annularis_Minorca.jpg"
 },
 "sharpsnout": {
  "file": "data/fish/sharpsnout.jpg",
  "title": "File:Sargo picudo (Diplodus puntazzo), Cabo de Palos, España, 2022-07-16, DD 46.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargo_picudo_(Diplodus_puntazzo),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-16,_DD_46.jpg"
 },
 "melanouri": {
  "file": "data/fish/melanouri.jpg",
  "title": "File:Oblada (Oblada melanura), Ċirkewwa, Malta, Malta, 2021-08-24, DD 26.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Oblada_(Oblada_melanura),_%C4%8Airkewwa,_Malta,_Malta,_2021-08-24,_DD_26.jpg"
 },
 "salema": {
  "file": "data/fish/salema.jpg",
  "title": "File:Salema (Sarpa salpa), Catania, Sicilia, Italia, 2025-04-04, DD 90.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Salema_(Sarpa_salpa),_Catania,_Sicilia,_Italia,_2025-04-04,_DD_90.jpg"
 },
 "bogue": {
  "file": "data/fish/bogue.jpg",
  "title": "File:Boga (Boops boops), franja marina Teno-Rasca, Tenerife, España, 2022-01-08, DD 99.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Boga_(Boops_boops),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-08,_DD_99.jpg"
 },
 "porgy": {
  "file": "data/fish/porgy.jpg",
  "title": "File:Pagrus pagrus 20-10-06.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Pagrus_pagrus_20-10-06.jpg"
 },
 "pandora": {
  "file": "data/fish/pandora.jpg",
  "title": "File:Pagellus erythrinus - Julien Renoult - 585827535.jpeg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pagellus_erythrinus_-_Julien_Renoult_-_585827535.jpeg"
 },
 "blackbream": {
  "file": "data/fish/blackbream.jpg",
  "title": "File:Spondyliosoma cantharus.jpg",
  "author": "Gronk",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Spondyliosoma_cantharus.jpg"
 },
 "redmullet": {
  "file": "data/fish/redmullet.jpg",
  "title": "File:Mullus barbatus - Julien Renoult - 585826858.jpeg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mullus_barbatus_-_Julien_Renoult_-_585826858.jpeg"
 },
 "surmullet": {
  "file": "data/fish/surmullet.jpg",
  "title": "File:Mullus surmuletus.jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mullus_surmuletus.jpg"
 },
 "greymullet": {
  "file": "data/fish/greymullet.jpg",
  "title": "File:Mugil cephalus Minorca (cropped).jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Mugil_cephalus_Minorca_(cropped).jpg"
 },
 "meagre": {
  "file": "data/fish/meagre.jpg",
  "title": "File:Corvinas negras (Sciaena umbra), Cabo de Palos, España, 2022-07-14, DD 52.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Corvinas_negras_(Sciaena_umbra),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-14,_DD_52.jpg"
 },
 "seabass": {
  "file": "data/fish/seabass.jpg",
  "title": "File:Dicentrarchus labrax LoroParqueTenerife seabass IMG 4959.JPG",
  "author": "Bjoertvedt",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dicentrarchus_labrax_LoroParqueTenerife_seabass_IMG_4959.JPG"
 },
 "goatfish": {
  "file": "data/fish/goatfish.jpg",
  "title": "File:Parupeneus forsskali - Libby Keatley - 602015885.jpeg",
  "author": "Libby Keatley",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Parupeneus_forsskali_-_Libby_Keatley_-_602015885.jpeg"
 },
 "littletunny": {
  "file": "data/fish/littletunny.jpg",
  "title": "File:Euthynnus alletteratus Italy 01.JPG",
  "author": "Etrusko25",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Euthynnus_alletteratus_Italy_01.JPG"
 },
 "bonito": {
  "file": "data/fish/bonito.jpg",
  "title": "File:Sarda sarda 1.jpg",
  "author": "Etrusko25",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sarda_sarda_1.jpg"
 },
 "bluefish": {
  "file": "data/fish/bluefish.jpg",
  "title": "File:Fish4397 - Flickr - NOAA Photo Library.jpg",
  "author": "SEFSC Pascagoula Laboratory; Collection of Brandi Noble, NOAA/NMFS/SEFSC.",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Fish4397_-_Flickr_-_NOAA_Photo_Library.jpg"
 },
 "horsemackerel": {
  "file": "data/fish/horsemackerel.jpg",
  "title": "File:Jurel blanco o mediterráneo (Trachurus mediterraneus).jpeg",
  "author": "Foundling",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Jurel_blanco_o_mediterr%C3%A1neo_(Trachurus_mediterraneus).jpeg"
 },
 "mackerel": {
  "file": "data/fish/mackerel.jpg",
  "title": "File:Lanzardo 2.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Lanzardo_2.jpg"
 },
 "garfish": {
  "file": "data/fish/garfish.jpg",
  "title": "File:Belone belone - Garfish.jpg",
  "author": "Zeynel Cebeci",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Belone_belone_-_Garfish.jpg"
 },
 "pompano": {
  "file": "data/fish/pompano.jpg",
  "title": "File:Trachinotus ovatus Alonissos.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Trachinotus_ovatus_Alonissos.jpg"
 },
 "swordfish": {
  "file": "data/fish/swordfish.png",
  "title": "File:Swordfish-0016.png",
  "author": "User:Citron; derivative by User:MathKnight",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Swordfish-0016.png"
 },
 "cornetfish": {
  "file": "data/fish/cornetfish.jpg",
  "title": "File:Cornetfish - Fistularia commersonii.jpg",
  "author": "Francois Libert",
  "license": "CC BY-SA 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Cornetfish_-_Fistularia_commersonii.jpg"
 },
 "shortfinsquid": {
  "file": "data/fish/shortfinsquid.jpg",
  "title": "File:Encornet rouge (Illex coindetii) (Ifremer 00710-82219 - 35063).jpg",
  "author": "Isabelle Cheret (IFREMER)",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Encornet_rouge_(Illex_coindetii)_(Ifremer_00710-82219_-_35063).jpg"
 },
 "whitegrouper": {
  "file": "data/fish/whitegrouper.jpg",
  "title": "File:Epinephelus aeneus Greece.jpg",
  "author": "Roberto Pillon",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Epinephelus_aeneus_Greece.jpg"
 },
 "goldblotch": {
  "file": "data/fish/goldblotch.jpg",
  "title": "File:Falso abadejo (Epinephelus costae), Cabo de Palos, España, 2022-07-15, DD 22.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Falso_abadejo_(Epinephelus_costae),_Cabo_de_Palos,_Espa%C3%B1a,_2022-07-15,_DD_22.jpg"
 },
 "mottledgrouper": {
  "file": "data/fish/mottledgrouper.jpg",
  "title": "File:Abadejo rojo (Mycteroperca rubra), Regga, Gozo, Malta, 2021-08-23, DD 07.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Abadejo_rojo_(Mycteroperca_rubra),_Regga,_Gozo,_Malta,_2021-08-23,_DD_07.jpg"
 },
 "comber": {
  "file": "data/fish/comber.jpg",
  "title": "File:Pez cabra (Serranus cabrilla), Parque natural de la Arrábida, Portugal, 2021-09-09, DD 52.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_cabra_(Serranus_cabrilla),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2021-09-09,_DD_52.jpg"
 },
 "paintedcomber": {
  "file": "data/fish/paintedcomber.jpg",
  "title": "File:Serranus scriba Greece.jpg",
  "author": "shaharchaikin",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Serranus_scriba_Greece.jpg"
 },
 "scorpionfish": {
  "file": "data/fish/scorpionfish.jpg",
  "title": "File:Red Scorpionfish.jpg",
  "author": "Vicmicallef",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Red_Scorpionfish.jpg"
 },
 "blackscorpion": {
  "file": "data/fish/blackscorpion.jpg",
  "title": "File:Brauner Drachenkopf - 6615.jpg",
  "author": "Amada44",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Brauner_Drachenkopf_-_6615.jpg"
 },
 "moray": {
  "file": "data/fish/moray.jpg",
  "title": "File:Morena del Mediterráneo (Muraena helena), Regga, Gozo, Malta, 2021-08-23, DD 14.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Morena_del_Mediterr%C3%A1neo_(Muraena_helena),_Regga,_Gozo,_Malta,_2021-08-23,_DD_14.jpg"
 },
 "conger": {
  "file": "data/fish/conger.jpg",
  "title": "File:Meeraal Conger conger 1.jpg",
  "author": "Holger Krisp",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Meeraal_Conger_conger_1.jpg"
 },
 "rainbowwrasse": {
  "file": "data/fish/rainbowwrasse.jpg",
  "title": "File:Coris julis 14-07-05 female.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Coris_julis_14-07-05_female.jpg"
 },
 "ornatewrasse": {
  "file": "data/fish/ornatewrasse.jpg",
  "title": "File:Female Thalassoma pavo.JPG",
  "author": "Matthieu Sontag (User:Mirgolth)",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Female_Thalassoma_pavo.JPG"
 },
 "squirrelfish": {
  "file": "data/fish/squirrelfish.jpg",
  "title": "File:Sargocentron rubrum.jpg",
  "author": "Matthieu Sontag (User:Mirgolth)",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Sargocentron_rubrum.jpg"
 },
 "leatherjacket": {
  "file": "data/fish/leatherjacket.jpg",
  "title": "File:Stephanolepis diaspros 222159502 (cropped).jpg",
  "author": "Sarah Faulwetter",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Stephanolepis_diaspros_222159502_(cropped).jpg"
 },
 "toadfish": {
  "file": "data/fish/toadfish.jpg",
  "title": "File:Lagocephalus sceleratus.jpg",
  "author": "Martin",
  "license": "CC BY 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Lagocephalus_sceleratus.jpg"
 },
 "weever": {
  "file": "data/fish/weever.jpg",
  "title": "File:Trachinus draco Stefano Guerrieri.jpg",
  "author": "Etrusko25",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Trachinus_draco_Stefano_Guerrieri.jpg"
 }
};
// >>> round 11 species inventory (eval/species-inventory/new-species.mjs): do not edit by hand
Object.assign(window.PSAREMA_FISH_IMG, {
 "stripedbream": {
  "file": "data/fish/stripedbream.jpg",
  "title": "File:Pez herrera (Lithognathus mormyrus), franja marina Teno-Rasca, Tenerife, España, 2022-01-06, DD 38.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_herrera_(Lithognathus_mormyrus),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-06,_DD_38.jpg"
 },
 "picarel": {
  "file": "data/fish/picarel.jpg",
  "title": "File:Spicara smaris 166033799.jpg",
  "author": "Julien Renoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Spicara_smaris_166033799.jpg"
 },
 "axillary": {
  "file": "data/fish/axillary.jpg",
  "title": "File:Aligote (Pagellus acarne).JPG",
  "author": "Foundling",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Aligote_(Pagellus_acarne).JPG"
 },
 "bluerunner": {
  "file": "data/fish/bluerunner.jpg",
  "title": "File:Caranx crysos (S0909) (12599879365).jpg",
  "author": "Smithsonian Environmental Research Center",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Caranx_crysos_(S0909)_(12599879365).jpg"
 },
 "triggerfish": {
  "file": "data/fish/triggerfish.jpg",
  "title": "File:Pez ballesta (Balistes capriscus), Parque natural de la Arrábida, Portugal, 2020-07-31, DD 27.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_ballesta_(Balistes_capriscus),_Parque_natural_de_la_Arr%C3%A1bida,_Portugal,_2020-07-31,_DD_27.jpg"
 },
 "razorfish": {
  "file": "data/fish/razorfish.jpg",
  "title": "File:Pez peine (Xyrichtys novacula), franja marina Teno-Rasca, Tenerife, España, 2022-01-09, DD 33.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Pez_peine_(Xyrichtys_novacula),_franja_marina_Teno-Rasca,_Tenerife,_Espa%C3%B1a,_2022-01-09,_DD_33.jpg"
 },
 "shidrum": {
  "file": "data/fish/shidrum.jpg",
  "title": "File:Umbrina cirrosa ro.jpg",
  "author": "Rvalette",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Umbrina_cirrosa_ro.jpg"
 },
 "bluefin": {
  "file": "data/fish/bluefin.jpg",
  "title": "File:Bluefin-big.jpg",
  "author": "Unknown authorUnknown author",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Bluefin-big.jpg"
 },
 "bullettuna": {
  "file": "data/fish/bullettuna.jpg",
  "title": "File:Auxis rochei (USNM-403144).jpg",
  "author": "The U.S. Food and Drug Administration",
  "license": "Public domain",
  "url": "https://commons.wikimedia.org/wiki/File:Auxis_rochei_(USNM-403144).jpg"
 },
 "damselfish": {
  "file": "data/fish/damselfish.jpg",
  "title": "File:Castañuela (Chromis chromis), Catania, Sicilia, Italia, 2025-04-04, DD 60.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Casta%C3%B1uela_(Chromis_chromis),_Catania,_Sicilia,_Italia,_2025-04-04,_DD_60.jpg"
 },
 "lizardfish": {
  "file": "data/fish/lizardfish.jpg",
  "title": "File:Synodus saurus France.jpg",
  "author": "jujurenoult",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Synodus_saurus_France.jpg"
 },
 "stargazer": {
  "file": "data/fish/stargazer.jpg",
  "title": "File:Uranoscopus scaber 1.jpg",
  "author": "Georges Cuvier",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Uranoscopus_scaber_1.jpg"
 },
 "peacockwrasse": {
  "file": "data/fish/peacockwrasse.jpg",
  "title": "File:Tordo (Symphodus tinca), Catania, Sicilia, Italia, 2025-04-05, DD 26.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Tordo_(Symphodus_tinca),_Catania,_Sicilia,_Italia,_2025-04-05,_DD_26.jpg"
 },
 "yellowpuffer": {
  "file": "data/fish/yellowpuffer.jpg",
  "title": "File:Tetraodóntido (Torquigener flavimaculosus), Pistol Bay, Pafos, Chipre, 2021-12-12, DD 11.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Tetraod%C3%B3ntido_(Torquigener_flavimaculosus),_Pistol_Bay,_Pafos,_Chipre,_2021-12-12,_DD_11.jpg"
 },
 "stingray": {
  "file": "data/fish/stingray.jpg",
  "title": "File:Dasyatis pastinaca 24933880.jpg",
  "author": "Chris Taklis",
  "license": "CC BY 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Dasyatis_pastinaca_24933880.jpg"
 },
 "electricray": {
  "file": "data/fish/electricray.jpg",
  "title": "File:Torpedo marmorata2.jpg",
  "author": "Philippe Guillaume",
  "license": "CC BY 2.0",
  "url": "https://commons.wikimedia.org/wiki/File:Torpedo_marmorata2.jpg"
 },
 "guitarfish": {
  "file": "data/fish/guitarfish.jpg",
  "title": "File:Rhinobatos Rhinobatos.jpg",
  "author": "Esquilo",
  "license": "CC BY-SA 3.0",
  "url": "https://commons.wikimedia.org/wiki/File:Rhinobatos_Rhinobatos.jpg"
 },
 "thornback": {
  "file": "data/fish/thornback.jpg",
  "title": "File:Raja clavata (juv).jpg",
  "author": "Hans Hillewaert",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Raja_clavata_(juv).jpg"
 },
 "reefsquid": {
  "file": "data/fish/reefsquid.jpg",
  "title": "File:Calamar de arrecifes (Sepioteuthis lessoniana), Nosy Iranja, Madagascar, 2025-09-17, DD 90.jpg",
  "author": "Diego Delso",
  "license": "CC BY-SA 4.0",
  "url": "https://commons.wikimedia.org/wiki/File:Calamar_de_arrecifes_(Sepioteuthis_lessoniana),_Nosy_Iranja,_Madagascar,_2025-09-17,_DD_90.jpg"
 }
});
// <<< round 11 species inventory
