// Gear guides, part 3 (18 species).
Object.assign(window.PSAREMA_GEAR ||= {}, {
 "squid": {
  "summary": {
   "en": "European squid: the classic eging target. Egi 2.5–3.5 at dusk and night from piers, rocks and boats over sand and seagrass, especially around harbour lights; the traditional alternative is a fish on a squid needle (kafteró) under a float. Late autumn to winter is best.",
   "el": "Καλαμάρι: ο κλασικός στόχος του eging. Καλαμαριέρες 2,5–3,5 σούρουπο και νύχτα από προβλήτες, βράχια και σκάφη πάνω από άμμο και ποσειδωνία, ιδίως γύρω από τα φώτα των λιμανιών· η παραδοσιακή εναλλακτική είναι ψάρι σε καφτερό κάτω από φελλό. Καλύτερα τέλη φθινοπώρου ως χειμώνα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "eging_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8",
     "leader": "fluoro 0.18–0.25 mm, 2–3 m"
    },
    "rig": [
     "float_rig"
    ],
    "terminal": [
     "braid",
     "fluoro"
    ],
    "hook": "",
    "notes": {
     "en": "Eging rod 2.4–2.6 m (8 ft) for egi 2.5–3.5, 2500 reel with a soft, progressive drag so the tentacles do not tear. For the kafteró: a soft 3.5–4 m rod, a 2500–4000 reel and a float with a chemical light. Always use a net or a squid gaff.",
     "el": "Καλάμι eging 2,4–2,6 m (8 ft) για καλαμαριέρες 2,5–3,5, μηχανή 2500 με μαλακό, προοδευτικό φρένο για να μη σκίζονται τα πλοκάμια. Για το καφτερό: μαλακό καλάμι 3,5–4 m, μηχανή 2500–4000 και φελλός με χημικό φωτάκι. Πάντα απόχη ή γάντζος για καλαμάρια."
    }
   },
   "boat": {
    "rod": [
     "eging_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.22–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "sinker",
     "swivel"
    ],
    "hook": "",
    "notes": {
     "en": "Drift over 10–40 m (50–90 m early in the season, while the water is still warm) with an egi worked near the bottom, or a vertical rig of 3–6 identical squid jigs, with the sinker on a short, thinner link at the bottom so only the lead is lost if it snags.",
     "el": "Ντρίφτα στα 10–40 m (50–90 m στην αρχή της σεζόν, όσο τα νερά είναι ζεστά) με καλαμαριέρα κοντά στον βυθό, ή κάθετη αρματωσιά με 3–6 ίδιες καλαμαριέρες, με το μολύβι σε κοντό, λεπτότερο παραμαλλάκι στο τέλος ώστε αν σκαλώσει να χαθεί μόνο το μολύβι."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "A sardine or other small oily or shiny fish threaded on a squid needle (kafteró) and hung under a float with a chemical light: the traditional method, and on many nights as productive as eging.",
     "el": "Σαρδέλα ή άλλο μικρό λιπαρό ή γυαλιστερό ψάρι περασμένο σε καφτερό και κρεμασμένο κάτω από φελλό με χημικό φωτάκι: η παραδοσιακή μέθοδος, που πολλές νύχτες αποδίδει όσο και το eging."
    }
   }
  ],
  "lures": [
   {
    "gear": "egi",
    "weight": "10–28 g",
    "size": "2.5–3.5",
    "colors": [
     "orange",
     "pink",
     "red",
     "glow",
     "natural"
    ],
    "note": {
     "en": "2.5 for small squid and shallow water, 3.0–3.5 for bigger squid, wind and depth (a heavy, fast-sinking 3.5–4.0 in strong wind or current). Orange, pink, red and green are the most popular colours in Greece; glow or bright colours at night or in murky water, natural colours by day in clear water. Charge glow jigs only briefly, and change colour or model if nothing happens.",
     "el": "2,5 για μικρά καλαμάρια και ρηχά, 3,0–3,5 για μεγαλύτερα, αέρα και βάθος (βαριά, γρήγορης βύθισης 3,5–4,0 σε δυνατό αέρα ή ρεύμα). Πορτοκαλί, ροζ, κόκκινο και πράσινο είναι τα πιο δημοφιλή χρώματα στην Ελλάδα· φωσφοριζέ ή έντονα χρώματα τη νύχτα ή σε θολά νερά, φυσικά χρώματα τη μέρα σε καθαρά νερά. Φορτίστε τις φωσφοριζέ μόνο για λίγο, και αλλάξτε χρώμα ή μοντέλο αν δεν γίνεται τίποτα."
    }
   },
   {
    "gear": "squid_jig_vertical",
    "weight": "",
    "size": "6–9 cm",
    "colors": [
     "glow",
     "pink",
     "white"
    ],
    "note": {
     "en": "For vertical fishing from a boat: 3–6 identical jigs (prawn or \"piggy\" type) on one rig, so they move together like a shoal.",
     "el": "Για κάθετο ψάρεμα από σκάφος: 3–6 ίδιες καλαμαριέρες (τύπου γαρίδας ή «γουρουνάκι») στην ίδια αρματωσιά, για να κινούνται μαζί σαν κοπάδι."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not usually: squid jigs (egi) work far better than soft plastics.",
    "el": "Συνήθως όχι: οι καλαμαριέρες δουλεύουν πολύ καλύτερα από τις σιλικόνες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used; lights do the attracting.",
    "el": "Δεν χρησιμοποιείται· τα φώτα κάνουν την προσέλκυση."
   }
  },
  "technique": {
   "en": "Cast, count the egi down to near the bottom (about 3–6 s per metre), give 2–3 sharp upward jerks, then let it fall on a semi-slack line and wait 5–10 s: most squid grab it on the fall. Feel for weight on the next lift and wind steadily, never pump.",
   "el": "Ρίξτε, μετρήστε τη βύθιση της καλαμαριέρας ως κοντά στον βυθό (περίπου 3–6 δευτερόλεπτα το μέτρο), δώστε 2–3 απότομα τινάγματα προς τα πάνω και αφήστε την να πέσει με μισοχαλαρή πετονιά, περιμένοντας 5–10 δευτερόλεπτα: τα περισσότερα καλαμάρια την αρπάζουν στην πτώση. Νιώστε το βάρος στο επόμενο σήκωμα και μαζέψτε σταθερά, χωρίς τραβήγματα."
  },
  "where": {
   "en": "Harbours, piers and breakwaters with lights, and rocky shores over sand and seagrass at 2–30 m; at least 1.5 m deep with weed and rock.",
   "el": "Λιμάνια, προβλήτες και λιμενοβραχίονες με φώτα, και βραχώδεις ακτές πάνω από άμμο και ποσειδωνία στα 2–30 m· τουλάχιστον 1,5 m βάθος με φύκια και πέτρες."
  },
  "when": {
   "en": "Autumn to late winter: Greek sources give September–February, with squid moving inshore from late October to January (Cyprus-specific data are scarce). Best from half an hour before dark to 1–2 hours after, and at night; calm sea.",
   "el": "Φθινόπωρο ως τέλη χειμώνα: οι ελληνικές πηγές δίνουν Σεπτέμβριο–Φεβρουάριο, με τα καλαμάρια να γιαλώνουν από τέλη Οκτωβρίου ως Ιανουάριο (ειδικά κυπριακά στοιχεία λείπουν). Καλύτερα από μισή ώρα πριν νυχτώσει ως 1–2 ώρες μετά, και τη νύχτα· ήρεμη θάλασσα."
  },
  "handling": {
   "en": "Squid squirt ink and can bite with a small beak: hold the body away from you and from clothes. Land with a net.",
   "el": "Το καλαμάρι πετά μελάνι και μπορεί να δαγκώσει με το μικρό του ράμφος: κρατήστε το μακριά από εσάς και τα ρούχα. Ανέβασμα με απόχη."
  },
  "eating": {
   "en": "Excellent. Keep it cold and clean it the same day.",
   "el": "Εξαιρετικό. Κρατήστε το κρύο και καθαρίστε το την ίδια μέρα."
  },
  "sources": [
   "https://www.psarema.gr/blog/28-rock-fishing/1899-light-rock-fishing-lrf-kai-eging-psareyontas-kalamaria-kai-soypies-me-yperelafry-exoplismo",
   "https://www.decathlon.it/c/htc/eging-una-pesca-piena-di-sorprese_e82f5d58-510b-4bfe-a6cb-230e8c68b256",
   "https://www.hinelson.com/en/26089-sugoi-haru-egi-25-fishing-squid.html",
   "https://www.sealifebase.se/summary/Loligo-vulgaris.html",
   "https://www.boatfishing.gr/article-post/afieroma-psarema-gia-kalamaria/",
   "https://www.boatfishing.gr/article-post/epochiaka-psaremata-kalamaria-vs-thrapsala/",
   "https://www.drososfishing.gr/kalamaria-me-katheti-sta-vathia/",
   "https://www.peche.com/article/52474/comment-pecher-le-calamar-la-nuit-techniques-conseils-pour-reussir"
  ]
 },
 "shortfinsquid": {
  "summary": {
   "en": "Shortfin squid (thrápsalo): a deep-water squid caught from a boat at night, from dusk to dawn, over steep ground near the coast at 80–300 m. Glow weighted squid jigs or a fish on a squid needle (kafteró), with a chemical light stick; bright lamps are banned for recreational fishing in Cyprus (DFMR terms 2026 §19). Greek anglers fish it mainly in summer and early autumn; Cyprus-specific data are scarce.",
   "el": "Θράψαλο: καλαμάρι των βαθιών νερών που πιάνεται από σκάφος τη νύχτα, από το σούρουπο ως το ξημέρωμα, σε απότομους βυθούς κοντά στην ακτή στα 80–300 m. Φωσφοριζέ βαρυμένες θραψαλιέρες ή ψάρι σε καφτερό, με χημικό φωτάκι· οι δυνατοί προβολείς απαγορεύονται στην ερασιτεχνική αλιεία στην Κύπρο (όροι ΤΑΘΕ 2026 §19). Στην Ελλάδα ψαρεύεται κυρίως καλοκαίρι και αρχές φθινοπώρου· ειδικά κυπριακά στοιχεία λείπουν."
  },
  "best": [
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "slow_jig_rod",
     "jigging_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.5–2 (20–30 lb) / hand line mono 0.80–1.20 mm",
     "leader": "mono 0.40–0.50 mm, 2–3 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "mono",
     "swivel"
    ],
    "hook": "",
    "notes": {
     "en": "One weighted squid jig (thrapsaliéra, 80–300 g by depth and current) or a kafteró with a fish, on a strong snap swivel, with a chemical light a little above it. Vertical-jigging, slow-jig or heavy bottom rods of 1.8–2.2 m (about 40–200 g) with braid; a reel with a line counter helps find the depth again. Traditionally fished by hand line.",
     "el": "Μία βαρυμένη θραψαλιέρα (80–300 g ανάλογα με βάθος και ρεύμα) ή καφτερό με ψάρι, σε γερή στριφταροπαραμάνα, με ένα χημικό φωτάκι λίγο πιο πάνω. Καλάμια vertical jigging, slow jig ή βαριάς καθετής 1,8–2,2 m (περίπου 40–200 g) με νήμα· μηχανή με μετρητή πετονιάς για να ξαναβρίσκετε το βάθος. Παραδοσιακά ψαρεύεται με το χέρι."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Fresh or salted sardine, horse mackerel, bogue or garfish threaded on a kafteró, or small pieces pinned on the glow jig: the classic Greek method.",
     "el": "Φρέσκια ή παστή σαρδέλα, σαφρίδι, γόπα ή ζαργάνα περασμένη σε καφτερό, ή κομματάκια καρφωμένα πάνω στη φωσφοριζέ θραψαλιέρα: η κλασική ελληνική μέθοδος."
    }
   }
  ],
  "lures": [
   {
    "gear": "squid_jig_vertical",
    "weight": "80–300 g",
    "size": "",
    "colors": [
     "glow"
    ],
    "note": {
     "en": "Large glow or UV squid jigs with 3–4 rows of spikes and built-in weight; charge them with a UV torch. Lighter, unweighted ones (20–50 g) when the squid rise to feed 20–40 m down.",
     "el": "Μεγάλες φωσφοριζέ ή UV θραψαλιέρες με 3–4 σειρές αρπάδια και ενσωματωμένο βάρος· φορτίστε τες με φακό UV. Ελαφρύτερες, αμολύβωτες (20–50 g) όταν τα θράψαλα ανεβαίνουν να τραφούν στα 20–40 m."
    }
   },
   {
    "gear": "egi",
    "weight": "25–40 g",
    "size": "4.0–4.5",
    "colors": [
     "glow"
    ],
    "note": {
     "en": "Heavy eging gear with large egi works when the squid have risen to 20–40 m; too light for the deep water otherwise.",
     "el": "Βαρύ eging με μεγάλες καλαμαριέρες δουλεύει όταν τα θράψαλα έχουν ανέβει στα 20–40 m· αλλιώς είναι πολύ ελαφρύ για τα βαθιά."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used. In Greece a boat light is used to draw the squid up, but fishing with bright light sources is banned for recreational fishers in Cyprus (DFMR terms 2026 §19, Reg. 18).",
    "el": "Δεν χρησιμοποιείται. Στην Ελλάδα με φως στο σκάφος ανεβάζουν τα θράψαλα, όμως στην Κύπρο η αλιεία με ισχυρές πηγές φωτός απαγορεύεται στους ερασιτέχνες (όροι ΤΑΘΕ 2026 §19, Καν. 18)."
   }
  },
  "technique": {
   "en": "Drop to the bottom, lift 1–2 m and wait; if nothing, wind up a few metres at a time and wait again: they feed at all depths and rise as the night goes on, especially under a light. Most takes come on the drop as sudden slack line: strike firmly and wind fast without stopping, or it lets go.",
   "el": "Πατώστε, σηκώστε 1–2 m και περιμένετε· αν δεν γίνεται τίποτα, ανεβάστε λίγα μέτρα κάθε φορά και περιμένετε ξανά: τρώνε σε όλα τα βάθη και ανεβαίνουν όσο περνά η νύχτα, ιδίως κάτω από φως. Τα περισσότερα χτυπήματα έρχονται στο κατέβασμα σαν ξαφνικό «κενό» στην πετονιά: δυνατό κάρφωμα και γρήγορο μάζεμα χωρίς σταματήματα, αλλιώς ξεφεύγει."
  },
  "where": {
   "en": "Steep drop-offs near the coast and the shelf edge, usually from 80–100 m down to 300 m (the species ranges to 1000 m).",
   "el": "Απότομοι βυθοί κοντά στην ακτή και η άκρη της υφαλοκρηπίδας, συνήθως από 80–100 m ως 300 m (το είδος φτάνει ως τα 1000 m)."
  },
  "when": {
   "en": "Night, from dusk to dawn. Greek anglers fish thrápsala mainly from early summer into autumn (most and biggest around August); the species is present and spawns all year.",
   "el": "Νύχτα, από το σούρουπο ως το ξημέρωμα. Στην Ελλάδα τα θράψαλα ψαρεύονται κυρίως από αρχές καλοκαιριού ως το φθινόπωρο (τα περισσότερα και μεγαλύτερα γύρω στον Αύγουστο)· το είδος υπάρχει και γεννά όλο τον χρόνο."
  },
  "handling": {
   "en": "Ink and a small beak: hold away from you. Net or lift carefully: the arms tear.",
   "el": "Μελάνι και μικρό ράμφος: κρατήστε το μακριά σας. Απόχη ή προσεκτικό σήκωμα: τα πλοκάμια σκίζονται."
  },
  "eating": {
   "en": "Good but tougher than the European squid: freeze it for a few days or beat it before cooking; good stuffed or stewed.",
   "el": "Καλό αλλά πιο σκληρό από το καλαμάρι: αφήστε το λίγες μέρες στην κατάψυξη ή χτυπήστε το πριν το μαγείρεμα· ωραίο γεμιστό ή κοκκινιστό."
  },
  "sources": [
   "https://www.sealifebase.se/summary/Illex-coindetii.html",
   "https://www.fao.org/docrep/pdf/010/ah827i/ah827i03.pdf",
   "https://www.boatfishing.gr/article-post/epochiaka-psaremata-kalamaria-vs-thrapsala/",
   "https://magfishing.gr/arthra/shore-eging/to-psarema-tou-thrapsalou-me-tin-texniki-tou-eging",
   "https://magfishing.gr/arthra/shore-eging/to-psarema-tou-thrapsalou-kai-eksidikeusi-carpmatchfishing",
   "https://www.kynigesia.gr/psarema/psareyontas-thrapsala-se-vathia-nera/"
  ]
 },
 "cuttlefish": {
  "summary": {
   "en": "Common cuttlefish: comes inshore over sand, mud and seagrass to spawn in spring and early summer. Prawn-shaped egi dragged slowly along the bottom from shore or a slowly drifting boat; an easy spearfishing catch in spring.",
   "el": "Σουπιά: πλησιάζει στα ρηχά πάνω από άμμο, λάσπη και ποσειδωνία για να γεννήσει άνοιξη και αρχές καλοκαιριού. Καλαμαριέρες σε σχήμα γαρίδας που σέρνονται αργά στον βυθό από ακτή ή από σκάφος σε αργή ντρίφτα· εύκολη λεία για ψαροντούφεκο την άνοιξη."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "eging_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8",
     "leader": "fluoro 0.18–0.25 mm, 2 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro"
    ],
    "hook": "",
    "notes": {
     "en": "Same tackle as squid eging; a softer drag and a net matter even more, as cuttlefish are heavy and pull back hard.",
     "el": "Ίδιος εξοπλισμός με το eging για καλαμάρι· το μαλακό φρένο και η απόχη μετράνε ακόμη περισσότερο, γιατί η σουπιά είναι βαριά και τραβά προς τα πίσω."
    }
   },
   "boat": {
    "rod": [
     "eging_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1 / mono 0.28–0.35 mm",
     "leader": "fluoro 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "sinker",
     "swivel"
    ],
    "hook": "",
    "notes": {
     "en": "With a slight current or breeze, drift with the engine off so the jigs drag slowly on the bottom: two droppers 50–60 cm apart, a normal egi on the lower one and a small egi on the upper, and a small sinker on a swivel at the end. When the drift stops, cast and work a single egi instead (eging from the boat).",
     "el": "Με λίγο ρεύμα ή αεράκι, αρόδο με σβηστή μηχανή ώστε οι καλαμαριέρες να σέρνονται αργά στον βυθό: δύο παράμαλλα σε απόσταση 50–60 cm, κανονική καλαμαριέρα στο κάτω και μικρή στο πάνω, και μικρό μολύβι με στριφτάρι στο τέλος. Όταν σταματήσει η ντρίφτα, ρίψεις με μία καλαμαριέρα (eging από το σκάφος)."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "Swim slowly over seagrass and sand at 2–10 m in spring; cuttlefish rely on camouflage and let you come close.",
     "el": "Κολυμπήστε αργά πάνω από ποσειδωνία και άμμο στα 2–10 m την άνοιξη· η σουπιά βασίζεται στο καμουφλάζ και σας αφήνει να πλησιάσετε."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "note": {
     "en": "A dead small fish bound to a bait jig and dragged slowly is an old method; current Greek and Italian guides focus on egi, so treat it as secondary (sources thin).",
     "el": "Νεκρό ψαράκι δεμένο σε καλαμαριέρα δολώματος, που σέρνεται αργά, είναι παλιά μέθοδος· οι σημερινοί ελληνικοί και ιταλικοί οδηγοί εστιάζουν στην καλαμαριέρα, οπότε θεωρήστε το δευτερεύον (λίγες πηγές)."
    }
   }
  ],
  "lures": [
   {
    "gear": "egi",
    "weight": "6–16 g",
    "size": "2.0–3.0",
    "colors": [
     "orange",
     "pink",
     "red",
     "natural"
    ],
    "note": {
     "en": "Prawn-shaped (\"shrimp\" or \"piggy\") jigs weighted under the head. Bright colours in dim light, lighter or dark natural colours in bright sun; change often, as their preference shifts during the day. Keep the spikes clear of weed, ink and torn tentacle or the next one will not take.",
     "el": "Καλαμαριέρες σε σχήμα γαρίδας ή «γουρουνάκι» με βάρος κάτω από το κεφάλι. Έντονα χρώματα με λίγο φως, ανοιχτά ή σκούρα φυσικά με δυνατό ήλιο· αλλάζετε συχνά, γιατί οι προτιμήσεις τους αλλάζουν μέσα στη μέρα. Καθαρίζετε τα αρπάδια από φύκια, μελάνι και κομμάτια πλοκαμιού, αλλιώς η επόμενη δεν θα χτυπήσει."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not really: cuttlefish are fished with egi. Some anglers put a small soft-bodied squid jig on the top dropper, but that is still a squid jig with spikes, not a hook-rigged soft plastic.",
    "el": "Όχι ουσιαστικά: η σουπιά ψαρεύεται με καλαμαριέρα. Κάποιοι βάζουν μια μικρή σιλικονούχα καλαμαριέρα στο πάνω παράμαλλο, αλλά κι αυτή είναι καλαμαριέρα με αρπάδια, όχι σιλικόνη σε αγκίστρι."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Let the egi reach the bottom, then drag it slowly with long pauses and an occasional lift; cuttlefish follow and grab it with their two long tentacles when it stops. When it feels heavy, strike sharply, then wind steadily without stopping (the spikes have no barbs) and without pulling hard, so the tentacles do not tear. Net it and put it straight into a bucket: it inks a lot.",
   "el": "Αφήστε την καλαμαριέρα να πατώσει και σύρετέ την αργά με μεγάλες παύσεις και ένα σήκωμα πού και πού· η σουπιά ακολουθεί και την αρπάζει με τα δύο μακριά πλοκάμια όταν σταματά. Όταν βαρύνει, κοφτό κάρφωμα και μετά σταθερό μάζεμα χωρίς σταματήματα (τα αρπάδια δεν έχουν σκαλίδα) και χωρίς δυνατά τραβήγματα, για να μη σκιστούν τα πλοκάμια. Απόχη και κατευθείαν στον κουβά: βγάζει πολύ μελάνι."
  },
  "where": {
   "en": "Sand, mud and mixed bottoms with seagrass at 1–20 m: harbours, sheltered bays, sandy beaches with scattered rocks, and especially near freshwater outflows.",
   "el": "Άμμος, λάσπη και μεικτοί βυθοί με ποσειδωνία στα 1–20 m: λιμάνια, προστατευμένοι κόλποι, αμμουδιές με διάσπαρτες πέτρες, και ιδίως κοντά σε εκβολές γλυκού νερού."
  },
  "when": {
   "en": "Spring to early summer, when they come inshore to spawn (Italian guides give March–July); Greek eging guides fish them from May to late November, with fewer in midwinter. Dawn, dusk and night, in calm water.",
   "el": "Άνοιξη ως αρχές καλοκαιριού, όταν πλησιάζουν να γεννήσουν (οι ιταλικοί οδηγοί δίνουν Μάρτιο–Ιούλιο)· οι ελληνικοί οδηγοί eging τις ψαρεύουν από Μάιο ως τέλη Νοεμβρίου, λιγότερες στην καρδιά του χειμώνα. Χαράματα, σούρουπο και νύχτα, με ήρεμη θάλασσα."
  },
  "handling": {
   "en": "Lots of ink and a strong beak: keep it head-down away from you, and keep fingers away from the mouth.",
   "el": "Πολύ μελάνι και δυνατό ράμφος: κρατήστε τη με το κεφάλι προς τα κάτω μακριά σας, και τα δάχτυλα μακριά από το στόμα."
  },
  "eating": {
   "en": "Excellent. Spawning cuttlefish lay eggs on seagrass and objects: leave egg clusters in place.",
   "el": "Εξαιρετική. Οι σουπιές γεννούν τα αυγά τους σε ποσειδωνία και αντικείμενα: αφήστε τα αυγά στη θέση τους."
  },
  "sources": [
   "https://www.psarema.gr/blog/28-rock-fishing/1899-light-rock-fishing-lrf-kai-eging-psareyontas-kalamaria-kai-soypies-me-yperelafry-exoplismo",
   "https://www.decathlon.it/c/htc/eging-una-pesca-piena-di-sorprese_e82f5d58-510b-4bfe-a6cb-230e8c68b256",
   "https://www.sealifebase.se/summary/Sepia-officinalis.html",
   "https://magfishing.gr/arthra/shore-eging/pws-tha-pragmatopoihsete-ta-pio-apodotika-psaremata-soupias-me-tin-texniki-tou-eging-apo-to-skafos",
   "https://www.garmin.com/it-IT/blog/marine/come-pescare-le-seppie/",
   "http://megapsarades.blogspot.com/2012/12/blog-post_23.html"
  ]
 },
 "octopus": {
  "summary": {
   "en": "Common octopus: a den-dweller of rocky and sandy bottoms. A white octopus jig (crab-shaped, or with a crab or small fish tied on) dragged slowly from a drifting boat or scraped along harbour walls, or a tako egi cast from the rocks; spearos look for dens with shell piles. Best from mid-autumn through winter, in the morning.",
   "el": "Χταπόδι: ζει σε φωλιές σε βραχώδεις και αμμώδεις βυθούς. Άσπρη χταποδιέρα (σε σχήμα καβουριού, ή με καβούρι ή ψαράκι δεμένο) που σέρνεται αργά από σκάφος στη ντρίφτα ή ξύνει τους τοίχους των λιμανιών, ή tako egi με ρίψεις από τα βράχια· οι ψαροντουφεκάδες ψάχνουν φωλιές με σωρούς από όστρακα. Καλύτερα από τα μέσα του φθινοπώρου και όλο τον χειμώνα, το πρωί."
  },
  "best": [
   "boat",
   "shore",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod",
     "eging_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.80–1.00 mm hand line / PE 2–4",
     "leader": "mono 0.40–0.60 mm, 1–2 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "mono",
     "sinker",
     "swivel"
    ],
    "hook": "",
    "notes": {
     "en": "Traditionally a thick hand line (about 1 mm) and a weighted octopus jig, with a piece of chain instead of a sinker to avoid snags. Drift slowly over 1–25 m dragging the jig on the bottom, shaking the line now and then so it rattles; a stiff rod and strong line help pull an octopus off the rock before it anchors.",
     "el": "Παραδοσιακά χοντρή πετονιά στο χέρι (περίπου 1 mm) και βαρυμένη χταποδιέρα, με ένα κομμάτι αλυσίδα αντί για μολύβι για να μη σκαλώνει. Αργή ντρίφτα στα 1–25 m σέρνοντας τη χταποδιέρα στον βυθό και κουνώντας πού και πού την πετονιά σαν κουδουνίστρα· σκληρό καλάμι και γερή πετονιά βοηθούν να ξεκολλήσετε το χταπόδι από την πέτρα πριν «βεντουζάρει»."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 2–4 (4-strand)",
     "leader": "fluoro 0.50 mm, 50–60 cm"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "swivel"
    ],
    "hook": "",
    "notes": {
     "en": "A short, very stiff rod (a Japanese tako rod is ideal) and a strong reel. Cast a tako egi from rocks, harbours and beaches and drag it back along rock–sand edges, or lower a classic octopus jig straight down and scrape it up harbour walls and the gaps between blocks. Clear water and sun help.",
     "el": "Κοντό, πολύ σκληρό καλάμι (ιδανικά ιαπωνικό tako) και γερή μηχανή. Ρίψη με tako egi από βράχια, λιμάνια και παραλίες και σύρσιμο πίσω στις άκρες βράχου–άμμου, ή κατεβάστε κλασική χταποδιέρα κάθετα και ξύστε τη στους τοίχους του λιμανιού και στις χαραμάδες των ογκόλιθων. Βοηθούν τα καθαρά νερά και ο ήλιος."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "Look for den mouths at 1–15 m marked by piles of shells and crab remains. Many prefer to take octopus by hand or with a small gun; never put a hand deep into a hole you cannot see (morays).",
     "el": "Ψάξτε στόμια φωλιών στα 1–15 m με σωρούς από όστρακα και υπολείμματα καβουριών. Πολλοί προτιμούν να πιάνουν το χταπόδι με το χέρι ή με μικρό όπλο· ποτέ χέρι βαθιά σε τρύπα που δεν βλέπετε (σμέρνες)."
    }
   }
  },
  "baits": [
   {
    "gear": "crab",
    "best": true,
    "note": {
     "en": "A crab, real or imitation, on a white octopus jig is the classic.",
     "el": "Καβούρι, αληθινό ή ομοίωμα, πάνω σε άσπρη χταποδιέρα είναι το κλασικό."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Fresh small fish tied to the jig also work; chicken feet and pork rind are traditional too.",
     "el": "Πιάνουν και νωπά ψαράκια δεμένα στη χταποδιέρα· παραδοσιακά και κοτοπόδαρα ή γουρουνόπετσα."
    }
   }
  ],
  "lures": [
   {
    "gear": "octopus_jig",
    "weight": "40–150 g",
    "size": "",
    "colors": [
     "white",
     "red",
     "orange",
     "silver"
    ],
    "note": {
     "en": "Classic weighted jigs with white plastic fish or a crab imitation and a crown of spikes; try a white crab-shaped jig rather than the usual orange. Heavier for current and depth.",
     "el": "Κλασικές βαρυμένες χταποδιέρες με άσπρα πλαστικά ψαράκια ή ομοίωμα καβουριού και στεφάνι από αγκίστρια· δοκιμάστε άσπρη σε σχήμα καβουριού αντί για την κλασική πορτοκαλί. Βαρύτερες για ρεύμα και βάθος."
    }
   },
   {
    "gear": "egi",
    "weight": "20–40 g",
    "size": "",
    "colors": [
     "white",
     "orange",
     "pink",
     "glow"
    ],
    "note": {
     "en": "Tako egi (octopus egi), cast and dragged on the bottom with side-to-side twitches: white, white–yellow and bright orange or pink work best; a glow one at night.",
     "el": "Tako egi (καλαμαριέρα για χταπόδι), με ρίψη και σύρσιμο στον βυθό με τινάγματα δεξιά–αριστερά: καλύτερα άσπρο, άσπρο–κίτρινο και έντονο πορτοκαλί ή ροζ· φωσφοριζέ τη νύχτα."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not as a separate lure: the crab imitations and skirts on octopus jigs are part of the jig itself.",
    "el": "Όχι ως ξεχωριστό τεχνητό: τα ομοιώματα καβουριού και οι φούστες είναι μέρος της ίδιας της χταποδιέρας."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Drag slowly, bumping the bottom. A bite feels like sudden weight: keep steady pressure and wind evenly without jerking, and keep it coming so it cannot stick to a rock. If it does stick, slacken off and wait for it to move, then lift sharply and wind. Net or gaff it at the surface.",
   "el": "Αργό σύρσιμο ακουμπώντας τον βυθό. Το τσίμπημα είναι σαν ξαφνικό βάρος: σταθερή πίεση και ομαλό μάζεμα χωρίς τινάγματα, χωρίς να σταματάτε, για να μην κολλήσει σε πέτρα. Αν κολλήσει, χαλαρώστε και περιμένετε να κινηθεί, μετά κοφτό σήκωμα και μάζεμα. Απόχη ή γάντζος στην επιφάνεια."
  },
  "where": {
   "en": "Rocky and mixed bottoms, rock–sand edges and seagrass margins at 1–30 m.",
   "el": "Βραχώδεις και μεικτοί βυθοί, άκρες βράχου–άμμου και όρια ποσειδωνίας στα 1–30 m."
  },
  "when": {
   "en": "Mid-autumn to a winter peak (roughly October–April); mornings from first light are best, in calm, clear water.",
   "el": "Από τα μέσα του φθινοπώρου με κορύφωση τον χειμώνα (περίπου Οκτώβριο–Απρίλιο)· καλύτερα το πρωί από τα χαράματα, με ήρεμα, καθαρά νερά."
  },
  "handling": {
   "en": "It bites with a hard beak, and the bite can swell: keep it away from bare skin. Release small octopus: Greece sets a 500 g minimum; for Cyprus check current DFMR rules.",
   "el": "Δαγκώνει με σκληρό ράμφος και η δαγκωνιά μπορεί να πρηστεί: μακριά από γυμνό δέρμα. Αφήστε τα μικρά χταπόδια: στην Ελλάδα το ελάχιστο είναι 500 g· για την Κύπρο ελέγξτε τους ισχύοντες κανονισμούς του ΤΑΘΕ."
  },
  "eating": {
   "en": "Excellent grilled or stewed; tenderise by freezing or beating.",
   "el": "Εξαιρετικό στα κάρβουνα ή στιφάδο· μαλακώνει με κατάψυξη ή χτύπημα."
  },
  "sources": [
   "https://www.psarema.gr/sizitiseis/psaria-kai-to-psarema-tous/216613-texnikes-gia-xtapodia",
   "https://www.psarema.gr/sizitiseis/old-psaria-kai-to-psarema-tous/163844-meri-pou-vgainei-to-xtapodi",
   "https://psarema.gr/sizitiseis/psarontoyfeko/248089-xtapodi-psarontoyfeko-vinteakia",
   "https://www.plus-fishing.com/en/blog/megabass-taco-le-tako-eging-event?format=amp",
   "https://www.sealifebase.se/summary/Octopus-vulgaris.html",
   "https://www.boatfishing.gr/article-post/nees-technikes-tako-egi-me-stocho-ta-chtapodia/",
   "https://www.drososfishing.gr/epochiaka-psaremata-chtapodia-sta-richa/"
  ]
 },
 "comber": {
  "summary": {
   "en": "Comber: a small, abundant serranid of rock and seagrass edges at 15–80 m; a bottom-fishing staple from a drifting boat with small hooks and squid or shrimp strips. Daytime, all year.",
   "el": "Χάννος: μικρό, άφθονο ψάρι στις άκρες βράχου και ποσειδωνίας στα 15–80 m· βασικό ψάρι της καθετής από σκάφος στη ντρίφτα, με μικρά αγκίστρια και λωρίδες καλαμαριού ή γαρίδα. Μέρα, όλο τον χρόνο."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod",
     "slow_jig_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 0.8–1.5 / mono 0.30–0.35 mm",
     "leader": "mono 0.30–0.40 mm / 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 6–8",
    "notes": {
     "en": "Two- or three-hook paternoster with 20–30 cm droppers and a 50–150 g sinker, depth and drift depending.",
     "el": "Καθετή με 2–3 αγκίστρια σε παράμαλλα 20–30 cm και μολύβι 50–150 g, ανάλογα με βάθος και ντρίφτα."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8 / mono 0.22–0.25 mm",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "bottom_rig",
     "drop_shot"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 6–10",
    "notes": {
     "en": "From rocks with deep water close in.",
     "el": "Από βράχια με βαθιά νερά κοντά."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Fresh shrimp, whole or halved: the standard bottom-rig bait.",
     "el": "Φρέσκια γαρίδα, ολόκληρη ή μισή: το βασικό δόλωμα της καθετής."
    }
   },
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Squid strips, beaten soft, are just as good and resist small pickers.",
     "el": "Λωρίδες καλαμαριού, χτυπημένες να μαλακώσουν, είναι εξίσου καλές και αντέχουν στα μικρά ψάρια."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sardine strips.",
     "el": "Λωρίδες σαρδέλας."
    }
   }
  ],
  "lures": [
   {
    "gear": "inchiku",
    "weight": "30–80 g",
    "size": "",
    "colors": [
     "red",
     "orange",
     "gold"
    ],
    "note": {
     "en": "Small inchiku and slow jigs catch combers on rough ground.",
     "el": "Μικρά inchiku και slow jig πιάνουν χάννους σε πετρώδη βυθό."
    }
   },
   {
    "gear": "soft_grub",
    "weight": "5–20 g",
    "size": "5–8 cm",
    "colors": [
     "red",
     "orange",
     "natural"
    ],
    "note": {
     "en": "Small grubs bounced on the bottom.",
     "el": "Μικρά grub που χοροπηδούν στον βυθό."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 5–8 cm grubs or soft shrimp on 5–20 g heads, or on a drop-shot, hopped on rock–seagrass edges.",
    "el": "Ναι: σιλικόνες grub ή γαρίδες 5–8 cm σε μολυβοκέφαλα 5–20 g, ή σε drop-shot, με πηδηματάκια στις άκρες βράχου–ποσειδωνίας."
   },
   "ids": [
    "soft_grub",
    "soft_shrimp"
   ],
   "colors": [
    "red",
    "orange",
    "natural"
   ],
   "size": "5–8 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not needed.",
    "el": "Δεν χρειάζεται."
   }
  },
  "technique": {
   "en": "Drift over rock and seagrass edges, keep the sinker tapping the bottom and strike on the first sharp pull; combers bite boldly.",
   "el": "Ντρίφτα πάνω από άκρες βράχου και ποσειδωνίας, με το μολύβι να χτυπά τον βυθό, και κάρφωμα στο πρώτο απότομο τράβηγμα· ο χάννος τσιμπά θαρραλέα."
  },
  "where": {
   "en": "Rocky, coralligenous and seagrass-edge bottoms at 15–80 m all round Cyprus.",
   "el": "Βραχώδεις και κοραλλιογενείς βυθοί και άκρες ποσειδωνίας στα 15–80 m γύρω από όλη την Κύπρο."
  },
  "when": {
   "en": "All year; daytime.",
   "el": "Όλο τον χρόνο· μέρα."
  },
  "handling": {
   "en": "Spiny dorsal and gill cover: hold firmly with a cloth; release small fish quickly.",
   "el": "Αγκαθωτό ραχιαίο και βράγχιο: πιάστε σφιχτά με πανί· γρήγορη απελευθέρωση των μικρών."
  },
  "eating": {
   "en": "Tasty but bony; good fried or in fish soup.",
   "el": "Νόστιμος αλλά με κόκκαλα· καλός τηγανητός ή σε ψαρόσουπα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Serranus-cabrilla.html",
   "https://www.psarema.gr/blog/19-syrti/1588-i-texni-tis-syrtis-a-meros",
   "https://www.psarema.gr/sizitiseis/psarema-apo-skafos-eksoplismos/248376-slow-pitch-jigging",
   "https://www.boatfishing.gr/article-post/katheti-sta-70-metra-gia-palioys-kai-neoys-psarades/",
   "https://bolkas.gr/i-techniki-psarematos-toy-light-rock-fishing-lrf-hrf/"
  ]
 },
 "paintedcomber": {
  "summary": {
   "en": "Painted comber: a bold little serranid of shallow rocks and seagrass. Shrimp, worm or squid on small hooks from shore, or tiny soft lures (LRF); daytime, all year.",
   "el": "Πέρκα: θαρραλέο μικρό ψάρι στα ρηχά βράχια και την ποσειδωνία. Γαρίδα, σκουλήκι ή καλαμάρι σε μικρά αγκίστρια από ακτή, ή μικροσκοπικές σιλικόνες (LRF)· μέρα, όλο τον χρόνο."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "bolognese_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.3–0.6 / mono 0.18–0.22 mm",
     "leader": "fluoro 0.16–0.22 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig",
     "drop_shot"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 8–12",
    "notes": {
     "en": "LRF rod 0.5–8 g with a 1000–2500 reel, or a float rig set just above the weed.",
     "el": "Καλάμι LRF 0,5–8 g με μηχανή 1000–2500, ή φελλός ρυθμισμένος λίγο πάνω από τα φύκια."
    }
   },
   "boat": {
    "rod": [
     "boat_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "mono 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 8–10",
    "notes": {
     "en": "Light paternoster over shallow rock and seagrass.",
     "el": "Ελαφριά καθετή πάνω από ρηχά βράχια και ποσειδωνία."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "Easy but small; take only good-sized fish.",
     "el": "Εύκολη αλλά μικρή· μόνο καλά μεγέθη."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Shrimp pieces.",
     "el": "Κομμάτια γαρίδας."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Small squid strips.",
     "el": "Μικρές λωρίδες καλαμαριού."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_grub",
    "weight": "1–5 g",
    "size": "3–6 cm",
    "colors": [
     "natural",
     "red",
     "chartreuse"
    ],
    "note": {
     "en": "LRF: hop along rocks and weed edges.",
     "el": "LRF: πηδηματάκια στα βράχια και στις άκρες των φυκιών."
    }
   },
   {
    "gear": "soft_shrimp",
    "weight": "1–5 g",
    "size": "3–5 cm",
    "colors": [
     "natural",
     "orange"
    ],
    "note": {
     "en": "Small soft shrimp dragged slowly.",
     "el": "Μικρή σιλικονένια γαρίδα που σέρνεται αργά."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 3–6 cm grubs, worms or shrimp on 1–5 g jig heads or a drop-shot; the most fun way to catch it.",
    "el": "Ναι: σιλικόνες grub, σκουλήκια ή γαρίδες 3–6 cm σε μολυβοκέφαλα 1–5 g ή σε drop-shot· ο πιο διασκεδαστικός τρόπος."
   },
   "ids": [
    "soft_grub",
    "soft_worm",
    "soft_shrimp"
   ],
   "colors": [
    "natural",
    "red",
    "chartreuse"
   ],
   "size": "3–6 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not needed.",
    "el": "Δεν χρειάζεται."
   }
  },
  "technique": {
   "en": "Fish close to cover; it attacks quickly, so strike on the first knock.",
   "el": "Ψαρεύετε κοντά σε κρυψώνες· επιτίθεται γρήγορα, κάρφωμα στο πρώτο χτύπημα."
  },
  "where": {
   "en": "Shallow rocks, boulders and Posidonia at 1–25 m; easy from most rocky shores.",
   "el": "Ρηχά βράχια, ογκόλιθοι και ποσειδωνία στα 1–25 m· εύκολα από τις περισσότερες βραχώδεις ακτές."
  },
  "when": {
   "en": "All year; daytime.",
   "el": "Όλο τον χρόνο· μέρα."
  },
  "handling": {
   "en": "Spiny fins: hold firmly; release small ones.",
   "el": "Αγκαθωτά πτερύγια: πιάστε σφιχτά· τα μικρά πίσω."
  },
  "eating": {
   "en": "Good for fish soup or frying; bony.",
   "el": "Καλή για ψαρόσουπα ή τηγάνι· με κόκκαλα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Serranus-scriba.html",
   "https://bolkas.gr/i-techniki-psarematos-toy-light-rock-fishing-lrf-hrf/",
   "https://www.psarema.gr/blog/19-syrti/1588-i-texni-tis-syrtis-a-meros",
   "https://www.boatfishing.gr/article-post/light-rock-fishing-ta-megalytera-tropaia-toy-lrf/"
  ]
 },
 "scorpionfish": {
  "summary": {
   "en": "Red scorpionfish: the big, prized scorpionfish of rocky and mixed ground at 30–120 m. Fish or squid strips on a two-hook bottom rig from a slowly drifting boat; small slow jigs and tai rubbers also work. Venomous spines.",
   "el": "Σκορπιός (σκορπίνα): ο μεγάλος, περιζήτητος σκορπιός των βραχωδών και μεικτών βυθών στα 30–120 m. Λωρίδες ψαριού ή καλαμαριού σε καθετή με δύο αγκίστρια από σκάφος σε αργή ντρίφτα· πιάνει και με μικρά slow jig και tai rubber. Δηλητηριώδη αγκάθια."
  },
  "best": [
   "boat",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod",
     "slow_jig_rod"
    ],
    "reel": [
     "reel_conv",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1–2",
     "leader": "mono 0.40–0.50 mm / 0.35–0.40 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–2/0",
    "notes": {
     "en": "Two-hook paternoster with 30–40 cm droppers and a 100–300 g sinker; drift as slowly as possible and keep the lead bumping the bottom.",
     "el": "Καθετή με δύο αγκίστρια σε παράμαλλα 30–40 cm και μολύβι 100–300 g· ντρίφτα όσο πιο αργή γίνεται, με το μολύβι να ακουμπά τον βυθό."
    }
   },
   "spear": {
    "gun": [
     "gun_band",
     "gun_pneu"
    ],
    "length": "60–90 cm",
    "notes": {
     "en": "Rests motionless in holes and on ledges, camouflaged; search slowly. Careful when taking it off the shaft.",
     "el": "Κάθεται ακίνητος σε τρύπες και πεζούλες, καμουφλαρισμένος· ψάξτε αργά. Προσοχή όταν τον βγάζετε από τη βέργα."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Strips of oily fish (sardine, mackerel).",
     "el": "Λωρίδες λιπαρού ψαριού (σαρδέλα, κολιός)."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid strips stay on the hook.",
     "el": "Οι λωρίδες καλαμαριού μένουν στο αγκίστρι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Large shrimp.",
     "el": "Μεγάλη γαρίδα."
    }
   }
  ],
  "lures": [
   {
    "gear": "tai_rubber",
    "weight": "60–150 g",
    "size": "",
    "colors": [
     "orange",
     "red",
     "glow"
    ],
    "note": {
     "en": "Slow steady retrieve close to the bottom.",
     "el": "Αργό σταθερό μάζεμα κοντά στον βυθό."
    }
   },
   {
    "gear": "slow_jig",
    "weight": "80–200 g",
    "size": "",
    "colors": [
     "glow",
     "orange",
     "gold",
     "red"
    ],
    "note": {
     "en": "Keep it in the bottom 2–3 m.",
     "el": "Κρατήστε το στα τελευταία 2–3 m."
    }
   },
   {
    "gear": "inchiku",
    "weight": "60–150 g",
    "size": "",
    "colors": [
     "red",
     "orange",
     "glow"
    ],
    "note": {
     "en": "Bump it along the bottom with slow moves and short stops; the silicone octopus skirt seems to draw scorpionfish best. Bright colours, glow below about 100 m.",
     "el": "Χτυπήστε το κατά μήκος του βυθού με αργές κινήσεις και μικρά σταματήματα· το σιλικονούχο χταποδάκι φαίνεται να τραβά καλύτερα τις σκορπίνες. Έντονα χρώματα, φωσφοριζέ κάτω από τα 100 m περίπου."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not a mainstream method at these depths: the soft part that matters is the silicone skirt on inchiku and tai rubber. A shad or grub on a heavy jig head can take one, but it is not common practice here (sources thin).",
    "el": "Όχι συνηθισμένη μέθοδος σε αυτά τα βάθη: το μαλακό κομμάτι που μετράει είναι το σιλικονούχο χταποδάκι στο inchiku και στο tai rubber. Σιλικόνη shad ή grub σε βαριά μολυβοκεφαλή μπορεί να πιάσει, αλλά δεν είναι κοινή πρακτική εδώ (λίγες πηγές)."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Slow drift over rough ground with baits right on the bottom; scorpionfish ambush, so the bait must pass in front of them. Lift firmly on the bite.",
   "el": "Αργή ντρίφτα σε πετρώδη βυθό με τα δολώματα ακριβώς στον βυθό· ο σκορπιός παραμονεύει, το δόλωμα πρέπει να περάσει μπροστά του. Σταθερό σήκωμα στο τσίμπημα."
  },
  "where": {
   "en": "Rocky, coralligenous and mixed bottoms at 30–120 m.",
   "el": "Βραχώδεις, κοραλλιογενείς και μεικτοί βυθοί στα 30–120 m."
  },
  "when": {
   "en": "Autumn–winter; dusk is best.",
   "el": "Φθινόπωρο–χειμώνα· καλύτερα το σούρουπο."
  },
  "handling": {
   "en": "Venomous dorsal, pelvic, anal and gill-cover spines: handle with gloves, a cloth or pliers; cut the spines with scissors before cleaning. If stung, immerse in water as hot as bearable for 30–90 minutes and get medical help if severe.",
   "el": "Δηλητηριώδη αγκάθια στο ραχιαίο, κοιλιακά, εδρικό και βράγχια: χειρισμός με γάντια, πανί ή πένσα· κόψτε τα αγκάθια με ψαλίδι πριν το καθάρισμα. Αν τσιμπηθείτε, βάλτε το σημείο σε όσο πιο ζεστό νερό αντέχετε για 30–90 λεπτά και ζητήστε ιατρική βοήθεια αν είναι σοβαρό."
  },
  "eating": {
   "en": "Excellent firm flesh, the classic fish for soup (kakavia). The venom is only in the spines.",
   "el": "Εξαιρετικό σφιχτό κρέας, το κλασικό ψάρι για ψαρόσουπα (κακαβιά). Το δηλητήριο είναι μόνο στα αγκάθια."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://piscor.com/ie-gb/e/red-scorpionfish-fishing-from-the-boat-with-shrimp-horse-mackerel-and-mackerel-trigger",
   "https://www.fishbase.se/summary/Scorpaena-scrofa.html",
   "https://www.boatfishing.gr/article-post/slow-jigging-inchiku-peskandritses-kai-skorpines-se-vathia-nera/"
  ]
 },
 "blackscorpion": {
  "summary": {
   "en": "Black scorpionfish: a small shallow-water scorpionfish of rocks and breakwaters, hungry after dark. Shrimp, worm or squid on short bottom rigs tight to the rocks, or soft lures dragged through the rocks (rockfishing). Venomous spines.",
   "el": "Σκορπιός (μαύρος): μικρός σκορπιός των ρηχών βράχων και λιμενοβραχιόνων, που τρώει μετά το σκοτάδι. Γαρίδα, σκουλήκι ή καλαμάρι σε κοντή σύνθεση βυθού κολλητά στα βράχια, ή σιλικόνες που σέρνονται ανάμεσα στις πέτρες (rockfishing). Δηλητηριώδη αγκάθια."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8 / mono 0.25–0.30 mm",
     "leader": "fluoro 0.22–0.30 mm"
    },
    "rig": [
     "bottom_rig",
     "drop_shot"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Short rig with a 10–30 g sinker dropped straight down beside breakwater blocks; or LRF/rockfishing with 3–10 g jig heads.",
     "el": "Κοντή αρματωσιά με μολύβι 10–30 g ίσια κάτω δίπλα στους ογκόλιθους του λιμενοβραχίονα· ή LRF/rockfishing με μολυβοκέφαλα 3–10 g."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.2",
     "leader": "mono 0.30–0.35 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Light paternoster over shallow rock.",
     "el": "Ελαφριά καθετή πάνω από ρηχά βράχια."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "In holes at 2–15 m; mind the spines when unloading the shaft.",
     "el": "Σε τρύπες στα 2–15 m· προσοχή στα αγκάθια όταν τον βγάζετε από τη βέργα."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Shrimp, whole or in pieces.",
     "el": "Γαρίδα, ολόκληρη ή σε κομμάτια."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid strip.",
     "el": "Λωρίδα καλαμαριού."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_grub",
    "weight": "3–10 g",
    "size": "4–7 cm",
    "colors": [
     "natural",
     "white",
     "orange",
     "black"
    ],
    "note": {
     "en": "Mini grubs and creature baits dragged slowly through the rocks, pausing in gaps. Light colours (white, yellow, orange) at night, dark ones (black, grey, blue) in full sun, brown with glitter all round (Italian rockfishing practice).",
     "el": "Μικρά grub και creature που σέρνονται αργά ανάμεσα στις πέτρες, με παύσεις στα κενά. Ανοιχτά χρώματα (άσπρο, κίτρινο, πορτοκαλί) τη νύχτα, σκούρα (μαύρο, γκρι, μπλε) με δυνατό ήλιο, καφέ με γκλίτερ για όλες τις συνθήκες (ιταλική πρακτική rockfishing)."
    }
   },
   {
    "gear": "soft_shrimp",
    "weight": "3–10 g",
    "size": "4–6 cm",
    "colors": [
     "natural",
     "orange"
    ],
    "note": {
     "en": "Same, on a weedless or Texas-style rig.",
     "el": "Το ίδιο, σε αρμάτωμα weedless ή τύπου Texas."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "5–7 g",
    "size": "7–12 cm",
    "colors": [
     "natural",
     "white",
     "black"
    ],
    "note": {
     "en": "Bigger than you might expect: 7–12 cm shads on 5–7 g heads, or weedless on an offset hook, take the better fish.",
     "el": "Μεγαλύτερες απ’ ό,τι θα περιμένατε: shad 7–12 cm σε μολυβοκεφαλές 5–7 g, ή weedless σε αγκίστρι offset, φέρνουν τα καλύτερα ψάρια."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes, classic rockfishing: mini grubs and creatures on 3–10 g heads, or 7–12 cm shads on 5–7 g heads, ideally weedless on an offset hook, crawled through the rocks; strike hard on soft plastics.",
    "el": "Ναι, κλασικό rockfishing: μικρά grub και creature σε μολυβοκεφαλές 3–10 g, ή shad 7–12 cm σε 5–7 g, ιδανικά weedless σε αγκίστρι offset, που σέρνονται ανάμεσα στις πέτρες· δυνατό κάρφωμα με τις σιλικόνες."
   },
   "ids": [
    "soft_grub",
    "soft_shad",
    "soft_shrimp"
   ],
   "colors": [
    "natural",
    "white",
    "orange",
    "black"
   ],
   "size": "4–12 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not needed.",
    "el": "Δεν χρειάζεται."
   }
  },
  "technique": {
   "en": "Drop the bait into gaps between rocks or blocks, keep it still and strike at the first firm pull; lift it out of the rocks at once.",
   "el": "Ρίξτε το δόλωμα στα κενά ανάμεσα σε πέτρες ή ογκόλιθους, κρατήστε το ακίνητο και καρφώστε στο πρώτο δυνατό τράβηγμα· βγάλτε τον αμέσως από τις πέτρες."
  },
  "where": {
   "en": "Breakwaters, harbour walls and shallow rocky coasts, 0–30 m.",
   "el": "Λιμενοβραχίονες, μώλοι και ρηχές βραχώδεις ακτές, 0–30 m."
  },
  "when": {
   "en": "All year; bait after dark, lures by day as well.",
   "el": "Όλο τον χρόνο· με δόλωμα μετά το σκοτάδι, με τεχνητά και τη μέρα."
  },
  "handling": {
   "en": "Venomous spines: gloves, a cloth or pliers. If stung, immerse in water as hot as bearable and seek medical help if severe.",
   "el": "Δηλητηριώδη αγκάθια: γάντια, πανί ή πένσα. Αν τσιμπηθείτε, ζεστό νερό όσο αντέχετε και ιατρική βοήθεια αν είναι σοβαρό."
  },
  "eating": {
   "en": "Good for fish soup.",
   "el": "Καλός για ψαρόσουπα."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Scorpaena-porcus.html",
   "http://eroi-dello-spinning.blogspot.com/2021/05/spinning-allo-scorfano-20-dal-light.html",
   "https://www.raccontidipesca.it/le-10-domande-sul-ligth-rock-fishing/"
  ]
 },
 "moray": {
  "summary": {
   "en": "Mediterranean moray: a powerful hole-dweller of rocky breakwaters and reefs. Whole sardine or squid on a wire or heavy trace, fished tight to the rocks at dusk and night. Strong bite: never handle it.",
   "el": "Σμέρνα: δυνατό ψάρι των τρυπών σε λιμενοβραχίονες και ξέρες. Ολόκληρη σαρδέλα ή καλαμάρι σε σύρμα ή χοντρό παράμαλλο, κολλητά στα βράχια σούρουπο και νύχτα. Δυνατή δαγκωνιά: ποτέ με το χέρι."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_spin_l"
    ],
    "line": {
     "main": "mono 0.40–0.50 mm / PE 2–3",
     "leader": "wire 30–50 lb / mono 0.80–1.00 mm, 30–50 cm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "braid",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–4/0",
    "notes": {
     "en": "Short, strong rig with a 30–80 g sinker; drag locked. Pull it out the moment it bites, or it ties itself into the rocks.",
     "el": "Κοντή, γερή αρματωσιά με μολύβι 30–80 g· φρένο κλειστό. Τραβήξτε τη τη στιγμή που τσιμπά, αλλιώς δένεται στις πέτρες."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_conv"
    ],
    "line": {
     "main": "PE 2–3",
     "leader": "wire 40–60 lb"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 2/0–4/0",
    "notes": {
     "en": "Over reef holes at 5–40 m.",
     "el": "Πάνω από τρύπες σε ξέρες στα 5–40 m."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Whole sardine or oily fish.",
     "el": "Ολόκληρη σαρδέλα ή λιπαρό ψάρι."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Whole squid or cuttlefish strips.",
     "el": "Ολόκληρο καλαμάρι ή λωρίδες σουπιάς."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not used; morays hunt by smell.",
    "el": "Δεν χρησιμοποιείται· η σμέρνα κυνηγά με την όσφρηση."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Lower the bait right next to breakwater blocks or reef holes and keep the line tight; when it pulls, lift hard at once and do not give line.",
   "el": "Κατεβάστε το δόλωμα ακριβώς δίπλα στους ογκόλιθους ή στις τρύπες και κρατήστε τεντωμένη πετονιά· όταν τραβήξει, σηκώστε δυνατά αμέσως και μη δίνετε πετονιά."
  },
  "where": {
   "en": "Breakwaters, rocky shores and reef holes, 0–40 m.",
   "el": "Λιμενοβραχίονες, βραχώδεις ακτές και τρύπες σε ξέρες, 0–40 m."
  },
  "when": {
   "en": "May–October best; dusk and night.",
   "el": "Μάιο–Οκτώβριο καλύτερα· σούρουπο και νύχτα."
  },
  "handling": {
   "en": "Powerful bite that infects easily, and it keeps biting on land. Never reach into holes. Unhook with long pliers, or simply cut the line close to the mouth. Not recommended as a spearfishing target: a speared moray can turn on the diver.",
   "el": "Δυνατή δαγκωνιά που μολύνεται εύκολα, και δαγκώνει και έξω από το νερό. Ποτέ χέρι σε τρύπες. Ξαγκίστρωμα με μακριά πένσα, ή απλώς κόψτε την πετονιά κοντά στο στόμα. Δεν συνιστάται για ψαροντούφεκο: η χτυπημένη σμέρνα μπορεί να στραφεί στον δύτη."
  },
  "eating": {
   "en": "Edible, tasty but bony; best in stews.",
   "el": "Τρώγεται, νόστιμη αλλά με κόκκαλα· καλύτερα σε φαγητά κατσαρόλας."
  },
  "sources": [
   "https://www.fishbase.se/summary/Muraena-helena.html",
   "https://www.psarema.gr/sizitiseis/old-casting-surfcasting/166029-%CF%83%CF%85%CF%81%CE%BC%CE%AC%CF%84%CE%B9%CE%BD%CE%B1-%CF%80%CE%B1%CF%81%CE%AC%CE%BC%CE%B1%CE%BB%CE%B1",
   "https://www.psarema.gr/sizitiseis/old-dolomata/166831-%CF%84%CE%B1-%CF%80%CE%AC%CE%BD%CF%84%CE%B1-%CF%83%CF%87%CE%B5%CF%84%CE%B9%CE%BA%CE%AC-%CE%BC%CE%B5-%CF%84%CE%B1-%CE%B4%CE%BF%CE%BB%CF%8E%CE%BC%CE%B1%CF%84%CE%B1"
  ]
 },
 "conger": {
  "summary": {
   "en": "Conger eel: a very strong night feeder of breakwaters, wrecks and rocky ledges. Whole squid, cuttlefish or oily fish on heavy tackle on dark winter nights.",
   "el": "Μουγγρί: πολύ δυνατό ψάρι που τρώει τη νύχτα σε λιμενοβραχίονες, ναυάγια και βραχώδεις πεζούλες. Ολόκληρο καλαμάρι, σουπιά ή λιπαρό ψάρι σε βαρύ εξοπλισμό, τις σκοτεινές νύχτες του χειμώνα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "boat_rod"
    ],
    "reel": [
     "reel_spin_l"
    ],
    "line": {
     "main": "mono 0.45–0.60 mm / PE 3–4",
     "leader": "mono 1.00–1.40 mm / wire, 50 cm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "braid",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 4/0–8/0",
    "notes": {
     "en": "Heavy rod, locked drag and a weak link to the sinker. Do not give it time to get its tail around rocks.",
     "el": "Βαρύ καλάμι, κλειστό φρένο και αδύναμο κλάδο για το μολύβι. Μην του δώσετε χρόνο να τυλίξει την ουρά του στις πέτρες."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_conv"
    ],
    "line": {
     "main": "PE 3–5",
     "leader": "mono 1.20–1.50 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 6/0–8/0",
    "notes": {
     "en": "Anchored over wrecks and rocky ledges at night; deep fish to 100 m and more.",
     "el": "Αγκυροβολημένοι πάνω από ναυάγια και πεζούλες τη νύχτα· τα μεγάλα και πάνω από 100 m."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Whole squid or cuttlefish.",
     "el": "Ολόκληρο καλαμάρι ή σουπιά."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Oily fish: sardine, mackerel, or a fish head.",
     "el": "Λιπαρό ψάρι: σαρδέλα, κολιός ή ψαροκεφαλή."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not normally; a mesh bag of fish scraps near the bait can help on wrecks.",
    "el": "Συνήθως όχι· ένα διχτάκι με υπολείμματα ψαριού κοντά στο δόλωμα βοηθά καμιά φορά στα ναυάγια."
   }
  },
  "technique": {
   "en": "Big bait on the bottom next to cover, line tight; when the bite develops into a steady pull, strike hard and pump it straight up.",
   "el": "Μεγάλο δόλωμα στον βυθό δίπλα σε κρυψώνα, τεντωμένη πετονιά· όταν το τσίμπημα γίνει σταθερό τράβηγμα, δυνατό κάρφωμα και σηκώστε το ίσια πάνω."
  },
  "where": {
   "en": "Breakwaters, harbour walls, wrecks and rocky ledges; shore to 100 m+.",
   "el": "Λιμενοβραχίονες, μώλοι, ναυάγια και βραχώδεις πεζούλες· από την ακτή ως 100 m και πάνω."
  },
  "when": {
   "en": "Winter; dark, moonless nights.",
   "el": "Χειμώνα· σκοτεινές νύχτες χωρίς φεγγάρι."
  },
  "handling": {
   "en": "Very strong, bites hard and spins: keep fingers well clear; unhook with long pliers or cut the line. Kill or release it in the water.",
   "el": "Πολύ δυνατό, δαγκώνει σκληρά και στριφογυρίζει: δάχτυλα μακριά· ξαγκίστρωμα με μακριά πένσα ή κόψτε την πετονιά. Σκοτώστε ή απελευθερώστε το μέσα στο νερό."
  },
  "eating": {
   "en": "Good in soups and stews; the tail end is bony.",
   "el": "Καλό σε σούπες και φαγητά κατσαρόλας· η ουρά έχει πολλά κόκκαλα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Conger-conger.html",
   "https://www.psarema.gr/sizitiseis/psaria-tis-8alassas/100275-ta-psaria-tis-elladas",
   "https://www.psarema.gr/sizitiseis/old-casting-surfcasting/166029-%CF%83%CF%85%CF%81%CE%BC%CE%AC%CF%84%CE%B9%CE%BD%CE%B1-%CF%80%CE%B1%CF%81%CE%AC%CE%BC%CE%B1%CE%BB%CE%B1"
  ]
 },
 "rainbowwrasse": {
  "summary": {
   "en": "Mediterranean rainbow wrasse: a small, colourful, ever-present fish of rocks and seagrass. Tiny hooks with worm or shrimp on a float or light leger, or micro soft lures; sunny days, April–October.",
   "el": "Γύλος: μικρό, πολύχρωμο ψάρι που υπάρχει παντού σε βράχια και ποσειδωνία. Μικροσκοπικά αγκίστρια με σκουλήκι ή γαρίδα σε φελλό ή ελαφριά σύνθεση βυθού, ή μικροσκοπικές σιλικόνες· ηλιόλουστες μέρες, Απρίλιο–Οκτώβριο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm / PE 0.2–0.4",
     "leader": "fluoro/mono 0.12–0.16 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 12–14",
    "notes": {
     "en": "Bolognese 4–5 m with a 1–2 g float set near the bottom, or an LRF rod 0.5–5 g.",
     "el": "Μπολονέζ 4–5 m με φελλό 1–2 g ρυθμισμένο κοντά στον βυθό, ή καλάμι LRF 0,5–5 g."
    }
   },
   "boat": {
    "rod": [
     "boat_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8",
     "leader": "mono 0.18–0.20 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 12–14",
    "notes": {
     "en": "Light paternoster; usually a by-catch when bottom fishing.",
     "el": "Ελαφριά καθετή· συνήθως παρεμπίπτον αλίευμα στο ψάρεμα βυθού."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Small pieces of worm.",
     "el": "Μικρά κομματάκια σκουλήκι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Tiny shrimp pieces.",
     "el": "Μικροσκοπικά κομμάτια γαρίδας."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Mussel flesh.",
     "el": "Ψίχα μυδιού."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_worm",
    "weight": "0.5–2 g",
    "size": "2–4 cm",
    "colors": [
     "natural",
     "red",
     "chartreuse"
    ],
    "note": {
     "en": "Micro soft worms (LRF) bounced on the bottom.",
     "el": "Μικροσκοπικά σιλικονένια σκουλήκια (LRF) με πηδηματάκια στον βυθό."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 2–4 cm micro worms or grubs on 0.5–2 g jig heads; scented ones help.",
    "el": "Ναι: μικροσκοπικά σκουλήκια ή grub 2–4 cm σε μολυβοκέφαλα 0,5–2 g· βοηθούν τα αρωματισμένα."
   },
   "ids": [
    "soft_grub",
    "soft_worm"
   ],
   "colors": [
    "natural",
    "red"
   ],
   "size": "2–4 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A little crushed mussel or sea urchin brings them in quickly.",
    "el": "Λίγο λιωμένο μύδι ή αχινός τους φέρνει γρήγορα."
   }
  },
  "technique": {
   "en": "Fish small baits right on the bottom near rocks; strike lightly at the first sharp tug.",
   "el": "Μικρά δολώματα ακριβώς στον βυθό κοντά στα βράχια· ελαφρύ κάρφωμα στο πρώτο απότομο τράβηγμα."
  },
  "where": {
   "en": "Rocky shores and seagrass, 1–30 m; every harbour and rocky coast.",
   "el": "Βραχώδεις ακτές και ποσειδωνία, 1–30 m· σε κάθε λιμάνι και βραχώδη ακτή."
  },
  "when": {
   "en": "April–October; sunny daytime only (it buries in sand at night).",
   "el": "Απρίλιο–Οκτώβριο· μόνο ηλιόλουστη μέρα (τη νύχτα θάβεται στην άμμο)."
  },
  "handling": {
   "en": "Harmless; small mouth, so use a disgorger or small pliers.",
   "el": "Ακίνδυνος· μικρό στόμα, χρησιμοποιήστε ξαγκιστρωτήρι ή μικρή πένσα."
  },
  "eating": {
   "en": "Small, but good fried or in soup; many anglers release them.",
   "el": "Μικρός, αλλά καλός τηγανητός ή σε σούπα· πολλοί ψαράδες τον αφήνουν."
  },
  "sources": [
   "https://www.fishbase.se/summary/Coris-julis.html",
   "https://www.psarema.gr/sizitiseis/psaria-tis-8alassas/115129-o-gylos",
   "https://www.boatfishing.gr/article-post/light-rock-fishing-ta-megalytera-tropaia-toy-lrf/"
  ]
 },
 "ornatewrasse": {
  "summary": {
   "en": "Ornate wrasse: a bright green wrasse of very shallow rocks. Tiny hooks with shrimp, worm or mussel off rocks and jetties on hot sunny days, May–October.",
   "el": "Πρασινόγυλος: φωτεινός πράσινος γύλος των πολύ ρηχών βράχων. Μικροσκοπικά αγκίστρια με γαρίδα, σκουλήκι ή μύδι από βράχια και προβλήτες τις ζεστές ηλιόλουστες μέρες, Μάιο–Οκτώβριο."
  },
  "best": [
   "shore"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.14–0.18 mm / PE 0.2–0.4",
     "leader": "mono 0.12–0.14 mm"
    },
    "rig": [
     "float_rig",
     "free_line"
    ],
    "terminal": [
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 14–16",
    "notes": {
     "en": "Ultra-light: a tiny float or just a split shot, in 1–5 m of water.",
     "el": "Υπερελαφρύ: μικροσκοπικός φελλός ή απλώς ένα σκάγι, σε νερά 1–5 m."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Tiny shrimp pieces.",
     "el": "Μικροσκοπικά κομμάτια γαρίδας."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm pieces.",
     "el": "Κομματάκια σκουλήκι."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Mussel flesh.",
     "el": "Ψίχα μυδιού."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not really: tiny natural baits work far better; it only occasionally grabs micro lures meant for other fish.",
    "el": "Όχι ουσιαστικά: τα μικροσκοπικά φυσικά δολώματα δουλεύουν πολύ καλύτερα· μόνο πού και πού αρπάζει μικροσκοπικά τεχνητά για άλλα ψάρια."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A pinch of crushed mussel.",
    "el": "Λίγο λιωμένο μύδι."
   }
  },
  "technique": {
   "en": "Drop a small bait among shallow rocks and strike lightly; they steal baits fast.",
   "el": "Ρίξτε μικρό δόλωμα ανάμεσα στα ρηχά βράχια και καρφώστε ελαφρά· κλέβουν γρήγορα τα δολώματα."
  },
  "where": {
   "en": "Very shallow rocks and jetties, 0–15 m.",
   "el": "Πολύ ρηχά βράχια και προβλήτες, 0–15 m."
  },
  "when": {
   "en": "May–October; hot sunny days.",
   "el": "Μάιο–Οκτώβριο· ζεστές ηλιόλουστες μέρες."
  },
  "handling": {
   "en": "Harmless; release unwanted fish quickly.",
   "el": "Ακίνδυνος· γρήγορη απελευθέρωση όσων δεν θέλετε."
  },
  "eating": {
   "en": "Small; edible fried, but usually released.",
   "el": "Μικρός· τρώγεται τηγανητός, αλλά συνήθως απελευθερώνεται."
  },
  "sources": [
   "https://www.fishbase.se/summary/Thalassoma-pavo.html"
  ]
 },
 "squirrelfish": {
  "summary": {
   "en": "Redcoat squirrelfish: a red, big-eyed Red Sea newcomer that hides in caves and crevices by day and feeds at night. Small shrimp or squid baits on a light bottom rig close to rocks after dusk. Venomous gill-cover spine.",
   "el": "Ρώσος: κόκκινο ψάρι με μεγάλα μάτια από την Ερυθρά, που κρύβεται σε σπηλιές και σχισμές τη μέρα και τρώει τη νύχτα. Μικρή γαρίδα ή καλαμάρι σε ελαφριά σύνθεση βυθού κοντά στα βράχια μετά το σούρουπο. Δηλητηριώδες αγκάθι στο βράγχιο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8 / mono 0.22–0.25 mm",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "bottom_rig",
     "float_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 8–10",
    "notes": {
     "en": "Short light rig close to rocks, caves and breakwaters; a small float works over shallow ledges.",
     "el": "Κοντή ελαφριά αρματωσιά κοντά σε βράχια, σπηλιές και λιμενοβραχίονες· ένας μικρός φελλός πιάνει πάνω από ρηχές πεζούλες."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s",
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "mono 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 8–10",
    "notes": {
     "en": "Light paternoster over shallow reefs at night.",
     "el": "Ελαφριά καθετή πάνω από ρηχές ξέρες τη νύχτα."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small shrimp.",
     "el": "Μικρή γαρίδα."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Small squid strips.",
     "el": "Μικρές λωρίδες καλαμαριού."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not really used: it feeds at night on small crustaceans (mostly shrimps and crabs), so natural bait is the way; no reliable reports of soft-plastic catches.",
    "el": "Δεν χρησιμοποιείται ουσιαστικά: τρώει τη νύχτα μικρά καρκινοειδή (κυρίως γαρίδες και καβουράκια), οπότε το φυσικό δόλωμα είναι ο τρόπος· δεν υπάρχουν αξιόπιστες αναφορές για σιλικόνες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not needed.",
    "el": "Δεν χρειάζεται."
   }
  },
  "technique": {
   "en": "Fish after dark, baits still and close to the rock face; strike at the first pull.",
   "el": "Ψαρεύετε μετά το σκοτάδι, με τα δολώματα ακίνητα και κοντά στον βράχο· κάρφωμα στο πρώτο τράβηγμα."
  },
  "where": {
   "en": "Rocky reefs, caves, crevices and breakwaters at 1–50 m.",
   "el": "Βραχώδεις ξέρες, σπηλιές, σχισμές και λιμενοβραχίονες στα 1–50 m."
  },
  "when": {
   "en": "Summer nights.",
   "el": "Καλοκαιρινές νύχτες."
  },
  "handling": {
   "en": "Venomous spine on each gill cover and sharp fin spines: hold it with a cloth behind the head. If stung, immerse in hot water (as hot as bearable) and seek medical advice if severe.",
   "el": "Δηλητηριώδες αγκάθι σε κάθε βραγχιακό κάλυμμα και κοφτερά αγκάθια στα πτερύγια: πιάστε το με πανί πίσω από το κεφάλι. Αν τσιμπηθείτε, ζεστό νερό όσο αντέχετε και ιατρική συμβουλή αν είναι σοβαρό."
  },
  "eating": {
   "en": "Edible; non-native species, so keeping it does no harm.",
   "el": "Τρώγεται· ξενικό είδος, οπότε δεν βλάπτει να το κρατήσετε."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Sargocentron-rubrum.html",
   "https://fishes-fnam.linnaeus.naturalis.nl/linnaeus_ng/app/views/species/taxon.php?id=108920"
  ]
 },
 "leatherjacket": {
  "summary": {
   "en": "Reticulated leatherjacket: a Red Sea filefish that nibbles baits off hooks around rocks and seagrass. Small strong hooks with squid or shrimp bits; daytime, June–October.",
   "el": "Χοιρόψαρο: ψάρι από την Ερυθρά που «καθαρίζει» τα δολώματα από τα αγκίστρια γύρω από βράχια και ποσειδωνία. Μικρά γερά αγκίστρια με κομματάκια καλαμαριού ή γαρίδας· μέρα, Ιούνιο–Οκτώβριο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "bolognese_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.3–0.6 / mono 0.18–0.22 mm",
     "leader": "fluoro 0.18–0.22 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 10–12",
    "notes": {
     "en": "Small but strong hooks: its tiny beak-like teeth bite through fine wire and chew baits off.",
     "el": "Μικρά αλλά γερά αγκίστρια: τα μικρά δόντια του σαν ράμφος κόβουν το λεπτό σύρμα και τρώνε τα δολώματα."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "mono 0.22–0.25 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 10–12",
    "notes": {
     "en": "Light paternoster near rock and seagrass.",
     "el": "Ελαφριά καθετή κοντά σε βράχο και ποσειδωνία."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Tough little squid pieces stay on longest.",
     "el": "Τα σκληρά κομματάκια καλαμαριού μένουν περισσότερο στο αγκίστρι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp bits.",
     "el": "Κομματάκια γαρίδας."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not effective; it bites soft plastics to pieces without hooking.",
    "el": "Δεν αποδίδει· κομματιάζει τις σιλικόνες χωρίς να αγκιστρώνεται."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A little crushed mussel or fish brings them in.",
    "el": "Λίγο λιωμένο μύδι ή ψάρι τα φέρνει."
   }
  },
  "technique": {
   "en": "Use small baits that hide the hook point, and strike at the first light knock.",
   "el": "Μικρά δολώματα που κρύβουν τη μύτη του αγκιστριού, και κάρφωμα στο πρώτο ελαφρύ χτύπημα."
  },
  "where": {
   "en": "Rocks, seagrass and harbours at 3–40 m.",
   "el": "Βράχια, ποσειδωνία και λιμάνια στα 3–40 m."
  },
  "when": {
   "en": "June–October; daytime.",
   "el": "Ιούνιο–Οκτώβριο· μέρα."
  },
  "handling": {
   "en": "A stiff dorsal spine locks upright: fold it down before handling. Small sharp teeth.",
   "el": "Το σκληρό ραχιαίο αγκάθι κλειδώνει όρθιο: κατεβάστε το πριν το πιάσετε. Μικρά κοφτερά δόντια."
  },
  "eating": {
   "en": "Edible once skinned; non-native, so keeping it does no harm.",
   "el": "Τρώγεται αφού γδαρθεί· ξενικό, οπότε δεν βλάπτει να το κρατήσετε."
  },
  "sources": [
   "https://www.fishbase.se/summary/Stephanolepis-diaspros.html"
  ]
 },
 "toadfish": {
  "summary": {
   "en": "Silver-cheeked toadfish: an invasive pufferfish that is DEADLY TO EAT (tetrodotoxin survives cooking; no antidote). It shreds baits, lures and line. Gear here is only for removing it or avoiding losses: wire leaders, strong hooks, pliers.",
   "el": "Λαγοκέφαλος: ξενικός λαγοκέφαλος που είναι ΘΑΝΑΤΗΦΟΡΟΣ ΑΝ ΦΑΓΩΘΕΙ (η τετροδοτοξίνη αντέχει στο μαγείρεμα· δεν υπάρχει αντίδοτο). Κόβει δολώματα, τεχνητά και πετονιές. Ο εξοπλισμός εδώ είναι μόνο για να τον αφαιρέσετε ή να αποφύγετε ζημιές: συρματόπετονια, γερά αγκίστρια, πένσα."
  },
  "best": [
   "boat",
   "shore",
   "spear"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 1.5–3",
     "leader": "wire 30–60 lb, 20–30 cm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–3/0",
    "notes": {
     "en": "Short wire trace before the hook: its fused beak cuts mono and fluoro instantly. When toadfish show up, change spot: they follow the boat and strip every bait.",
     "el": "Κοντό σύρμα πριν από το αγκίστρι: το ενωμένο ράμφος του κόβει αμέσως μονόκλωνο και fluoro. Όταν εμφανιστούν λαγοκέφαλοι, αλλάξτε σημείο: ακολουθούν το σκάφος και καθαρίζουν κάθε δόλωμα."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "surf_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1–2 / mono 0.30–0.40 mm",
     "leader": "wire 30–40 lb, 20 cm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "braid",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–2/0",
    "notes": {
     "en": "Same principle from shore: short wire, strong hook, pliers ready.",
     "el": "Ίδια λογική από ακτή: κοντό σύρμα, γερό αγκίστρι, πένσα έτοιμη."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–90 cm",
    "notes": {
     "en": "Slow and curious, easy to spear for removal. Do not grab it: it bites; handle the speared fish with gloves and pliers.",
     "el": "Αργός και περίεργος, εύκολος στόχος για αφαίρεση. Μην τον πιάνετε: δαγκώνει· χειρισμός του χτυπημένου ψαριού με γάντια και πένσα."
    }
   }
  },
  "baits": [
   {
    "gear": "squid_bait",
    "best": true,
    "note": {
     "en": "Squid strips on wire attract it quickly (for removal only).",
     "el": "Λωρίδες καλαμαριού σε σύρμα τον τραβούν γρήγορα (μόνο για αφαίρεση)."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sardine also works; expect bitten-off baits.",
     "el": "Πιάνει και με σαρδέλα· να περιμένετε κομμένα δολώματα."
    }
   }
  ],
  "lures": [
   {
    "gear": "metal_jig",
    "weight": "20–100 g",
    "size": "",
    "colors": [
     "silver",
     "glow"
    ],
    "note": {
     "en": "It often bites jigs and cuts assist cords; for removal only, a jig with a single wire-rigged hook.",
     "el": "Χτυπά συχνά τα τζιγκ και κόβει τα assist· μόνο για αφαίρεση, τζιγκ με μονό αγκίστρι σε σύρμα."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Avoid when toadfish are around: they bite tails off soft plastics.",
    "el": "Αποφύγετε όταν υπάρχουν λαγοκέφαλοι: κόβουν τις ουρές από τις σιλικόνες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Do not chum: it draws more of them.",
    "el": "Χωρίς μάλαγρα: φέρνει περισσότερους."
   }
  },
  "technique": {
   "en": "Removal: wire-trace bottom rig with squid on strong long-shank hooks at 5–100 m over sand and mixed ground. Avoidance: move as soon as baits come back bitten clean, and use wire on any bait rig.",
   "el": "Αφαίρεση: σύνθεση βυθού με σύρμα και καλαμάρι σε γερά αγκίστρια με μακρύ λαιμό, στα 5–100 m πάνω από άμμο και μεικτό βυθό. Αποφυγή: αλλάξτε σημείο μόλις τα δολώματα γυρίζουν «καθαρισμένα», και βάλτε σύρμα σε κάθε σύνθεση με δόλωμα."
  },
  "where": {
   "en": "All around Cyprus over sand, seagrass and mixed bottoms, 5–100 m (to 250 m).",
   "el": "Γύρω από όλη την Κύπρο πάνω από άμμο, ποσειδωνία και μεικτούς βυθούς, 5–100 m (ως 250 m)."
  },
  "when": {
   "en": "All year; most common late spring–summer.",
   "el": "Όλο τον χρόνο· πιο συχνός τέλη άνοιξης–καλοκαίρι."
  },
  "handling": {
   "en": "Powerful fused-beak bite that can sever a fingertip: never hold it near the mouth; unhook with long pliers or cut the wire. Wear gloves, do not cut it open, wash hands and tools afterwards. Do not give it to anyone or to pets; dispose of it in a closed bin. Swimmers are not at risk; DFMR pays only professional fishers for removal.",
   "el": "Δυνατή δαγκωνιά με ενωμένο ράμφος που μπορεί να κόψει άκρη δαχτύλου: ποτέ κοντά στο στόμα· ξαγκίστρωμα με μακριά πένσα ή κόψτε το σύρμα. Γάντια, μην τον ανοίγετε, πλύνετε χέρια και εργαλεία μετά. Μην τον δίνετε σε κανέναν ούτε σε κατοικίδια· πετάξτε τον σε κλειστό κάδο. Οι λουόμενοι δεν κινδυνεύουν· το ΤΑΘΕ πληρώνει μόνο επαγγελματίες για την αφαίρεση."
  },
  "eating": {
   "en": "NEVER EAT IT. Tetrodotoxin in organs, skin and flesh is not destroyed by cooking, freezing or drying; there is no antidote, and eating or selling it is banned. Symptoms (tingling lips, numbness, weakness, breathing trouble) need emergency help: call 112.",
   "el": "ΠΟΤΕ ΜΗΝ ΤΟΝ ΦΑΤΕ. Η τετροδοτοξίνη σε όργανα, δέρμα και σάρκα δεν καταστρέφεται με μαγείρεμα, κατάψυξη ή αποξήρανση· δεν υπάρχει αντίδοτο, και η κατανάλωση και η πώληση απαγορεύονται. Τα συμπτώματα (μυρμήγκιασμα στα χείλη, μούδιασμα, αδυναμία, δύσπνοια) θέλουν επείγουσα βοήθεια: καλέστε 112."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://en.politis.com.cy/news/cy-news/1014698/cyprus-authorities-reassure-public-over-lagocephalus-fears",
   "https://cyprus-mail.com/2026/06/23/invasive-pufferfish-pose-no-threat-to-swimmers",
   "https://imbriw.hcmr.gr/wp-content/uploads/2014/01/enimerotiko-fylladio.pdf",
   "https://lionhare.hcmr.gr/wp-content/uploads/2022/10/Christidis_et_al.pdf",
   "https://eur-lex.europa.eu/eli/reg/2004/853/oj",
   "https://www.fishbase.se/summary/Lagocephalus-sceleratus.html"
  ]
 },
 "weever": {
  "summary": {
   "en": "Greater weever: a sand-buried ambusher of sandy bays, with venomous spines. Worm or shrimp on a running ledger at dusk and night in summer; small soft lures dragged on sand also work. Unhook with pliers.",
   "el": "Δράκαινα: ψάρι-ενέδρα θαμμένο στην άμμο των αμμωδών κόλπων, με δηλητηριώδη αγκάθια. Σκουλήκι ή γαρίδα σε συρόμενη σύνθεση βυθού σούρουπο και νύχτα το καλοκαίρι· πιάνει και με μικρές σιλικόνες που σέρνονται στην άμμο. Ξαγκίστρωμα με πένσα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "mono/fluoro 0.25–0.30 mm"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 6–2",
    "notes": {
     "en": "Running ledger or light surf rig with a 30–80 g sinker over clean sand; 1–1.5 m trace.",
     "el": "Συρόμενο μολύβι ή ελαφριά σύνθεση surf με μολύβι 30–80 g πάνω από καθαρή άμμο· παράμαλλο 1–1,5 m."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.5",
     "leader": "mono 0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "hook_j",
     "sinker"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Drift over sand at 5–30 m; frequent by-catch.",
     "el": "Ντρίφτα πάνω από άμμο στα 5–30 m· συχνό παρεμπίπτον αλίευμα."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Worm on a size 4–2 hook.",
     "el": "Σκουλήκι σε αγκίστρι 4–2."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp.",
     "el": "Γαρίδα."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Small fish strip.",
     "el": "Μικρή λωρίδα ψαριού."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_grub",
    "weight": "3–10 g",
    "size": "4–7 cm",
    "colors": [
     "natural",
     "chartreuse"
    ],
    "note": {
     "en": "Dragged slowly on the sand (LRF).",
     "el": "Αργό σύρσιμο στην άμμο (LRF)."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: small grubs or soft shrimp on 3–10 g heads, dragged slowly over sand; Greek anglers also take weevers on small soft lures and spoons trolled slowly over sandy shallows.",
    "el": "Ναι: μικρά grub ή σιλικονένιες γαρίδες σε μολυβοκέφαλα 3–10 g, αργό σύρσιμο στην άμμο· στην Ελλάδα δράκαινες πιάνονται και σε ελαφριά συρτή με μικρές σιλικόνες και κουταλάκια πάνω από ρηχές αμμουδιές."
   },
   "ids": [
    "soft_grub",
    "soft_shrimp"
   ],
   "colors": [
    "natural",
    "chartreuse"
   ],
   "size": "4–7 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Cast, let the bait settle on the sand and drag it a little every minute.",
   "el": "Ρίξτε, αφήστε το δόλωμα να κάτσει στην άμμο και σύρετέ το λίγο κάθε λεπτό."
  },
  "where": {
   "en": "Sandy bays such as Larnaca and Limassol, 1–30 m.",
   "el": "Αμμώδεις κόλποι όπως της Λάρνακας και της Λεμεσού, 1–30 m."
  },
  "when": {
   "en": "Summer; dusk and night.",
   "el": "Καλοκαίρι· σούρουπο και νύχτα."
  },
  "handling": {
   "en": "Venomous first dorsal fin and gill-cover spines; it stings even out of the water. Never touch it: pin it with a cloth or boot, unhook with pliers, and cut the spines off with scissors. If stung, immerse in water as hot as bearable and seek medical help if severe.",
   "el": "Δηλητηριώδη αγκάθια στο πρώτο ραχιαίο και στα βραγχιακά· τσιμπά ακόμη κι έξω από το νερό. Ποτέ με γυμνά χέρια: ακινητοποιήστε τη με πανί ή παπούτσι, ξαγκίστρωμα με πένσα, και κόψτε τα αγκάθια με ψαλίδι. Αν τσιμπηθείτε, ζεστό νερό όσο αντέχετε και ιατρική βοήθεια αν είναι σοβαρό."
  },
  "eating": {
   "en": "Excellent flesh, prized for soup; remove the spines first.",
   "el": "Εξαιρετικό κρέας, περιζήτητο για ψαρόσουπα· βγάλτε πρώτα τα αγκάθια."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Trachinus-draco.html",
   "https://www.psarema.gr/blog/19-syrti/1588-i-texni-tis-syrtis-a-meros"
  ]
 },
 "lionfish": {
  "summary": {
   "en": "Lionfish: an invasive reef predator that rarely flees; spearfishing is the way to remove it, and the fillets are excellent. Venomous spines: puncture-resistant gloves are essential. Take all you can.",
   "el": "Λεοντόψαρο: ξενικό αρπακτικό των υφάλων που σπάνια φεύγει· το ψαροντούφεκο είναι ο τρόπος να το αφαιρέσετε, και τα φιλέτα του είναι εξαιρετικά. Δηλητηριώδη αγκάθια: απαραίτητα γάντια που δεν τρυπιούνται. Πάρτε όσα μπορείτε."
  },
  "best": [
   "spear"
  ],
  "setups": {
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "A short band gun or a pole spear is ideal: shots are close, among rocks. Approach slowly, it stays put; shoot through the head. Slide it off the shaft into a container or bag without touching the spines, wearing puncture-resistant gloves. Remember freediving only, no scuba.",
     "el": "Ιδανικό είναι κοντό λαστιχοβόλο ή καμάκι χειρός: οι βολές είναι κοντινές, ανάμεσα σε πέτρες. Πλησιάστε αργά, μένει στη θέση του· χτυπήστε στο κεφάλι. Βγάλτε το από τη βέργα σε δοχείο ή σακούλα χωρίς να αγγίξετε τα αγκάθια, φορώντας γάντια που δεν τρυπιούνται. Μόνο με ελεύθερη κατάδυση, όχι με φιάλες."
    }
   },
   "shore": {
    "rod": [
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Occasional catch on small baits near rocks; handle as below.",
     "el": "Πιάνεται πού και πού με μικρά δολώματα κοντά στα βράχια· χειρισμός όπως παρακάτω."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "note": {
     "en": "Small shrimp or fish bits near rocks occasionally take lionfish on hook and line.",
     "el": "Μικρή γαρίδα ή κομματάκια ψαριού κοντά στα βράχια πιάνουν καμιά φορά λεοντόψαρο με πετονιά."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not in practice: there are no reliable reports of lionfish taking soft plastics here; spearfishing is the way to remove it.",
    "el": "Όχι στην πράξη: δεν υπάρχουν αξιόπιστες αναφορές για λεοντόψαρα σε σιλικόνες εδώ· το ψαροντούφεκο είναι ο τρόπος να αφαιρεθεί."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Search ledges, overhangs, wrecks and crevices slowly; lionfish hover in place, often head-down. Close in to 1 m and take a head shot.",
   "el": "Ψάξτε αργά πεζούλες, προεξοχές, ναυάγια και σχισμές· το λεοντόψαρο αιωρείται ακίνητο, συχνά με το κεφάλι κάτω. Πλησιάστε σε 1 m και χτυπήστε στο κεφάλι."
  },
  "where": {
   "en": "Rocky reefs, wrecks, ledges and harbour structures at 5–35 m (deeper too); common in eastern and southern Cyprus.",
   "el": "Βραχώδεις ύφαλοι, ναυάγια, πεζούλες και λιμενικές κατασκευές στα 5–35 m (και βαθύτερα)· συχνό στην ανατολική και νότια Κύπρο."
  },
  "when": {
   "en": "All year; daytime (spearfishing only from sunrise to sunset).",
   "el": "Όλο τον χρόνο· μέρα (ψαροντούφεκο μόνο από την ανατολή ως τη δύση του ηλίου)."
  },
  "handling": {
   "en": "Venomous dorsal, pelvic and anal spines, venomous even after death. Wear puncture-resistant gloves, keep it in a hard container, and cut all spines off with scissors before cleaning. If stung, immerse in hot (not scalding) water for 30–90 minutes and get medical help.",
   "el": "Δηλητηριώδη αγκάθια στο ραχιαίο, κοιλιακά και εδρικό, που μένουν δηλητηριώδη και μετά τον θάνατο. Γάντια που δεν τρυπιούνται, σκληρό δοχείο, και κόψτε όλα τα αγκάθια με ψαλίδι πριν το καθάρισμα. Αν τσιμπηθείτε, ζεστό (όχι καυτό) νερό για 30–90 λεπτά και ιατρική βοήθεια."
  },
  "eating": {
   "en": "Excellent white fillets; the venom is only in the spines. Eating it helps control the invasion.",
   "el": "Εξαιρετικά άσπρα φιλέτα· το δηλητήριο είναι μόνο στα αγκάθια. Τρώγοντάς το βοηθάτε να ελεγχθεί η εισβολή."
  },
  "sources": [
   "https://webgate.ec.europa.eu/life/publicWebsite/project/LIFE16-NAT-CY-000832/preventing-a-lionfish-invasion-in-the-mediterranean-through-early-response-and-targeted-removal",
   "https://world.dan.org/?p=35348",
   "https://www.malaymail.com/news/life/2019/07/17/lionfish-invasion-in-cyprus-if-you-cant-beat-em-eat-em/1772406",
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Pterois-miles.html"
  ]
 },
 "cornetfish": {
  "summary": {
   "en": "Bluespotted cornetfish: a long, thin invasive predator over seagrass and sand. Small metal jigs, minnows, slim soft shads or a fish strip by day; an easy spearfishing target in summer. Keep it: it is invasive and good to eat.",
   "el": "Πιθκιαύλι: μακρύ, λεπτό ξενικό αρπακτικό πάνω από ποσειδωνία και άμμο. Μικρά μεταλλικά jig, minnow, λεπτές σιλικόνες shad ή λωρίδα ψαριού τη μέρα· εύκολος στόχος για ψαροντούφεκο το καλοκαίρι. Κρατήστε το: είναι ξενικό και τρώγεται."
  },
  "best": [
   "spear",
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "lrf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.4–0.8",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "float_rig"
    ],
    "terminal": [
     "braid",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 10–8",
    "notes": {
     "en": "Light spinning or LRF; its tiny tube mouth needs small hooks.",
     "el": "Ελαφρύ spinning ή LRF· το μικρό σωληνωτό στόμα θέλει μικρά αγκίστρια."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.22–0.25 mm"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro"
    ],
    "hook": "J 10–8 · treble 10–8",
    "notes": {
     "en": "Cast small lures over seagrass from a drifting boat.",
     "el": "Ρίψεις με μικρά τεχνητά πάνω από ποσειδωνία από σκάφος στη ντρίφτα."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Slow and easy to approach over seagrass and sand at 2–20 m.",
     "el": "Αργό και εύκολο να το πλησιάσετε πάνω από ποσειδωνία και άμμο στα 2–20 m."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "A thin fish strip under a float or slowly retrieved.",
     "el": "Λεπτή λωρίδα ψαριού με φελλό ή με αργό μάζεμα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small shrimp.",
     "el": "Μικρή γαρίδα."
    }
   }
  ],
  "lures": [
   {
    "gear": "casting_jig",
    "weight": "10–30 g",
    "size": "",
    "colors": [
     "silver"
    ],
    "note": {
     "en": "Small metal casting jigs over seagrass by day: the most-logged lure type in angler catch reports (worldwide, not Cyprus-specific).",
     "el": "Μικρά μεταλλικά jig για ρίψεις πάνω από ποσειδωνία τη μέρα: ο τύπος τεχνητού με τις περισσότερες καταγεγραμμένες συλλήψεις σε αναφορές ψαράδων (παγκόσμια, όχι ειδικά για την Κύπρο)."
    }
   },
   {
    "gear": "soft_shad",
    "weight": "3–10 g",
    "size": "5–12 cm",
    "colors": [
     "natural",
     "white",
     "silver"
    ],
    "note": {
     "en": "Small slim shads, slow and steady.",
     "el": "Μικρές λεπτές σιλικόνες, αργά και σταθερά."
    }
   },
   {
    "gear": "minnow",
    "weight": "",
    "size": "5–7 cm",
    "colors": [
     "silver"
    ],
    "note": {
     "en": "Small minnows.",
     "el": "Μικρά minnow."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: slim 5–12 cm paddle-tail shads on 3–10 g heads, retrieved slowly and steadily.",
    "el": "Ναι: λεπτές σιλικόνες shad 5–12 cm σε μολυβοκέφαλα 3–10 g, με αργό, σταθερό μάζεμα."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "natural",
    "white",
    "silver"
   ],
   "size": "5–12 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Retrieve small lures slowly over seagrass edges and sand; it follows and sucks in the lure, so keep going after a tap.",
   "el": "Αργό μάζεμα με μικρά τεχνητά πάνω από άκρες ποσειδωνίας και άμμο· ακολουθεί και ρουφά το τεχνητό, συνεχίστε μετά από ένα χτύπημα."
  },
  "where": {
   "en": "Seagrass meadows, sand and reef edges, 0–40 m.",
   "el": "Λιβάδια ποσειδωνίας, άμμος και άκρες υφάλων, 0–40 m."
  },
  "when": {
   "en": "Daytime; summer is best.",
   "el": "Μέρα· καλύτερα το καλοκαίρι."
  },
  "handling": {
   "en": "Harmless; the long snout is fragile.",
   "el": "Ακίνδυνο· το μακρύ ρύγχος σπάει εύκολα."
  },
  "eating": {
   "en": "Edible, firm white flesh; non-native, so keep it.",
   "el": "Τρώγεται, σφιχτό άσπρο κρέας· ξενικό, κρατήστε το."
  },
  "sources": [
   "https://www.fishbase.se/summary/Fistularia-commersonii.html",
   "https://ciesm.org/atlas/fishes_2nd_edition/Fistularia_commersonii.pdf",
   "https://www.fishfriender.com/fish/Fistularia-Commersonii.md"
  ]
 }
});
// >>> round 11 species inventory (eval/species-inventory/new-species.mjs): do not edit by hand
// Gear guides for the 19 fish added from the species inventory.
Object.assign(window.PSAREMA_GEAR ||= {}, {
 "stripedbream": {
  "summary": {
   "en": "Striped seabream: the classic surf fish of sandy beaches. It grubs in the sand stirred by the waves, so a worm on a long, light trace just behind the breakers at dusk and at night is the way; keep only fish over 20 cm.",
   "el": "Μούρμουρος: το κλασικό ψάρι του surf casting στις αμμουδιές. Σκαλίζει την άμμο που σηκώνει το κύμα, άρα σκουλήκι σε μακρύ, λεπτό παράμαλλο λίγο πίσω από το κύμα, σούρουπο και νύχτα· κρατήστε μόνο ψάρια πάνω από 20 cm."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–4, long shank",
    "notes": {
     "en": "Surf rod 4–4.2 m with a 60–100 g sinker; trace of 0.20–0.22 mm fluoro, 1.5–2 m long, one or two hooks. Fish the gutter 20–60 m out: longer casts often pass the fish.",
     "el": "Καλάμι surf 4–4,2 m με μολύβι 60–100 g· παράμαλλο fluoro 0,20–0,22 mm, 1,5–2 m, με ένα ή δύο αγκίστρια. Ψαρέψτε το κανάλι στα 20–60 m: οι πιο μακρινές βολές συχνά περνούν πάνω από τα ψάρια."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1 / mono 0.25 mm",
     "leader": "fluoro 0.20–0.25 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–4",
    "notes": {
     "en": "Anchor or drift over clean sand at 5–20 m with a light two-hook rig and a 20–40 g sinker.",
     "el": "Αγκυροβολημένοι ή σε ντρίφτα πάνω από καθαρή άμμο στα 5–20 m, με ελαφριά σύνθεση δύο αγκιστριών και μολύβι 20–40 g."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "60–75 cm",
    "notes": {
     "en": "Lie still on the sand at 3–10 m near the edge of the seagrass: schools come in to look. Measure before you shoot: 20 cm minimum.",
     "el": "Καρτέρι ακίνητοι στην άμμο στα 3–10 m, κοντά στην άκρη της ποσειδωνίας: τα κοπάδια πλησιάζουν από περιέργεια. Μετρήστε πριν ρίξετε: ελάχιστο 20 cm."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "Sandworm or ragworm threaded on a long-shank hook: the standard bait.",
     "el": "Σκουλήκι της άμμου ή μανά περασμένο σε μακρύλαιμο αγκίστρι: το βασικό δόλωμα."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Small peeled shrimp.",
     "el": "Μικρή καθαρισμένη γαρίδα."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Mussel or clam flesh tied on with bait elastic.",
     "el": "Ψίχα από μύδι ή αχιβάδα, δεμένη με λαστιχάκι."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": true,
   "what": {
    "en": "Sometimes: scented 5 cm worms dragged slowly on the sand on a light Carolina rig.",
    "el": "Κάποιες φορές: αρωματισμένα σκουλήκια 5 cm, αργό σύρσιμο στην άμμο με ελαφρύ Carolina."
   },
   "ids": [
    "soft_worm"
   ],
   "colors": [
    "natural",
    "red"
   ],
   "size": "5 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Cast, tighten the line and wait; move the bait a metre every few minutes. Bites are sharp taps: let the fish take before you lift.",
   "el": "Ρίξτε, τεντώστε την πετονιά και περιμένετε· μετακινείτε το δόλωμα ένα μέτρο κάθε λίγα λεπτά. Τα τσιμπήματα είναι κοφτά: αφήστε το ψάρι να πάρει πριν σηκώσετε."
  },
  "where": {
   "en": "Sandy beaches and bays, 1–20 m: Larnaca Bay, Limassol, Polis.",
   "el": "Αμμουδιές και κόλποι, 1–20 m: κόλπος Λάρνακας, Λεμεσός, Πόλη."
  },
  "when": {
   "en": "May–October; dusk and night, with a little surf.",
   "el": "Μάιο–Οκτώβριο· σούρουπο και νύχτα, με λίγο κύμα."
  },
  "handling": {
   "en": "Harmless. Measure it: under 20 cm it goes back at once.",
   "el": "Ακίνδυνο. Μετρήστε το: κάτω από 20 cm επιστρέφει αμέσως."
  },
  "eating": {
   "en": "Very good grilled or fried.",
   "el": "Πολύ καλό ψητό ή τηγανητό."
  },
  "sources": [
   "https://www.fishbase.se/summary/Lithognathus-mormyrus.html",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "picarel": {
  "summary": {
   "en": "Picarels: small schooling fish of the Posidonia meadows, one of the main catches of the Cyprus coastal fleet. For anglers a light-tackle fish and a fine live or cut bait: sabiki or tiny hooks over groundbait.",
   "el": "Μαρίδα: μικρό ψάρι που κινείται σε κοπάδια πάνω από τις ποσειδώνιες, από τα βασικά αλιεύματα του κυπριακού παράκτιου στόλου. Για τον ερασιτέχνη, ψάρι για λεπτά εργαλεία και πολύ καλό δόλωμα, ζωντανό ή κομμένο: τσαπαρί ή μικρά αγκίστρια πάνω από μαλάγρα."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.4–0.8 / mono 0.20 mm",
     "leader": "fluoro 0.14–0.18 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 14–10 · sabiki 10–14",
    "notes": {
     "en": "Light rod, sabiki with a 20–40 g sinker, or a three-hook paternoster. Find the school over the seagrass edge and stay on it.",
     "el": "Ελαφρύ καλάμι, τσαπαρί με μολύβι 20–40 g, ή σύνθεση με τρία αγκίστρια. Βρείτε το κοπάδι στην άκρη της ποσειδωνίας και μείνετε πάνω του."
    }
   },
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm",
     "leader": "fluoro 0.12–0.16 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 14–10",
    "notes": {
     "en": "From deep harbour walls and rocky points where 10 m or more is within reach: a 3–5 g float set deep, over groundbait.",
     "el": "Από βαθιούς μόλους και κάβους όπου τα 10 m και πάνω είναι κοντά: φελλός 3–5 g ρυθμισμένος βαθιά, πάνω από μαλάγρα."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Tiny pieces of peeled shrimp.",
     "el": "Μικρά κομματάκια καθαρισμένης γαρίδας."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Slivers of sardine or squid.",
     "el": "Λεπτές λωρίδες σαρδέλας ή καλαμαριού."
    }
   },
   {
    "gear": "bread",
    "note": {
     "en": "Bread or cheese paste.",
     "el": "Ζύμη από ψωμί ή τυρί."
    }
   }
  ],
  "lures": [
   {
    "gear": "sabiki",
    "weight": "20–40 g sinker",
    "size": "hooks 10–14",
    "colors": [
     "white",
     "glow"
    ],
    "note": {
     "en": "Jigged gently just above the seagrass.",
     "el": "Ελαφρύ ανεβοκατέβασμα λίγο πάνω από την ποσειδωνία."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely worth it: the mouth is small.",
    "el": "Σπάνια αξίζει: έχει μικρό στόμα."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A cloud of mashed sardine and bread holds the school under the boat.",
    "el": "Σύννεφο από λιωμένη σαρδέλα και ψωμί κρατά το κοπάδι κάτω από το σκάφος."
   }
  },
  "technique": {
   "en": "Lower to the bottom, lift a metre and jig slowly; once the first fish comes, feed little and often.",
   "el": "Κατεβάστε ως τον βυθό, σηκώστε ένα μέτρο και δουλέψτε αργά· μόλις έρθει το πρώτο ψάρι, μαλάγρα λίγη και συχνά."
  },
  "where": {
   "en": "Posidonia meadows and their sandy edges, 15–60 m, all round the island.",
   "el": "Λιβάδια ποσειδωνίας και οι αμμώδεις άκρες τους, 15–60 m, σε όλο το νησί."
  },
  "when": {
   "en": "Best late winter and spring; by day.",
   "el": "Καλύτερα τέλη χειμώνα και άνοιξη· την ημέρα."
  },
  "handling": {
   "en": "Harmless and delicate: ice it at once.",
   "el": "Ακίνδυνη και ευαίσθητη: αμέσως στον πάγο."
  },
  "eating": {
   "en": "Fried whole, a Cyprus classic.",
   "el": "Τηγανητή ολόκληρη, κλασικός κυπριακός μεζές."
  },
  "sources": [
   "https://www.fishbase.se/summary/Spicara-smaris.html",
   "https://www.seaaroundus.org/doc/publications/wp/2013/Ulman-et-al-Cyprus.pdf"
  ]
 },
 "axillary": {
  "summary": {
   "en": "Axillary seabream: a schooling bream of sand and seagrass, mostly at 40–100 m, with the young closer in. A boat fish for light bottom rigs with small hooks; keep only fish over 17 cm.",
   "el": "Φατσούκλι: σπαρίδης που κινείται σε κοπάδια πάνω από άμμο και ποσειδωνία, κυρίως στα 40–100 m, με τα μικρά πιο κοντά στην ακτή. Ψάρι του σκάφους για ελαφριές συνθέσεις βυθού με μικρά αγκίστρια· κρατήστε μόνο ψάρια πάνω από 17 cm."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.2",
     "leader": "fluoro 0.22–0.28 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 10–6",
    "notes": {
     "en": "Two or three short droppers above a 60–120 g sinker; drift slowly and mark the spot at the first bite.",
     "el": "Δύο ή τρία κοντά παράμαλλα πάνω από μολύβι 60–120 g· αργή ντρίφτα και σημάδεμα του σημείου στο πρώτο τσίμπημα."
    }
   },
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 10–6",
    "notes": {
     "en": "Only where deep water is close: long casts from breakwaters and rocky points onto sand at 15 m or more. Mostly small fish: measure them.",
     "el": "Μόνο όπου τα βαθιά είναι κοντά: μακρινές βολές από κυματοθραύστες και κάβους σε άμμο στα 15 m και πάνω. Κυρίως μικρά ψάρια: μετρήστε τα."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Peeled shrimp pieces.",
     "el": "Κομμάτια καθαρισμένης γαρίδας."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Thin squid strip: stays on the hook in deep water.",
     "el": "Λεπτή λωρίδα καλαμαριού: κρατά στο αγκίστρι στα βαθιά."
    }
   }
  ],
  "lures": [
   {
    "gear": "tai_rubber",
    "weight": "40–80 g",
    "size": "",
    "colors": [
     "orange",
     "red",
     "pink"
    ],
    "note": {
     "en": "Small tai rubber or a tipped micro-jig worked slowly on the bottom.",
     "el": "Μικρό tai rubber ή μικρό jig με δόλωμα, αργά στον βυθό."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not a soft-lure fish at these depths.",
    "el": "Δεν είναι ψάρι για σιλικόνες σε αυτά τα βάθη."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Keep the sinker on the bottom and the line tight; bites are quick double taps.",
   "el": "Το μολύβι στον βυθό και η πετονιά τεντωμένη· τα τσιμπήματα είναι γρήγορα και διπλά."
  },
  "where": {
   "en": "Sand, gravel and seagrass edges at 30–100 m off all coasts.",
   "el": "Άμμος, χαλίκι και άκρες ποσειδωνίας στα 30–100 m, σε όλες τις ακτές."
  },
  "when": {
   "en": "All year, best in summer; dawn.",
   "el": "Όλο τον χρόνο, καλύτερα το καλοκαίρι· χαράματα."
  },
  "handling": {
   "en": "Harmless. Under 17 cm it goes back.",
   "el": "Ακίνδυνο. Κάτω από 17 cm επιστρέφει."
  },
  "eating": {
   "en": "Good fried or grilled; soft flesh, eat it fresh.",
   "el": "Καλό τηγανητό ή ψητό· μαλακή σάρκα, θέλει φρέσκο."
  },
  "sources": [
   "https://www.fishbase.se/summary/Pagellus-acarne.html",
   "https://eur-lex.europa.eu/eli/reg/2019/1241/oj"
  ]
 },
 "bluerunner": {
  "summary": {
   "en": "Blue runner: a fast schooling jack of harbours, points and fish farms in the warm months, and a hard fighter on light spinning tackle. Small metal jigs, minnows and poppers at first and last light.",
   "el": "Σούρος: γρήγορο ψάρι που κινείται σε κοπάδια γύρω από λιμάνια, κάβους και ιχθυοκαλλιέργειες τους ζεστούς μήνες, δυνατός αντίπαλος σε ελαφρύ spinning. Μικρά μεταλλικά jig, ψαράκια και poppers στο πρώτο και στο τελευταίο φως."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1.2",
     "leader": "fluoro 0.25–0.35 mm, 1 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook",
     "swivel"
    ],
    "hook": "assist 1–1/0 · treble 6–4",
    "notes": {
     "en": "Rod 2.4–2.9 m casting 10–40 g, 3000–4000 reel. Fast retrieve with short pauses; follow the school along the wall.",
     "el": "Καλάμι 2,4–2,9 m για 10–40 g, μηχανή 3000–4000. Γρήγορο μάζεμα με μικρές παύσεις· ακολουθήστε το κοπάδι κατά μήκος του μόλου."
    }
   },
   "boat": {
    "rod": [
     "spinning_rod",
     "trolling_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 1.5–2 / mono 0.40–0.50 mm",
     "leader": "fluoro 0.40–0.50 mm"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 1/0–2/0",
    "notes": {
     "en": "Troll small feathers and 7–9 cm minnows at 4–6 knots along points and outside harbour mouths, or cast jigs to surface activity.",
     "el": "Συρτή με μικρά φτερά και ψαράκια 7–9 cm στους 4–6 κόμβους κατά μήκος των κάβων και έξω από τα λιμάνια, ή ρίψεις με jig εκεί που σκάει το ψάρι."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Schools circle a still diver once or twice near points and drop-offs at 5–15 m: wait and take the shot as they pass.",
     "el": "Τα κοπάδια κάνουν έναν-δύο κύκλους γύρω από τον ακίνητο δύτη σε κάβους και κατωφέρειες στα 5–15 m: περιμένετε και ρίξτε στο πέρασμα."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "A small live bogue or picarel under a float.",
     "el": "Μικρή ζωντανή γόπα ή μαρίδα κάτω από φελλό."
    }
   },
   {
    "gear": "sardine",
    "note": {
     "en": "Sardine strip on a free line in a groundbait trail.",
     "el": "Λωρίδα σαρδέλας σε ελεύθερη πετονιά, μέσα σε μαλάγρα."
    }
   }
  ],
  "lures": [
   {
    "gear": "casting_jig",
    "weight": "10–30 g",
    "size": "",
    "colors": [
     "sardine",
     "silver",
     "pink"
    ],
    "note": {
     "en": "Long cast, fast retrieve near the surface.",
     "el": "Μακρινή βολή, γρήγορο μάζεμα κοντά στην επιφάνεια."
    }
   },
   {
    "gear": "minnow",
    "weight": "8–15 g",
    "size": "7–9 cm",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "Twitched quickly along walls and points.",
     "el": "Γρήγορα τινάγματα κατά μήκος μόλων και κάβων."
    }
   },
   {
    "gear": "popper",
    "weight": "10–20 g",
    "size": "6–9 cm",
    "colors": [
     "white",
     "silver"
    ],
    "note": {
     "en": "At dawn when fish break the surface.",
     "el": "Τα χαράματα, όταν το ψάρι σκάει στην επιφάνεια."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 7–9 cm shads on 7–14 g heads, retrieved fast.",
    "el": "Ναι: shad 7–9 cm σε μολυβοκέφαλα 7–14 g, με γρήγορο μάζεμα."
   },
   "ids": [
    "soft_shad"
   ],
   "colors": [
    "sardine",
    "white"
   ],
   "size": "7–9 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Sardine groundbait from a boat or pier holds a passing school.",
    "el": "Μαλάγρα σαρδέλας από σκάφος ή προβλήτα κρατά το κοπάδι που περνά."
   }
  },
  "technique": {
   "en": "Speed triggers the strike: retrieve faster than feels natural and never stop the lure dead.",
   "el": "Η ταχύτητα φέρνει το χτύπημα: μαζέψτε πιο γρήγορα απ' όσο φαίνεται φυσικό και μη σταματάτε εντελώς το τεχνητό."
  },
  "where": {
   "en": "Harbour mouths, breakwaters, rocky points, the edges of fish-farm zones (keep outside the 100 m limit).",
   "el": "Στόμια λιμανιών, κυματοθραύστες, κάβοι, άκρες ζωνών ιχθυοκαλλιέργειας (έξω από το όριο των 100 m)."
  },
  "when": {
   "en": "June–November; dawn and dusk.",
   "el": "Ιούνιο–Νοέμβριο· χαράματα και σούρουπο."
  },
  "handling": {
   "en": "Sharp scutes along the tail: hold it by the head and belly. Bleed at once.",
   "el": "Κοφτερές φολίδες κατά μήκος της ουράς: κρατήστε το από το κεφάλι και την κοιλιά. Αφαίμαξη αμέσως."
  },
  "eating": {
   "en": "Good grilled when bled and iced; dark, firm flesh.",
   "el": "Καλό ψητό αν αφαιμαχθεί και μπει στον πάγο· σκούρα, σφιχτή σάρκα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Caranx-crysos.html"
  ]
 },
 "triggerfish": {
  "summary": {
   "en": "Grey triggerfish: a tough-skinned reef fish that crushes shells and crabs, seen over rocks and wrecks in the warm months. Small strong hooks and firm baits from a boat, or the speargun; mind the teeth.",
   "el": "Χοιρόψαρο (γκρίζο): ψάρι των ξερών με σκληρό δέρμα, που σπάει όστρακα και καβούρια· βγαίνει πάνω από βράχια και ναυάγια τους ζεστούς μήνες. Μικρά, γερά αγκίστρια και σφιχτά δολώματα από σκάφος, ή ψαροντούφεκο· προσοχή στα δόντια."
  },
  "best": [
   "boat",
   "spear",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1–1.5",
     "leader": "fluoro 0.35–0.45 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 4–1, forged",
    "notes": {
     "en": "Short, stiff droppers and forged hooks: it bends thin wire and bites through light line. 60–150 g sinker, bait just off the bottom.",
     "el": "Κοντά, σκληρά παράμαλλα και σφυρήλατα αγκίστρια: ανοίγει τα λεπτά και κόβει τις ψιλές πετονιές. Μολύβι 60–150 g, δόλωμα λίγο πάνω από τον βυθό."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Curious and slow over reefs at 5–25 m; aim behind the eye, the skin is like leather. Do not put fingers near the mouth.",
     "el": "Περίεργο και αργό πάνω από ξέρες στα 5–25 m· σημαδέψτε πίσω από το μάτι, το δέρμα είναι σαν πετσί. Δάχτυλα μακριά από το στόμα."
    }
   },
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm",
     "leader": "fluoro 0.12–0.16 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 6–2, forged",
    "notes": {
     "en": "Now and then from deep breakwaters and rock ledges in summer, on float-fished shrimp or crab.",
     "el": "Πού και πού από βαθιούς κυματοθραύστες και βράχια το καλοκαίρι, με γαρίδα ή καβούρι σε φελλό."
    }
   }
  },
  "baits": [
   {
    "gear": "crab",
    "best": true,
    "note": {
     "en": "Small crab or half a crab: stays on while it nibbles.",
     "el": "Μικρό καβούρι ή μισό: αντέχει στο τσιμπολόγημα."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Tough squid strip.",
     "el": "Σφιχτή λωρίδα καλαμαριού."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Whole shrimp, shell on.",
     "el": "Ολόκληρη γαρίδα με το κέλυφος."
    }
   }
  ],
  "lures": [
   {
    "gear": "tai_rubber",
    "weight": "40–80 g",
    "size": "",
    "colors": [
     "orange",
     "red"
    ],
    "note": {
     "en": "Takes slow-moving rubbers and tipped jigs near the reef.",
     "el": "Χτυπά αργά tai rubber και jig με δόλωμα κοντά στην ξέρα."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "It bites soft lures to pieces.",
    "el": "Κομματιάζει τις σιλικόνες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Feel the nibbles and wait for a steady pull, then lift firmly; keep it coming so it cannot wedge itself in a hole.",
   "el": "Νιώστε το τσιμπολόγημα και περιμένετε σταθερό τράβηγμα, μετά σηκώστε αποφασιστικά· μην το αφήσετε να σφηνώσει σε τρύπα."
  },
  "where": {
   "en": "Rocky reefs, wrecks and artificial reefs at 10–50 m.",
   "el": "Ξέρες, ναυάγια και τεχνητοί ύφαλοι στα 10–50 m."
  },
  "when": {
   "en": "June–October; by day.",
   "el": "Ιούνιο–Οκτώβριο· την ημέρα."
  },
  "handling": {
   "en": "Teeth that cut to the bone and a locking dorsal spine: grip it behind the head with a cloth, use pliers.",
   "el": "Δόντια που κόβουν ως το κόκαλο και ραχιαίο αγκάθι που κλειδώνει: πιάστε το πίσω από το κεφάλι με πανί, με πένσα."
  },
  "eating": {
   "en": "Excellent white fillets; skin it like a filefish.",
   "el": "Εξαιρετικά λευκά φιλέτα· γδέρνεται όπως το χοιρόψαρο."
  },
  "sources": [
   "https://www.fishbase.se/summary/Balistes-capriscus.html"
  ]
 },
 "razorfish": {
  "summary": {
   "en": "Pearly razorfish: a pink wrasse of clean, shallow sand next to seagrass that dives head first into the bottom when frightened. A daytime summer fish for light bottom rigs with shrimp; prized on the plate.",
   "el": "Ποντικός: ροζ χειλού της καθαρής, ρηχής άμμου δίπλα στην ποσειδωνία, που βουτά με το κεφάλι στον βυθό όταν τρομάξει. Ψάρι της καλοκαιρινής μέρας για ελαφριές συνθέσεις βυθού με γαρίδα· περιζήτητος στο τηγάνι."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.4–0.8 / mono 0.20–0.25 mm",
     "leader": "fluoro 0.18–0.22 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 10–6, long shank",
    "notes": {
     "en": "Two hooks close to a 20–40 g sinker so the baits lie on the sand; drift slowly or anchor on the sand patch.",
     "el": "Δύο αγκίστρια κοντά σε μολύβι 20–40 g ώστε τα δολώματα να ακουμπούν στην άμμο· αργή ντρίφτα ή αγκυροβόλι πάνω στην αμμούδα."
    }
   },
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 10–6, long shank",
    "notes": {
     "en": "Short casts from beaches and low rocks onto clean sand at 3–8 m on calm sunny days.",
     "el": "Κοντινές βολές από αμμουδιές και χαμηλά βράχια σε καθαρή άμμο στα 3–8 m, σε ήρεμες ηλιόλουστες μέρες."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small peeled shrimp.",
     "el": "Μικρή καθαρισμένη γαρίδα."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Mussel or clam flesh.",
     "el": "Ψίχα από μύδι ή αχιβάδα."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": true,
   "what": {
    "en": "Sometimes: 4–5 cm scented worms hopped on the sand.",
    "el": "Κάποιες φορές: αρωματισμένα σκουλήκια 4–5 cm με μικρά πηδηματάκια στην άμμο."
   },
   "ids": [
    "soft_worm"
   ],
   "colors": [
    "natural",
    "pink"
   ],
   "size": "4–5 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Let the bait rest on the sand and move it a little now and then; strike at the first firm pull.",
   "el": "Αφήστε το δόλωμα στην άμμο και κουνάτε το λίγο πού και πού· κάρφωμα στο πρώτο σταθερό τράβηγμα."
  },
  "where": {
   "en": "Clean sand patches beside Posidonia at 3–30 m.",
   "el": "Καθαρές αμμούδες δίπλα σε ποσειδωνία στα 3–30 m."
  },
  "when": {
   "en": "June–September; sunny days, never at night.",
   "el": "Ιούνιο–Σεπτέμβριο· ηλιόλουστες μέρες, ποτέ νύχτα."
  },
  "handling": {
   "en": "It bites: hold it firmly behind the head.",
   "el": "Δαγκώνει: κρατήστε το σταθερά πίσω από το κεφάλι."
  },
  "eating": {
   "en": "One of the best frying fish.",
   "el": "Από τα καλύτερα ψάρια για τηγάνι."
  },
  "sources": [
   "https://www.fishbase.se/summary/Xyrichtys-novacula.html"
  ]
 },
 "shidrum": {
  "summary": {
   "en": "Shi drum: a strong, bearded drum of sandy shores and river mouths that feeds on worms and crabs in the stirred surf at night. A surf-casting prize; it is listed as Vulnerable, so a quick photo and release is a good ending.",
   "el": "Μυλοκόπι: δυνατό ψάρι με μουστάκι, των αμμωδών ακτών και των εκβολών, που τρώει σκουλήκια και καβούρια στο ανακατεμένο νερό τη νύχτα. Τρόπαιο του surf casting· θεωρείται ευάλωτο είδος, άρα μια γρήγορη φωτογραφία και απελευθέρωση είναι ωραίο τέλος."
  },
  "best": [
   "shore",
   "boat",
   "spear"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 4–1/0",
    "notes": {
     "en": "Surf rod 4.2 m, 100–130 g sinker, trace of 0.28–0.33 mm, 1–1.5 m. Fish the nearest gutter and the edges of rocks in the sand.",
     "el": "Καλάμι surf 4,2 m, μολύβι 100–130 g, παράμαλλο 0,28–0,33 mm, 1–1,5 m. Ψαρέψτε το κοντινό κανάλι και τις άκρες των βράχων μέσα στην άμμο."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1–1.5",
     "leader": "fluoro 0.30–0.35 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 2–1/0",
    "notes": {
     "en": "Anchor on sand next to rock at 8–25 m at dusk with a running ledger.",
     "el": "Αγκυροβόλι σε άμμο δίπλα σε βράχο στα 8–25 m το σούρουπο, με συρόμενο μολύβι."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "75–90 cm",
    "notes": {
     "en": "Small groups rest under ledges on sandy bottom at 5–20 m by day. Vulnerable: take none, or one large fish at most.",
     "el": "Μικρές παρέες ξεκουράζονται κάτω από πλάκες σε αμμώδη βυθό στα 5–20 m την ημέρα. Ευάλωτο: κανένα, ή το πολύ ένα μεγάλο ψάρι."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "A big worm bait, or several on the hook.",
     "el": "Μεγάλο δόλωμα από σκουλήκι, ή αρκετά μαζί στο αγκίστρι."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Soft or peeled crab.",
     "el": "Μαλακό ή καθαρισμένο καβούρι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Whole shrimp.",
     "el": "Ολόκληρη γαρίδα."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Rarely taken on lures.",
    "el": "Σπάνια χτυπά τεχνητά."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Hold the rod or set a light drag: the bite is a slow, heavy pull, then a strong run along the beach.",
   "el": "Κρατάτε το καλάμι ή αφήνετε χαλαρό φρένο: το τσίμπημα είναι αργό, βαρύ τράβηγμα και μετά δυνατό φευγιό κατά μήκος της ακτής."
  },
  "where": {
   "en": "Sandy beaches with scattered rock, and river mouths.",
   "el": "Αμμουδιές με σκόρπιους βράχους, και εκβολές ποταμών."
  },
  "when": {
   "en": "May–October; dusk and night, as the sea calms after wind.",
   "el": "Μάιο–Οκτώβριο· σούρουπο και νύχτα, όταν η θάλασσα ηρεμεί μετά τον αέρα."
  },
  "handling": {
   "en": "Harmless. To release, support it in the water until it swims off.",
   "el": "Ακίνδυνο. Για απελευθέρωση, στηρίξτε το μέσα στο νερό ώσπου να φύγει μόνο του."
  },
  "eating": {
   "en": "Fine white flesh.",
   "el": "Ωραία λευκή σάρκα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Umbrina-cirrosa.html"
  ]
 },
 "bluefin": {
  "summary": {
   "en": "Atlantic bluefin tuna: recreational fishing for it is forbidden in Cyprus. Do not target it. This entry covers only what to do if one is hooked by accident while trolling for other fish: release it alive, in the water.",
   "el": "Ερυθρός τόνος: η ερασιτεχνική αλιεία του απαγορεύεται στην Κύπρο. Μην τον στοχεύετε. Εδώ υπάρχει μόνο τι κάνετε αν πιαστεί κατά λάθος στη συρτή για άλλα ψάρια: τον απελευθερώνετε ζωντανό, μέσα στο νερό."
  },
  "best": [],
  "setups": {},
  "baits": [],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not applicable: no targeting.",
    "el": "Δεν ισχύει: δεν επιτρέπεται η στόχευση."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not applicable.",
    "el": "Δεν ισχύει."
   }
  },
  "where": {
   "en": "Not applicable.",
   "el": "Δεν ισχύει."
  },
  "when": {
   "en": "Not applicable.",
   "el": "Δεν ισχύει."
  },
  "technique": {
   "en": "Accidental hook-up: shorten the fight as much as the tackle allows, keep the boat moving slowly ahead so water runs over the gills, and cut the leader as close to the hook as is safe. No gaff, no lifting aboard.",
   "el": "Αν πιαστεί κατά λάθος: συντομέψτε τη μάχη όσο αντέχουν τα εργαλεία, κρατήστε το σκάφος να προχωρά αργά ώστε να περνά νερό από τα βράγχια, και κόψτε το παράμαλλο όσο πιο κοντά στο αγκίστρι γίνεται με ασφάλεια. Ούτε γάντζος ούτε ανέβασμα στο σκάφος."
  },
  "handling": {
   "en": "A big tuna beside the boat is dangerous: never wrap the leader round your hand, and cut the line if the fish is still strong.",
   "el": "Μεγάλος τόνος δίπλα στο σκάφος είναι επικίνδυνος: ποτέ το παράμαλλο τυλιγμένο στο χέρι, και κόψτε την πετονιά αν το ψάρι είναι ακόμη δυνατό."
  },
  "eating": {
   "en": "Not applicable: it may not be kept.",
   "el": "Δεν ισχύει: δεν επιτρέπεται να κρατηθεί."
  },
  "sources": [
   "https://cyprus-mail.com/2024/08/05/fishermen-catching-bluefin-tuna-must-throw-it-back",
   "https://www.fishbase.se/summary/Thunnus-thynnus.html"
  ]
 },
 "bullettuna": {
  "summary": {
   "en": "Bullet tuna: the smallest tuna, in tight fast schools near the coast and round the island in the warm months. Small trolled feathers and fast little jigs; bleed and ice it at once.",
   "el": "Κοπάνι: ο μικρότερος τόνος, σε πυκνά γρήγορα κοπάδια κοντά στην ακτή και γύρω από το νησί τους ζεστούς μήνες. Μικρά φτερά στη συρτή και γρήγορα μικρά jig· αφαίμαξη και πάγος αμέσως."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "spinning_rod",
     "trolling_rod"
    ],
    "reel": [
     "reel_spin_m",
     "reel_conv"
    ],
    "line": {
     "main": "PE 1.5–2 / mono 0.40–0.50 mm",
     "leader": "fluoro 0.40–0.50 mm"
    },
    "rig": [
     "trolling_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "swivel"
    ],
    "hook": "J 1/0–2/0",
    "notes": {
     "en": "Troll three or four small feathers or a 7–9 cm minnow 30–50 m behind the boat at 5–7 knots; go round the school, not through it.",
     "el": "Συρτή με τρία-τέσσερα μικρά φτερά ή ψαράκι 7–9 cm, 30–50 m πίσω από το σκάφος στους 5–7 κόμβους· γύρω από το κοπάδι, όχι μέσα του."
    }
   },
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.2",
     "leader": "fluoro 0.30–0.35 mm, 1 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook",
     "swivel"
    ],
    "hook": "assist 1–1/0",
    "notes": {
     "en": "From points and outer breakwaters when schools come within range: 20–30 g jig, the longest cast you can make.",
     "el": "Από κάβους και εξωτερικούς κυματοθραύστες όταν τα κοπάδια πλησιάζουν: jig 20–30 g, όσο πιο μακριά γίνεται."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Sardine strip drifted in a groundbait trail.",
     "el": "Λωρίδα σαρδέλας σε ελεύθερη πετονιά, μέσα σε μαλάγρα."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "Small live baitfish.",
     "el": "Μικρό ζωντανό ψαράκι."
    }
   }
  ],
  "lures": [
   {
    "gear": "feather",
    "weight": "",
    "size": "4–6 cm",
    "colors": [
     "white",
     "pink",
     "green_silver"
    ],
    "note": {
     "en": "A string of small feathers is the standard trolling lure.",
     "el": "Η αρμαθιά με μικρά φτερά είναι το κλασικό τεχνητό της συρτής."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "15–30 g",
    "size": "",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "Very fast retrieve through the surface.",
     "el": "Πολύ γρήγορο μάζεμα στην επιφάνεια."
    }
   },
   {
    "gear": "minnow",
    "weight": "8–15 g",
    "size": "7–9 cm",
    "colors": [
     "sardine",
     "silver"
    ],
    "note": {
     "en": "Trolled or cast.",
     "el": "Στη συρτή ή με ρίψεις."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Too fast for soft lures; use metal.",
    "el": "Πολύ γρήγορο για σιλικόνες· προτιμήστε μέταλλο."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A sardine trail from a drifting boat brings schools close.",
    "el": "Μαλάγρα σαρδέλας από σκάφος σε ντρίφτα φέρνει τα κοπάδια κοντά."
   }
  },
  "technique": {
   "en": "Watch for birds and splashes at dawn, get ahead of the school and present small, fast lures.",
   "el": "Ψάξτε πουλιά και αφρούς τα χαράματα, βγείτε μπροστά από το κοπάδι και δώστε μικρά, γρήγορα τεχνητά."
  },
  "where": {
   "en": "Open water off points, 0.5–15 km out, along current lines.",
   "el": "Ανοιχτά από τους κάβους, 0,5–15 km από την ακτή, πάνω στις γραμμές των ρευμάτων."
  },
  "when": {
   "en": "June–November; dawn.",
   "el": "Ιούνιο–Νοέμβριο· χαράματα."
  },
  "handling": {
   "en": "Bleed and ice at once: tuna flesh spoils fast and can cause histamine poisoning if left warm.",
   "el": "Αφαίμαξη και πάγος αμέσως: η σάρκα των τονοειδών χαλά γρήγορα και, αν μείνει στη ζέστη, μπορεί να προκαλέσει δηλητηρίαση από ισταμίνη."
  },
  "eating": {
   "en": "Dark, strong flesh: good salted, preserved or grilled fresh.",
   "el": "Σκούρα, δυνατή σάρκα: καλό παστό, σε κονσέρβα ή φρέσκο στη σχάρα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Auxis-rochei.html"
  ]
 },
 "damselfish": {
  "summary": {
   "en": "Damselfish: the small dark fish that hangs in clouds above every rocky reef and seagrass edge. It picks plankton and small baits, so it is by-catch on tiny hooks and a nuisance for float anglers; too small to keep.",
   "el": "Παπαδιά: το μικρό σκούρο ψάρι που στέκεται σε σύννεφα πάνω από κάθε ξέρα και άκρη ποσειδωνίας. Τρώει πλαγκτόν και μικρά δολώματα, άρα πιάνεται παρεμπιπτόντως σε μικρά αγκίστρια και ενοχλεί όσους ψαρεύουν με φελλό· πολύ μικρό για να κρατηθεί."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm",
     "leader": "fluoro 0.12–0.16 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 16–12",
    "notes": {
     "en": "The lightest float tackle, bait 1–3 m down beside the rock.",
     "el": "Τα πιο λεπτά εργαλεία φελλού, δόλωμα 1–3 m κάτω, δίπλα στον βράχο."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.18–0.22 mm",
     "leader": "fluoro 0.12–0.16 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 16–12 · sabiki 12–14",
    "notes": {
     "en": "Comes up on sabikis over reefs; lower the rig past the cloud to reach other fish.",
     "el": "Ανεβαίνει στο τσαπαρί πάνω από ξέρες· κατεβάστε τη σύνθεση κάτω από το σύννεφο για να φτάσετε τα άλλα ψάρια."
    }
   }
  },
  "baits": [
   {
    "gear": "bread",
    "best": true,
    "note": {
     "en": "Bread paste the size of a lentil.",
     "el": "Ζύμη σε μέγεθος φακής."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "A speck of shrimp.",
     "el": "Ελάχιστη γαρίδα."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Too small for lures.",
    "el": "Πολύ μικρό για τεχνητά."
   }
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "Any groundbait draws the cloud at once; feed away from your float to pull them off the bait.",
    "el": "Κάθε μαλάγρα μαζεύει το σύννεφο αμέσως· ρίξτε τη μακριά από τον φελλό για να τις τραβήξετε από το δόλωμα."
   }
  },
  "technique": {
   "en": "To avoid them: bigger, tougher baits, fished deeper and after sunset, when they hide in the rocks.",
   "el": "Για να τις αποφύγετε: μεγαλύτερα, πιο σκληρά δολώματα, πιο βαθιά και μετά τη δύση, όταν κρύβονται στα βράχια."
  },
  "where": {
   "en": "Rocky reefs, harbour walls and seagrass edges at 2–25 m.",
   "el": "Ξέρες, μόλοι και άκρες ποσειδωνίας στα 2–25 m."
  },
  "when": {
   "en": "All year, most in summer; by day only.",
   "el": "Όλο τον χρόνο, περισσότερο το καλοκαίρι· μόνο την ημέρα."
  },
  "handling": {
   "en": "Harmless: unhook gently and release.",
   "el": "Ακίνδυνη: ξαγκιστρώστε απαλά και αφήστε την."
  },
  "eating": {
   "en": "Not eaten.",
   "el": "Δεν τρώγεται."
  },
  "sources": [
   "https://www.fishbase.se/summary/Chromis-chromis.html"
  ]
 },
 "lizardfish": {
  "summary": {
   "en": "Atlantic lizardfish: an ambusher that lies half-buried on sand and shoots up at anything passing. It takes lures almost as long as itself, so it is the usual surprise when you work a small lure over sand.",
   "el": "Παπανικολής: ψάρι-ενέδρα που κάθεται μισοθαμμένο στην άμμο και εκτοξεύεται σε ό,τι περάσει. Χτυπά τεχνητά σχεδόν ίσα με το μήκος του, άρα είναι η συνηθισμένη έκπληξη όταν δουλεύετε μικρό τεχνητό πάνω από άμμο."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "spinning_rod",
     "shore_jig_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.4–0.8",
     "leader": "fluoro 0.20–0.28 mm"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro",
     "assist_hook",
     "swivel"
    ],
    "hook": "jig head 3–10 g, hook 4–1",
    "notes": {
     "en": "Light spinning or LRF tackle; work the lure in hops along the sand.",
     "el": "Ελαφρύ spinning ή LRF· δουλέψτε το τεχνητό με πηδηματάκια πάνω στην άμμο."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 6–2",
    "notes": {
     "en": "By-catch on strip baits and small jigs drifting over sand at 5–30 m.",
     "el": "Παρεμπίπτον αλίευμα σε λωρίδες ψαριού και μικρά jig, σε ντρίφτα πάνω από άμμο στα 5–30 m."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "A thin strip of fish, moved slowly.",
     "el": "Λεπτή λωρίδα ψαριού, με αργή κίνηση."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp.",
     "el": "Γαρίδα."
    }
   }
  ],
  "lures": [
   {
    "gear": "soft_shad",
    "weight": "3–10 g",
    "size": "5–7 cm",
    "colors": [
     "natural",
     "white"
    ],
    "note": {
     "en": "Hopped along the sand.",
     "el": "Πηδηματάκια πάνω στην άμμο."
    }
   },
   {
    "gear": "casting_jig",
    "weight": "7–20 g",
    "size": "",
    "colors": [
     "silver",
     "sardine"
    ],
    "note": {
     "en": "Let it touch bottom between lifts.",
     "el": "Αφήστε το να ακουμπά στον βυθό ανάμεσα στα σηκώματα."
    }
   }
  ],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 5–7 cm shads and grubs on 3–10 g heads.",
    "el": "Ναι: shad και grub 5–7 cm σε μολυβοκέφαλα 3–10 g."
   },
   "ids": [
    "soft_shad",
    "soft_grub"
   ],
   "colors": [
    "natural",
    "white"
   ],
   "size": "5–7 cm"
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Lift and drop the lure close to the bottom; the take comes on the drop.",
   "el": "Σηκώστε και αφήστε το τεχνητό κοντά στον βυθό· το χτύπημα έρχεται στην πτώση."
  },
  "where": {
   "en": "Sand and gravel next to rock, 2–20 m.",
   "el": "Άμμος και χαλίκι δίπλα σε βράχο, 2–20 m."
  },
  "when": {
   "en": "May–October; dawn and dusk.",
   "el": "Μάιο–Οκτώβριο· χαράματα και σούρουπο."
  },
  "handling": {
   "en": "Needle teeth: hold it behind the head and use pliers.",
   "el": "Δόντια σαν βελόνες: κρατήστε το πίσω από το κεφάλι και χρησιμοποιήστε πένσα."
  },
  "eating": {
   "en": "Edible but bony; mostly released or used as bait.",
   "el": "Τρώγεται αλλά έχει πολλά κόκαλα· συνήθως απελευθερώνεται ή γίνεται δόλωμα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Synodus-saurus.html"
  ]
 },
 "stargazer": {
  "summary": {
   "en": "Atlantic stargazer: a big-headed ambusher buried in sand and mud with only the eyes and the upturned mouth showing. Nobody targets it, but it comes up on boat bottom rigs; it has a venomous spine behind each gill cover.",
   "el": "Λύχνος: ψάρι-ενέδρα με μεγάλο κεφάλι, θαμμένο στην άμμο και τη λάσπη με μόνο τα μάτια και το στόμα έξω. Κανείς δεν τον στοχεύει, αλλά ανεβαίνει στις συνθέσεις βυθού από σκάφος· έχει δηλητηριώδες αγκάθι πίσω από κάθε βραγχιακό επικάλυμμα."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.8–1.5",
     "leader": "mono 0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Any bottom rig whose bait lies on soft ground at 15–80 m can find one.",
     "el": "Κάθε σύνθεση βυθού με το δόλωμα ακουμπισμένο σε μαλακό βυθό στα 15–80 m μπορεί να τον βρει."
    }
   },
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 4–1",
    "notes": {
     "en": "Rare from the shore: long casts onto deep sand from breakwaters.",
     "el": "Σπάνια από την ακτή: μακρινές βολές σε βαθιά άμμο από κυματοθραύστες."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Fish strip lying on the bottom.",
     "el": "Λωρίδα ψαριού ακουμπισμένη στον βυθό."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp.",
     "el": "Γαρίδα."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not targeted.",
    "el": "Δεν στοχεύεται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "No special technique: it swallows a still bait whole. It feels like a dead weight coming up.",
   "el": "Χωρίς ειδική τεχνική: καταπίνει ολόκληρο το ακίνητο δόλωμα. Ανεβαίνει σαν νεκρό βάρος."
  },
  "where": {
   "en": "Sand and mud at 15–100 m.",
   "el": "Άμμος και λάσπη στα 15–100 m."
  },
  "when": {
   "en": "All year.",
   "el": "Όλο τον χρόνο."
  },
  "handling": {
   "en": "Venomous spine behind each gill cover: never grip it over the head. Hold from below with a thick cloth, pliers for the hook, and cut the spines before it goes in the box.",
   "el": "Δηλητηριώδες αγκάθι πίσω από κάθε βραγχιακό επικάλυμμα: ποτέ πιάσιμο πάνω από το κεφάλι. Κράτημα από κάτω με χοντρό πανί, πένσα για το αγκίστρι, και κόψτε τα αγκάθια πριν μπει στο ψυγείο."
  },
  "eating": {
   "en": "Firm white flesh, a classic soup fish.",
   "el": "Σφιχτή λευκή σάρκα, κλασικό ψάρι για σούπα."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Uranoscopus-scaber.html"
  ]
 },
 "peacockwrasse": {
  "summary": {
   "en": "Peacock wrasse: the largest of the common wrasses, at home among weedy rocks and seagrass in a few metres of water. An easy, colourful shore fish for float or light bottom tackle by day.",
   "el": "Χειλού: η μεγαλύτερη από τις κοινές χειλούδες, μέσα σε βράχια με φύκια και ποσειδωνία σε λίγα μέτρα νερό. Εύκολο, πολύχρωμο ψάρι της ακτής για φελλό ή ελαφρύ βυθό την ημέρα."
  },
  "best": [
   "shore",
   "spear",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "bolognese_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "mono 0.16–0.20 mm",
     "leader": "fluoro 0.12–0.16 mm"
    },
    "rig": [
     "float_rig",
     "bottom_rig"
    ],
    "terminal": [
     "mono",
     "fluoro",
     "hook_j",
     "sinker"
    ],
    "hook": "J 12–8",
    "notes": {
     "en": "A 2–4 g float with the bait just above the weed, or a light ledger in the gaps between rocks.",
     "el": "Φελλός 2–4 g με το δόλωμα λίγο πάνω από τα φύκια, ή ελαφρύς βυθός στα κενά ανάμεσα στα βράχια."
    }
   },
   "spear": {
    "gun": [
     "gun_band"
    ],
    "length": "50–75 cm",
    "notes": {
     "en": "Easy in 2–8 m over weedy rock: take only the large ones.",
     "el": "Εύκολη στα 2–8 m πάνω από βράχο με φύκια: μόνο τις μεγάλες."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.22–0.25 mm",
     "leader": "fluoro 0.16–0.20 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 12–8",
    "notes": {
     "en": "Small hooks over shallow seagrass and rock at 5–15 m.",
     "el": "Μικρά αγκίστρια πάνω από ρηχή ποσειδωνία και βράχο στα 5–15 m."
    }
   }
  },
  "baits": [
   {
    "gear": "shrimp",
    "best": true,
    "note": {
     "en": "Small shrimp or pieces.",
     "el": "Μικρή γαρίδα ή κομμάτια."
    }
   },
   {
    "gear": "worm",
    "note": {
     "en": "Worm.",
     "el": "Σκουλήκι."
    }
   },
   {
    "gear": "mussel",
    "note": {
     "en": "Mussel flesh.",
     "el": "Ψίχα μυδιού."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": true,
   "what": {
    "en": "Yes: 3–5 cm scented worms on 1–3 g heads (LRF).",
    "el": "Ναι: αρωματισμένα σκουλήκια 3–5 cm σε μολυβοκέφαλα 1–3 g (LRF)."
   },
   "ids": [
    "soft_worm",
    "soft_grub"
   ],
   "colors": [
    "natural",
    "red"
   ],
   "size": "3–5 cm"
  },
  "groundbait": {
   "use": true,
   "what": {
    "en": "A little crushed mussel or sea urchin brings them out of the weed.",
    "el": "Λίγο λιωμένο μύδι ή αχινός τις βγάζει από τα φύκια."
   }
  },
  "technique": {
   "en": "Strike quickly and lift it clear of the weed at once.",
   "el": "Γρήγορο κάρφωμα και αμέσως σήκωμα έξω από τα φύκια."
  },
  "where": {
   "en": "Weedy rocks, harbour walls and Posidonia at 1–15 m.",
   "el": "Βράχια με φύκια, μόλοι και ποσειδωνία στα 1–15 m."
  },
  "when": {
   "en": "April–October; sunny hours.",
   "el": "Απρίλιο–Οκτώβριο· ηλιόλουστες ώρες."
  },
  "handling": {
   "en": "Harmless and slimy: a wet cloth helps.",
   "el": "Ακίνδυνη και γλιστερή: βοηθά ένα βρεγμένο πανί."
  },
  "eating": {
   "en": "Soft flesh: fried, or in soup.",
   "el": "Μαλακή σάρκα: τηγανητή ή σε σούπα."
  },
  "sources": [
   "https://www.fishbase.se/summary/Symphodus-tinca.html"
  ]
 },
 "yellowpuffer": {
  "summary": {
   "en": "Yellowspotted puffer: a small invasive pufferfish from the Red Sea, now among the most often recorded fish on shallow sand and seagrass in Cyprus. It is not to be eaten; for anglers it is a bait-stealer that cuts light traces.",
   "el": "Μαππουρούι: μικρός ξενικός λαγοκέφαλος από την Ερυθρά Θάλασσα, πλέον από τα ψάρια που καταγράφονται συχνότερα σε ρηχή άμμο και ποσειδωνία στην Κύπρο. Δεν τρώγεται· για τον ψαρά είναι κλέφτης δολωμάτων που κόβει τα λεπτά παράμαλλα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–4, long shank",
    "notes": {
     "en": "Nothing is set up for it: it takes worm and shrimp meant for bream. Long-shank hooks save traces.",
     "el": "Δεν στήνεται τίποτα γι' αυτό: παίρνει το σκουλήκι και τη γαρίδα που προορίζονται για σπαροειδή. Τα μακρύλαιμα αγκίστρια γλιτώνουν παράμαλλα."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.25–0.30 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 8–4, long shank",
    "notes": {
     "en": "The same over shallow sand: if every bait comes back bitten off, move 200–300 m or fish deeper than 30 m.",
     "el": "Το ίδιο πάνω από ρηχή άμμο: αν κάθε δόλωμα γυρίζει κομμένο, μετακινηθείτε 200–300 m ή ψαρέψτε βαθύτερα από 30 m."
    }
   }
  },
  "baits": [
   {
    "gear": "worm",
    "best": true,
    "note": {
     "en": "It takes any small bait, worm first.",
     "el": "Παίρνει κάθε μικρό δόλωμα, πρώτα το σκουλήκι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "Shrimp is stripped within a minute.",
     "el": "Η γαρίδα καθαρίζεται σε ένα λεπτό."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Avoid: it bites the tails off soft lures.",
    "el": "Αποφύγετε: κόβει τις ουρές από τις σιλικόνες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Do not groundbait: it draws more of them.",
    "el": "Χωρίς μαλάγρα: φέρνει περισσότερα."
   }
  },
  "technique": {
   "en": "Avoidance: larger, tougher baits (crab, squid), fished at night or beyond 30 m, where it is scarce.",
   "el": "Αποφυγή: μεγαλύτερα, πιο σκληρά δολώματα (καβούρι, καλαμάρι), τη νύχτα ή πέρα από τα 30 m, όπου σπανίζει."
  },
  "where": {
   "en": "Shallow sand and seagrass all round the island, 2–30 m.",
   "el": "Ρηχή άμμος και ποσειδωνία σε όλο το νησί, 2–30 m."
  },
  "when": {
   "en": "All year, most from May to October; by day.",
   "el": "Όλο τον χρόνο, περισσότερο Μάιο–Οκτώβριο· την ημέρα."
  },
  "handling": {
   "en": "It puffs up and bites: use pliers. Do not feed it to pets either.",
   "el": "Φουσκώνει και δαγκώνει: με πένσα. Μην το δίνετε ούτε σε ζώα."
  },
  "eating": {
   "en": "Do not eat.",
   "el": "Δεν τρώγεται."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Torquigener-flavimaculosus.html"
  ]
 },
 "stingray": {
  "summary": {
   "en": "Common stingray: a ray of sandy and muddy bays that comes into very shallow water on warm nights. It takes baits meant for other fish; the tail carries a venomous barbed spine, and the species is listed as Vulnerable, so release it without handling.",
   "el": "Βατί: σελάχι των αμμωδών και λασπωδών κόλπων, που τις ζεστές νύχτες μπαίνει σε πολύ ρηχά νερά. Παίρνει δολώματα που προορίζονται για άλλα ψάρια· η ουρά έχει δηλητηριώδες αγκάθι, και το είδος θεωρείται ευάλωτο, άρα απελευθερώστε το χωρίς να το πιάσετε."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1/0–3/0 or circle 2/0–4/0",
    "notes": {
     "en": "It comes on the heavier surf rods fished with fish baits at night. A circle hook sets in the corner of the mouth and makes release easy.",
     "el": "Έρχεται στα πιο βαριά καλάμια surf με δολώματα ψαριού τη νύχτα. Το κυκλικό αγκίστρι πιάνει στη γωνία του στόματος και κάνει εύκολη την απελευθέρωση."
    }
   },
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.5–2",
     "leader": "mono 0.50 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "circle 2/0–4/0",
    "notes": {
     "en": "At anchor over sand at night. Do not bring it aboard: cut the trace at the surface.",
     "el": "Αγκυροβολημένοι πάνω από άμμο τη νύχτα. Μην το ανεβάσετε στο σκάφος: κόψτε το παράμαλλο στην επιφάνεια."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Half a sardine or a fish fillet on the bottom.",
     "el": "Μισή σαρδέλα ή φιλέτο ψαριού στον βυθό."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid.",
     "el": "Καλαμάρι."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Crab.",
     "el": "Καβούρι."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not targeted.",
    "el": "Δεν στοχεύεται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "A heavy, slow pull that sticks to the bottom: keep steady pressure and walk it into the shallows rather than lifting.",
   "el": "Βαρύ, αργό τράβηγμα που κολλά στον βυθό: σταθερή πίεση και φέρτε το στα ρηχά περπατώντας, χωρίς σήκωμα."
  },
  "where": {
   "en": "Sandy and muddy bays, 1–40 m: Larnaca Bay, Akrotiri, Chrysochou.",
   "el": "Αμμώδεις και λασπώδεις κόλποι, 1–40 m: κόλπος Λάρνακας, Ακρωτήρι, Χρυσοχού."
  },
  "when": {
   "en": "May–October; at night.",
   "el": "Μάιο–Οκτώβριο· νύχτα."
  },
  "handling": {
   "en": "Stay away from the tail: the spine goes through boots. Leave it in the water, cut the line as close as is safe and let it go. If stung: out of the water, warm the wound, medical care at once.",
   "el": "Μακριά από την ουρά: το αγκάθι περνά και από μπότα. Αφήστε το στο νερό, κόψτε την πετονιά όσο πιο κοντά γίνεται με ασφάλεια και αφήστε το να φύγει. Αν τσιμπηθείτε: έξω από το νερό, ζεστάνετε την πληγή, άμεση ιατρική φροντίδα."
  },
  "eating": {
   "en": "Best released (IUCN Vulnerable).",
   "el": "Καλύτερα να απελευθερώνεται (Ευάλωτο είδος IUCN)."
  },
  "sources": [
   "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf",
   "https://www.fishbase.se/summary/Dasyatis-pastinaca.html"
  ]
 },
 "electricray": {
  "summary": {
   "en": "Marbled electric ray: a round, soft ray that lies buried by day and stuns small fish with an electric shock at night. Anglers meet it only by accident; it shocks the hand that grabs it, so release it without touching.",
   "el": "Μουδιάστρα: στρογγυλό, μαλακό σελάχι που μένει θαμμένο την ημέρα και τη νύχτα ναρκώνει μικρά ψάρια με ηλεκτρική εκκένωση. Ο ψαράς τη συναντά μόνο κατά τύχη· «χτυπά» το χέρι που την πιάνει, άρα απελευθερώστε τη χωρίς να την αγγίξετε."
  },
  "best": [
   "boat",
   "shore"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1–1.5",
     "leader": "mono 0.35–0.40 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1–2/0",
    "notes": {
     "en": "By-catch on any fish bait on sand or seagrass at night.",
     "el": "Παρεμπίπτον αλίευμα σε κάθε δόλωμα ψαριού πάνω σε άμμο ή ποσειδωνία τη νύχτα."
    }
   },
   "shore": {
    "rod": [
     "surf_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "mono 0.25–0.30 mm / PE 0.8–1.2",
     "leader": "fluoro 0.20–0.28 mm, 1–1.5 m"
    },
    "rig": [
     "surf_rig",
     "carolina"
    ],
    "terminal": [
     "mono",
     "braid",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "J 1–2/0",
    "notes": {
     "en": "Sometimes on night surf baits in the cooler months.",
     "el": "Κάποιες φορές στα νυχτερινά δολώματα του surf τους πιο δροσερούς μήνες."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Fish bait on the bottom.",
     "el": "Δόλωμα ψαριού στον βυθό."
    }
   },
   {
    "gear": "live_fish",
    "note": {
     "en": "It takes small live baits meant for other fish.",
     "el": "Παίρνει μικρά ζωντανά δολώματα που προορίζονται για άλλα ψάρια."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not targeted.",
    "el": "Δεν στοχεύεται."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "It comes up as a dead weight. At the surface, cut the trace near the hook.",
   "el": "Ανεβαίνει σαν νεκρό βάρος. Στην επιφάνεια, κόψτε το παράμαλλο κοντά στο αγκίστρι."
  },
  "where": {
   "en": "Sand, seagrass and nearby rock, 5–60 m.",
   "el": "Άμμος, ποσειδωνία και κοντινός βράχος, 5–60 m."
  },
  "when": {
   "en": "Mostly the cooler months; at night.",
   "el": "Κυρίως τους δροσερούς μήνες· νύχτα."
  },
  "handling": {
   "en": "Do not touch the body: the shock is strongest on the back, and wet hands and a wet line conduct it. Long pliers, or cut the line.",
   "el": "Μην αγγίζετε το σώμα: η εκκένωση είναι πιο δυνατή στη ράχη, και τα βρεγμένα χέρια και η βρεγμένη πετονιά την άγουν. Μακριά πένσα, ή κόψτε την πετονιά."
  },
  "eating": {
   "en": "Not eaten.",
   "el": "Δεν τρώγεται."
  },
  "sources": [
   "https://www.fishbase.se/summary/Torpedo-marmorata.html"
  ]
 },
 "guitarfish": {
  "summary": {
   "en": "Guitarfishes: shark-like rays of shallow sand, both species Critically Endangered and protected by EU law. Do not target them. This entry covers only how to release one hooked by accident.",
   "el": "Ρινόβατοι (βιόλες): σελάχια με σώμα καρχαρία, της ρηχής άμμου· και τα δύο είδη είναι κρισίμως κινδυνεύοντα και προστατεύονται από την ευρωπαϊκή νομοθεσία. Μην τα στοχεύετε. Εδώ υπάρχει μόνο πώς απελευθερώνεται όποιο πιαστεί κατά λάθος."
  },
  "best": [],
  "setups": {},
  "baits": [],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not applicable: no targeting.",
    "el": "Δεν ισχύει: δεν επιτρέπεται η στόχευση."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not applicable.",
    "el": "Δεν ισχύει."
   }
  },
  "where": {
   "en": "Not applicable.",
   "el": "Δεν ισχύει."
  },
  "when": {
   "en": "Not applicable.",
   "el": "Δεν ισχύει."
  },
  "technique": {
   "en": "Accidental hook-up: bring it in steadily, keep it in knee-deep water, turn it gently on its back to calm it, take the hook out with long pliers or cut the line at the hook, and point it out to sea.",
   "el": "Αν πιαστεί κατά λάθος: φέρτε το σταθερά, κρατήστε το σε νερό ως το γόνατο, γυρίστε το απαλά ανάσκελα για να ηρεμήσει, βγάλτε το αγκίστρι με μακριά πένσα ή κόψτε την πετονιά στο αγκίστρι, και στρέψτε το προς τα ανοιχτά."
  },
  "handling": {
   "en": "Harmless. Support the body with both hands; never lift it by the tail or the snout, and keep it out of the dry sand.",
   "el": "Ακίνδυνο. Στηρίξτε το σώμα με τα δύο χέρια· ποτέ σήκωμα από την ουρά ή το ρύγχος, και όχι πάνω στη στεγνή άμμο."
  },
  "eating": {
   "en": "Not applicable: it may not be kept.",
   "el": "Δεν ισχύει: δεν επιτρέπεται να κρατηθεί."
  },
  "sources": [
   "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32015R2102",
   "https://www.fishbase.se/summary/Rhinobatos-rhinobatos.html"
  ]
 },
 "thornback": {
  "summary": {
   "en": "Thornback ray: the commonest skate of sand and mud, a night feeder on crabs and small fish. A by-catch of boat bottom fishing in deeper water; slow-breeding, so keep only what you will eat and release the rest.",
   "el": "Ράζα: το πιο κοινό σελάχι της άμμου και της λάσπης, που τρέφεται τη νύχτα με καβούρια και μικρά ψάρια. Παρεμπίπτον αλίευμα του ψαρέματος βυθού από σκάφος στα πιο βαθιά· αναπαράγεται αργά, άρα κρατήστε μόνο ό,τι θα φάτε και αφήστε τα υπόλοιπα."
  },
  "best": [
   "boat"
  ],
  "setups": {
   "boat": {
    "rod": [
     "boat_rod"
    ],
    "reel": [
     "reel_spin_m"
    ],
    "line": {
     "main": "PE 1.5–2",
     "leader": "mono 0.45–0.50 mm"
    },
    "rig": [
     "bottom_rig"
    ],
    "terminal": [
     "braid",
     "mono",
     "fluoro",
     "hook_j",
     "sinker",
     "swivel"
    ],
    "hook": "circle 2/0–4/0 or J 1/0–3/0",
    "notes": {
     "en": "Running ledger with a 150–300 g sinker and the bait flat on the bottom, at anchor or on a very slow drift.",
     "el": "Συρόμενο μολύβι 150–300 g με το δόλωμα ακουμπισμένο στον βυθό, αγκυροβολημένοι ή σε πολύ αργή ντρίφτα."
    }
   }
  },
  "baits": [
   {
    "gear": "sardine",
    "best": true,
    "note": {
     "en": "Fish fillet or half a sardine.",
     "el": "Φιλέτο ψαριού ή μισή σαρδέλα."
    }
   },
   {
    "gear": "squid_bait",
    "note": {
     "en": "Squid.",
     "el": "Καλαμάρι."
    }
   },
   {
    "gear": "crab",
    "note": {
     "en": "Crab.",
     "el": "Καβούρι."
    }
   }
  ],
  "lures": [],
  "silicone": {
   "use": false,
   "what": {
    "en": "Not targeted with lures.",
    "el": "Δεν στοχεύεται με τεχνητά."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "It covers the bait and sits on it: wait, then lift steadily to break it off the bottom.",
   "el": "Σκεπάζει το δόλωμα και κάθεται πάνω του: περιμένετε, μετά σηκώστε σταθερά για να το ξεκολλήσετε από τον βυθό."
  },
  "where": {
   "en": "Sand and mud at 30–150 m off all coasts.",
   "el": "Άμμος και λάσπη στα 30–150 m, σε όλες τις ακτές."
  },
  "when": {
   "en": "All year, more in the cooler months; dusk and night.",
   "el": "Όλο τον χρόνο, περισσότερο τους δροσερούς μήνες· σούρουπο και νύχτα."
  },
  "handling": {
   "en": "Thorns on back and tail: gloves, and hold it by the edge of the snout. To release, slide it back flat.",
   "el": "Αγκάθια στη ράχη και την ουρά: γάντια, και κράτημα από την άκρη του ρύγχους. Για απελευθέρωση, αφήστε το να γλιστρήσει οριζόντια στο νερό."
  },
  "eating": {
   "en": "The wings are eaten.",
   "el": "Τρώγονται τα «φτερά»."
  },
  "sources": [
   "https://www.fishbase.se/summary/Raja-clavata.html"
  ]
 },
 "reefsquid": {
  "summary": {
   "en": "Bigfin reef squid: a Red Sea squid with fins along the whole body, now settled on the shallow reefs and seagrass of Cyprus. The summer eging target: bigger egi than for the native squid, worked close to weed and rock at night.",
   "el": "Σουπιοκαλάμαρο: καλαμάρι της Ερυθράς Θάλασσας με πτερύγια σε όλο το μήκος του σώματος, εγκατεστημένο πλέον στις ρηχές ξέρες και την ποσειδωνία της Κύπρου. Ο καλοκαιρινός στόχος του eging: μεγαλύτερες καλαμαριέρες από του ντόπιου καλαμαριού, κοντά σε φύκια και βράχο τη νύχτα."
  },
  "best": [
   "shore",
   "boat"
  ],
  "setups": {
   "shore": {
    "rod": [
     "eging_rod",
     "lrf_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–0.8",
     "leader": "fluoro 0.22–0.28 mm, 2 m"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro"
    ],
    "hook": "",
    "notes": {
     "en": "Eging rod 2.5 m for egi 3.0–3.5, 2500 reel with a soft drag. It pulls harder than the native squid: use a net.",
     "el": "Καλάμι eging 2,5 m για καλαμαριέρες 3,0–3,5, μηχανή 2500 με μαλακό φρένο. Τραβά πιο δυνατά από το ντόπιο καλαμάρι: με απόχη."
    }
   },
   "boat": {
    "rod": [
     "eging_rod",
     "spinning_rod"
    ],
    "reel": [
     "reel_spin_s"
    ],
    "line": {
     "main": "PE 0.6–1",
     "leader": "fluoro 0.25–0.30 mm"
    },
    "rig": [],
    "terminal": [
     "braid",
     "fluoro"
    ],
    "hook": "",
    "notes": {
     "en": "Drift along the outer edge of seagrass and reef at 5–20 m and cast towards the structure.",
     "el": "Ντρίφτα κατά μήκος της εξωτερικής άκρης της ποσειδωνίας και της ξέρας στα 5–20 m, με ρίψεις προς τη δομή."
    }
   }
  },
  "baits": [
   {
    "gear": "live_fish",
    "best": true,
    "note": {
     "en": "A small fish on a squid needle under a float with a light stick.",
     "el": "Μικρό ψάρι σε καφτερό κάτω από φελλό με φωτάκι."
    }
   },
   {
    "gear": "shrimp",
    "note": {
     "en": "A whole large shrimp on a squid needle.",
     "el": "Ολόκληρη μεγάλη γαρίδα σε καφτερό."
    }
   }
  ],
  "lures": [
   {
    "gear": "egi",
    "weight": "15–25 g",
    "size": "3.0–3.5",
    "colors": [
     "orange",
     "pink",
     "natural",
     "glow"
    ],
    "note": {
     "en": "Two or three sharp jerks, then let it sink on a tight line for 5–10 s: takes come on the drop.",
     "el": "Δύο-τρία κοφτά τινάγματα και μετά βύθιση με τεντωμένη πετονιά για 5–10 s: το χτύπημα έρχεται στην πτώση."
    }
   }
  ],
  "silicone": {
   "use": false,
   "what": {
    "en": "Squid jigs only.",
    "el": "Μόνο καλαμαριέρες."
   }
  },
  "groundbait": {
   "use": false,
   "what": {
    "en": "Not used.",
    "el": "Δεν χρησιμοποιείται."
   }
  },
  "technique": {
   "en": "Cast beyond the weed edge, let the egi reach the bottom, jerk and pause. Keep steady pressure; never pump the rod.",
   "el": "Ρίξτε πέρα από την άκρη των φυκιών, αφήστε την καλαμαριέρα να φτάσει στον βυθό, τινάγματα και παύση. Σταθερή πίεση· ποτέ απότομες αντλήσεις."
  },
  "where": {
   "en": "Seagrass and rocky reef at 2–20 m; harbour mouths and lit piers.",
   "el": "Ποσειδωνία και ξέρες στα 2–20 m· στόμια λιμανιών και φωτισμένες προβλήτες."
  },
  "when": {
   "en": "June–November; dusk and night.",
   "el": "Ιούνιο–Νοέμβριο· σούρουπο και νύχτα."
  },
  "handling": {
   "en": "It squirts ink and can nip with its beak: lift it with a net and point it away from you.",
   "el": "Πετά μελάνι και μπορεί να τσιμπήσει με το ράμφος: σήκωμα με απόχη, γυρισμένο μακριά από εσάς."
  },
  "eating": {
   "en": "Excellent, thicker and sweeter than the native squid. Invasive: keep it.",
   "el": "Εξαιρετικό, πιο χοντρό και γλυκό από το ντόπιο καλαμάρι. Ξενικό είδος: κρατήστε το."
  },
  "sources": [
   "https://www.sealifebase.se/summary/Sepioteuthis-lessoniana.html"
  ]
 }
});
// <<< round 11 species inventory
