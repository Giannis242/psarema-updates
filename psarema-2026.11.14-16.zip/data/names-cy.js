// Cypriot names for the fish (Greek interface). Sources at the bottom.
// Main source: DFMR (Cyprus Dept. of Fisheries) "Τα 100 σημαντικότερα είδη ψαριών των Κυπριακών Θαλασσών" (2011),
// which lists species "βάσει του κοινού κυπριακού τους ονόματος", cross-checked with Cyprus' official
// commercial designations (EU list, ms=CY) and FishBase common names for Cyprus (Ioannou 2011).
window.PSAREMA_NAMES_CY = {
  sargos:         { cy: 'Σορκός',          also: 'Σαργός',            note: '' },
  tsipoura:       { cy: 'Τσιπούρα',        also: 'Τσιπούρα',          note: '' },
  grouper:        { cy: 'Ορφός',           also: 'Ροφός',             note: '' },
  dentex:         { cy: 'Συναγρίδα',       also: 'Συναγρίδα',         note: '' },
  amberjack:      { cy: 'Μινέρι',          also: 'Μαγιάτικο',         note: 'also μαγιάτικο in Cyprus' },
  dolphinfish:    { cy: 'Κυνηγός (Ακκανομούττας)', also: 'Κυνηγός',   note: 'λαμπούκα is not a Cypriot name' },
  albacore:       { cy: 'Τονάκι',          also: 'Τόνος μακρύπτερος', note: 'also μακρύπτερος τόνος' },
  leerfish:       { cy: 'Λίτσα',           also: 'Λίτσα',             note: '' },
  barracuda:      { cy: 'Σφύρνα',          also: 'Λούτσος',           note: 'also λούτσος in Cyprus' },
  parrotfish:     { cy: 'Σκάρος',          also: 'Σκάρος',            note: '' },
  rabbitfish:     { cy: 'Κουρκούνα',       also: 'Αγριόσαλπα',        note: 'S. rivulatus = άσπρη, S. luridus = μαύρη κουρκούνα; also προσφυγούλα' },
  lionfish:       { cy: 'Λεοντόψαρο',      also: 'Λεοντόψαρο',        note: '' },
  squid:          { cy: 'Καλαμάρι',        also: 'Καλαμάρι',          note: '' },
  cuttlefish:     { cy: 'Σουπιά',          also: 'Σουπιά',            note: '' },
  octopus:        { cy: 'Χταπόδι',         also: 'Χταπόδι',           note: 'also οκταπόδι' },
  twoband:        { cy: 'Χαρατζίδα',       also: 'Καμπανάς',          note: 'also κακαρέλος' },
  annular:        { cy: 'Σπάρος',          also: 'Σπάρος',            note: '' },
  sharpsnout:     { cy: 'Ούγενα',          also: 'Μυτάκι',            note: 'also μυτάκι in some areas of Cyprus' },
  melanouri:      { cy: 'Μελάνα',          also: 'Μελανούρι',         note: 'also μελανούρι' },
  salema:         { cy: 'Σάρπα',           also: 'Σάλπα',             note: 'also σάλπα' },
  bogue:          { cy: 'Γόππα',           also: 'Γόπα',              note: 'also βόππα in some areas' },
  porgy:          { cy: 'Φαγκρί',          also: 'Φαγκρί',            note: '' },
  pandora:        { cy: 'Λυθρίνι',         also: 'Λυθρίνι',           note: '' },
  blackbream:     { cy: 'Σκαθάρι',         also: 'Σκαθάρι',           note: 'also μουτσιοσορκός in some areas' },
  redmullet:      { cy: 'Στρίλια',         also: 'Κουτσομούρα',       note: 'also κουτσομούρα' },
  surmullet:      { cy: 'Μπαρμπούνι',      also: 'Μπαρμπούνι',        note: '' },
  greymullet:     { cy: 'Κέφαλος',         also: 'Κέφαλος',           note: 'also πόκλανος' },
  meagre:         { cy: 'Σιακός',          also: 'Σκιός',             note: 'also συκιός, ομπρέλλα' },
  seabass:        { cy: 'Λαβράκι',         also: 'Λαβράκι',           note: '' },
  goatfish:       { cy: 'Πετρομπάρμπουνο', also: 'Πετρομπάρμπουνο',   note: 'official Cyprus market name; not in the DFMR book' },
  littletunny:    { cy: 'Παλαμίδα (καρβούνι)',        also: 'Καρβούνι',          note: 'Cypriots call all small tunas παλαμίδα' },
  bonito:         { cy: 'Παλαμίδα',        also: 'Παλαμίδα',          note: '' },
  bluefish:       { cy: 'Γοφάρι',          also: 'Γοφάρι',            note: '' },
  horsemackerel:  { cy: 'Σαυρίδι',         also: 'Σαυρίδι',           note: '' },
  mackerel:       { cy: 'Κολιός',          also: 'Κολιός',            note: '' },
  garfish:        { cy: 'Βελονίδα',        also: 'Ζαργάνα',           note: 'in Cyprus ζαργάνα is the spearfish' },
  pompano:        { cy: 'Λιτσούι',         also: 'Μαυρολίτσα',        note: '' },
  swordfish:      { cy: 'Ξιφίας',          also: 'Ξιφίας',            note: '' },
  cornetfish:     { cy: 'Πιθκιαύλι',       also: 'Αυλός',             note: 'also τρομπέτα' },
  shortfinsquid:  { cy: 'Θράψαλο',         also: 'Θράψαλο',           note: '' },
  whitegrouper:   { cy: 'Σφυρίδα',         also: 'Σφυρίδα',           note: '' },
  goldblotch:     { cy: 'Στήρα',           also: 'Στήρα',             note: '' },
  mottledgrouper: { cy: 'Πίγγα',           also: 'Πίγκα',             note: 'also κυνηγός in some areas' },
  comber:         { cy: 'Χάννος',          also: 'Χάνος',             note: '' },
  paintedcomber:  { cy: 'Πέρκα',           also: 'Πέρκα',             note: '' },
  scorpionfish:   { cy: 'Σκορπιός (κόκκινος)',        also: 'Σκορπίνα',          note: 'Cypriots call all Scorpaena σκορπιός' },
  blackscorpion:  { cy: 'Σκορπιός (μαύρος)',        also: 'Μαυροσκορπιός',     note: 'Cypriots call all Scorpaena σκορπιός' },
  moray:          { cy: 'Σμέρνα',          also: 'Σμέρνα',            note: 'also σμύρνα' },
  conger:         { cy: 'Μουγγρί',         also: 'Μουγγρί',           note: 'also μουγγράσσιελο' },
  rainbowwrasse:  { cy: 'Γύλος',           also: 'Γύλος',             note: '' },
  ornatewrasse:   { cy: 'Γύλος (πράσινος)',           also: 'Γαϊτανούρι',        note: 'Cypriots call both wrasses γύλος' },
  squirrelfish:   { cy: 'Ρώσσος',          also: 'Ακανθόπερκα',       note: '' },
  leatherjacket:  { cy: 'Χοιρόψαρο',       also: 'Μονάκανθος',        note: 'also χοίρος' },
  toadfish:       { cy: 'Λαγοκέφαλος',     also: 'Λαγοκέφαλος',       note: 'also κουνελόψαρο, κουνέλι' },
  weever:         { cy: 'Δράκαινα',        also: 'Δράκαινα',          note: '' }
};
window.PSAREMA_NAMES_CY_SOURCES = [
  'https://web.archive.org/web/20250515164623/https://www.moa.gov.cy/moa/dfmr/dfmr.nsf/All/0BCFFC84FB9802F242257D7000369693/$file/%CE%A4%CE%B1%20100%20%CF%83%CE%B7%CE%BC%CE%B1%CE%BD%CF%84%CE%B9%CE%BA%CF%8C%CF%84%CE%B5%CF%81%CE%B1%20%CE%B5%CE%AF%CE%B4%CE%B7%20%CF%88%CE%B1%CF%81%CE%B9%CF%8E%CE%BD%20%CF%84%CF%89%CE%BD%20%CE%9A%CF%85%CF%80%CF%81%CE%B9%CE%B1%CE%BA%CF%8E%CE%BD%20%CE%98%CE%B1%CE%BB%CE%B1%CF%83%CF%83%CF%8E%CE%BD.pdf',
  'https://web.archive.org/web/20250516091204/https://www.moa.gov.cy/moa/dfmr/dfmr.nsf/All/0A379DE382F847F4C225863000382BB3/$file/%CE%91%CE%A6%CE%99%CE%A3%CE%91%20-%20%CE%9A%CE%A5%CE%A1%CE%99%CE%91%20%CE%95%CE%99%CE%94%CE%97%20%CE%9A%CE%95%CE%A6%CE%91%CE%9B%CE%9F%CE%A0%CE%9F%CE%94%CE%A9%CE%9D%20%CE%A4%CE%97%CE%A3%20%CE%9A%CE%A5%CE%A0%CE%A1%CE%9F%CE%A5.pdf',
  'https://fish-commercial-names.ec.europa.eu/fish-names/commercial-designations_el?ms=CY',
  'https://fish-commercial-names.ec.europa.eu/fish-names/commercial-designations_el?ms=GR',
  'https://www.fishbase.se/references/FBRefSummary.php?id=86644',
  'https://www.fishbase.se/ComNames/CommonNamesList.php?GenusName=Coryphaena&SpeciesName=hippurus',
  'https://www.fishbase.se/ComNames/CommonNamesList.php?GenusName=Seriola&SpeciesName=dumerili',
  'https://www.fishbase.se/ComNames/CommonNamesList.php?GenusName=Diplodus&SpeciesName=sargus',
  'https://zygi.com/?p=248',
  'https://www.cnn.gr/kosmos/story/540240/poy-kataligoun-oi-lagokefaloi-pou-alieyontai-stin-kypro'
];
// >>> round 11 species inventory (eval/species-inventory/new-species.mjs): do not edit by hand
// Names: Cyprus' official commercial designations (https://fish-commercial-names.ec.europa.eu/fish-names/commercial-designations_el?ms=CY) and the DFMR toxic-fish booklet; "also" = the common Greek name.
Object.assign(window.PSAREMA_NAMES_CY, {
 "stripedbream": {
  "cy": "Μούρμουρος",
  "also": "Μουρμούρα",
  "note": "official Cyprus market name μούρμουρος"
 },
 "picarel": {
  "cy": "Μαρίδα",
  "also": "Μένουλα",
  "note": "μαρίδα = S. smaris, μένουλα = S. maena (official Cyprus market names)"
 },
 "axillary": {
  "cy": "Φατσούκλι",
  "also": "Μουσμούλι",
  "note": "official Cyprus market name φατσούκλι"
 },
 "bluerunner": {
  "cy": "Σούρος",
  "also": "Κοκάλι",
  "note": "official Cyprus market name σούρος"
 },
 "triggerfish": {
  "cy": "Χοιρόψαρο (γκρίζο)",
  "also": "Γουρουνόψαρο",
  "note": "Cyprus calls both this and the filefish χοιρόψαρο"
 },
 "razorfish": {
  "cy": "Ποντικός",
  "also": "Κατσούλα",
  "note": "official Cyprus market name ποντικός"
 },
 "shidrum": {
  "cy": "Μυλοκόπι",
  "also": "Μυλοκόπι",
  "note": ""
 },
 "bluefin": {
  "cy": "Ερυθρός τόνος",
  "also": "Τόνος",
  "note": "official Cyprus market name ερυθρός τόνος"
 },
 "bullettuna": {
  "cy": "Παλαμίδα (κοπάνι)",
  "also": "Κοπάνι",
  "note": "Cypriots call all small tunas παλαμίδα (official market name too)"
 },
 "damselfish": {
  "cy": "Παπαδιά",
  "also": "Καλόγρια",
  "note": "official Cyprus market name παπαδιά"
 },
 "lizardfish": {
  "cy": "Παπανικολής",
  "also": "Σκαρμός",
  "note": "official Cyprus market name παπανικολής, also for the invasive Saurida"
 },
 "stargazer": {
  "cy": "Λύχνος",
  "also": "Λύχνος",
  "note": "also μύξης (DFMR)"
 },
 "peacockwrasse": {
  "cy": "Χειλού",
  "also": "Χειλού",
  "note": "the Symphodus and Labrus wrasses are all χειλού in Cyprus"
 },
 "yellowpuffer": {
  "cy": "Μαππουρούι",
  "also": "Νάνος λαγοκέφαλος",
  "note": "official Cyprus market name μαππουρούι"
 },
 "stingray": {
  "cy": "Βατί",
  "also": "Τρυγόνα",
  "note": "βατί = every stingray (Dasyatidae) in Cyprus (DFMR)"
 },
 "electricray": {
  "cy": "Μουδιάστρα",
  "also": "Μουδιάστρα",
  "note": "all three Torpedo species"
 },
 "guitarfish": {
  "cy": "Βιόλα",
  "also": "Κιθάρα",
  "note": "official Cyprus market name βιόλα (Rhinobatos); also ρινόβατος"
 },
 "thornback": {
  "cy": "Ράζα",
  "also": "Σαλάχι",
  "note": "ράζα = every skate (Rajidae) in Cyprus"
 },
 "reefsquid": {
  "cy": "Σουπιοκαλάμαρο",
  "also": "Σουπιοκαλάμαρο",
  "note": "official Cyprus market name σουπιοκαλάμαρο"
 }
});
window.PSAREMA_NAMES_CY_SOURCES.push("https://fish-commercial-names.ec.europa.eu/fish-names/commercial-designations_el?ms=CY", "https://publications.gov.cy/assets/user/publications/2017/2017_078/GEORG_ALIEIAS_Toxika%20psaria.pdf");
// <<< round 11 species inventory
