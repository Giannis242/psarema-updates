# Psarema ocean data sources, part 2 (verified 2026-10-23, 17:37–17:51 UTC)

Box: lat 34.225–35.875, lon 31.875–34.875. All requests were made with `Origin: null` (curl `-H "Origin: null"` or Node 24 `fetch`).
"CORS" means the `Access-Control-Allow-Origin` header that came back. Sizes are compressed bytes on the wire (sum of `Content-Length`).
Times are Node wall-clock times for one layer, including `.zmetadata` + lat/lon/time reads (~0.55–0.7 s of each figure) and 6 parallel requests (about a browser's per-host limit).

Scratchpad `{S}` = `C:\Users\User\AppData\Local\Temp\claude\C--Users-User-AppData-Local-Claude-Data-claude-pzs8sxrjxfjjc-scratch-workspaces-fd613261-efa7-4c0a-8eac-8a3526f0f2af-dbdedb30-ced1-4fc4-b159-eef95699115d-scratch-2026-10-23-64b7f2\51680ce4-7c5c-46a1-b01c-954743aea35f\scratchpad\ocean2`
- `{S}\scripts\arco2.mjs` is the tested reader. It handles N-D arrays (3-D `[time,lat,lon]` and 4-D `[time,elevation,lat,lon]`), a range of time steps, `t=now`, `z=top`, missing chunks (403 = fill), `head` (sizes only), `range` (HTTP Range block reads, see §5) and `dump=` (raw float32 grid for cross-checks). It was regression-tested against the SOURCES.md SST result and gives the same output (57 273 valid, 296.25–299.19 K).
- `{S}\scripts\meta.mjs` prints a `.zmetadata` summary. Saved metadata and STAC JSON are in `{S}\downloads\zmeta`, `{S}\downloads\stac`, and cross-check dumps are in `{S}\downloads\cmp`.

## Summary (recommended access per layer)

| Layer | Store / access | Box bytes | Time | Valid cells | CORS |
|---|---|---|---|---|---|
| Currents uo, next 72 h hourly | 2D hourly **geoChunked + Range** | 3.94 MB | 1.7 s | 2 335 / 2 920 per hour | `*` |
| Currents vo, next 72 h hourly | same | 3.95 MB | 1.7 s | 2 335 / 2 920 | `*` |
| Surface temp thetao, 72 h hourly | 2D hourly tem geoChunked + Range | 2.80 MB | 1.6 s | 2 335 / 2 920 | `*` |
| Bottom temp bottomT, today | daily tem **timeChunked + Range** | 0.43 MB | 1.0 s | 2 335 / 2 920 | `*` |
| Mixed layer mlotst, today | daily mld timeChunked + Range | 0.53 MB | 1.1 s | 2 335 / 2 920 | `*` |
| Waves VHM0, 72 h hourly | WAV geoChunked + Range | 1.30 MB | 1.5 s | 2 335 / 2 920 | `*` |
| Waves VMDR, 72 h hourly | same | 1.81 MB | 1.6 s | 2 335 / 2 920 | `*` |
| Clarity KD490, latest day (L3, clouds) | OC L3 1 km timeChunked + Range | 0.72 MB | 1.2 s | 11 059 / 31 067 sea cells (36%) | `*` |
| Clarity KD490, gap-free | **no such ARCO dataset yet**. Derive from the gap-free CHL already loaded (§2.3) | 0 extra | – | 31 067 / 31 067 | – |

Running all eight reads in sequence took **12.0 s** and about 15.6 MB. A page can run them in parallel and share the metadata.
**Over budget: currents.** uo+vo for 72 h is **7.9 MB** today, above the 6 MB limit, and the cost moves with a 512-hour cycle (§1.4). The lighter options are in §1.5.

---

## 1. MEDSEA_ANALYSISFORECAST_PHY_006_013 (CMCC MedFS, 1/24°)

STAC: `https://stac.marine.copernicus.eu/metadata/MEDSEA_ANALYSISFORECAST_PHY_006_013/<dataset>/dataset.stac.json` (CORS `*`).
Use the **`_202511`** datasets. The listed `_202611` versions (e.g. `cmems_mod_med_phy-cur_anfc_4.2km-2D_PT1H-m_202611`, renamed `temp`) only have a `native` asset, are not in ARCO yet, and have empty cube metadata.
STAC says `admp_retired_date` 2027-01-12 for the `_202511` stores, so plan to switch to `_202611` after that.

Grid (identical in every PHY store checked): `latitude` 380 × f4, first 30.1875, step 1/24. `longitude` 1287 × f4, first −17.291666, step 1/24.
Box indices: **i = 97…136** (34.2292–35.8542, 40 rows), **j = 1180…1252** (31.8750–34.8750, 73 cols), so 2 920 cells. The model sea mask leaves **2 335** valid at every time step (land = fill).
i = round((lat − 30.1875)·24), j = round((lon + 17.291667)·24).

Common format: Zarr v2, C order, `blosc/lz4`, shuffle 1, dtype **`<f4`**, **no scale/offset**, fill/missing **1e20** (`100000002004087730000`; in JS compare with `Math.fround(1e20)`).
Time is `<i4` **"minutes since 1900-01-01"**, regular. The first hourly time is 2023-11-01T00:00Z. Chunks before `admp_valid_start_index` 7152 (2024-08-25) were deleted and return **403** (with ACAO `*`). Treat 403 as "all fill".

### 1.1 Hourly surface currents uo, vo (dataset `cmems_mod_med_phy-cur_anfc_4.2km-2D_PT1H-m_202511`)

- `{G}` = `https://s3.waw3-1.cloudferro.com/mdl-arco-geo-033/arco/MEDSEA_ANALYSISFORECAST_PHY_006_013/cmems_mod_med_phy-cur_anfc_4.2km-2D_PT1H-m_202511/geoChunked.zarr`
- `{T}` = same with `mdl-arco-time-033` and `timeChunked.zarr`
- Variables `uo` (eastward) and `vo` (northward), units **m s-1**, dims **`[time, latitude, longitude]`**. This "2D" store is surface-only and has **no depth dimension**, so no depth index is needed.
- Shape `[26328, 380, 1287]`. Chunks: timeChunked **`[2, 380, 1287]`**, geoChunked **`[3576, 16, 16]`**. `time` chunk is 17928 (key `time/1` holds the latest values).
- Values are hourly means centred on the timestamp (STAC `field_type: hourly_mean_centered_at_time_field`). Timestamps are on the hour.
- **Now index:** `tNow = floor((Date.now() − Date.UTC(2023,10,1)) / 3.6e6)`. At 17:41Z this gave **26105** = 2026-10-23T17:00Z, which matches `time[26105]` read from `time/1`. The reader does the robust version: decode `time/{floor((shape−1)/17928)}` and take the last value ≤ now.
- **Future hours:** `shape[0]−1` = 26327 = **2026-11-01T23:00Z**, so 222 h after now (223 steps including now). All 223 steps were decoded and are valid (2 335 cells each). The STAC extent end agrees. `shape[0]` comes from `.zmetadata`.
- Decoded over the box, 72 h: **uo −0.448 … +0.440 m/s**, **vo −0.507 … +0.555 m/s**.

**timeChunked vs geoChunked for 72 h over the box (uo; vo is the same size)**, measured by HEAD or GET:

| Access | Keys | Bytes | Time |
|---|---|---|---|
| timeChunked, whole chunks | 37 (`13052.0.0` … `13088.0.0`) | 60.4 MB (≈1.63 MB each) | – (HEAD only) |
| timeChunked + Range (one contiguous range per chunk) | 37 | 49.7 MB | 2.9 s |
| geoChunked, whole chunks | 18 | 18.6 MB (≈1.05 MB each) | 1.9 s |
| **geoChunked + Range (recommended)** | 18 keys, 36 range GETs | **3.94 MB** | **1.6–1.7 s** |
| timeChunked + Range, **one hour only** | 1 | 0.57 MB | 1.0 s |

All four paths decode to **byte-identical** grids (`cmp` of dumps: geo full = geo Range = timeChunked).

**Recommended keys (geoChunked):** `{G}/uo/{floor(t/3576)}.{floor(i/16)}.{floor(j/16)}` for t ∈ [tNow, tNow+71], i ∈ 97…136, j ∈ 1180…1252.
Today that is `7.{6,7,8}.{73,74,75,76,77,78}` (18 keys, same for `vo`). The time-chunk part doubles only when the window crosses t = 28608 (2027-01-11).
Fetch each key with two Range GETs (§5). Inside a chunk, element (t,i,j) is at flat index `(t − 3576·T)·256 + (i mod 16)·16 + (j mod 16)`. Each blosc block holds **512 time steps** (bsize 524 288 B).
Today all 72 h sit in block 2 of each chunk (t 26056–26567 = 2026-10-21T16:00 → 2026-11-11T23:00). So **72 h, or the whole 223-h forecast, cost the same 3.94 MB** (measured with n=223: 3 936 985 B, the same as n=72).

**Single-hour key (timeChunked):** `{T}/uo/{floor(t/2)}.0.0`. The hour is at offset `(t mod 2)·380·1287`. With Range the box rows cost 0.57 MB per variable.

### 1.2 Hourly surface temperature thetao (dataset `cmems_mod_med_phy-tem_anfc_4.2km-2D_PT1H-m_202511`)

- `{G}` = `https://s3.waw3-1.cloudferro.com/mdl-arco-geo-033/arco/MEDSEA_ANALYSISFORECAST_PHY_006_013/cmems_mod_med_phy-tem_anfc_4.2km-2D_PT1H-m_202511/geoChunked.zarr` (timeChunked: `mdl-arco-time-033/.../timeChunked.zarr`)
- This is a separate store with exactly the same layout as §1.1: `thetao` `[time, latitude, longitude]` (surface only, no depth), **degrees_C**, f4, fill 1e20, shape `[26328,380,1287]`, geo chunk `[3576,16,16]`, time chunk `[2,380,1287]`, same time axis, now index, and last time (2026-11-01T23:00Z).
- Keys: `{G}/thetao/7.{6,7,8}.{73…78}` (18). geoChunked + Range for 72 h: **2 799 302 B, 1.6 s** (whole geo chunks would be 13.5 MB by HEAD).
- Decoded 72 h: **23.06 … 27.00 °C** (now step 23.26–27.00). That fits the L4 SST of 23.1–26.0 °C, given the model's hourly diurnal warming.

### 1.3 3-D hourly store and the surface depth index (4-D check)

`https://s3.waw3-1.cloudferro.com/mdl-arco-geo-033/arco/MEDSEA_ANALYSISFORECAST_PHY_006_013/cmems_mod_med_phy-cur_anfc_4.2km-3D_PT1H-m_202511/geoChunked.zarr` (and `mdl-arco-time-033/.../timeChunked.zarr`):
- `uo`/`vo` dims **`[time, elevation, latitude, longitude]`**, shape `[9288,141,380,1287]`. Chunks: time `[2,1,380,1287]`, geo `[2880,1,16,16]`.
- `elevation` is 141 × f4, positive up and ascending, so the **surface is the last index, 140 (−1.018 m)**.
- Time starts 2025-10-06T00:00Z (rolling store, so read the time chunk instead of hard-coding). Now = 9185. The last time is **2026-10-27T23:00Z, only 102 h ahead**.
- Keys: geo `{floor(t/2880)}.140.{floor(i/16)}.{floor(j/16)}` (today `3.140.{6,7,8}.{73…78}`), time `{floor(t/2)}.140.0.0`.
- Surface level vs the 2D store at 17:00Z: same mask (2 335 valid), **max |diff| 1.6e-6 m/s**. Use the 2D store: its forecast is longer and it needs no depth index.
- geo + Range, 72 h: 2.00 MB, 1.75 s. It is cheaper today only because its current block holds just 136 steps of data (§1.4).

### 1.4 How the Range cost changes over time (hourly geo stores)

The bytes fetched equal the steps with data in the touched 512-step block × about 800 B (f4, per 16×16 tile) × 18 tiles.
Today block 2 holds 272 data steps (26056–26327; the rest is fill, which compresses to almost nothing), so 3.94 MB.
*Estimate, not measured:* as daily forecast updates extend the axis to the end of the block (t 26567, 2026-11-11T23:00), uo or vo grows to about 512 × 820 × 18 ≈ **7.5 MB**.
If the 72-h window crosses a block boundary (when `(t − 3576·T) mod 512 > 440`), the read needs two blocks, up to about 10 MB per variable for a few days. Then the cost drops back when the next block starts.
The same logic applies to thetao (≈ 580 B/step/tile today) and waves (§3).

### 1.5 Lighter alternatives for currents (uo+vo 72 h = 7.9 MB today, over the 6 MB budget)

1. Show "now" first with timeChunked + Range: 0.57 MB per variable, 1 key, about 1 s. Load the 72-h geo + Range blocks only when the user opens the time slider.
   One block covers the whole 223-h forecast, so cache it for the session.
2. Accept about 8 MB (rising to about 15 MB) for uo+vo in about 2 s. Note that 3-hourly subsampling does **not** save bytes on geo stores, because a block always holds 512 consecutive hours.
3. Open-Meteo (SOURCES.md §5) costs at least 1 API call per location. The 2 335 sea cells would be 3 requests and about 2 335 calls of the 10 000/day quota per page load, so it only suits a few points.

### 1.6 Daily sea-bottom temperature bottomT (dataset `cmems_mod_med_phy-tem_anfc_4.2km_P1D-m_202511`)

- `{T}` = `https://s3.waw3-1.cloudferro.com/mdl-arco-time-033/arco/MEDSEA_ANALYSISFORECAST_PHY_006_013/cmems_mod_med_phy-tem_anfc_4.2km_P1D-m_202511/timeChunked.zarr`
  (geo: `mdl-arco-geo-033/.../geoChunked.zarr`)
- `bottomT` dims **`[time, latitude, longitude]`** (no depth), **degrees_C**, f4, fill 1e20, shape `[1097,380,1287]`. Chunks: time `[2,380,1287]`, geo `[150,32,64]`.
  The same store has `thetao` 4-D `[time, elevation, lat, lon]`, chunks `[2,1,380,1287]` / `[150,2,32,64]`, with surface at elevation index 140.
- Daily means timestamped 00:00Z. Time is "minutes since 1900-01-01", first 2023-11-01, `time` chunk 747.
  **Today** `d = floor((Date.now() − Date.UTC(2023,10,1)) / 864e5)` = **1087** = 2026-10-23. The last day is index 1096 = **2026-11-01** (9 forecast days).
- **Keys:** timeChunked `{T}/bottomT/{floor(d/2)}.0.0` = **`543.0.0`**, with the day at offset `(d mod 2)·380·1287`. geo: `{floor(d/150)}.{3,4}.{18,19}` = `7.3.18, 7.3.19, 7.4.18, 7.4.19`.
- Sizes for today: time full chunk 1 256 799 B / 1.1 s. **time + Range 428 544 B / 1.0 s (recommended)**. geo full 741 825 B / 1.2 s. geo + Range 734 489 B / 1.3 s. All four are byte-identical.
- Decoded: **13.59 … 25.52 °C**, 2 335 / 2 920 valid. That fits Levantine deep water at about 13.6 °C and warm shelf bottoms.
- 4-D check, daily surface thetao today: geo keys `7.70.{3,4}.{18,19}` (294 KB) and time key `543.140.0.0` (440 KB) are identical, 23.18–26.99 °C.

### 1.7 Daily mixed layer depth mlotst (dataset `cmems_mod_med_phy-mld_anfc_4.2km_P1D-m_202511`)

- `{T}` = `https://s3.waw3-1.cloudferro.com/mdl-arco-time-033/arco/MEDSEA_ANALYSISFORECAST_PHY_006_013/cmems_mod_med_phy-mld_anfc_4.2km_P1D-m_202511/timeChunked.zarr`
- `mlotst` dims `[time, latitude, longitude]`, units **m**, f4, fill 1e20, shape `[1097,380,1287]`. Chunks: time `[2,380,1287]`, geo `[150,64,64]`. Time axis is the same as §1.6 (today 1087, last 2026-11-01).
- Keys: time `543.0.0`. geo `7.{1,2}.{18,19}`.
- Sizes: time full 1 522 340 B / 1.3 s. **time + Range 525 871 B / 1.1 s**. geo full 1 642 877 B. geo + Range 539 222 B / 1.1 s. All are byte-identical.
- Decoded: **11.90 … 53.82 m**, 2 335 / 2 920 valid.

## 2. Water clarity (ocean colour, MED)

### 2.1 What does not exist (yet)
- The **gap-free daily L4 transparency** `cmems_obs-oc_med_bgc-transp_nrt_l4-gapfree-multi-1km_P1D-m_202611` (product 009_142) is `admp_in_preparation: true` with `admp_released_date` **2026-11-24**. It has only a `native` asset.
  Its ARCO `.zmetadata` returns **403** in buckets mdl-arco-time-033/044/045/046, and the native folder returns 404. The same is true for `optics_..._gapfree_..._202611` and the HR `transp_nrt_l4-hr_P1D-m_202105`.
- **No live MED dataset has ZSD (Secchi depth).** I checked the cube variables of every item in 009_141, 009_142, 009_205 and 009_211. The transparency datasets carry only `KD490` (plus `QI_KD490`, `SENSORMASK`, `KD490_count`, `KD490_error`).

### 2.2 Daily L3 KD490 1 km (has cloud gaps)
- `https://s3.waw3-1.cloudferro.com/mdl-arco-time-045/arco/OCEANCOLOUR_MED_BGC_L3_NRT_009_141/cmems_obs-oc_med_bgc-transp_nrt_l3-multi-1km_P1D_202207/timeChunked.zarr`
  (`geoChunked` and `downsampled4.zarr` also exist; see the STAC asset list)
- `KD490` dims `[time, latitude, longitude]`, **m^-1**, `<f4`, no scale, fill/missing **−999**, chunk `[1,512,1024]`, shape `[1273,1580,3308]`.
  Time is "seconds since 1981-01-01", `time` chunk 9. Latest = `shape[0]−1` = **1272 = 2026-10-22** (1 day old).
- This is the same grid as the CHL datasets in SOURCES.md: box i 417–579, j 2948–3181 (163 × 234). Keys: **`{t}.0.2, {t}.0.3, {t}.1.2, {t}.1.3`**.
- Full chunks 1 669 895 B / 1.2 s. **Range 722 879 B / 1.1 s** (byte-identical).
- Decoded: **0.0191 … 0.0424 m^-1**. **11 059 of 31 067 sea cells valid (36%)**, the same swath as L3 CHL.

### 2.3 Gap-free KD490 derived from the gap-free CHL (recommended for now, 0 extra bytes)
Morel et al. (2007): `KD490 = 0.0166 + 0.0773 · CHL^0.6715`, applied to the gap-free L4 CHL of 2026-10-22 (SOURCES.md §2, same grid).
Checked against L3 KD490 on all **11 059** co-valid cells: **R = 0.984, bias +0.0011 m^-1, RMSE 0.0019 m^-1**, ratio derived/L3 median 1.045 (5–95%: 0.95–1.15).
Over the box it covers all 31 067 sea cells, range 0.0221–0.0426 m^-1. When the official gap-free product goes live (after 2026-11-24), swap it in at the same grid and the same keys pattern.
ZSD: nothing to verify against (§2.1). Any Secchi value would be an empirical conversion from KD490, which I have not tested here.

### 2.4 Monthly L4 KD490 1 km (gap-filled monthly composite)
`https://s3.waw3-1.cloudferro.com/mdl-arco-time-045/arco/OCEANCOLOUR_MED_BGC_L4_NRT_009_142/cmems_obs-oc_med_bgc-transp_nrt_l4-multi-1km_P1M_202207/timeChunked.zarr`
`KD490` (also `KD490_count`, `KD490_error`): same format and grid, `time` chunk 16. Latest **t 56 = 2026-09-01**. Keys `56.{0,1}.{2,3}`.
2 045 188 B / 1.3 s (full chunks). 30 862 valid cells, 0.0191–0.0483 m^-1.
There is also a 300 m OLCI variant (`..._l4-olci-300m_P1M_202207`, with `downsampled4/8/16.zarr`), not read.

## 3. MEDSEA_ANALYSISFORECAST_WAV_006_017 (hourly, 1/24°)

- `{G}` = `https://s3.waw3-1.cloudferro.com/mdl-arco-geo-034/arco/MEDSEA_ANALYSISFORECAST_WAV_006_017/cmems_mod_med_wav_anfc_4.2km_PT1H-i_202311/geoChunked.zarr`
  (`{T}`: `mdl-arco-time-034/.../timeChunked.zarr`)
- `VHM0` (significant wave height, **m**) and `VMDR` (mean direction **from**, **degree**). Dims `[time, latitude, longitude]`, dtype **`<i2`**, fill/missing **−32767**.
  **VHM0 = raw · 0.001** (scale 0.0010000000474974513, offset 0). **VMDR = raw · 0.01 + 180** (scale 0.009999999776482582, add_offset 180; raw valid −18000…18000).
- Shape `[43152, 380, 1307]`. Chunks: time `[2,380,1307]`, geo **`[3216,16,16]`** (blosc bsize 262 144 = 512 steps per block). `.zmetadata` is 27 KB (19 variables).
- Time is `<i4` **"seconds since 1970-01-01"**, instantaneous hourly (`PT1H-i`), first 2021-11-30T00:00Z, `time` chunk 16080.
  **Now** `= floor((Date.now() − Date.UTC(2021,10,30)) / 3.6e6)` = **42929** = 2026-10-23T17:00Z. The last time is index 43151 = **2026-11-01T23:00Z** (222 h ahead).
- Grid: lat as PHY (i 97…136). **lon differs**: 1307 values, first −18.125, so j = round((lon + 18.125)·24) = **1200…1272**.
- **Keys:** `{G}/VHM0/{floor(t/3216)}.{floor(i/16)}.{floor(j/16)}` = today **`13.{6,7,8}.{75,76,77,78,79}`** (15 keys). Same for VMDR.
- 72 h sizes: timeChunked whole chunks 37 keys, 23.0 MB (HEAD). geo whole 5.44 MB (VHM0) / 7.26 MB (VMDR) (HEAD).
  **geo + Range: VHM0 1 295 462 B / 1.5 s, VMDR 1 805 842 B / 1.6 s.** One hour via timeChunked + Range: 195 KB. First step geo = time (byte-identical).
  The current block is t 42832–43343 (2026-10-19T16:00 → 2026-11-09T23:00), so the same block-cycle caveat as §1.4 applies (roughly ≤ 2× today's size when full).
- Decoded 72 h: **VHM0 0.013 … 1.065 m** (now 0.08–0.80 m). **VMDR 0.01 … 359.99°**. 2 335 / 2 920 valid every hour.

## 4. CORS observed

- Every GET (`.zmetadata`, coordinates, chunks, 200 and **206** Range responses, and **403** missing chunks) returned `access-control-allow-origin: *` and `access-control-allow-methods: GET`.
- Preflight `OPTIONS` with `Origin: null`, `Access-Control-Request-Headers: range` returned **200** with `access-control-allow-origin: null`, `vary: Origin`, `access-control-allow-methods: GET`, `access-control-allow-headers: range`, and **no max-age**.
  So Range reads work from file:// whether or not the browser treats `Range` as safelisted. Without max-age, expect at most one preflight per chunk URL.
- Real-browser check (Claude browser pane). It could not open file:// or data: pages, so I ran the fetches cross-origin from `https://stac.marine.copernicus.eu`: `.zmetadata` 200. `uo/7.6.73` with `Range: bytes=0-1039` → 206, 1040 B. Block-2 range → 206, 235 442 B (exactly as expected). 3 requests in 612 ms.
  An opaque-origin (`null`) browser fetch was not run; the server's preflight answer for `Origin: null` above is the evidence for that case.
- STAC (`stac.marine.copernicus.eu`) answers `access-control-allow-origin: *`.

## 5. Range read recipe (for the in-page decoder)

For one chunk URL and a wanted raw byte span `[from, to)` (element offset × 4 for f4, × 2 for i2):
1. `GET` with `Range: bytes=0-1039`. That gives the 16-byte blosc header (`nbytes` u32@4, `bsize` u32@8, `cbytes` u32@12, flags u8@2) and the block-start table, `bstarts[b]` = i32@`16+4b`.
   1040 B covers ≤ 256 blocks; the PHY/WAV chunks have 4–8.
2. Needed blocks are `b0 = floor(from/bsize)` … `b1 = floor((to−1)/bsize)`.
   `GET` with `Range: bytes=min(bstarts[b0..b1]) - (end−1)`, where end is the next larger `bstarts` value after `bstarts[b1]` (or `cbytes`). Do not assume blocks are stored in order.
3. Place both responses at their real offsets in a zeroed `Uint8Array(cbytes)` and run the existing `blosc()` with a block filter.
   This is the only decoder change: `if ((b+1)*bsize <= from || b*bsize >= to) continue;`. Then read elements as before.
If the memcpyed flag (`flags & 2`) is set, fetch `16+from … 16+to−1` directly. In `arco2.mjs` this is `getPartial()` plus the `from/to` arguments of `blosc()`.

## 6. Did not work / caveats

- Gap-free daily KD490/ZSD: not in ARCO until about 2026-11-24 (§2.1). There is no ZSD at all in live MED products.
- `_202611` PHY datasets: STAC entries only, no ARCO assets yet. `downsampled4.zarr` does not exist for the PHY stores (403).
- 72-h hourly currents cannot fit 6 MB for uo+vo with any ARCO layout (best: 7.9 MB today, geo + Range). timeChunked is 7–15× worse for multi-hour windows (60 MB whole, 50 MB with my contiguous-range reads).
- `arco2.mjs` `range` uses one contiguous byte span per chunk. That is optimal for geoChunked and single-step timeChunked reads, but not for multi-step timeChunked reads. The `ponytail:` comment in the code marks where to split per step; the recommended paths do not need it.

## 7. Live weather: which forecast model, and measured wind (round 8, checked 2026-11-03)

Scripts: `scripts/verify/wind.mjs` (download, cache, score; `node scripts/verify/wind.mjs --sea` for the app's own cell choice),
`scripts/verify/check-blend.mjs` (self-check of `blendModels()` in `js/sources.js`). Open-Meteo calls used for all of this: about 300 of the 1 500 budget.

### 7.1 Wind and pressure: what was measured

- **Truth**: the three coastal airports, Larnaca LCLK, Paphos LCPH, Akrotiri LCRA. Wind (10-min mean, direction, gust groups) from their METARs,
  [Iowa Environmental Mesonet](https://mesonet.agron.iastate.edu/) ASOS/METAR download (public domain, "attributing the IEM would be appreciated").
  Sea-level pressure to 0.1 hPa from their hourly SYNOPs (17609, 17600, 17601) via [OGIMET](https://www.ogimet.com/) (used for checking only, not shipped).
  The nearest report within 10 min of each hour; direction only when the wind is 5 kn or more.
- **Forecasts**: Open-Meteo's previous-runs API (`previous-runs-api.open-meteo.com`): for each hour, the latest run (lead 0–12 h) and the runs
  1, 2 and 3 days before (leads ~24, ~48, ~72 h). 35 days, 2026-09-29 to 2026-11-02: 2 516 station-hours per lead, the same hours for every model.
- **Cells**: `cell_selection=sea`, as the app's forecast grid uses (its numbers are for the sea). A second run with the nearest land cell is in 7.3.
- Models offered for Cyprus and scored: `best_match` (= `icon_seamless` = `icon_eu`, ICON-EU 7 km here), `ecmwf_ifs` (IFS 9 km), `ecmwf_ifs025`,
  `ecmwf_aifs025_single`, `icon_global`, `gfs_seamless`, `meteofrance_arpege_europe`, `meteofrance_arpege_world`, `ukmo_global_deterministic_10km`,
  `gem_global`. `kma_gdps` and `gfs_graphcast025` have no history there; `dmi_harmonie_arome_europe` returned an error.

### 7.2 Before and after (sea cells; wind in knots, pressure in hPa, bias = forecast − observed)

| Lead | App forecast | Speed MAE | Speed bias | Direction MAE | MSLP MAE | MSLP bias |
|---|---|---|---|---|---|---|
| 0–12 h | before: `best_match` | 2.18 | −1.04 | 23° | 0.30 | +0.02 |
| | **now: mean of `best_match` and `ecmwf_ifs`** | **1.88** | −0.73 | 25° | **0.22** | +0.05 |
| ~24 h | before | 2.38 | −1.35 | 27° | 0.51 | +0.43 |
| | now | **2.07** | −1.04 | 28° | **0.44** | +0.37 |
| ~48 h | before | 2.47 | −1.31 | 30° | 0.60 | +0.47 |
| | now | **2.17** | −1.03 | 31° | **0.52** | +0.40 |
| ~72 h | before | 2.56 | −1.52 | 31° | 0.64 | +0.44 |
| | now | **2.21** | −1.14 | 31° | **0.55** | +0.38 |

The blend beats `best_match` on speed at each of the three stations and each lead, and on pressure; direction is 1–2° worse
at short leads. Single models at ~24 h (speed MAE / direction MAE / MSLP MAE): `ecmwf_ifs` 2.32 / 34° / 0.42, `best_match` 2.38 / 27° / 0.51,
`icon_global` 2.43 / 33° / 0.54, `gem_global` 2.44 / 32° / 0.60, `ecmwf_ifs025` 2.73 / 40° / 0.41, `ecmwf_aifs025_single` 2.74 / 39° / 0.40,
`meteofrance_arpege_world` 2.75 / 38° / 0.50, `ukmo_global_deterministic_10km` 2.81 / 35° / 0.51, `meteofrance_arpege_europe` 2.84 / 39° / 0.46,
`gfs_seamless` 3.07 / 40° / 0.42. The runner-up blend, `best_match` + `gem_global`, is within 0.08 kn on speed but no better than now on
pressure; the mean of three (adding `gem_global`) gains ≤ 0.06 kn but would be 15 variables per location, 1.5× the call weight.

**How the app uses it** (`js/sources.js` `WX_MODELS`, `blendModels()`): the forecast request asks for `models=best_match,ecmwf_ifs` (still one
request; 2 models × 5 variables stays within Open-Meteo's 10-variable unit) and takes the mean speed, the vector-mean direction, the mean gust
and the mean pressure; cloud cover stays `best_match` (not measured). `js/ocean.js` history does the same for wind and pressure (rain and air
temperature stay `best_match`). Cache key `psarema-v5` and its layout are unchanged.

### 7.3 Caveats (read before quoting the numbers)

- The airports are on land by the sea; the app's cells are over the sea, where the wind is usually stronger. Both chosen models, and most others, are
  biased low against the stations even at their sea cells.
- With the **nearest land cell** instead, the ranking changes: `best_match` is the best single model (2.25 kn at ~24 h), `best_match` + `gem_global`
  the best pair (2.13), and `best_match` + `ecmwf_ifs` is slightly worse than `best_match` alone (2.32). The app shows sea cells, so the choice follows 7.2.
- **Gusts are not verified**: only 5 METAR gust groups fell within 10 min of an hour in 35 days, and the Cyprus SYNOPs carry no gust group.
  The app's gust is the two models' mean, untested.
- 35 days of autumn at 3 stations: a winter of storms could rank the models differently. Re-run the script each season.

### 7.4 Waves and sea temperature: no open observations near Cyprus

- Copernicus Marine In Situ TAC, Mediterranean (`INSITU_MED_PHYBGCWAV_DISCRETE_MYNRT_013_035`, `index_platform.txt` of 2026-11-03): no moored
  buoy reports waves within 30–37.5 N, 26–37 E; the easternmost active wave buoy is Heraklion, Crete (~700 km away). Near Cyprus there are only
  Argo floats (profiles every ~10 days), one drifter east of the box (35.9 E) and ship temperature reports. EMODnet Physics' ERDDAP has nothing
  more. Satellite altimeter wave heights exist (Copernicus `WAVE_GLO_PHY_SWH_L3_NRT_014_001`, public S3) but only as HDF5 files that need a
  NetCDF library, which this project doesn't use: not done.
- So the wave model is chosen by coverage, not measured: the app keeps Open-Meteo's marine `best_match` (Météo-France MFWAM, ~8 km, assimilates
  altimeter wave heights, runs 8 days, enough for the app's 7). DWD EWAM is finer (~5 km) but ends after ~3.8 days; ECMWF WAM (`ecmwf_wam`)
  also runs 8 days. At one point off Limassol on 2026-10-01 the models disagreed by a factor of 2–3 (0.26–0.70 m), so an observation would matter.
- Sea temperature in the marine API comes from one model only (Météo-France currents); the fish map's temperature is the Copernicus satellite
  analysis anyway (§1, SOURCES.md).

### 7.5 Measured wind in the app (`js/obs.js`, `window.PsObs`)

| Source | Use | Licence | CORS (from `http://localhost:8417` and `https://localhost`) |
|---|---|---|---|
| IEM `api/1/currents.json?network=CY__ASOS` | latest METAR wind of LCLK, LCPH, LCRA (LCEN, inland in the north, is skipped) | public domain; credit appreciated | `Access-Control-Allow-Origin: *` |
| aviationweather.gov `api/data/metar` | — | US Government | **none**: a WebView can't read it |
| tgftp.nws.noaa.gov METAR text, OGIMET | — | — | none |

~7.5 kB per fetch, after start-up and then every 10 min while the app is in view; reports older than 3 h are hidden. No relay is needed
(the IEM sends CORS), so `scripts/live-ais/worker.js` is unchanged. The credits (map attribution) name ICON (DWD), IFS (ECMWF, CC BY 4.0) via
Open-Meteo, and the IEM.

## 8. Live fish sightings: the Feed and the map pins (`js/records.js`; round 8, checked 2026-11-03)

Open observations of fish by divers and naturalists, shown as **sightings** (never as catches), each with its observer, licence and a link to
the original. Box = the app grid (lat 34.225–35.875, lon 31.875–34.875); the app then drops records in the north mask and any more than one
grid cell (~250 m) from the sea (reservoirs, rivers, inland towns, fish markets). Cached on the device (localStorage) for 6 h; offline with
no saved copy, the Feed falls back to `data/sightings.js` (the same sources, built in, no photos). ≤ 1 request a second to each API.

| Source | Request | Licence filter | CORS (from `http://localhost:8417`; `Origin: https://localhost` checked with curl) |
|---|---|---|---|
| iNaturalist API **v2** `/v2/observations` | box, `taxon_id=47178,47273,47459` (ray-finned fishes, sharks and rays, cephalopods), `quality_grade=research`, `geoprivacy=open&taxon_geoprivacy=open`, `captive=false`, `acc_below_or_unknown=1000`, `order_by=observed_on`, `per_page=100`, a `fields=` list | `license` and `photo_license` = `cc0,cc-by,cc-by-nc` (checked again per record and per photo) | `Access-Control-Allow-Origin: *` |
| GBIF `/v1/occurrence/search` | box, `basisOfRecord=HUMAN_OBSERVATION`, `year=2015,<now>`, `hasGeospatialIssue=false`, `occurrenceStatus=PRESENT`, `checklistKey=7ddf754f-d193-4cc9-b351-99906754a03b` with `taxonKey=8VR36` (Actinopterygii), `LB` (Elasmobranchii), `7NF3H` (Cephalopoda); every dataset except iNaturalist's own copy (`50c9509d-…`, which comes direct) | `license=CC0_1_0, CC_BY_4_0, CC_BY_NC_4_0`; media kept only when their own licence is one of those (Observation.org's photos are BY-NC-ND: dropped, the record stays) | `Access-Control-Allow-Origin: *` |

Measured 2026-11-03: iNaturalist has 1 549 research-grade, open-licence, open-coordinate fish/cephalopod observations in the box (1 351 with
accuracy ≤ 1 km or unknown); page 1 kept 91 of 100 after the sea/north filter, all with a photo. A page of 100 is 66 kB of JSON, **9 kB on the
wire** (gzip), ~1 s. GBIF has 881 non-iNaturalist human observations since 2015 (ORMEF 685, CROMIS, ClimateFish, Diveboard, Observation.org,
NABU|naturgucker…), only 32 with images; GBIF sends no compression (~7 kB a record), so it is read one year per request, newest first, and only
as the Feed is scrolled back to that year. A test fixture saved from the live APIs (first page plus four more) holds 409 records:
395 iNaturalist (all with photos), 14 GBIF (none); 287 of them are fish in the app (28 species); licences 385 CC BY-NC, 17 CC BY, 7 CC0.

Caveats found:
- iNaturalist API v1 ignores `fields`: 50 observations were **4.1 MB**. v2 takes the same filters plus `fields` (≈ 0.66 kB a record).
- iNaturalist obscures threatened species (`taxon_geoprivacy`): the dusky grouper (*Epinephelus marginatus*, 47 records here) never comes
  live, because its coordinates are randomised. The app does not show obscured locations.
- `taxon_name` takes one name (a comma list returns 0): a fish that is several species of one genus asks for the genus.
- GBIF's backbone puts most fish orders directly under Chordata (no class), so `taxonKey=204` (Actinopterygii) returns 0 in this box; the
  Catalogue of Life checklist keys above work. GBIF's occurrence search cannot sort by date (`sort=` is ignored), hence the per-year reads.
- iNaturalist place ids, for reference: 10289 Cyprus (1 380 such records), 235723 Cyprus Coastal Waters (1 464), 140296 Cyprus island (1 518);
  the box gets 1 549 (it also takes offshore and boat records).
- Licences: CC BY-NC records (the large majority, from iNaturalist users) are fine only while the app is free; the Feed shows each record's
  licence, and the credits (map attribution) name iNaturalist and GBIF observers.

## 9. The map's styles: depth chart and nautical marks (`js/chart.js`; round 8, checked 2026-11-03)

- **Depth chart** (offline, no new download): drawn from the EMODnet Bathymetry DTM grid the app already ships (`data/bathy.bin`, 250 m,
  CC BY 4.0) and the OpenStreetMap coastline (`data/coast.js`, ODbL). Contours 5–2000 m are traced in the app (d3.contours). The map credits
  keep naming EMODnet and OpenStreetMap while the chart replaces the imagery. It is a fishing aid, not a navigation chart (the Layers panel says so).
- **Nautical marks** (online overlay, off by default): OpenSeaMap seamark tiles, `https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png`,
  data © OpenSeaMap contributors, ODbL; credited in the map attribution while on. Keyless, served with `Access-Control-Allow-Origin: *`
  (only needed for images anyway); tiles around Limassol at z11–14 returned 200 with buoys, lights and anchorages (0.5–8 KB each).

## Catch reports (`data/reports.js`, Feed › Reports) — 2026-11-04
31 published reports of fish caught in Republic of Cyprus waters (2016–2026), found on public news sites (Cyprus Mail, Sigmalive, Pafos Press,
Reporter, Larnakaonline, AP, FM4/ORF, CSM, Tala Community News), official/EU pages (EU LIFE RELIONMED, University of Plymouth), organised
angling pages (Limassol Marina charity tuna tournaments) and scientific first-record papers (Mediterranean Marine Science, Biodiversity Data
Journal, Scientific Reports, Frontiers in Marine Science). Every source page was opened and checked. Each row holds the facts only (species, date,
count / weight / size / method when stated, the public place the source names, its coordinates estimated on the coast) with a one-sentence summary
written by us in English and Greek, the publisher, the headline and the link. No personal data: no names, handles or photos of anyone, no exact
private spots. Left out: the north of Cyprus, enforcement and illegal-fishing stories, sightings and strandings, pages that could not be verified
(one fishing site's "catch" was labelled on the page as AI-generated). Built by `build-reports.mjs` (validation: dates, https links, inside the
app grid and outside the north, both summaries; duplicates merged, six more removed on manual review).

## 10. The fishing areas in 3D, high resolution (`js/area3d.js`, `scripts/area3d/build-packs.mjs`; round 11, 2026-11-13)
One pack per fishing area (`<id>.bin`, 0.23–0.65 MB, gzip): the area's block (centre ± min(r, 14) km) as a 1025 × 1025 height grid (17–27 m apart)
plus the buildings and harbour works. Built offline from open data only, no keys or accounts; the downloads stay in `scripts/area3d/cache/` (not shipped).
- **Land: Copernicus DEM GLO-30** (30 m, heights above the EGM2008 geoid), the COG tiles `Copernicus_DSM_COG_10_N34|N35_00_E032|E033|E034_00_DEM.tif`
  from the AWS Open Data bucket `https://copernicus-dem-30m.s3.amazonaws.com/` (six tiles, 42 MB, no account). Licence: free of charge for any use
  (the Copernicus DEM licence for GLO-30); required credit, shown in the 3D view (short form, full text on its tooltip):
  "© DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved".
  GLO-30 is a surface model (roofs and trees): where OpenStreetMap has buildings the ground is lowered towards the lowest of the 5 × 5 points
  around (~100 m), so buildings are not counted twice.
- **Seabed: EMODnet Bathymetry DTM** (1/16′, ~115 m; CC BY 4.0), the tiles `scripts/terrain/fetch.mjs` already caches; bilinear from sea cells
  only, smoothed over sea points, never shallower than a 1:30 shore slope in the first ~50 m nor steeper than ~39° (the DTM puts a whole cell's
  depth at a cliff's foot). Land and sea are split by the app's OpenStreetMap coastline (`data/coast.js`, ODbL).
- **Buildings, piers, breakwaters, groynes, quays: OpenStreetMap** via the Overpass API (one query per area with a pause between; the main
  instance, then the overpass.private.coffee mirror when busy), © OpenStreetMap contributors, ODbL 1.0, credited in the view. Heights from
  `height`, else `building:levels` × 3.2 m + 0.8, else a default per building type (house 6.5 m, apartments 12, hotel 15, church 11, …);
  breakwaters 3 m above the sea (14 m wide when drawn as a line), piers 1.6 m, groynes 1.5 m. Footprints simplified (0.5 m), under 12 m² dropped.
  Of the 82 600 footprints in the 7 areas with buildings so far, 1.2 % carry a height and 12.9 % a level count; the other 86 % use the
  defaults. Akrotiri, Zygi, Ayia Napa and Protaras have the fine terrain but no buildings yet (Overpass was overloaded on 2026-11-13; rerun
  `node scripts/area3d/build-packs.mjs --fetch-only --areas akrotiri,zygi,ayianapa,protaras`, then build those four).
- **Imagery** in the view: the map's Esri World Imagery tiles (as before), now up to zoom 18 in a window around the point looked at.
- **Light**: SunCalc (already loaded) for the sun and moon of the chosen hour at the area.
Hosting: the packs are bundled in `data/area3d/` or published in the data repo (`https://giannis242.github.io/psarema-data/area3d/<id>.bin`);
the app tries the bundled copy first, then the repo, and keeps a downloaded pack in the Cache API (`psarema-area3d-v1`) for offline use.

## R13. Area profiles (round 13 phase 1: `data/area-profile.js`, built by `scripts/areas/build.mjs`, read by `js/area-profile.js`)
Everything keyless, downloaded once into `scripts/areas/cache/` (git-ignored). Each fact is counted inside the area's ring (centre + radius of
`data/areas.js`), the occupied north left out. Shown on the area page with the source under each section.
- **Seabed mix to 50 m, coralligenous**: `data/terrain.js` (EMODnet Seabed Habitats, CC BY 4.0: Cyprus survey map CY005001, EUSeaMap 2025,
  coralligenous platforms CY004001). Rock and Posidonia by mapped cover, the rest by the cell's soft-bottom class. Predictive between surveys.
- **Depth bands, distance to 20 m / 50 m, drop-offs**: EMODnet Bathymetry DTM (CC BY 4.0) on the app's 250 m grid. A drop-off = the biggest
  fall within ~500 m of a cell 3 to 60 m deep (at least 20 m), the three best at least 2.5 km apart; named after the nearest OSM cape, bay or place.
- **Wrecks, artificial reefs, river mouths, outfalls**: `data/attractors.js` (© OpenStreetMap contributors, ODbL; reef zones EEA / KDP orders).
- **Caves on the shore, reefs, charted rocks**: OpenStreetMap (Geofabrik Cyprus extract of scripts/area3d, ODbL): `natural=cave_entrance` or a
  feature named "Sea Caves" with a sea cell within 300 m; `natural=reef|shoal`; `seamark:type=rock`. No open data set of underwater caves exists.
- **Fish farms, desalination, waste water**: EMODnet Human Activities WFS `https://ows.emodnet-humanactivities.eu/wfs` (CC BY 4.0), layers
  `emodnet:finfish` (15 Cyprus sites, active ones kept), `emodnet:desalination` (online seawater plants of 5 000 m³/day or more; positions are
  town-level, and the Vasilikos plants are filed under "Nicosia", so they are not placed) and `emodnet:dischargepoints` (EEA Waterbase UWWTD:
  active points "into coastal water", reporting year 2022: Larnaca and Limassol-Moni).
- **Harbours and marinas**: `data/map-places.js` (OpenStreetMap, ODbL). **Protected zones**: `data/protected.js`.
- **Bathing water**: European Environment Agency. Classes of the 2025 season, 123 Cyprus sites:
  `https://water.discomap.eea.europa.eu/arcgis/rest/services/BathingWater/BathingWater_Dyna_WM_2025/MapServer/3/query` (where countryCode='CY').
  Samples (enterococci, E. coli, cfu/100 ml), seasons 2021 to 2024, 4 477 samples: `https://discodata.eea.europa.eu/sql`, table
  `[WISE_BWD].[latest].[timeseries_MonitoringResult]`, one query per season (a query with `>=` or `GROUP BY` gets 403 from the gateway). The 2025
  samples are not in that table yet. EEA standard re-use policy (CC BY 4.0); data and coordinates: Member State authorities.
- **Visibility by month and `PsAreaProfile.clarityAt`**: Copernicus Marine OCEANCOLOUR_MED_BGC_L4_NRT_009_142, monthly KD490 1 km
  (`mdl-arco-geo-045 … cmems_obs-oc_med_bgc-transp_nrt_l4-multi-1km_P1M_202207/geoChunked.zarr`, chunks 8 × 256 × 512, 32 chunks, 54 MB),
  2022-01 to 2026-10, averaged by calendar month over 163 × 89 pixels (34.4–35.3° N, 32.1–34.2° E). Since phase 2 the metres are a
  Secchi-type depth (js/sources.js `secchiM`): Kd(PAR) = 0.0864 + 0.884 KD490 − 0.00137 / KD490 (Morel et al. 2007, eq. 9'), Secchi =
  1.7 / Kd(PAR) (Poole & Atkins 1929): 28–46 m by area and month. The spot card's visibility text uses the same helper; the model's
  `clarityM` (1.3 / KD490, ~1.7 times more) is unchanged. Not validated against any in-water reading.

## R13b. Inshore turbidity from Sentinel-2 (round 13 phase 2: `data/area-clarity.js`, built by `scripts/areas/s2-clarity.mjs`)
- **Data**: Copernicus Sentinel-2 L2A (free and open Copernicus licence; "contains modified Copernicus Sentinel data 2023-2026") from the
  Microsoft Planetary Computer STAC with its anonymous read token (no account; the COG reader of scripts/seabed-s2/lib.mjs, own cache
  `scripts/areas/cache/s2`, 0.9 GB). MGRS tiles 36SVD and 36SWD, 345 candidate scenes with cloud < 10 %, per tile and season the 8 with the
  least glint over deep water: 64 scenes. Bands B4 and B8 on the 40 m overview, SCL on its 40 m overview.
- **Grid**: sea cells of the app grid within 2.5 km of the Republic's shore, split 4 × 4 (~57 × 69 m): 12 707 cells, 203 312 pixels (water joined to the open sea only: the Larnaca salt lakes are out), 4 seasons,
  one byte each (FNU × 20). 1.10 MB (0.19 MB gzip), loaded only by `PsAreaProfile.load(true)`.
- **Method**: water reflectance at 665 nm = B4 − B8; turbidity = 228.1 r / (1 − r / 0.1641) FNU (Dogliotti et al. 2015, red band; the
  coefficients as in ACOLITE's defaults); seasonal median of the valid scenes (≥ 3) minus the tile's deep-water median (0 to 0.6 FNU);
  only water ≥ 10 m deep is measured (75 % of the pixels), shallower pixels take the nearest measured one within ~600 m (91 % with a value).
  Visibility = `secchiTurbid`: 0.067 1/m of Kd(PAR) per FNU (Devlin et al. 2008 slope on suspended matter, UK coastal water, taking
  1 FNU ≈ 1 g/m³: quoted from memory, not re-read, and not measured in Cyprus). Values under 0.5 FNU count as open water (noise floor).
- **Checks** (`node scripts/areas/check-clarity.mjs` → scripts/areas/validation.json): the reader returns the stored bytes; turbidity falls
  with distance from shore (first 500 m 0.27 / 0.28 / 0.24 / 0.05 FNU winter to autumn, beyond 1.5 km ≤ 0.08); within 1 km of the big river
  mouths 0.19 / 0.14 / 0.21 / 0.05 against 0.15 / 0.13 / 0.16 / 0.04 for the whole first kilometre; rank correlation with the Copernicus
  KD490 climatology on the same 1 km pixels −0.09 / 0.00 / 0.33 / 0.24 (weak); with the EEA sites' enterococci −0.13 (none: bacteria are not
  sediment). With a 7 m depth floor the first 500 m read twice as turbid: bottom glow, hence the 10 m floor.
- **Not settled**: the west coast (tile 36SVD: Pomos to Paphos) reads 16–39 % of its first kilometre "murkier" in spring and summer, the south
  and east 0–3 %. That can be surf on the exposed rocky shore or bottom seen through water the 100 m DTM calls ≥ 10 m, rather than sediment;
  and tile 36SWD had 0.44–0.60 FNU subtracted in summer and autumn, which hides anything smaller there. No in-water turbidity or Secchi
  reading was available to decide. Clear days only: storm run-off and the days after rough seas are not in it.
