'use strict';
Object.assign(I18N.en, {
  ac_title: 'Create account', ac_edit: 'Edit profile', ac_hello: 'Create your angler profile',
  ac_helloSub: 'Your catches, species and personal bests in one profile, with your name and photo.',
  ac_local: 'Your account is stored on this phone. No email, no password, nothing uploaded.', ac_cloud: 'You can link it to a cloud account later and keep everything.',
  ac_b1: 'A profile with your photo, home area and how you fish', ac_b2: 'Your catches, species and personal bests counted for you', ac_b3: 'Your favourite fish and home area, a tap away', ac_prof: 'Profile',
  ac_start: 'Get started', ac_later: 'Not now', ac_next: 'Continue', ac_back: 'Back', ac_skip: 'Skip', ac_save: 'Save', ac_cancel: 'Cancel', ac_stepOf: (a, b) => `Step ${a} of ${b}`,
  ac_nameQ: 'What should we call you?', ac_nameSub: 'Your name and username show on your profile and on catches you share.',
  ac_name: 'Display name', ac_user: 'Username', ac_userHint: '3–20 characters: letters, digits, dot and underscore',
  ac_errName: 'Type a name (up to 40 characters).', ac_errUser: 'Use 3–20 letters, digits, . or _ (no spaces).',
  ac_photoQ: 'Add a profile photo', ac_photoSub: 'A square photo for your profile. It stays on this phone.', ac_cam: 'Take a photo', ac_gal: 'Choose from gallery', ac_rmPhoto: 'Remove photo', ac_photoErr: 'That picture could not be read.',
  ac_areaQ: 'Where do you fish most?', ac_areaSub: 'Your home area. You can change it any time.', ac_area: 'Home area',
  ac_styleQ: 'How do you fish?', ac_styleSub: 'Pick all that apply.', ac_style: 'How you fish',
  ac_fishQ: 'Your favourite fish', ac_fishSub: 'Pick the fish you go for most.', ac_fish: 'Favourite fish',
  ac_doneT: n => `Welcome aboard, ${n}!`, ac_doneSub: 'Your profile is ready. Log a catch and it shows up on your profile.', ac_toProfile: 'Go to my profile', ac_logCatch: 'Log a catch',
  ac_photo: 'Profile photo', ac_del: 'Delete account', ac_delSub: 'Removes your profile and its photo from this phone.',
  ac_delQ: 'Delete your account?', ac_delTxt: 'Your profile and photo are removed from this phone. Your catches stay unless you tick the box.',
  ac_delCatches: 'Also delete my catches (cannot be undone)', ac_delYes: 'Delete account', ac_deleted: 'Account deleted', ac_saved: 'Profile saved',
  ac_offerT: 'Create your angler profile', ac_offerSub: 'Stored on this phone · takes a minute', ac_create: 'Create',
});
Object.assign(I18N.el, {
  ac_title: 'Δημιουργία λογαριασμού', ac_edit: 'Επεξεργασία προφίλ', ac_hello: 'Φτιάξτε το προφίλ ψαρά σας',
  ac_helloSub: 'Οι ψαριές, τα είδη και τα ρεκόρ σας σε ένα προφίλ, με το όνομα και τη φωτογραφία σας.',
  ac_local: 'Ο λογαριασμός σας αποθηκεύεται σε αυτό το τηλέφωνο. Χωρίς email, χωρίς κωδικό, τίποτα δεν ανεβαίνει.', ac_cloud: 'Αργότερα μπορείτε να τον συνδέσετε με λογαριασμό στο cloud και να τα κρατήσετε όλα.',
  ac_b1: 'Ένα προφίλ με τη φωτογραφία σας, την περιοχή σας και πώς ψαρεύετε', ac_b2: 'Οι ψαριές, τα είδη και τα ρεκόρ σας μετρημένα για εσάς', ac_b3: 'Τα αγαπημένα σας ψάρια και η περιοχή σας, με ένα άγγιγμα', ac_prof: 'Προφίλ',
  ac_start: 'Ξεκινήστε', ac_later: 'Όχι τώρα', ac_next: 'Συνέχεια', ac_back: 'Πίσω', ac_skip: 'Παράλειψη', ac_save: 'Αποθήκευση', ac_cancel: 'Άκυρο', ac_stepOf: (a, b) => `Βήμα ${a} από ${b}`,
  ac_nameQ: 'Πώς να σας λέμε;', ac_nameSub: 'Το όνομα και το όνομα χρήστη φαίνονται στο προφίλ σας και στις ψαριές που μοιράζεστε.',
  ac_name: 'Όνομα', ac_user: 'Όνομα χρήστη', ac_userHint: '3–20 χαρακτήρες: λατινικά γράμματα, ψηφία, τελεία και κάτω παύλα',
  ac_errName: 'Γράψτε ένα όνομα (έως 40 χαρακτήρες).', ac_errUser: 'Χρησιμοποιήστε 3–20 λατινικά γράμματα, ψηφία, . ή _ (χωρίς κενά).',
  ac_photoQ: 'Προσθέστε φωτογραφία προφίλ', ac_photoSub: 'Μια τετράγωνη φωτογραφία για το προφίλ σας. Μένει σε αυτό το τηλέφωνο.', ac_cam: 'Τραβήξτε φωτογραφία', ac_gal: 'Επιλογή από τη συλλογή', ac_rmPhoto: 'Αφαίρεση φωτογραφίας', ac_photoErr: 'Η εικόνα δεν διαβάστηκε.',
  ac_areaQ: 'Πού ψαρεύετε συνήθως;', ac_areaSub: 'Η περιοχή σας. Την αλλάζετε όποτε θέλετε.', ac_area: 'Περιοχή',
  ac_styleQ: 'Πώς ψαρεύετε;', ac_styleSub: 'Επιλέξτε όσα ισχύουν.', ac_style: 'Πώς ψαρεύετε',
  ac_fishQ: 'Τα αγαπημένα σας ψάρια', ac_fishSub: 'Επιλέξτε τα ψάρια που ψαρεύετε πιο συχνά.', ac_fish: 'Αγαπημένα ψάρια',
  ac_doneT: n => `Καλώς ήρθατε, ${n}!`, ac_doneSub: 'Το προφίλ σας είναι έτοιμο. Καταγράψτε μια ψαριά και θα φανεί στο προφίλ σας.', ac_toProfile: 'Στο προφίλ μου', ac_logCatch: 'Καταγραφή ψαριάς',
  ac_photo: 'Φωτογραφία προφίλ', ac_del: 'Διαγραφή λογαριασμού', ac_delSub: 'Αφαιρεί το προφίλ και τη φωτογραφία του από αυτό το τηλέφωνο.',
  ac_delQ: 'Διαγραφή του λογαριασμού σας;', ac_delTxt: 'Το προφίλ και η φωτογραφία σας αφαιρούνται από αυτό το τηλέφωνο. Οι ψαριές σας μένουν, εκτός αν τσεκάρετε το κουτί.',
  ac_delCatches: 'Διαγραφή και των ψαριών μου (δεν αναιρείται)', ac_delYes: 'Διαγραφή λογαριασμού', ac_deleted: 'Ο λογαριασμός διαγράφηκε', ac_saved: 'Το προφίλ αποθηκεύτηκε',
  ac_offerT: 'Φτιάξτε το προφίλ ψαρά σας', ac_offerSub: 'Αποθηκεύεται σε αυτό το τηλέφωνο · ένα λεπτό', ac_create: 'Δημιουργία',
});
// Psarema: the angler account (css/account.css). No server: a local profile kept on this phone (the profile in localStorage, its square
// photo as a small JPEG Blob in IndexedDB). A step-by-step "Create account" page (PsNav 'account'), Edit profile (the same parts on one page,
// with Delete account), and a one-time, dismissible offer after the first-launch tour.
// window.PsAccount = { get() → profile | null, open(step?), edit(askDelete?), remove(alsoCatches?) }; document fires 'ps:account' on any change.
// profile: { id, name, username, photo (getter: an object URL, or undefined), area, styles[], fish[], createdAt }
const PsAccount = window.PsAccount = (() => {
  const KEY = 'psarema-account-v1', OFFER = 'psarema-account-offer-v1', DB = 'psarema-account', ST = 'kv', STEPS = ['welcome', 'name', 'photo', 'area', 'styles', 'fish', 'done'];
  const MODES = ['boat', 'shore', 'spear'], AREAS = () => window.PSAREMA_AREAS || [];
  const USER_RE = /^[A-Za-z0-9._]{3,20}$/;
  let prof = null, photoUrl = '', el = null, d = null; // d: the draft being edited
  try { prof = JSON.parse(localStorage.getItem(KEY)) || null; } catch {}

  /* ---------- Storage ---------- */
  let dbp = null;
  const db = () => dbp ||= new Promise((ok, no) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => ok(r.result); r.onerror = () => { dbp = null; no(r.error); };
  });
  const run = (mode, f) => db().then(x => new Promise((ok, no) => { const t = x.transaction(ST, mode), q = f(t.objectStore(ST)); t.oncomplete = () => ok(q?.result); t.onerror = t.onabort = () => no(t.error); }));
  const fire = () => document.dispatchEvent(new CustomEvent('ps:account', { detail: { profile: get() } }));
  const setUrl = blob => { if (photoUrl) URL.revokeObjectURL(photoUrl); photoUrl = blob ? URL.createObjectURL(blob) : ''; };
  if (prof?.hasPhoto) run('readonly', s => s.get('photo')).then(b => { if (b && prof) { setUrl(b); fire(); } }, e => console.warn('Profile photo unavailable:', e));

  function get() {
    if (!prof) return null;
    const { hasPhoto, ...p } = prof;
    return Object.defineProperty({ ...p, styles: [...p.styles], fish: [...p.fish] }, 'photo', { get: () => photoUrl || undefined, enumerable: true });
  }
  async function save(p, photo) { // photo: undefined = keep, null = none, a Blob = this one
    if (photo !== undefined) {
      await run('readwrite', s => photo ? s.put(photo, 'photo') : s.delete('photo')).catch(e => console.warn('Profile photo not saved:', e));
      setUrl(photo); p.hasPhoto = !!photo;
    }
    prof = p;
    try { localStorage.setItem(KEY, JSON.stringify(p)); } catch {}
    fire();
  }
  async function remove(alsoCatches = false) {
    prof = null; setUrl(null);
    try { localStorage.removeItem(KEY); } catch {}
    await run('readwrite', s => s.clear()).catch(() => {});
    fire();
    if (alsoCatches) { // ponytail: PsCatch has no clear(); empty its store directly and reload so it reads the empty log
      await new Promise(ok => { const r = indexedDB.open('psarema-catches'); r.onsuccess = () => { const x = r.result;
        if (!x.objectStoreNames.contains('catches')) { x.close(); return ok(); }
        const t = x.transaction('catches', 'readwrite'); t.objectStore('catches').clear(); t.oncomplete = t.onerror = () => { x.close(); ok(); }; }; r.onerror = ok; });
      location.reload();
    }
  }

  /* ---------- Helpers ---------- */
  const GR = { α: 'a', β: 'v', γ: 'g', δ: 'd', ε: 'e', ζ: 'z', η: 'i', θ: 'th', ι: 'i', κ: 'k', λ: 'l', μ: 'm', ν: 'n', ξ: 'x', ο: 'o', π: 'p', ρ: 'r', σ: 's', ς: 's', τ: 't', υ: 'y', φ: 'f', χ: 'ch', ψ: 'ps', ω: 'o' };
  const suggest = name => String(name).normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/ου/g, 'ou').replace(/[α-ω]/g, c => GR[c] || '')
    .trim().replace(/\s+/g, '.').replace(/[^a-z0-9._]/g, '').slice(0, 20);
  const initials = n => String(n || '').trim().split(/\s+/).slice(0, 2).map(w => [...w][0] || '').join('').toUpperCase();
  const areaName = id => { const a = AREAS().find(x => x.id === id); return a ? (state.lang === 'el' ? a.el : a.en) : ''; };
  const avatar = (url, name, cls = '') => `<span class="ui-av ac-av ${cls}">${url ? `<img src="${esc(url)}" alt="">` : initials(name) ? `<b>${esc(initials(name))}</b>` : ic('user')}</span>`;
  async function square(file) { // the middle square, 320 px, as JPEG
    const b = await createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => createImageBitmap(file));
    try {
      const s = Math.min(b.width, b.height), c = Object.assign(document.createElement('canvas'), { width: 320, height: 320 });
      c.getContext('2d').drawImage(b, (b.width - s) / 2, (b.height - s) / 2, s, s, 0, 0, 320, 320);
      return await new Promise((ok, no) => c.toBlob(x => x ? ok(x) : no(new Error('no JPEG')), 'image/jpeg', .85));
    } finally { b.close?.(); }
  }
  const checkName = () => { const n = d.name.trim(); return n.length >= 1 && n.length <= 40; };
  const checkUser = () => USER_RE.test(d.username);

  /* ---------- Parts (one per step; Edit profile shows them all) ---------- */
  const tile = (attr, on, inner, cls = '') => `<button type="button" class="ac-tile ${cls}" ${attr} aria-pressed="${on}">${inner}<span class="ac-tick">${ic('check')}</span></button>`;
  const part = {
    name: () => `<label class="ui-field"><span>${esc(tr('ac_name'))}</span><input class="ui-input" data-ac-in="name" maxlength="40" autocomplete="name" value="${esc(d.name)}">` +
      `<small class="ac-err" data-ac-err="name"${d.err.name ? '' : ' hidden'}>${esc(tr('ac_errName'))}</small></label>` +
      `<label class="ui-field"><span>${esc(tr('ac_user'))}</span><span class="ac-at"><i>@</i><input class="ui-input" data-ac-in="username" maxlength="20" autocomplete="username" autocapitalize="none" spellcheck="false" value="${esc(d.username)}"></span>` +
      `<small data-ac-err="username" class="${d.err.username ? 'ac-err' : ''}">${esc(tr(d.err.username ? 'ac_errUser' : 'ac_userHint'))}</small></label>`,
    photo: () => `<div class="ac-photo">${avatar(d.purl, d.name, 'ac-big')}<div class="ac-photo-acts">` +
      `<label class="btn lg block">${ic('camera')}${esc(tr('ac_cam'))}<input type="file" accept="image/*" capture="user" data-ac-photo hidden></label>` +
      `<label class="btn lg block">${ic('image')}${esc(tr('ac_gal'))}<input type="file" accept="image/*" data-ac-photo hidden></label>` +
      (d.purl ? `<button type="button" class="btn ghost block" data-ac="nophoto">${ic('trash')}${esc(tr('ac_rmPhoto'))}</button>` : '') + '</div></div>',
    area: () => d.mode === 'edit' // one compact field on the edit page; a list to tap through in the flow
      ? `<select class="ui-input" data-ac-in="area" aria-label="${esc(tr('ac_area'))}"><option value="">–</option>${AREAS().map(a => `<option value="${esc(a.id)}"${d.area === a.id ? ' selected' : ''}>${esc(state.lang === 'el' ? a.el : a.en)}</option>`).join('')}</select>`
      : `<div class="ui-list ac-areas" role="radiogroup">${AREAS().map(a => `<button type="button" class="ui-row ac-area" role="radio" data-ac-area="${esc(a.id)}" aria-checked="${d.area === a.id}">` +
      `${ic('pin')}<span class="ui-row-main"><b>${esc(state.lang === 'el' ? a.el : a.en)}</b></span><span class="ac-radio">${ic('check')}</span></button>`).join('')}</div>`,
    styles: () => `<div class="ac-styles">${MODES.map(m => tile(`data-ac-style="${m}"`, d.styles.includes(m), `${ic(m)}<b>${esc(tr(m))}</b>`, 'ac-style')).join('')}</div>`,
    fish: () => `<div class="ac-fish">${SPECIES.map(s => tile(`data-ac-fish="${esc(s.id)}"`, d.fish.includes(s.id),
      `<span class="ac-cut">${PsPanel.fish(s) || ic('fish')}</span><b>${esc(fishName(s))}</b>`, 'ac-fishtile')).join('')}</div>`,
  };
  const Q = { name: ['ac_nameQ', 'ac_nameSub'], photo: ['ac_photoQ', 'ac_photoSub'], area: ['ac_areaQ', 'ac_areaSub'], styles: ['ac_styleQ', 'ac_styleSub'], fish: ['ac_fishQ', 'ac_fishSub'] };
  const LBL = { name: 'ac_prof', photo: 'ac_photo', area: 'ac_area', styles: 'ac_style', fish: 'ac_fish' };

  function draw() {
    if (!el || !d) return;
    if (d.mode === 'edit') return drawEdit();
    const st = STEPS[d.step], k = d.step, n = STEPS.length - 2; // steps 1..5 count
    let main, foot;
    if (st === 'welcome') {
      main = `<div class="ac-hero"><span class="ac-badge">${ic('user')}<i>${ic('fish')}</i></span><h2>${esc(tr('ac_hello'))}</h2><p>${esc(tr('ac_helloSub'))}</p></div>` +
        `<ul class="ac-bul">${['ac_b1', 'ac_b2', 'ac_b3'].map((b, i) => `<li>${ic(['user', 'trophy', 'fish'][i])}<span>${esc(tr(b))}</span></li>`).join('')}</ul>` +
        `<div class="ac-note">${ic('shield')}<p><b>${esc(tr('ac_local'))}</b> ${esc(tr('ac_cloud'))}</p></div>`;
      foot = `<button type="button" class="btn lg block primary" data-ac="next">${esc(tr('ac_start'))}</button><button type="button" class="btn ghost block" data-ac="close">${esc(tr('ac_later'))}</button>`;
    } else if (st === 'done') {
      main = `<div class="ac-hero ac-done">${avatar(photoUrl, prof?.name, 'ac-big')}<h2>${esc(tr('ac_doneT', prof?.name || ''))}</h2>` +
        `<p class="ac-handle">@${esc(prof?.username || '')}${prof?.area ? ` · ${esc(areaName(prof.area))}` : ''}</p><p>${esc(tr('ac_doneSub'))}</p></div>`;
      foot = `<button type="button" class="btn lg block primary" data-ac="profile">${esc(tr('ac_toProfile'))}</button><button type="button" class="btn lg block" data-ac="log">${ic('plus')}${esc(tr('ac_logCatch'))}</button>`;
    } else {
      main = `<div class="ac-prog" aria-hidden="true">${Array.from({ length: n }, (_, i) => `<i${i < k ? ' class="on"' : ''}></i>`).join('')}</div>` +
        `<p class="lbl ac-of">${esc(tr('ac_stepOf', k, n))}</p><h2 class="ac-q">${esc(tr(Q[st][0]))}</h2><p class="ac-sub">${esc(tr(Q[st][1]))}</p><div class="ac-part">${part[st]()}</div>`;
      foot = `<div class="ac-row"><button type="button" class="btn lg" data-ac="prev">${ic('chevron-left')}${esc(tr('ac_back'))}</button>` +
        (st !== 'name' ? `<button type="button" class="btn lg ghost" data-ac="skip">${esc(tr('ac_skip'))}</button>` : '') +
        `<button type="button" class="btn lg primary ac-go" data-ac="next">${esc(tr('ac_next'))}${ic('chevron-right')}</button></div>`;
    }
    el.innerHTML = `<div class="ac-main" data-ac-step="${st}">${main}</div><div class="ac-foot">${foot}</div>`;
    el.scrollTop = 0;
  }
  function drawEdit() {
    const y = el.scrollTop;
    el.innerHTML = `<div class="ac-main ac-edit">${['photo', 'name', 'area', 'styles', 'fish'].map(k => `<div class="ui-sec"><h3>${esc(tr(LBL[k]))}</h3></div><div class="ac-part">${part[k]()}</div>`).join('')}` +
      `<div class="ui-sec"><h3>${esc(tr('ac_del'))}</h3></div>` + (d.confirm
        ? `<div class="ui-card ac-confirm" role="alertdialog" aria-labelledby="ac-del-q"><b id="ac-del-q">${esc(tr('ac_delQ'))}</b><p>${esc(tr('ac_delTxt'))}</p>` +
          `<label class="ac-check"><input type="checkbox" data-ac-in="alsoCatches"${d.alsoCatches ? ' checked' : ''}><span>${esc(tr('ac_delCatches'))}</span></label>` +
          `<div class="ac-row"><button type="button" class="btn lg" data-ac="nodel">${esc(tr('ac_cancel'))}</button><button type="button" class="btn lg danger" data-ac="del">${ic('trash')}${esc(tr('ac_delYes'))}</button></div></div>`
        : `<div class="ui-list"><button type="button" class="ui-row ac-delrow" data-ac="askdel">${ic('trash')}<span class="ui-row-main"><b>${esc(tr('ac_del'))}</b><small>${esc(tr('ac_delSub'))}</small></span></button></div>`) +
      `</div><div class="ac-foot"><div class="ac-row"><button type="button" class="btn lg" data-ac="close">${esc(tr('ac_cancel'))}</button><button type="button" class="btn lg primary ac-go" data-ac="save">${ic('check')}${esc(tr('ac_save'))}</button></div></div>`;
    el.scrollTop = y;
  }

  /* ---------- Flow ---------- */
  function fresh(mode, step = 0) {
    const p = prof || {};
    if (d?.purl && d.photo) URL.revokeObjectURL(d.purl);
    d = { mode, step, name: p.name || '', username: p.username || '', area: p.area || '', styles: [...(p.styles || (state.mode ? [state.mode] : []))], fish: [...(p.fish || [])],
      photo: undefined, purl: photoUrl, uTouched: !!p.username, err: {}, confirm: false, alsoCatches: false };
  }
  function open(step) {
    const i = typeof step === 'number' ? step : Math.max(0, STEPS.indexOf(step));
    fresh('create', i); PsNav.open('account', 'create');
  }
  function edit(askDelete) {
    if (!prof) return open();
    fresh('edit'); d.confirm = !!askDelete; PsNav.open('account', 'edit');
    if (askDelete) requestAnimationFrame(() => el?.querySelector('.ac-confirm')?.scrollIntoView({ block: 'center' }));
  }
  const valid = () => { d.err = { name: !checkName(), username: !checkUser() }; return !d.err.name && !d.err.username; };
  const profileOf = () => ({ id: prof?.id || (crypto.randomUUID?.() || 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8)),
    name: d.name.trim(), username: d.username, area: d.area, styles: d.styles, fish: d.fish, createdAt: prof?.createdAt || Date.now(), hasPhoto: prof?.hasPhoto || false });
  async function next(skip) {
    const st = STEPS[d.step];
    if (st === 'name' && !valid()) { draw(); el.querySelector(d.err.name ? '[data-ac-in=name]' : '[data-ac-in=username]')?.focus(); return; }
    if (skip && st === 'photo' && d.photo) { d.photo = null; d.purl = ''; }
    if (skip && st === 'area') d.area = '';
    if (skip && st === 'styles') d.styles = [];
    if (skip && st === 'fish') d.fish = [];
    if (st === 'fish') await save(profileOf(), d.photo); // the last question: the account exists from here
    d.step++; draw();
  }
  async function click(e) {
    const t = e.target.closest('[data-ac], [data-ac-area], [data-ac-style], [data-ac-fish]'); if (!t || !d) return;
    const a = t.dataset;
    if (a.acArea != null) { d.area = d.area === a.acArea ? '' : a.acArea; for (const b of el.querySelectorAll('[data-ac-area]')) b.setAttribute('aria-checked', b.dataset.acArea === d.area); return; }
    const flip = (list, v) => { const i = list.indexOf(v); i < 0 ? list.push(v) : list.splice(i, 1); t.setAttribute('aria-pressed', i < 0); };
    if (a.acStyle) return flip(d.styles, a.acStyle);
    if (a.acFish) return flip(d.fish, a.acFish);
    switch (a.ac) {
      case 'next': return next(false);
      case 'skip': return next(true);
      case 'prev': d.step = Math.max(0, d.step - 1); return draw();
      case 'close': return PsNav.back();
      case 'profile': return PsNav.open('me');
      case 'log': PsNav.open('me'); return window.PsCatch?.log?.(-1);
      case 'nophoto': if (d.photo) URL.revokeObjectURL(d.purl); d.photo = null; d.purl = ''; return draw();
      case 'askdel': d.confirm = true; draw(); return el.querySelector('.ac-confirm')?.scrollIntoView({ block: 'center' });
      case 'nodel': d.confirm = false; return draw();
      case 'del': { const also = d.alsoCatches; d = null; PsNav.open('me'); toast(tr('ac_deleted')); return remove(also); }
      case 'save': if (!valid()) { drawEdit(); return el.querySelector('.ac-err:not([hidden])')?.closest('.ui-field')?.scrollIntoView({ block: 'center' }); }
        await save(profileOf(), d.photo); toast(tr('ac_saved')); return PsNav.back();
    }
  }
  function input(e) {
    const t = e.target, k = t.dataset.acIn; if (!k || !d) return;
    if (k === 'alsoCatches') { d.alsoCatches = t.checked; return; }
    d[k] = t.value;
    if (k === 'username') { d.uTouched = !!t.value; d.err.username = false; }
    if (k === 'name') {
      d.err.name = false;
      if (!d.uTouched) { d.username = suggest(t.value); const u = el.querySelector('[data-ac-in=username]'); if (u) u.value = d.username; }
    }
    const er = el.querySelector(`[data-ac-err="${k}"]`); // the hint comes back once it is being fixed
    if (er) { if (k === 'name') er.hidden = true; else { er.className = ''; er.textContent = tr('ac_userHint'); } }
  }
  async function change(e) {
    const t = e.target; if (!t.matches('[data-ac-photo]') || !t.files?.[0] || !d) return;
    try {
      const b = await square(t.files[0]);
      if (d.photo) URL.revokeObjectURL(d.purl);
      d.photo = b; d.purl = URL.createObjectURL(b); draw();
    } catch (err) { console.warn(err); toast(tr('ac_photoErr')); }
    t.value = '';
  }
  PsNav.add('account', { title: a => tr(a === 'edit' ? 'ac_edit' : 'ac_title'), icon: 'user', big: false,
    show(body, arg) {
      if (!el) { el = body; el.classList.add('ac-body'); el.addEventListener('click', click); el.addEventListener('input', input); el.addEventListener('change', change); }
      if (!d || d.mode !== (arg === 'edit' ? 'edit' : 'create')) fresh(arg === 'edit' && prof ? 'edit' : 'create');
      draw();
    },
    hide() { if (d?.mode === 'create' && STEPS[d.step] === 'done') d = null; } });

  /* ---------- The one-time offer, after the first-launch tour ---------- */
  function offer() {
    if (prof || localStorage.getItem(OFFER)) return;
    try { localStorage.setItem(OFFER, '1'); } catch {}
    const o = Object.assign(document.createElement('div'), { className: 'ac-offer', role: 'dialog' });
    o.setAttribute('aria-labelledby', 'ac-offer-t');
    o.innerHTML = `<span class="ui-av">${ic('user')}</span><div class="ac-offer-txt"><b id="ac-offer-t">${esc(tr('ac_offerT'))}</b><small>${esc(tr('ac_offerSub'))}</small></div>` +
      `<button type="button" class="btn primary" data-o="go">${esc(tr('ac_create'))}</button><button type="button" class="icon-btn" data-o="x" aria-label="${esc(tr('ac_later'))}">${ic('close')}</button>`;
    const bye = () => { o.classList.add('out'); setTimeout(() => o.remove(), 200); document.removeEventListener('ps:page', bye); };
    o.addEventListener('click', e => { const b = e.target.closest('[data-o]'); if (!b) return; bye(); if (b.dataset.o === 'go') open(); });
    document.addEventListener('ps:page', bye); // any move elsewhere puts it away: it never blocks the app
    setTimeout(bye, 15000);
    document.body.append(o);
  }
  try {
    const g = $('#guide');
    if (g && !prof && !localStorage.getItem(GUIDE_SEEN) && !localStorage.getItem(OFFER)) { // a first launch: js/app.js shows the tour right after
      let seen = false;
      const mo = new MutationObserver(() => { if (!g.hidden) seen = true; else if (seen) { mo.disconnect(); setTimeout(offer, 700); } });
      mo.observe(g, { attributes: true, attributeFilter: ['hidden'] });
    }
  } catch {}

  return { get, open, edit, remove };
})();
