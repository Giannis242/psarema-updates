'use strict';
Object.assign(I18N.en, {
  mp_pbs: 'Personal bests', mp_tCatches: 'Catches', mp_tSpecies: 'Species', mp_tStats: 'Stats', mp_inviteT: 'Create your angler profile',
  mp_inviteSub: 'Your name, photo and catches in one profile. Stored on this phone, no email or password.', mp_create: 'Create account', mp_edit: 'Edit profile',
  mp_noSpecies: 'The species you catch are listed here, with your best for each.', mp_n: n => n === 1 ? '1 catch' : `${n} catches`, mp_best: 'Best', mp_noCatch: 'No catches yet', mp_emptySub: 'Log one with + and your catches, species and personal bests show up here.', mp_rate: 'Trips with fish',
  mp_logbook: 'Open the logbook', mp_account: 'Account', mp_delSub: 'Profile and photo; catches can stay', mp_joined: d => `Since ${d}`,
  mp_local: 'Your profile, catches, saved places and settings stay on this device. Nothing of yours is uploaded.',
});
Object.assign(I18N.el, {
  mp_pbs: 'Ρεκόρ', mp_tCatches: 'Ψαριές', mp_tSpecies: 'Είδη', mp_tStats: 'Στατιστικά', mp_inviteT: 'Φτιάξτε το προφίλ ψαρά σας',
  mp_inviteSub: 'Το όνομα, η φωτογραφία και οι ψαριές σας σε ένα προφίλ. Αποθηκεύεται σε αυτό το τηλέφωνο, χωρίς email ή κωδικό.', mp_create: 'Δημιουργία λογαριασμού', mp_edit: 'Επεξεργασία προφίλ',
  mp_noSpecies: 'Εδώ φαίνονται τα είδη που πιάνετε, με το ρεκόρ σας για το καθένα.', mp_n: n => n === 1 ? '1 ψαριά' : `${n} ψαριές`, mp_best: 'Ρεκόρ', mp_noCatch: 'Καμία ψαριά ακόμη', mp_emptySub: 'Καταγράψτε μία με το + και εδώ θα δείτε τις ψαριές, τα είδη και τα ρεκόρ σας.', mp_rate: 'Έξοδοι με ψάρι',
  mp_logbook: 'Άνοιγμα ημερολογίου', mp_account: 'Λογαριασμός', mp_delSub: 'Προφίλ και φωτογραφία· οι ψαριές μπορούν να μείνουν', mp_joined: d => `Από ${d}`,
  mp_local: 'Το προφίλ, οι ψαριές, τα αποθηκευμένα σημεία και οι ρυθμίσεις σας μένουν σε αυτή τη συσκευή. Τίποτα δικό σας δεν ανεβαίνει πουθενά.',
});
// Psarema: the Me page (css/me.css; a tab of js/nav.js), a profile like a fishing app's: the header (photo, name, @username, home area, how you
// fish; js/account.js PsAccount, or an invite to create the account), the numbers (catches · species · personal bests, PsCatch.stats()), three
// tabs (Catches: a photo grid · Species: what you caught, with counts and bests · Stats: by month and personal bests), then Tools, Settings
// (language, how you usually fish, the daily brief where the app can notify), Account and About as grouped lists (each tool opens as from the ⋯
// menu: the same data-* hooks). Drawn on each open, and again when the catches or the account change while it shows.
(() => {
  let el = null, tab = 'catches';
  const shows = () => el && PsNav.current() === 'me';
  const go = ic('chevron-right', 'ui-chev');
  const row = (attrs, icon, label, side = '') => `<button class="ui-row me-row" ${attrs}>${ic(icon)}<span class="ui-row-main"><b>${esc(label)}</b></span>${side}${go}</button>`;
  const stats = () => { const s = window.PsCatch?.stats?.(); return s && typeof s.n === 'number' ? s : null; }; // the logbook's summary, when there
  const caught = () => (window.PsCatch?.entries?.() || []).filter(e => e.n > 0);
  const size = b => [b.kg && `${nf(b.kg, b.kg < 10 && Math.round(b.kg * 100) % 10 ? 2 : 1)} kg`, b.cm && `${Math.round(b.cm)} cm`].filter(Boolean).join(' · ');
  const brief = () => { try { return { brief: false, time: '07:00', ...JSON.parse(localStorage.getItem('psarema-notif-v1')) }; } catch { return { brief: false, time: '07:00' }; } }; // js/native.js keeps it
  const cut = sp => { const f = byId(sp); return f && PsPanel.fish(f) || ic('fish'); };
  const thumbs = new Map(); // catch id → [Blob, object URL]: made once per thumbnail
  const thumbUrl = e => { const b = e.thumb || e.photo; if (!b) return ''; let t = thumbs.get(e.id); if (t?.[0] !== b) { if (t) URL.revokeObjectURL(t[1]); thumbs.set(e.id, t = [b, URL.createObjectURL(b)]); } return t[1]; };
  const initials = n => String(n || '').trim().split(/\s+/).slice(0, 2).map(w => [...w][0] || '').join('').toUpperCase();
  const areaName = id => { const a = (window.PSAREMA_AREAS || []).find(x => x.id === id); return a ? (state.lang === 'el' ? a.el : a.en) : ''; };

  function head(p) {
    if (!p) return `<div class="ui-card me-invite"><span class="ui-av lg">${ic('user')}</span><div class="me-inv-txt"><b>${esc(tr('mp_inviteT'))}</b><p>${esc(tr('mp_inviteSub'))}</p></div>` +
      `<button class="btn primary block lg" data-me-acc="create">${ic('plus')}${esc(tr('mp_create'))}</button></div>`;
    const fav = p.fish.map(byId).filter(Boolean);
    return `<div class="me-prof"><span class="ui-av lg me-av">${p.photo ? `<img src="${esc(p.photo)}" alt="">` : `<b>${esc(initials(p.name))}</b>`}</span>` +
      `<div class="me-who"><h3>${esc(p.name)}</h3><p class="me-handle">@${esc(p.username)}</p>` +
      `<p class="me-meta">${p.area ? `<span>${ic('pin')}${esc(areaName(p.area))}</span>` : ''}${p.styles.map(m => `<span>${ic(m)}${esc(tr(m))}</span>`).join('')}</p></div></div>` +
      (fav.length ? `<div class="ui-chips me-fav">${fav.map(f => `<button class="ui-chip" data-sp-page="${esc(f.id)}"><span class="me-favcut">${PsPanel.fish(f) || ic('fish')}</span>${esc(fishName(f))}</button>`).join('')}</div>` : '') +
      '';
  }
  function numbers(s) {
    const n = (v, label, t) => `<button class="ui-stat me-stat" data-me-tab="${t}" aria-label="${esc(`${v} ${label}`)}"><b>${v}</b><span>${esc(label)}</span></button>`;
    return `<div class="ui-card ui-grid3 me-stats">${n(s?.n || 0, tr('me_catches'), 'catches')}${n(s?.species || 0, tr('me_species'), 'species')}${n(s?.best?.length || 0, tr('mp_pbs'), 'stats')}</div>`;
  }
  const empty = () => `<div class="ui-empty me-empty">${ic('fish')}<b>${esc(tr('mp_noCatch'))}</b><p>${esc(tr('mp_emptySub'))}</p><button class="btn primary" data-me-log>${ic('plus')}${esc(tr('me_logFirst'))}</button></div>`;
  function catchesTab(C, pb) {
    if (!C.length) return empty();
    return `<div class="ui-grid3 photos me-grid">${C.map(e => { const u = thumbUrl(e), f = byId(e.sp);
      return `<button class="me-tile${u ? '' : ' cut'}" data-me-catch="${esc(e.id)}" aria-label="${esc(f ? fishName(f) : e.sp)}">${u ? `<img src="${esc(u)}" alt="" loading="lazy">` : cut(e.sp)}` +
        `${pb.has(e.id) ? `<span class="me-pb" title="${esc(tr('me_bests'))}">${ic('trophy')}</span>` : ''}<span class="me-tl">${esc(f ? fishName(f) : '')}${e.n > 1 ? ` ×${e.n}` : ''}</span></button>`; }).join('')}</div>`;
  }
  function speciesTab(C, s) {
    if (!C.length) return `<div class="ui-empty me-empty">${ic('fish-list')}<p>${esc(tr('mp_noSpecies'))}</p></div>`;
    const by = new Map(); for (const e of C) by.set(e.sp, (by.get(e.sp) || 0) + (e.n || 1));
    const best = new Map((s?.best || []).map(b => [b.sp, b]));
    return `<div class="ui-list">${[...by].sort((a, b) => b[1] - a[1]).map(([sp, n]) => { const f = byId(sp), b = best.get(sp);
      return `<button class="ui-row" data-sp-page="${esc(sp)}"><span class="ui-thumb fish">${cut(sp)}</span><span class="ui-row-main"><b>${esc(f ? fishName(f) : sp)}</b>` +
        `<small>${esc(tr('mp_n', n))}${b && size(b) ? ` · ${esc(tr('mp_best'))} ${esc(size(b))}` : ''}</small></span>${go}</button>`; }).join('')}</div>`;
  }
  function statsTab(s) {
    if (!s?.n) return empty();
    const m = Array.isArray(s.byMonth) && s.byMonth.length === 12 ? s.byMonth : null, top = m && Math.max(...m);
    const mon = k => fmtT(Date.UTC(2024, k, 15), { month: 'narrow', timeZone: 'UTC' });
    return `<div class="ui-card ui-grid3 me-stats sm"><div class="ui-stat"><b>${s.trips}</b><span>${esc(tr('me_trips'))}</span></div><div class="ui-stat"><b>${s.n}</b><span>${esc(tr('me_catches'))}</span></div>` +
      `<div class="ui-stat"><b>${s.trips ? Math.round(s.n / s.trips * 100) : 0}%</b><span>${esc(tr('mp_rate'))}</span></div></div>` +
      (top ? `<div class="ui-sec"><h3>${esc(tr('me_byMonth'))}</h3></div><div class="ui-card me-months" aria-hidden="true">${m.map((v, k) => `<span><i style="--h:${(v / top).toFixed(3)}"></i><small>${esc(mon(k))}</small></span>`).join('')}</div>` : '') +
      (s.best?.length ? `<div class="ui-sec"><h3>${esc(tr('me_bests'))}</h3></div><div class="ui-list">${s.best.map(b => { const f = byId(b.sp);
        return `<button class="ui-row" data-me-catch="${esc(b.id)}"><span class="ui-thumb fish">${cut(b.sp)}</span><span class="ui-row-main"><b>${esc(f ? fishName(f) : b.sp)}</b></span><span class="ui-row-end">${esc(size(b))}</span>${go}</button>`; }).join('')}</div>` : '') +
      `<div class="ui-list me-gap">${row('data-ct-open="stats"', 'book', tr('mp_logbook'))}</div>`;
  }
  function placesHtml() { // js/pins.js, when there: the saved places, in a fold
    const list = window.PsPins?.places?.(); if (!Array.isArray(list)) return '';
    return `<details class="me-fold"><summary class="ui-row me-row">${ic('pin')}<span class="ui-row-main"><b>${esc(tr('me_places'))}</b></span><span class="ui-row-end">${list.length}</span>${go}</summary>` +
      (list.length ? list.map(p => `<button class="ui-row me-sub" data-me-place="${esc(p.id)}"><span class="ui-row-main"><b>${esc(p.name)}</b></span><span class="ui-row-end">${esc(fmtT(p.t, { day: 'numeric', month: 'short' }))}</span></button>`).join('')
        : `<p class="hint me-sub">${esc(tr('me_noPlaces'))}</p>`) + '</details>';
  }
  function draw() {
    const p = window.PsAccount?.get?.(), s = stats(), C = caught(), pb = new Set((s?.best || []).map(b => b.id));
    const b = brief(), upd = $('#mb-update'), seg = (key, list) => `<div class="seg me-seg" style="--n:${list.length}">${list.map(([v, label, icon]) =>
      `<button data-me-${key}="${v}" aria-pressed="${state[key] === v}">${icon ? ic(icon) : ''}<span>${esc(label)}</span></button>`).join('')}</div>`;
    const tabs = [['catches', 'mp_tCatches'], ['species', 'mp_tSpecies'], ['stats', 'mp_tStats']];
    const acts = el.closest('.pg')?.querySelector('.pg-acts');
    if (acts) acts.innerHTML = p ? `<button class="icon-btn" data-me-acc="edit" aria-label="${esc(tr('mp_edit'))}" title="${esc(tr('mp_edit'))}">${ic('edit')}</button>` : '';
    el.innerHTML = head(p) + numbers(s) +
      `<div class="ui-seg block me-tabs" role="tablist">${tabs.map(([t, k]) => `<button role="tab" data-me-tab="${t}" aria-selected="${tab === t}" aria-pressed="${tab === t}">${esc(tr(k))}</button>`).join('')}</div>` +
      `<div class="me-pane" role="tabpanel">${tab === 'species' ? speciesTab(C, s) : tab === 'stats' ? statsTab(s) : catchesTab(C, pb)}</div>` +
      `<div class="ui-sec"><h3>${esc(tr('mb_tools'))}</h3></div><div class="ui-list">` +
        row('data-ct-open', 'fish', tr('ct_my')) + placesHtml() + row('data-cal-open', 'calendar', tr('cal_title')) + row('data-ui="plan"', 'route', tr('pl_title')) +
        row('data-ps-offline', 'map', tr('offAreas')) + row('data-ui="help"', 'knot', tr('me_help')) + '</div>' +
      `<div class="ui-sec"><h3>${esc(tr('me_settings'))}</h3></div><div class="ui-list me-set">` +
        `<div class="me-setrow"><p class="me-k">${ic('globe')}${esc(tr('language'))}</p>${seg('lang', [['en', 'English'], ['el', 'Ελληνικά']])}</div>` +
        `<div class="me-setrow"><p class="me-k">${ic('rod')}${esc(tr('me_method'))}</p>${seg('mode', ['boat', 'shore', 'spear'].map(m => [m, tr(m), m]))}</div>` +
        (window.PsNative?.canNotify ? `<label class="ui-row me-row me-sw">${ic('clock')}<span class="ui-row-main"><b>${esc(tr('nfBrief'))}</b><small>${esc(tr('me_briefSub', b.time))}</small></span><input type="checkbox" class="ui-switch" role="switch" data-me-brief${b.brief ? ' checked' : ''}></label>` : '') +
      '</div>' +
      `<div class="ui-sec"><h3>${esc(tr('mp_account'))}</h3></div><div class="ui-list">` + (p
        ? row('data-me-acc="edit"', 'edit', tr('mp_edit'), `<span class="ui-row-end">@${esc(p.username)}</span>`) +
          `<button class="ui-row me-row me-danger" data-me-acc="delete">${ic('trash')}<span class="ui-row-main"><b>${esc(tr('ac_del'))}</b><small>${esc(tr('mp_delSub'))}</small></span>${go}</button>`
        : row('data-me-acc="create"', 'user', tr('mp_create'))) + '</div>' +
      `<div class="ui-sec"><h3>${esc(tr('me_about'))}</h3></div><div class="ui-list">` +
        `<div class="ui-row me-row me-static">${ic('info')}<span class="ui-row-main"><b>${esc(tr('me_version'))}</b></span><span class="ui-row-end">${esc(window.PSAREMA_VERSION || '–')}</span></div>` +
        row('data-me-credits', 'globe', tr('credits')) +
        `<a class="ui-row me-row" href="privacy.html" target="_blank" rel="noopener">${ic('shield')}<span class="ui-row-main"><b>${esc(tr('me_privacy'))}</b></span>${ic('external', 'ui-chev')}</a>` +
        (upd && !upd.hidden ? row('data-me-update', 'refresh', tr('checkUpdates')) : '') + '</div>' +
      `<p class="hint me-foot">${esc(tr('mp_local'))}</p>`;
  }
  function credits() { // the map's and data's sources and licences: the same words as the map's (i) and the ⋯ menu
    const k = 'credits';
    PsPanel.show(k, PsPanel.head(k, 'globe', tr('credits')) + `<div class="me-credits">${map.attributionControl.getContainer().innerHTML}<p>${esc(tr('photos'))}</p></div>`, true);
  }
  function click(e) {
    const t = e.target.closest('[data-me-log], [data-me-catch], [data-me-place], [data-me-lang], [data-me-mode], [data-me-credits], [data-me-update], [data-me-tab], [data-me-acc]'); if (!t) return;
    const d = t.dataset;
    if ('meLog' in d) window.PsCatch?.log?.(-1);
    else if (d.meTab) { if (tab !== d.meTab) { tab = d.meTab; draw(); } if (t.classList.contains('me-stat')) el.querySelector('.me-tabs')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
    else if (d.meAcc) { const A = window.PsAccount; if (!A) return; d.meAcc === 'create' ? A.open() : A.edit(d.meAcc === 'delete'); }
    else if (d.meCatch) PsNav.pages.catch ? PsNav.open('catch', d.meCatch) : window.PsCatch?.open?.(d.meCatch);
    else if (d.mePlace) { PsNav.open('map'); window.PsPins?.focus?.({ kind: 'place', id: d.mePlace }); }
    else if (d.meLang) { if (d.meLang !== state.lang) $(`#lang [data-lang="${d.meLang}"]`).click(); } // js/ui.js applyLang; the page draws again (js/nav.js)
    else if (d.meMode) { $(`#mode [data-mode="${d.meMode}"]`).click(); draw(); }
    else if ('meCredits' in d) credits();
    else if ('meUpdate' in d) $('#mb-update')?.click(); // js/updater.js (the Android app)
  }
  async function change(e) {
    const t = e.target; if (!t.matches('[data-me-brief]')) return;
    t.disabled = true; t.checked = !!(await PsNative.setBrief(t.checked).catch(() => false)); t.disabled = false; // it asks for the permission, and toasts the result
  }
  PsNav.add('me', { title: () => tr('nav_me'), icon: 'user', tab: true,
    show(body) {
      if (!el) { el = body; el.classList.add('me'); el.addEventListener('click', click); el.addEventListener('change', change); el.closest('.pg')?.querySelector('.pg-acts')?.addEventListener('click', click); }
      draw();
    } });
  document.addEventListener('ps:catches', () => { if (shows()) draw(); }); // js/catchlog.js: a catch logged, edited or removed
  document.addEventListener('ps:account', () => { if (shows()) draw(); }); // js/account.js: the profile made, edited or removed
})();
