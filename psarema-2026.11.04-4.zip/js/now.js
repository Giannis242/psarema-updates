'use strict';
// The "right now" hero, the phone sheet's peek carousel and the spot lists' mini-maps (css/now.css; the peek: css/mobile.css .m-peek).
// Peek (phones, #m-peek over the sheet's head): a row of cards that scrolls sideways: the day's brief (js/planner.js briefData, instead of
// its panel opening over the map at start; a tap opens that panel, × hides it for the day), then the best spots at the hour (map.js tops):
// dial, the fish's cut-out, the place, how far and how deep. A tap flies there and opens the spot's card; "See all" opens the Spots list.
// Hero, at the top of the When tab (phone sheet, desktop rail): the best spot for the fish and method at the hour on the map (map.js
// drawTop's tops[0]): a crop of the heat around it with its dial, the place, the going-out verdict and the best time to go there
// (js/conditions.js card(), as the spot's own card shows them). A tap flies there and opens its card. When nothing scores (a banned or
// closed fish, an hour it does not bite) or there is no forecast, it says so and offers the way on (another fish, the best hour).
// Mini-maps: each Spots / Near me row has a canvas (ui.js spotRow) that gets a crop of `scores` around its spot (~10 km, the spot in
// the middle cell): a night chart (land grey with a lighter coast, the sea darker with depth) under the map's own heat colours (map.js
// LUT: its colours and its "hide below"). Beside it, the spot's chance over the shown hour's day as a small line (the hour a dot).
// Speed: ui.js only asks (update, lists); the drawing waits for the next frame and is done only where it can be seen (a hidden tab,
// the folded rail, the phone sheet at its peek or showing a spot: once it shows). So an hour step stays a patch: the hero's parts whose
// HTML changed, its dial's --p and colour, its picture only when the spot or hour changed; a list's pictures once per list draw.
const PsNow = window.PsNow = (() => {
  /* ---------- Mini-maps ---------- */
  const LAND = [56, 53, 49], RIM = [104, 99, 92], OUT = [8, 15, 22]; // land a warm grey (the satellite map's), apart from the grey cards around it
  let seaRgb = null; // the sea's colour per depth, lighter where shallow (log scale: most of the change is in the first 100 m)
  // cv: K pixels a cell (ui.js: 123 = 41 cells). The chart and the heat are drawn a pixel a cell, then scaled up smooth onto it (a small
  // canvas scaled by CSS can come out blocky); the heat through a slight blur, so its patches glow like the map's, not as squares.
  const K = 3, cells = document.createElement('canvas'), cg = cells.getContext('2d');
  function mini(cv, i) {
    if (!seaRgb) {
      seaRgb = new Uint8Array((DMAX + 1) * 3);
      for (let d = 0; d <= DMAX; d++) { const t = clamp(Math.log1p(d) / Math.log1p(1500)); seaRgb[d * 3] = lerp(30, 7, t); seaRgb[d * 3 + 1] = lerp(72, 15, t); seaRgb[d * 3 + 2] = lerp(92, 24, t); }
    }
    const w = cv.width / K | 0, h = cv.height / K | 0, chart = cg.createImageData(w, h), heat = cg.createImageData(w, h), px = chart.data, hp = heat.data, x0 = i % W - (w >> 1), y0 = (i / W | 0) - (h >> 1);
    for (let y = 0, o = 0; y < h; y++) for (let x = 0; x < w; x++, o += 4) {
      const cx = x0 + x, cy = y0 + y; px[o + 3] = 255;
      if (cx < 1 || cy < 1 || cx >= W - 1 || cy >= H - 1) { px.set(OUT, o); continue; }
      const j = cy * W + cx, d = depth[j];
      if (!d) { px.set(depth[j - 1] || depth[j + 1] || depth[j - W] || depth[j + W] ? RIM : LAND, o); continue; }
      px[o] = seaRgb[d * 3]; px[o + 1] = seaRgb[d * 3 + 1]; px[o + 2] = seaRgb[d * 3 + 2];
      // the best score within a cell (as the map's own spread when zoomed out): a band one cell wide, as many inshore fish have, still shows
      const s = 4 * Math.max(scores[j - W - 1], scores[j - W], scores[j - W + 1], scores[j - 1], scores[j], scores[j + 1], scores[j + W - 1], scores[j + W], scores[j + W + 1]);
      if (LUT[s + 3]) { hp[o] = LUT[s]; hp[o + 1] = LUT[s + 1]; hp[o + 2] = LUT[s + 2]; hp[o + 3] = Math.min(255, LUT[s + 3] * 1.3); } // the map's colours and "hide below"; a little more opaque
    }
    if (cells.width !== w || cells.height !== h) Object.assign(cells, { width: w, height: h }); // exactly the cells: the smoothing at the edges reads nothing else
    const g = cv.getContext('2d'), up = () => g.drawImage(cells, 0, 0, w, h, 0, 0, cv.width, cv.height);
    g.imageSmoothingQuality = 'high'; g.filter = 'none';
    cg.putImageData(chart, 0, 0); up();
    cg.putImageData(heat, 0, 0); g.filter = `blur(${K * .7}px)`; up(); g.filter = 'none';
  }
  // The fish's chance at a cell every hour, in one scoreCells pass (as ui.js bestHourAt), kept per spot until the fish, method or forecast change
  const curves = { key: '', m: new Map() };
  function curve(i) {
    const key = `${curGen}|${state.first}|${F.T}`; if (curves.key !== key) { curves.key = key; curves.m.clear(); }
    let a = curves.m.get(i);
    if (!a) { a = new Float64Array(F.T); ONE[0] = i; scoreCells(cur, 0, F.T, ONE, 0, 1, 1, a); curves.m.set(i, a); }
    return a;
  }
  function spark(i) { // the shown hour's local day: a line on the day's own scale (at least 20 points, as the timeline), the hour a dot
    let d0 = state.h, d1 = state.h + 1; while (d0 > 0 && hours[d0].local !== 0) d0--; while (d1 < F.T && hours[d1].local !== 0) d1++;
    const a = curve(i), n = d1 - d0, sw = 44, sh = 14; let hi = 0, lo = 100;
    for (let h = d0; h < d1; h++) { if (a[h] > hi) hi = a[h]; if (a[h] < lo) lo = a[h]; }
    if (n < 2 || !hi) return '';
    const span = Math.max(20, hi - lo), X = h => ((h - d0) / (n - 1) * (sw - 4) + 2).toFixed(1), Y = h => (sh - 2 - (a[h] - (hi - span)) / span * (sh - 4)).toFixed(1);
    let p = ''; for (let h = d0; h < d1; h++) p += (h === d0 ? 'M' : 'L') + X(h) + ' ' + Y(h);
    return `<svg width="${sw}" height="${sh}" viewBox="0 0 ${sw} ${sh}" aria-hidden="true"><path d="${p}"/><circle cx="${X(state.h)}" cy="${Y(state.h)}" r="2.2" style="fill:${solid(a[state.h])}"/></svg>`;
  }

  /* ---------- Hero ---------- */
  const hero = Object.assign(document.createElement('section'), { className: 'now', id: 'now-hero', hidden: true });
  // [the picture, its dial on the corner | when, place, fish · depth · seabed, the verdict] over the best time to go: short enough to show
  // whole with the phone sheet half up
  hero.innerHTML = '<div class="now-card"><span class="mm now-mm"><canvas width="135" height="135" aria-hidden="true"></canvas><i class="mm-dot"></i><span class="ring lg"><b></b></span></span>' +
    '<div class="now-txt"><p class="lbl now-lbl"></p><b class="now-place"></b><small class="now-meta"></small><div class="now-cond"></div></div>' +
    '<button class="now-go" type="button"></button><div class="now-win"></div></div><div class="now-empty"></div>';
  $('#tab-when').prepend(hero);
  const q = s => hero.querySelector(s), [lbl, card, cv, ringEl, place, meta, cond, go, win, empty] =
    ['.now-lbl', '.now-card', 'canvas', '.ring', '.now-place', '.now-meta', '.now-cond', '.now-go', '.now-win', '.now-empty'].map(q);
  const put = (el, html) => { if (el.psHtml !== html) el.innerHTML = el.psHtml = html; }; // the same words are not written again
  let list = [], wxHooked = false;
  function emptyHtml(when) { // why nothing shows, and the way on: the best hour when there is one, else another fish (when '': no label, the peek's card)
    const closed = F && sp.closed?.includes(hours[state.h].month + 1), k = !F ? 'now_noFc' : sp.banned ? 'now_banned' : closed ? 'now_closed' : 'now_none';
    const later = F && !sp.banned && !closed && bestHour !== state.h && best[bestHour] >= 40;
    return `${when ? `<p class="lbl">${esc(when)}</p>` : ''}${ic(k === 'now_none' ? 'clock' : k === 'now_noFc' ? 'warning' : 'ban', 'lg')}<span>${esc(tr(k))}</span>` + (!F ? '' : later
      ? `<button class="btn primary" data-ui="best">${esc(tr('best', whenT(hours[bestHour].t)))}</button>` : `<button class="btn" data-ui="gallery">${ic('fish-list', 'sm')}${esc(tr('now_pick'))}</button>`);
  }
  function drawHero() {
    const t = list[0], h = state.h, when = !F ? tr('now_title') : h === state.first ? `${tr('now_title')} · ${hm(hours[h].t)}` : tr('now_at', whenT(hours[h].t));
    hero.hidden = false; card.hidden = !t; empty.hidden = !!t;
    if (!t) { put(empty, emptyHtml(when)); return; }
    lbl.textContent = when;
    const i = t.i, s = t.s, p = describe(...t.p), run = state.mode === 'boat' && LAUNCH[launchOf[i]] && launchKm[i] >= .5 ? ` · ${tr('run', launchKm[i].toFixed(0))}` : ''; // at a harbour: no "0 km"
    const c = solid(s); ringEl.style.setProperty('--p', s); ringEl.style.setProperty('--c', c); card.style.setProperty('--now-c', c); ringEl.title = rating(s); ringEl.firstChild.textContent = s; // a patch: a transition on --p can run
    put(place, esc(p));
    put(meta, `${esc(sp.all ? likelyAt(i, state.mode, 2).map(fishName).join(', ') || fishName(sp) : fishName(sp))} · ${depth[i]} m${esc(habPart(i))}${run}`);
    // ponytail: conditions.js caches one cell's week; with the desktop card open on another cell, each settle works both out again (~0.3 ms each)
    const cd = condHtml('card', i), bh = cd.go == null ? bestHourAt(i) : null; // as ui.js cardParts: without conditions.js, the fish's own best hour
    put(cond, cd.why || '');
    put(win, cd.go ?? (bh.s ? goRow(bh.h, bh.h === h ? tr('now') : whenT(hours[bh.h].t), tr('bestUpTo', bh.s)) : ''));
    const name = tr('now_open', p); if (go.getAttribute('aria-label') !== name) go.setAttribute('aria-label', name);
    const key = `${i}|${h}|${curGen}|${state.min}`; if (cv.psKey !== key) { cv.psKey = key; mini(cv, i); } // the picture: only a new spot, hour, fish or "hide below"
    if (!wxHooked && window.PsWeather?.ready) { wxHooked = true; PsWeather.ready.then(() => { dirty.hero = true; later(); }); } // the verdict counts rain, fog and heat once they are in
  }
  const goTo = t => { if (!t) return; map.setView(t.p, Math.max(map.getZoom(), 12)); openCell(t.i); }; // as a Spots row
  go.addEventListener('click', () => goTo(list[0]));

  /* ---------- Peek: the brief, then the best spots ---------- */
  const peekEl = $('#m-peek'), pkRow = $('#pk-row'), pkWhen = $('#pk-when'), BKEY = 'psarema-brief-v1'; // js/planner.js's own key: { off, day }
  const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(Date.now()); // as planner.js dayKey
  const bpref = () => { try { return JSON.parse(localStorage.getItem(BKEY)) || {}; } catch { return {}; } };
  let brief = null; // the day's brief (briefData), while it is not hidden for the day
  function hookBrief() { // phones: app.js's once-a-day call fills the card instead of opening the panel; a notification or shortcut (force) still opens it
    const P = window.PsPlanner; if (!P || P.psPeek) return;
    const open = P.brief; P.psPeek = true;
    P.brief = force => force || !peekEl.offsetParent ? open(force) : loadBrief(); // no peek (a wide screen, a phone on its side): the panel as before
  }
  function loadBrief() {
    const p = bpref(); if (p.off || p.day === today()) { brief = null; dirty.peek = true; later(); return; }
    PsPlanner.briefData().then(b => { brief = b; dirty.peek = true; later(); }, e => console.warn('brief:', e));
  }
  function dropBrief() { try { localStorage.setItem(BKEY, JSON.stringify({ ...bpref(), day: today() })); } catch {} brief = null; dirty.peek = true; later(); }
  const briefCard = () => { const b = brief, it = b?.items?.[0]; if (!b) return '';
    return `<div class="pk-wrap"><button class="pk-card pk-brief" style="--pk-c:${it ? solid(it.score) : 'var(--line-2)'}"><span class="lbl">${ic('sunrise')}${esc(tr('pl_brief'))}</span>` +
      `${ring(it?.score)}<b>${esc(it ? it.title : b.title)}</b><small>${esc(it ? it.body : b.body)}</small></button>` +
      `<button class="pk-x" aria-label="${esc(tr('close'))}" title="${esc(tr('close'))}">${ic('close')}</button></div>`; };
  function pkCard(t, n) {
    const i = t.i, r = state.loc && km(state.loc, t.p), f = sp.all ? likelyAt(i, state.mode, 1)[0] : sp, cut = f && CUT[f.id];
    const meta = (r ? fmtKm(r.d) + ' km · ' : '') + depth[i] + ' m' + habPart(i);
    return `<button class="pk-card" data-pk="${n}" style="--pk-c:${solid(t.s)}">${ring(t.s)}<span class="pk-art">${cut ? `<img src="${esc(cut.file)}" alt="${esc(fishName(f))}">` : ''}</span>` +
      `<b>${esc(describe(...t.p))}</b><small>${esc(meta)}</small></button>`;
  }
  function drawPeek() {
    const when = F ? tr('topAt', whenT(hours[state.h].t)) : '';
    if (pkWhen.textContent !== when) pkWhen.textContent = when;
    if (!F && !$('#status').classList.contains('error')) return; // the skeleton cards until the forecast is in
    put(pkRow, briefCard() + (list.slice(0, 8).map(pkCard).join('') || `<div class="pk-empty">${emptyHtml('')}</div>`));
  }
  pkRow.addEventListener('click', e => {
    if (e.target.closest('.pk-x')) { dropBrief(); return; }
    if (e.target.closest('.pk-brief')) { dropBrief(); PsPlanner.brief(true); return; } // the full brief (seen: the card goes for the day)
    const b = e.target.closest('[data-pk]'); if (b) goTo(list[+b.dataset.pk]);
  });
  $('#pk-all').addEventListener('click', () => { showTab('spots'); savePrefs(); PsMobile.sheet(2); $('#m-body').scrollTop = 0; }); // the whole list
  new MutationObserver(() => { if (brief) loadBrief(); dirty.peek = true; later(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] }); // ui.js applyLang
  document.addEventListener('DOMContentLoaded', hookBrief, { once: true }); // data/boot.js: every app script is in (planner.js loads after this file)

  /* ---------- Drawing: next frame, only what can be seen ---------- */
  const seen = el => el.checkVisibility?.({ checkVisibilityCSS: true, visibilityProperty: true }) ?? true;
  const dirty = { hero: false, peek: false, lists: new Set() };
  let raf = 0;
  const later = () => { raf ||= requestAnimationFrame(paint); };
  function paint() {
    raf = 0;
    if (dirty.hero && seen(hero.parentNode)) { dirty.hero = false; try { drawHero(); } catch (e) { console.warn(e); } } // its tab: the hero is hidden until its first draw
    if (dirty.peek && peekEl.offsetParent) { dirty.peek = false; try { drawPeek(); } catch (e) { console.warn(e); } }
    if (F) for (const ol of dirty.lists) if (seen(ol)) {
      dirty.lists.delete(ol);
      for (const c of ol.querySelectorAll('canvas[data-mm]')) { const i = +c.dataset.mm; mini(c, i); const sl = c.closest('.row')?.querySelector('.spark'); if (sl) sl.innerHTML = spark(i); }
    }
  }
  // shown again (a tab, the rail, the phone sheet up or back from a spot): draw what changed meanwhile
  const showing = new MutationObserver(() => { if (dirty.hero || dirty.lists.size) later(); });
  for (const [s, a] of [['#tab-when', 'hidden'], ['#tab-spots', 'hidden'], ['#tab-near', 'hidden'], ['#rail', 'class'], ['#m-main', 'hidden'], ['#m-sheet', 'class']]) { const el = $(s); if (el) showing.observe(el, { attributes: true, attributeFilter: [a] }); }
  // no forecast (it failed to load): the hero says so instead of staying away
  new MutationObserver(() => { if (!F && $('#status').classList.contains('error')) { list = []; dirty.hero = dirty.peek = true; later(); } }).observe($('#status'), { attributes: true, attributeFilter: ['class'] });

  console.assert(LUT.length === 404 && (123 / K | 0) === 41, 'now: map.js LUT is 101 rgba; a row canvas (ui.js) is 41 cells, the spot the middle one');
  const near = $('#near-list');
  return {
    update(l) { list = l; dirty.hero = dirty.peek = true; hookBrief(); if (!near.hidden) dirty.lists.add(near); later(); }, // map.js drawTop's spots (via ui.js drawSpotList), at every settle; Near me's pictures follow the hour too
    lists(ol) { dirty.lists.add(ol); later(); }, // a list (#top, #near-list) was drawn: its pictures and lines
  };
})();
